import React from "react";
import { GetStaticProps } from "next";
import { useRouter } from 'next/router';
import { Gigya, GigyaObject } from "@services/Gigya";
import { Header, Footer, InnerBanner } from "@templates";
import { fetchHeaderData } from "../api/header";
import { fetchOffersData } from "../api/offers";
import {SeoMeta, SkipTarget} from "@templates";

interface Props {
  headerData: any;
  popupData:Record<any, any>;
  host?: Record<any, any>;
}

const ResetPassword: React.FC<Props> = (props: Props) => {
  const headerData = props?.headerData;
  const router = useRouter();
  const [userLogin, setuserLogin] = React.useState(null);
  const loginCallBack = (response) => {
    if (response?.profile && response?.response?.status === "OK") {
      setuserLogin(response?.profile);
    }
  };
  const updateCallBack = (response) => {
    console.log(response, "==== register");
  };
  const handleOnLogout = (response) => {
    setuserLogin(null);
  };
  const onLogout = () => {
    if (GigyaObject != undefined) {
      GigyaObject.accounts.logout({
        callback: handleOnLogout,
      });
    }
  };
  React.useEffect(() => {
    const getAccountInfoResponse = (response) => {
      if (response.status === "OK") {
        setuserLogin(response?.profile);
        router.push('/');
      }
    };
    //@ts-ignore

    if (GigyaObject != undefined) {
      GigyaObject.accounts.getAccountInfo({ callback: getAccountInfoResponse });
    }
  }, []);
  return (
    <>
      <Header headerData={headerData} offerData={props?.popupData} host={props?.host}/>
      <SeoMeta 
      title={props?.popupData?.acf_tru_seometa?.[0]?.blockdata?.[0]?.browserList?.[process?.env?.NEXT_PUBLIC_GIGYA_BRAND]?.title}
      description={props?.popupData?.acf_tru_seometa?.[0]?.blockdata?.[0]?.browserList?.[process?.env?.NEXT_PUBLIC_GIGYA_BRAND]?.browserMetaDescription}
      keywords={props?.popupData?.acf_tru_seometa?.[0]?.blockdata?.[0]?.browserList?.[process?.env?.NEXT_PUBLIC_GIGYA_BRAND]?.browserMetaKeywords}
      />
      <InnerBanner title="Reset Password" id="start-of-content" />
      {/* <SkipTarget /> */}
      <div className="customform py-18 reset-password-gigya">
        <Gigya
          overrideStyle={{
            margin: "20px",
          }}
          screenId={`${process.env.NEXT_PUBLIC_GIGYA_BANNER}-RegistrationLogin`}
          startScreen="gigya-reset-password-screen"
          loginCallback={updateCallBack}
          id="login-dev-new"
          key="test"
        />
      </div>
      <Footer footerData={headerData} />
    </>
  );
};
export default ResetPassword;

export const getStaticProps: GetStaticProps = async ({locale}) => {

  const [headerData, popupData] = await Promise.all([fetchHeaderData(locale), fetchOffersData(locale)]);
  if (!headerData || !popupData) {
    return {
      notFound: true,
    };
  }
  return {
    props: {
      headerData,
      popupData
    },
    revalidate: 7776000,
  };
};
