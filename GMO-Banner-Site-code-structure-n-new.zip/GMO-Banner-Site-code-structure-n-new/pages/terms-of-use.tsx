import React from "react";
import { GetStaticProps } from "next";
import { useRouter } from "next/router";
import Head from "next/head";
import { Text, Row, Col } from "@components";
import { Header, Footer, InnerBanner, SectionBoxed, SkipTarget, SeoMeta } from "@templates";
import { fetchTermofUseData } from "../api/termofUse";
import { fetchHeaderData } from "../api/header";
import { fetchOffersData } from "../api/offers";
import parse from "html-react-parser";

interface Props {
  headerData: Record<any, any>;
  pageData: Record<any, any>;
  popupData: Record<any, any>;
  host?:Record<any, any>;
}

const PrivacyPolicy: React.FC<Props> = (props: Props) => {
  const router = useRouter();
  const headerData = props?.headerData;
  const pageData = props?.pageData;
  const canonicalUrl = (`${process.env.NEXT_PUBLIC_APP_URL?.replace(/\/$/, "")}` + (router.asPath === "/" ? "": router.asPath)).split("?")[0];
  return (
    <>
     <Head>
        <link rel="canonical" href={canonicalUrl} />
      </Head>
      <Header headerData={headerData} offerData={props?.popupData} host={props?.host}/>
      <SeoMeta 
      title={pageData?.acf_tru_seometa?.[0]?.blockdata?.[0]?.browserList?.[process?.env?.NEXT_PUBLIC_GIGYA_BRAND]?.title}
      description={pageData?.acf_tru_seometa?.[0]?.blockdata?.[0]?.browserList?.[process?.env?.NEXT_PUBLIC_GIGYA_BRAND]?.browserMetaDescription}
      keywords={pageData?.acf_tru_seometa?.[0]?.blockdata?.[0]?.browserList?.[process?.env?.NEXT_PUBLIC_GIGYA_BRAND]?.browserMetaKeywords}
      />
      {/* <SkipTarget /> */}
      {pageData?.acf_tru_inner_header?.[0] &&
        <InnerBanner
          title={pageData?.acf_tru_inner_header[0]?.blockdata[0]?.titles[0]}
          id="start-of-content"
        />
      }
      
      <SectionBoxed className="py-18">
        <Row>
          <Col xs={12}>
            {pageData?.acf_tru_content_editor?.[0] && pageData?.acf_tru_content_editor?.[0]?.blockdata?.map((data) => {
              const tabindexTitle = (data.tabindex_title && data.tabindex_title ==1) ? {tabIndex: 0} : ({});
              const tabindexSubTitle = (data.tabindex_subtitle && data.tabindex_subtitle ==1) ? {tabIndex: 0} : ({});
              return (
                <>
                  <Text as="div" className="SimpleContent">
                    {data?.title && <h2 {...tabindexTitle} className="heading">
                      {parse(data.title)}
                    </h2>}
                    {data?.sub_title && <h3 {...tabindexSubTitle} className="heading">{parse(data?.sub_title)}</h3>}
                    {data?.description && <Text as="div" className="Description">{parse(data.description)}</Text>}
                  </Text>
                </>
              );
            })}
          </Col>
        </Row>
      </SectionBoxed>
      <Footer footerData={headerData} />
    </>
  );
};
export default React.memo(PrivacyPolicy);

export const getStaticProps: GetStaticProps = async ({locale}) => {
  const [headerData, pageData, popupData] = await Promise.all([
    fetchHeaderData(locale),
    fetchTermofUseData(locale),
    fetchOffersData(locale)
  ]);
  if (!headerData || !pageData || !popupData) {
    return {
      notFound: true,
    };
  }
  return {
    props: {
      headerData,
      pageData,
      popupData
    },
    revalidate: 7776000,
  };
};
