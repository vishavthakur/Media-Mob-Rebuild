import React from "react";
import { GetStaticProps } from "next";
import { useRouter } from "next/router";
import Head from "next/head";
import { Text, Row, Col } from "@components";
import { Header, Footer, InnerBanner, SectionBoxed, SkipTarget, SeoMeta } from "@templates";
import { fetchPrivacyPolicyData } from "../api/privacyPolicy";
import { fetchHeaderData } from "../api/header";
import { fetchOffersData } from "../api/offers";
import parse from "html-react-parser";

interface Props {
  headerData: Record<any, any>;
  pageData: Record<any, any>;
  popupData: Record<any, any>;
  host?: Record<any, any>;
}

const PrivacyPolicy: React.FC<Props> = (props: Props) => {
  const router = useRouter();
  const canonicalUrl = (`${process.env.NEXT_PUBLIC_APP_URL?.replace(/\/$/, "")}` + (router.asPath === "/" ? "": router.asPath)).split("?")[0];
  const customScrollTop = () =>{
    document?.querySelectorAll('#privacy_content_inner a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const attrHref = '#!';
                 if(this.getAttribute('href') === attrHref) {
                     e.preventDefault();
                 }else{
                     document.querySelector(this.getAttribute('href')).scrollIntoView({
                         behavior: 'smooth'
                     });
                     document.querySelector(this.getAttribute('href')).setAttribute("tabindex","-1");
                     document.querySelector(this.getAttribute('href')).focus();
                 } 
        });
    });
  }

  React.useEffect(() => {
      customScrollTop();
  },[]);

  const headerData = props?.headerData;
  const pageData = props?.pageData;
  return (
    <>
     <Head>
        <link rel="canonical" href={canonicalUrl} />
      </Head>
      <Header headerData={headerData} offerData={props?.popupData} host={props?.host}/>
      <SeoMeta 
      title={pageData?.acf_tru_seometa?.[0]?.blockdata?.[0]?.browserList?.[process?.env?.NEXT_PUBLIC_GIGYA_BRAND]?.title}
      description={pageData?.acf_tru_seometa?.[0]?.blockdata?.[0]?.browserList?.[process?.env?.NEXT_PUBLIC_GIGYA_BRAND]?.browserMetaDescription}
      keywords={pageData?.acf_tru_seometa?.[0]?.blockdata?.[0]?.browserList?.[process?.env?.NEXT_PUBLIC_GIGYA_BRAND]?.browserMetaKeywords}
      />
      {pageData?.acf_tru_inner_header  &&
        <InnerBanner
          title={pageData?.acf_tru_inner_header?.[0]?.blockdata[0]?.titles[0]}
          id="start-of-content"
        />
      }
      {/* <SkipTarget /> */}
      <div className="outer_section_privacy"  id="privacy_content_inner">
      <SectionBoxed className="py-18">
        <Row>
          {pageData?.acf_tru_content_editor?.[0] &&
            <Col xs={12}>
              {pageData?.acf_tru_content_editor?.[0]?.blockdata?.map((data) => {
                const tabindexTitle = (data.tabindex_title && data.tabindex_title ==1) ? {tabIndex: 0} : ({});
                const tabindexSubTitle = (data.tabindex_subtitle && data.tabindex_subtitle ==1) ? {tabIndex: 0} : ({});
                return (
                  <>
                    <Text as="div" className="SimpleContent">
                      {data.title && <h2 {...tabindexTitle} className="heading" id={data.title?.replaceAll(" ","_")}>
                        {parse(data.title)}
                      </h2>}
                      {data?.sub_title && <h3 {...tabindexSubTitle} className="heading" id={data.sub_title?.replaceAll(" ","_")}>{parse(data?.sub_title)}</h3>}
                      {data.description && <Text as="div" className="Description">
                        {parse(data.description)}
                      </Text>}
                    </Text>
                  </>
                );
              })}
            </Col>
          }
        </Row>
      </SectionBoxed>
      </div>
      <Footer footerData={headerData} />
    </>
  );
};
export default React.memo(PrivacyPolicy);

export const getStaticProps: GetStaticProps = async ({locale}) => {
  const [headerData, pageData, popupData] = await Promise.all([
    fetchHeaderData(locale),
    fetchPrivacyPolicyData(locale),
    fetchOffersData(locale)
  ]);
  if (!headerData || !pageData || !popupData) {
    return {
      notFound: true,
    };
  }
  return {
    props: {
      headerData,
      pageData,
      popupData
    },
    revalidate: 7776000,
  };
};
