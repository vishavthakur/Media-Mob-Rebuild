import React from "react";
import { GetStaticProps } from "next";
import { Gigya, GigyaLogin as gigyaLoginFn, GigyaObject } from "@services/Gigya";
import {getMemberDetail} from "@services/Mulesoft";
import { Header, Footer, InnerBanner, SeoMeta,Loader, SkipTarget } from "@templates";
import { fetchHeaderData } from "../api/header";
import { useSelector, RootStateOrAny, useDispatch } from "react-redux";
import {useRouter} from 'next/router'
import { USER_AUTH,LINKAGE_ACCOUNT } from "@redux/actions/authActions";
import { fetchOffersData } from "../api/offers";
import { removeCookie} from "@util/manageCookies"
interface Props {
     headerData: Record<any, any>;
     popupData: Record<any, any>;
     host?:Record<any, any>;
}
const MyProfile: React.FC<Props> = (props: Props) => {
     const dispatch = useDispatch();
     const Banner = useSelector((state: RootStateOrAny) => state.banner);
     const Auth = useSelector((state: RootStateOrAny) => state.auth);
     const UserAccess = useSelector((state: RootStateOrAny) => state.userAccess);
     const AccountLinkage = useSelector((state: RootStateOrAny) => state.accountLinkage);
     const headerData = props?.headerData;
     const [userLogin, setuserLogin] = React.useState(null);
     const [profileFormKey, setProfileFormKey] = React.useState('edit-profile-screen');
     const [userCard, setUserCard] = React.useState(null);
     const [loader, setLoader] = React.useState(true);
     const router = useRouter();
     const { locale } = router;
     const UpdateUserCallback = async (response) => {
          if (response?.response?.status === "OK") {
               if (response?.data?.scene?.cardNumber != userCard)
               {
                     /**** Removed the cookies to start over the process ***/
                    removeCookie({cookiesRemoved:['disableAddCard','disableVerifyCard','disableGhostCard','counter_disableGhostCard','counter_disableVerifyCard','counter_disableAddCard']})
                    if (response?.data?.scene?.linkedStatus) {
                         addClassInCard();
                    }
                     setLoader(true);
                  setUserCard(response?.data?.scene?.cardNumber);
                   
                  
                    /***
                     * Added the new card in the redux
                     */
                    /***
                     * Removed already exists error
                     */
                     dispatch({
                         type: LINKAGE_ACCOUNT,
                         payload: {
                           /**** Lp card number not coming from response so added empty here or can be changed from url */
                           value: {...AccountLinkage?.value,error:null},
                         },
                   });
                   dispatch({
                         type: USER_AUTH,
                         payload: {
                           /**** Lp card number not coming from response so added empty here or can be changed from url */
                           user: {...Auth?.value,lpCardNumber:response?.data?.scene?.cardNumber, linkedStatus:(response?.data?.scene?.linkedStatus)?response?.data?.scene?.linkedStatus:"false",skipVerify:true},
                         },
                   });
                    const timer = setTimeout(() => {
                         setLoader(false);
                    }, 4500);
                    return () => clearTimeout(timer);
               }
              
          }
     }
     /****
      * Callback on profile update
      */
     const updateUserProfile = () => {
          const getAccountInfoResponse = (response) => {
               if (response.status === "OK") {
                    if (response?.data?.scene?.cardNumber != userCard && response?.data?.scene?.cardNumber != undefined)
                    {
                          /**** Removed the cookies to start over the process ***/
                         removeCookie({cookiesRemoved:['disableAddCard','disableVerifyCard','disableGhostCard','counter_disableGhostCard','counter_disableVerifyCard','counter_disableAddCard']})
                         if (response?.data?.scene?.linkedStatus) {
                              addClassInCard();
                         }
                       setLoader(true);
                       setUserCard(response?.data?.scene?.cardNumber);
                       /**
                        * Get the user information after profile update
                        */
                       if(response?.data?.scene?.cardNumber != '' && response?.data?.scene?.cardNumber != undefined){
                       getMemberDetail(response?.data?.scene?.cardNumber, false);
                       }
                       else {
                        removeCookie({cookiesRemoved:['personOffersUniqueId']});       
                       }
                       
                         /***
                          * Added the new card in the redux
                          */
                         /***
                          * Removed already exists error
                          */
                          dispatch({
                              type: LINKAGE_ACCOUNT,
                              payload: {
                                /**** Lp card number not coming from response so added empty here or can be changed from url */
                                value: {...AccountLinkage?.value,error:null},
                              },
                        });
                        dispatch({
                              type: USER_AUTH,
                              payload: {
                                /**** Lp card number not coming from response so added empty here or can be changed from url */
                                user: {...Auth?.value,lpCardNumber:response?.data?.scene?.cardNumber, linkedStatus:(response?.data?.scene?.linkedStatus)?response?.data?.scene?.linkedStatus:"false",enrollementStatusGigya: response?.data?.scene?.enrollmentStatus,skipVerify:true},
                              },
                        });
                         const timer = setTimeout(() => {
                              setLoader(false);
                         }, 4500);
                         return () => clearTimeout(timer);
                         // setLoader(false);
                    }
                    
               }
             };
             //@ts-ignore
         
             if (GigyaObject != undefined) {
               GigyaObject.accounts.getAccountInfo({ callback: getAccountInfoResponse });
             }
          
     }
     const addClassInCard = () => {
          const timer = setTimeout(() => {
           //@ts-ignore
          let list = document.querySelectorAll('[data-gigya-name="data.scene.cardNumber"]');
          for (var i = 0; i < list.length; ++i) {
               list[i].classList.add('disable-card');
            }
          },1000);
      }
     const handleOnLogout = (response) => {
          setuserLogin(null);
     }
     const onLogout = () => {
          //@ts-ignore
          let gigya = window?.gigya;
          if (gigya != undefined) {
               gigya.accounts.logout({
                    callback: handleOnLogout,
               });
          }
     };

     React.useEffect(() => {
         /***
          * Added state for testing purpose
          */
          setUserCard(Auth?.value?.lpCardNumber);
          const timer = setTimeout(() => {
               const getAccountInfoResponse = (response) => {
                    if (response.status === "OK") {
                         setuserLogin(response?.profile);
                         setUserCard(response?.data?.scene?.cardNumber);
                         setLoader(false);
                         if (response?.data?.scene?.linkedStatus) {
                              addClassInCard();
                         }
                    }
                    else {
                         if (Banner?.value != undefined) {
                              gigyaLoginFn({value:Banner?.value,langauge:locale});
                         }
                    }
               }
               //@ts-ignore

               if (GigyaObject != undefined) {
                    GigyaObject.accounts.getAccountInfo({ callback: getAccountInfoResponse })
               }
             
          }, 3000);
          return () => clearTimeout(timer);
     }, [Auth?.value,Banner])
     /***
      * To check new card added in the profile 
      * 
      */
     React.useEffect(() => {
          if (Auth?.value?.lpCardNumber != userCard) {
               setProfileFormKey(`edit-my-profile-${(Math.random() + 1).toString(36).substring(2)}`)
          }
     },[Auth?.value?.lpCardNumber])
     return (<>
          <Header headerData={headerData} offerData={props?.popupData} host={props?.host}/>
          <SeoMeta 
      title={props?.popupData?.acf_tru_seometa?.[0]?.blockdata?.[0]?.browserList?.[process?.env?.NEXT_PUBLIC_GIGYA_BRAND]?.title}
      description={props?.popupData?.acf_tru_seometa?.[0]?.blockdata?.[0]?.browserList?.[process?.env?.NEXT_PUBLIC_GIGYA_BRAND]?.browserMetaDescription}
      keywords={props?.popupData?.acf_tru_seometa?.[0]?.blockdata?.[0]?.browserList?.[process?.env?.NEXT_PUBLIC_GIGYA_BRAND]?.browserMetaKeywords}
      />
          <InnerBanner title="Profile Update" id="start-of-content" />
          {/* <SkipTarget /> */}
          <div className="customform profile-sec py-18">
               {loader?(<Loader/>):( <Gigya
                    screenId={`${process.env.NEXT_PUBLIC_GIGYA_BANNER}-ProfileUpdate`}
                    startScreen="gigya-update-profile-screen"
                    id="edit-my-profile"
                    key={profileFormKey}
               />)}
              
          </div>
          <span id="profile-update-callback" onClick={() => updateUserProfile()} className="clear"></span>
          <Footer footerData={headerData} />
     </>);
}
export default React.memo(MyProfile);

export const getStaticProps: GetStaticProps = async ({locale}) => {
     /****
      * Getting the header from api
      */
     const [headerData,popupData] = await Promise.all([fetchHeaderData(locale),fetchOffersData(locale)]);
     if (!headerData) {
          return {
               notFound: true,
          };
     }
     return {
          props: {
               headerData,
               popupData
          },
          revalidate: 7776000,
     };
};
