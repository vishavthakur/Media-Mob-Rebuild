import React from "react";
import { GetServerSideProps, GetStaticProps } from "next";
import { useRouter } from "next/router";
import Head from "next/head";
import { Text, Row, Col } from "@components";
import { Header, Footer, InnerBanner, SectionBoxed, SkipTarget, SeoMeta } from "@templates";
import { fetchPrivacyPolicyData } from "../../api/privacyPolicy";
import { fetchHeaderData } from "../../api/header";
import { fetchOffersData } from "../../api/offers";
import { fetchMassOfferTerms } from "../../api/signleMassoffer";
import parse from "html-react-parser";

interface Props {
  headerData: Record<any, any>;
  pageData: Record<any, any>;
  popupData: Record<any, any>;
  host?: Record<any, any>;
}

const PrivacyPolicy: React.FC<Props> = (props: Props) => {
  const router = useRouter();
  const canonicalUrl = (`${process.env.NEXT_PUBLIC_APP_URL?.replace(/\/$/, "")}` + (router.asPath === "/" ? "": router.asPath)).split("?")[0];
  const customScrollTop = () =>{
    document?.querySelectorAll('#privacy_content_inner a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const attrHref = '#!';
                 if(this.getAttribute('href') === attrHref) {
                     e.preventDefault();
                 }else{
                     document.querySelector(this.getAttribute('href')).scrollIntoView({
                         behavior: 'smooth'
                     });
                 } 
        });
    });
  }

  React.useEffect(() => {
      customScrollTop();
  },[]);

  const headerData = props?.headerData;
  const pageData = props?.pageData;
  return (
    <>
     <Head>
        <link rel="canonical" href={canonicalUrl} />
      </Head>
      <Header headerData={headerData} offerData={props?.popupData} host={props?.host}/>
      <SeoMeta 
      title={pageData?.acf_tru_seometa?.[0]?.blockdata?.[0]?.browserList?.[process?.env?.NEXT_PUBLIC_GIGYA_BRAND]?.title}
      description={pageData?.acf_tru_seometa?.[0]?.blockdata?.[0]?.browserList?.[process?.env?.NEXT_PUBLIC_GIGYA_BRAND]?.browserMetaDescription}
      keywords={pageData?.acf_tru_seometa?.[0]?.blockdata?.[0]?.browserList?.[process?.env?.NEXT_PUBLIC_GIGYA_BRAND]?.browserMetaKeywords}
      />
      {pageData?.acf_tru_inner_header  &&
        <InnerBanner
          title={pageData?.acf_tru_inner_header?.[0]?.blockdata[0]?.titles[0]}
          id="start-of-content"
        />
      }
      {/* <SkipTarget /> */}
      <div className="outer_section_privacy section_terms_getmyoffer"  id="privacy_content_inner">
      <SectionBoxed className="py-18">
        <Row>
          {pageData?.acf_tru_content_editor[0] &&
            <Col xs={12}>
              {pageData?.acf_tru_content_editor[0]?.blockdata.map((data) => {
                return (
                  <>
                    <Text as="div" className="SimpleContent">
                      {data.title && <h2 className="heading" id={data.title?.replaceAll(" ","_")}>
                        {data.title}
                      </h2>}
                      {data?.sub_title && <h3 className="heading" id={data.sub_title?.replaceAll(" ","_")}>{data?.sub_title}</h3>}
                      {data.description && <Text as="div" className="Description">
                        {parse(data.description)}
                      </Text>}
                    </Text>
                  </>
                );
              })}
            </Col>
          }
        </Row>
      </SectionBoxed>
      </div>
      <Footer footerData={headerData} />
    </>
  );
};
export default React.memo(PrivacyPolicy);

export const getServerSideProps: GetServerSideProps = async (context) => {
  const [headerData, pageData, popupData] = await Promise.all([
    fetchHeaderData(context.locale),
    fetchMassOfferTerms(context.query.slug,context.locale),
    fetchOffersData(context.locale)
  ]);
  if (!headerData || !pageData || !popupData) {
    return {
      notFound: true,
    };
  }
  return {
    props: {
      headerData,
      pageData,
      popupData
    },
   
  };
};
