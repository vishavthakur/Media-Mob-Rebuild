import React from "react";
import { GetStaticProps } from "next";
import {SkipTarget, SeoMeta } from "@templates";
import { fetchMaintainData } from "../api/maintenance";
import Image from "@templates/ImageConversion";
import Style from './../src/styles/Maintenance.module.scss';
import parse from "html-react-parser";
interface Props {
  pageData: Record<any, any>;
}

const Maintenance: React.FC<Props> = (props: Props) => {
  return (
    <>
      <SeoMeta 
      title={props?.pageData?.acf_tru_seometa?.[0]?.blockdata?.[0]?.browserList?.[process?.env?.NEXT_PUBLIC_GIGYA_BRAND]?.title}
      description={props?.pageData?.acf_tru_seometa?.[0]?.blockdata?.[0]?.browserList?.[process?.env?.NEXT_PUBLIC_GIGYA_BRAND]?.browserMetaDescription}
      keywords={props?.pageData?.acf_tru_seometa?.[0]?.blockdata?.[0]?.browserList?.[process?.env?.NEXT_PUBLIC_GIGYA_BRAND]?.browserMetaKeywords}
      />
        <SkipTarget />
        <div className={Style.Maintenance_modules}>
            <div className={Style.Maintenance_modules_icon}>
                <Image src={props?.pageData?.acf_tru_information_banner?.[0]?.blockdata?.[0]?.image_content?.[0]?.image?.src} alt={props?.pageData?.acf_tru_information_banner?.[0]?.blockdata?.[0]?.image_content?.[0]?.image?.alt} layout="fill" objectFit="contain" />
            </div>
            <h1 className='maintenance-head'>{props?.pageData?.acf_tru_information_banner?.[0]?.blockdata?.[0]?.title}</h1>
            <p>{parse(props?.pageData?.acf_tru_information_banner?.[0]?.blockdata?.[0]?.description)}</p>
            {/* <Link href="/"><a className="themeBtn">Back to Home</a></Link> */}
        </div>
    </>
  );
};
export default React.memo(Maintenance);

export const getStaticProps: GetStaticProps = async ({locale}) => {
  const [pageData] = await Promise.all([
    fetchMaintainData(locale),
  ]);
  if (!pageData) {
    return {
      notFound: true,
    };
  }
  return {
    props: {

      pageData,
    },
    revalidate: 7776000,
  };
};
