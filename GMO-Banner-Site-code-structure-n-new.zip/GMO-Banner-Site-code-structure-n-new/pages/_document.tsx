import Document, { Html, Head, Main, NextScript } from "next/document";

const themes = 'sobeys';
class CustomDocument extends Document {
  static async getInitialProps(ctx) {
    const initialProps = await Document.getInitialProps(ctx);
    // locale is in ctx.locale

    return { ...initialProps, locale: ctx?.locale || 'en' };
  }
  render() {
      return (
          <Html lang={this.props.locale === 'fr' ? 'fr' : 'en'} className={`${this.props?.__NEXT_DATA__?.props?.host?.renderFrom?(this.props?.__NEXT_DATA__?.props?.host?.renderFrom).toLowerCase():themes}`}>
              <Head>
              {process.env?.NEXT_PUBLIC_NOFOLLOW_ENABLE  && process.env?.NEXT_PUBLIC_NOFOLLOW_ENABLE === "true" && <meta name="robots" content="noindex,nofollow"/>}
                 {/* Google Tag Manager */}
             <script data-nscript="afterInteractive" dangerouslySetInnerHTML={{
                        __html: `(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
                        new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
                        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
                        'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
                        })(window,document,'script','dataLayer','${process.env.NEXT_PUBLIC_GTM_KEY?.replaceAll('"','')}');`
              }}/>
              {process.env.NEXT_PUBLIC_SITE_VERIFICATION_KEY &&  <meta name="google-site-verification" content={`${process.env.NEXT_PUBLIC_SITE_VERIFICATION_KEY}`} />}
        
            <meta charSet="utf-8" />
            <link rel="icon" type="image/png" sizes="48x48" href={`/${this.props?.__NEXT_DATA__?.props?.host?.renderFrom?(this.props?.__NEXT_DATA__?.props?.host?.renderFrom).toLowerCase():themes}.ico`} />
              <link rel="shortcut icon" href={`/${this.props?.__NEXT_DATA__?.props?.host?.renderFrom?(this.props?.__NEXT_DATA__?.props?.host?.renderFrom).toLowerCase():themes}.ico`} />
            
              <script data-nscript="beforeInteractive" type="text/javascript" src="/js/newrelic.js" data-newrelic-account-id={`${process.env.NEXT_PUBLIC_NEWRELIC_ACCOUNT_ID}`} data-newrelic-trust-key={`${process.env.NEXT_PUBLIC_NEWRELIC_TRUST_KEY}`} data-newrelic-agent-id={`${process.env.NEXT_PUBLIC_NEWRELIC_AGENT_ID}`} data-newrelic-license-key={`${process.env.NEXT_PUBLIC_NEWRELIC_LICENSE_KEY}`} data-newrelic-application-id={`${process.env.NEXT_PUBLIC_NEWRELIC_APPLICATION_ID}`}/>
             <script
                         dangerouslySetInnerHTML={{
                              __html: `
                            function handleCloseModal(type,supression){
                            if(type==='addCard' && supression==='soft'){
                              const collection = document.getElementById("remind-addcard");
                              collection.click();
                            }
                          }
                          function gmo_handle_submission(response){
                            if(response?.screen === "gigya-add-card-screen"){
                              const collection = document.getElementById("add-card-aftersubmit");
                              collection.click();
                            }
                            else{
                              const collection = document.getElementById("profile-update-callback");
                              collection.click();
                            }
                           
                          }  
                            `,
                         }}
                    />

                   
            <script data-nscript="beforeInteractive" src={`https://cdns.global.gigya.com/js/gigya.js?apikey=${process.env.NEXT_PUBLIC_GIGYA_KEY}`}
            ></script>
             <script
                         async
                         src={`https://maps.googleapis.com/maps/api/js?key=${process.env.NEXT_PUBLIC_GOOGLE_MAP_API_KEY}`}
                    ></script>
                         <script type='text/javascript' src='/assets/iga_cmn.js'> </script>
                  <script
                         dangerouslySetInnerHTML={{
                              __html: `
                              function getCookie(name) {
                                var dc = document.cookie;
                                var prefix = name + "=";
                                var begin = dc.indexOf("; " + prefix);
                                if (begin == -1) {
                                  begin = dc.indexOf(prefix);
                                  if (begin != 0) return null;
                                }
                                else {
                                  begin += 2;
                                  var end = document.cookie.indexOf(";", begin);
                                  if (end == -1) {
                                    end = dc.length;
                                  }
                                }
                                // because unescape has been deprecated, replaced with decodeURI
                                //return unescape(dc.substring(begin + prefix.length, end));
                                return decodeURI(dc.substring(begin + prefix.length, end));
                              }
                              
                            function glDecorateUrl (){
                              var ga = window[window['GoogleAnalyticsObject']];
                              let glGenration = '';
                              if (ga && typeof ga.getAll === 'function' &&  window.google_tag_data.glBridge != undefined ) {
                               glGenration = window.google_tag_data.glBridge.generate({
                                _ga: getCookie("_ga").slice(6),      
                                _ga_${(process.env.NEXT_PUBLIC_GTM_V4)?.replaceAll('"','')}: getCookie("_ga_${(process.env.NEXT_PUBLIC_GTM_V4)?.replaceAll('"','')}").slice(6)
                            }); 
                          }
                          return glGenration;
                             
                            }
                            function decorateUrl() {
                              var urlString = "/"
                              var ga = window[window['GoogleAnalyticsObject']];
                              var tracker;
                              if (ga && typeof ga.getAll === 'function' && window.gaplugins != undefined) {
                                tracker = ga.getAll()[0]; // Uses the first tracker created on the page
                                urlString = (new window.gaplugins.Linker(tracker).decorate(urlString));
                                var gaParams = new URLSearchParams(urlString); // parse the /?_ga linker parameter
                                var gaLinker = gaParams.get('/?_ga');
                              }
                              
                              return gaLinker;
                            }`,
                         }}
            />

{(process.env.NEXT_PUBLIC_USERSNAPAPIKEY  && (process.env.NEXT_PUBLIC_USERSNAP_ENABLE=="true"))&& (
               <script
               dangerouslySetInnerHTML={{
                    __html: `
                    window.onUsersnapCXLoad = function(api) {
                      api.init();
                    }
                    var script = document.createElement('script');
                    script.async = 1;
                    script.src = 'https://widget.usersnap.com/load/${process.env.NEXT_PUBLIC_USERSNAPAPIKEY}?onload=onUsersnapCXLoad';
                    document.getElementsByTagName('head')[0].appendChild(script);`,
               }}
  />
            )}
              </Head>
              <body role="main">
              <div className="skipToContent" role="complementary" aria-label="Skip to main content">
                  <a href="#start-of-content" tabIndex={0}>Skip to content</a>
              </div>
                  <Main />
                  <NextScript />

                  {/* Google Tag Manager */}
                  <noscript dangerouslySetInnerHTML={{
                        __html: `<iframe src="https://www.googletagmanager.com/ns.html?id=${process.env.NEXT_PUBLIC_GTM_KEY?.replaceAll('"','')}"
                        height="0" width="0" style="display:none;visibility:hidden"></iframe>`
                    }}/>

              </body>
          </Html>
      );
  }
}

export default CustomDocument;
