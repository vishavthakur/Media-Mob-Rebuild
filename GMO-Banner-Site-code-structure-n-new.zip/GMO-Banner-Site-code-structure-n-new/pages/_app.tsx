import "@styles/app.global.scss";
import React from "react";
import { AppProps } from "next/app";
import { StyledThemeProvider } from "@definitions/styled-components";
import Head from 'next/head'
import ThemeProvider from "src/context/ThemeProvider";
import store from "@redux/store";
import { Provider } from "react-redux";
import Bus from "@util/Bus";
interface customProps extends AppProps {
  host: any
}
function MyApp({ Component, pageProps,host }: customProps): JSX.Element {
  globalThis.flash = (message, type = "success") => Bus.emit('flash', ({ message, type }));
  pageProps = {
    ...pageProps,
    host,
  }
  return (<>
   <Head>
      {/* <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=2, user-scalable=0"/> */}
      </Head>
    <StyledThemeProvider>
      <ThemeProvider>
        <Provider store={store}>
          <Component {...pageProps}/>
        </Provider>
      </ThemeProvider>
    </StyledThemeProvider>
    </>
  );
}
/***
 * @function getInitialProps 
 * Get the host value from the url
 */
MyApp.getInitialProps = async ctx => {
  let host = process?.env?.NEXT_PUBLIC_APP_URL;
  /***
   * Domain based banners for filters
   */
  let banners_offers = [
    { title: "All", value: "" },
    { title: "Sobeys", value: "A" },
    { title: "Safeway", value: "C" },
    { title: "Foodland", value: "B" },
    { title: "IGA West", value: "D" },
    { title: "FreshCo", value: "H" },
    { title: "ChaloFreshco", value: "K" },
    { title: "Thrifty Foods", value: "E" }
  ];
  let filter_offers = [
    'A','C','B','D','H','K','E',''
  ];
  let banners_liquor = [
    { title: "All", value: "" },
    { title: "Sobeys Liquor", value: "F" },
    { title: "Safeway Liquor", value: "G" },
    { title: "Thrifty Foods Liquor", value: "J" },
  ];
  let filter_Liquor = [
    'F','G','J',''
  ];
  let banners_IGA = [
    { title: "All", value: "" },
    { title: "IGA West", value: "D" },
  ];
  let filter_IGA = [
    'D',''
  ];
  try {
    let props = {};
    if (host) {
      if (host?.match(/mygroceryoffers/)) {
        props = {
          renderFrom: 'Offers',
          brand: 'gmo',
          filterItemsBanners: banners_offers,
          fliters: filter_offers,
          defaultRegion: process.env.NEXT_PUBLIC_DEFAULT_REGION,
          rolledOut: [],
          banners:{
            ontario: ["sobeys", "safeway", "foodland", "freshCo"],
            west: ["sobeys", "safeway", "freshco"],
            atlantic: ["sobeys", "foodland"],
            quebec: [],
          },
          showrolledpopup:true,
        }
      }
      else if (host?.match(/myliquoroffers/)) {
        props = {
          renderFrom: 'LiquorOffers',
          brand: 'myliquoroffers',
          filterItemsBanners: banners_liquor,
          fliters: filter_Liquor,
          defaultRegion: process.env.NEXT_PUBLIC_DEFAULT_REGION,
          rolledOut: [],
          banners:{
            ontario: [],
            west: ["Liquor Sobeys", "Liquor Safeway", "Liquor Thrifty"],
            atlantic: [],
            quebec: [],
          },
          showrolledpopup:false,
        }
      }
      else if (host?.match(/mesoffresiga/)) {
        props = {
          renderFrom: 'IGAOffers',
          brand: 'mesoffresiga',
          filterItemsBanners: banners_IGA,
          fliters: filter_IGA,
          defaultRegion: process.env.NEXT_PUBLIC_DEFAULT_REGION,
          rolledOut: ['quebec'],
          banners:{
            ontario: ["IGA West"],
            west: ["IGA West"],
            atlantic: [],
            quebec: ["IGA West"],
          },
          showrolledpopup:false,
        }
      }
      else {
        props = {
          renderFrom: 'Offers',
          brand: 'gmo',
          filterItemsBanners: banners_offers,
          fliters: filter_offers,
          defaultRegion: process.env.NEXT_PUBLIC_DEFAULT_REGION,
          rolledOut: [],
          banners:{
            ontario: ["sobeys", "safeway", "foodland", "freshCo"],
            west: ["sobeys", "safeway", "freshco"],
            atlantic: ["sobeys", "foodland"],
            quebec: [],
          },
          showrolledpopup:true,
        }
      }
      return { host: props }
    }
    else {
      props = {
        renderFrom: 'Offers',
        brand: 'gmo',
        filterItemsBanners: banners_offers,
        fliters: filter_offers,
        defaultRegion: 'ontario',
        rolledOut: [],
        banners:{
          ontario: ["sobeys", "safeway", "foodland", "freshCo"],
          west: ["sobeys", "safeway", "freshco"],
          atlantic: ["sobeys", "foodland"],
          quebec: [],
        },
        showrolledpopup:true,
      }
      return { host: props }
    }
  }
  catch (error) {
    console.log(error);
  }
}
export default MyApp;
