import React from "react";
import { useForm, Controller } from "react-hook-form";
import OtpInput from "react-otp-input-rc-17";
import { AlertCircle } from "react-feather";
import Link from "next/link";
import { useSelector, RootStateOrAny } from "react-redux";
import { GetServerSideProps } from "next";
import { GigyaLogin as gigyaLoginFn, GigyaObject,gigyaLoggedIn,checkRolledOut } from "@services/Gigya";
import Image from "@templates/ImageConversion";
import { Text, Row, Col } from "@components";
import { HeaderVerify, Footer, GhostSceneCard, SeoMeta, SectionBoxed, Loader, SkipTarget } from "@templates";
import styled from "../src/styles/verifyCard.module.scss";
import { fetchHeaderData } from "../api/header";
import { verifyCardData } from "../api/verifycard";
import { thankYouData } from "../api/thankYou";
import { fetchOffersData } from "../api/offers";
import { useRouter } from "next/router";
import {verifyCode,resendCode,linkAccount} from "@services/Mulesoft";
import { accountVerificationInitiated, accountCodeSubmitted, accountVerified } from "@services/NewRelic";
import { getCookie } from "cookies-next";


interface Props {
  headerData: Record<any, any>;
  verifyData: Record<any, any>;
  thankPageData: Record<any, any>;
  popupData: Record<any, any>;
  host?: Record<any, any>;
}

const popupData: React.FC<Props> = (props: Props) => {
  const {
    register,
    handleSubmit,
    setValue,
    control,
    formState: { errors, isValid },
  } = useForm({ mode: "all" });
  const router = useRouter();
  const { locale } = router;
  const AccountLinkage = useSelector((state: RootStateOrAny) => state.accountLinkage);
  const Auth = useSelector((state: RootStateOrAny) => state.auth);
  const Banner = useSelector((state: RootStateOrAny) => state.banner);
  const headerData = props?.headerData;
  const verifyData = props?.verifyData?.acf_tru_modal[0]?.blockdata;

  const thankData = props?.thankPageData;
  const [value, setvalue] = React.useState("");
  const [showOtp, setShowOtp] = React.useState(false);
  const [showErrorCard, setShowErrorCard] = React.useState(false);
  const [otpError, setOtpError] = React.useState(null);
  const [showResendCode, setShowResendCode] = React.useState(false);
  const [inputOtp, setinputOtp] = React.useState("");
  const [otpConfirmed, setOtpConfirmed] = React.useState(false);
  const [otpResend, setOtpResend] = React.useState(false);
  const [ verifyOtp, setVerifyOtp] = React.useState(false);
  const [otpLinkageError, setOtpLinkageError] = React.useState(null);
  const [redirectUrl, setRedirectUrl] = React.useState(null);
  const [redirectName, setRedirectName] = React.useState(null);
  const onChangeInputHandler = (event) => {
    setvalue(event.target.value);
  };

  const onSubmitCard = (data) => {
    setVerifyOtp(true);
    linkAccount(Auth?.value?.lpCardNumber, Auth?.value?.guid).then((data) => {
      if (data?.error) {
        setOtpLinkageError(data?.error?.details[0]?.message);
        setVerifyOtp(false);
		accountVerificationInitiated(getCookie("personOffersUniqueId"), data?.error?.code);   //initiated newRelic accountVerificationInitiated event

      }
      else {
        setShowOtp(true);
        setShowErrorCard(false);
        setVerifyOtp(false);
		accountVerificationInitiated(getCookie("personOffersUniqueId"), "true");   //initiated newRelic accountVerificationInitiated event
      }
    })
  };
  const onFormSubmit = (data) => {
    console.log(data, "data otp card number");
    setVerifyOtp(true);
    accountCodeSubmitted(getCookie("personOffersUniqueId"), "success");   // initiated newRelic accountCodeSubmitted event
    verifyCode(data?.otpnumber, Auth?.value?.guid).then((data) => {
      if (data?.error)
      {
        accountVerified(getCookie("personOffersUniqueId"), data?.error?.code);     // initiated newRelic accountVerified event
        if (data?.error?.details[0]?.code !== "6112") {
          setOtpError(data?.error?.details[0].message);
        }
        else {
          setOtpError(data?.error?.details[0].message);
          setShowResendCode(true);
        }
        setVerifyOtp(false);
      }
      else {
        setOtpConfirmed(true); 
        setVerifyOtp(false);
        accountVerified(getCookie("personOffersUniqueId"), "success");     // initiated newRelic accountVerified event
      }
    })
  };
  
  /****
   * 
   */
  const handleOtpResend = () => {
    setShowResendCode(false);
    setOtpResend(true);
    resendCode(Auth?.value?.guid).then((data) => {
      if (data?.error)
      {
        setOtpResend(false);
        setOtpError(data?.error?.details[0].message);
      }
      else {
        setOtpResend(false);
      }
    }) 
   }

  /****
   * @function isURL to check url is valid
   */
   const  isURL = (str) => {
    var pattern = new RegExp('^(https?:\\/\\/)?'+ // protocol
    '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.?)+[a-z]{2,}|'+ // domain name
    '((\\d{1,3}\\.){3}\\d{1,3}))'+ // OR ip (v4) address
    '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*'+ // port and path
    '(\\?[;&a-z\\d%_.~+=-]*)?'+ // query string
    '(\\#[-a-z\\d_]*)?$','i'); // fragment locator
    return pattern.test(str);
  }
  React.useEffect(() => {
    if (AccountLinkage?.value?.otp && !AccountLinkage?.value?.error)
    {
      setShowOtp(true);
      setShowErrorCard(false)
    }
    else if ((AccountLinkage?.value?.error)?.length > 0) {
      setOtpLinkageError(AccountLinkage?.value?.error);
      setShowErrorCard(true)
      setShowOtp(false);
    }
  }, [AccountLinkage]);

  React.useEffect(() => {
    const timer = setTimeout(() => {
      /***
       * Set the redirect back url
       */
      if (router?.query?.home_url) {
        try {
          let back_url = decodeURI(router?.query?.home_url as string);
          let redirect_url = Buffer.from(back_url, 'base64').toString('utf-8');
          if (isURL(redirect_url)){
            setRedirectUrl(`${redirect_url}`);
            let domain = (new URL(redirect_url));
            setRedirectName(domain?.hostname?.replace('www.',''))
          };
        }
        catch (error) {
          console.log(error,"=== error")
        }
      }
      const getAccountInfoResponse = (response) => {
        if (response.status === "OK") {
          
        }
        else {
          if(checkRolledOut((props?.host?.rolledOut).length > 0 ?props?.host?.rolledOut :GigyaObject?.thisScript?.globalConf?.ELM_REGIONS)){
            gigyaLoginFn({value:JSON.parse(localStorage.getItem("banner")),langauge:locale});
          }
         
        }
      }
      //@ts-ignore

      if (GigyaObject != undefined) {
        GigyaObject.accounts.getAccountInfo({
			callback: getAccountInfoResponse,
		  });
      }
    }, 300);
    return () => clearTimeout(timer);
  }, [router?.query]);
  const handleOTPChange = (otp) => {
    setinputOtp(otp);
    const re = /^[0-9\b]+$/;
    if (otp === '' || re.test(otp)) {
      setValue('otpnumber', otp);
    }
    else {
      setValue('otpnumber', '');
    }
    setOtpError(null);
  };
  return (
    <>
      <HeaderVerify headerData={headerData} offerData={props?.popupData} host={props?.host}/>
      <SeoMeta 
      title={props?.verifyData?.acf_tru_seometa?.[0]?.blockdata?.[0]?.browserList?.[process?.env?.NEXT_PUBLIC_GIGYA_BRAND]?.title}
      description={props?.verifyData?.acf_tru_seometa?.[0]?.blockdata?.[0]?.browserList?.[process?.env?.NEXT_PUBLIC_GIGYA_BRAND]?.browserMetaDescription}
      keywords={props?.verifyData?.acf_tru_seometa?.[0]?.blockdata?.[0]?.browserList?.[process?.env?.NEXT_PUBLIC_GIGYA_BRAND]?.browserMetaKeywords}
      />
      <SkipTarget />
      {(showOtp || otpConfirmed || showErrorCard ) ? (
        <>
            {/* show error Card Start here */}
  {showErrorCard && (
        <SectionBoxed>
          <Text as="div" className={styled.verifyCardPopup + " verify-card-popup"}>
            {verifyData[0]?.title &&
              <Text as="h3">{verifyData[0]?.title}</Text>
            }
            {verifyData[0]?.description &&
              <Text as="p" colorScheme="accent">{verifyData[0]?.description}</Text>
            }
            <Text as="div" className={styled.verifyCardImage}>
              {verifyData[0]?.image_group[0]?.image &&
                <Image
                  src={verifyData[0]?.image_group[0]?.image?.src}
                  alt={verifyData[0]?.image_group[0]?.image?.alt}
                  objectFit="contain"
                  width={verifyData[0]?.image_group[0]?.image?.dimensions?.width}
                  height={
                    verifyData[0]?.image_group[0]?.image?.dimensions?.height
                  }
                />
              }
            </Text>
            <Text as="div" className={styled.verifyCardImageMobile}>
              {verifyData[0]?.image_group[0]?.image &&
                <Image
                  src={verifyData[0]?.image_group[1]?.image?.src}
                  objectFit="contain"
                  width={verifyData[0]?.image_group[1]?.image?.dimensions?.width}
                  height={
                    verifyData[0]?.image_group[1]?.image?.dimensions?.height
                  }
                />
              }
            </Text>

            <Text as="div" className="">
              {verifyData[0]?.modalcontent[0][0] &&
                <Text as="div" colorScheme="accent" className="inputLabel">
                  {`${verifyData[0]?.modalcontent[0][0]}`}
                </Text>
              }
              <GhostSceneCard onSubmit={onSubmitCard} errorResponse={otpLinkageError}>
                {verifyData[0]?.actionproperties[0]?.text &&
                      <button 
                      aria-label={verifyData[0]?.actionproperties[0]?.arialabel} 
                      id={verifyData[0]?.actionproperties[0]?.buttonId} 
                      data-gtm={verifyData[0]?.actionproperties[0]?.datagmt}
                      className={`themeBtn btnFluid ${(verifyOtp)?`btn-error-disable`:``}`} disabled={(verifyOtp)?true:false}>{verifyData[0]?.actionproperties[0]?.text}</button>
                }
              </GhostSceneCard>
                  {verifyData[1]?.actionproperties[0] &&
                    <>
               
                    <Text as="p" colorScheme="accent" className={`${styled.verifyCardCta} space-between`}>
                      {<Link href={(redirectUrl) ? (`${redirectUrl}?utm_source=${process.env.NEXT_PUBLIC_GIGYA_BRAND}&utm_medium=cross_site_referral&utm_campaign=back_to_site`) : '/'}><a className="simple-link purple-1">Go back </a></Link>}
                      <Text as="span">
                  {verifyData[1]?.actionproperties[0]?.text}{" "}
                  <Link href={locale==='en'?GigyaObject?.thisScript?.globalConf?.SCENE_CONTACT_SUPPORT_URL:GigyaObject?.thisScript?.globalConf?.SCENE_CONTACT_SUPPORT_URL_FR}>
                    <a className="simple-link" target={`_blank`}>
                      {verifyData[1]?.actionproperties[0]?.label}
                    </a>
                        </Link>
                        </Text>
                    </Text>
                    </>
              }
            </Text>
          </Text>
        </SectionBoxed>
      )}
      {/* ENd show error Card Code End here */}
      {showOtp && !otpConfirmed && (
        <SectionBoxed>
          <Text as="div" className={styled.verifyCardPopup}>
            {verifyData[2]?.title && <Text as="h3">{verifyData[2]?.title}</Text>}
            {verifyData[2]?.modalcontent[0] && <Text as="p" colorScheme="accent">{verifyData[2]?.modalcontent[0]}</Text>}
            <form onSubmit={handleSubmit(onFormSubmit)}>
              <Text as="div">
                <Controller
                  name="otpnumber"
                  control={control}
                  rules={{
                    required: "Please enter a 6 digit number.",
                    pattern: {
                      value: /^[0-9\b]+$/,
                      message: "Only digits are allowed",
                    },
                    minLength: {
                      value: 6,
                      message: "Please enter a 6 digit number.",
                    },
                  }}
                  render={({ field }) => (
                    <Text as="div" className={styled.verifyOtpContainer}>
                      <OtpInput
                         onChange={!isValid ?  setOtpError(null):''}
                        numInputs={6}
                        className={`input-style-below-line small ${(errors.otpnumber || otpError?.length > 0)?'otp-error':''}`}
                        separator={<span className="otpseparator"> </span>}
                        {...field}
                      />
                    </Text>
                  )}
                />
                {errors.otpnumber && (
                  <div className="error error-otp">
                    <div className="error-icon">
                      <AlertCircle style={{ marginRight: "5px" }} size="12px" />
                      {errors.otpnumber.message}
                    </div>
                  </div>
                )}
                 {otpError && (
                  <div className="error error-otp">
                    <div className="error-icon">
                      <AlertCircle style={{ marginRight: "5px" }} size="12px" />
                      {otpError}
                    </div>
                  </div>
                )}
              </Text>
              {!showResendCode &&
                <div className={(errors.otpnumber || !isValid) && 'disable-submit'}>
                      <button 
                      aria-label={verifyData[2]?.actionproperties[0]?.arialabel} 
                      id={verifyData[2]?.actionproperties[0]?.buttonId} 
                      data-gtm={verifyData[2]?.actionproperties[0]?.datagmt}
                      className={`themeBtn btn-error btnFluid ${(verifyOtp)?`btn-error-disable`:``}`} disabled={(verifyOtp)?true:false}>{verifyData[2]?.actionproperties[0]?.text}</button>
                </div>
              }
            </form>
            <div>

                  <button
                  aria-label={verifyData[2]?.actionproperties[1]?.arialabel} 
                  id={verifyData[2]?.actionproperties[1]?.buttonId} 
                  data-gtm={verifyData[2]?.actionproperties[1]?.datagmt}
                  className={`themeBtn outline btnFluid ${(otpResend)?`btn-error-disable`:``}`} onClick={() => handleOtpResend()} disabled={(otpResend)?true:false}>{(!showResendCode)?verifyData[2]?.actionproperties[1]?.text:(`Resend Otp`)}</button>
            </div>
            {verifyData[3]?.actionproperties && verifyData[3]?.actionproperties.map((item) => {
              return (
                <div className={styled.verifyCardCta}>
               
                <Text as="p" >
                <Link href={(redirectUrl) ? (`${redirectUrl}?utm_source=${process.env.NEXT_PUBLIC_GIGYA_BRAND}&utm_medium=cross_site_referral&utm_campaign=back_to_site`) : '/'}><a>Go back</a></Link>
                <Text as="span" colorScheme="accent">
                  {item?.text}
                    <Link href={locale==='en'?GigyaObject?.thisScript?.globalConf?.SCENE_CONTACT_SUPPORT_URL:GigyaObject?.thisScript?.globalConf?.SCENE_CONTACT_SUPPORT_URL_FR}>
                      <a target={`_blank`}> {item?.label}</a>
                    </Link>
                </Text>
                 
                </Text>
                </div>
                )
            })}


          </Text>
        </SectionBoxed>
      )}

      {/**** Thank you */}

      {otpConfirmed && (
        <SectionBoxed className={styled.ThankyouSection}>
          <Row justifyContent="center">
            <Text textAlign="center" className={styled.TopHeading}>
              {thankData?.acf_tru_heading[0]?.blockdata[0]?.heading &&
                <h2 className="ThankyouHeading">{thankData?.acf_tru_heading[0]?.blockdata[0]?.heading}</h2>
              }
              {thankData?.acf_tru_heading[0]?.blockdata[0]?.sub_heading &&
                <p>

                  {thankData?.acf_tru_heading[0]?.blockdata[0]?.sub_heading}
                </p>
              }

            </Text>
          </Row>
          <Row alignItems="stretch">
            {thankData?.acf_tru_cards[0]?.blockdata && thankData?.acf_tru_cards[0]?.blockdata.map((data) => {
              return (
                <Col sm={4}>
                  <div className={styled.ThankyouBox}>
                    <div className={styled.ThankyouBoxImg}>
                      <Image
                        src={data?.cardimages?.[0]?.desktopimage?.src}
                        alt={data?.cardimages?.[0]?.desktopimage?.alt}
                        width={64}
                        height={64}
                      />
                    </div>
                    <p>{data?.card_discription}</p>
                  </div>
                </Col>
              );
            })}
          </Row>
          <Row justifyContent="center">
          <div className={styled.ThankBoxBtn}>
            {thankData?.acf_tru_information_banner[0] &&
              <a className="themeBtn" target={thankData?.acf_tru_information_banner[0]?.blockdata[0]?.action_properties[0]?.url?.target} aria-label={thankData?.acf_tru_information_banner[0]?.blockdata[0]?.action_properties[0]?.arialabel} id={thankData?.acf_tru_information_banner[0]?.blockdata[0]?.action_properties[0]?.buttonId}
                data-gmt={thankData?.acf_tru_information_banner[0]?.blockdata[0]?.action_properties[0]?.datagmt} href={thankData?.acf_tru_information_banner[0]?.blockdata[0]?.action_properties[0]?.url?.url}> {thankData?.acf_tru_information_banner[0]?.blockdata[0]?.action_properties[0]?.label}</a>
            }
            {redirectUrl && <a className="themeBtn outline" href={`${redirectUrl}?utm_source=${process.env.NEXT_PUBLIC_GIGYA_BRAND}&utm_medium=cross_site_referral&utm_campaign=back_to_site`}>{`Back To ${redirectName}`}</a>}

          </div>
          </Row>
        </SectionBoxed>
      )}
      </>):(<Loader/>)}
      <Footer footerData={headerData} />
    </>
  );
};
export default React.memo(popupData);

export const getServerSideProps: GetServerSideProps = async ({locale}) => {

  const [headerData, verifyData, thankPageData,popupData] = await Promise.all([
    fetchHeaderData(locale),
    verifyCardData(locale),
    thankYouData(locale),
    fetchOffersData(locale)
  ]);
  if (!headerData || !verifyCardData || !thankYouData || !popupData) {
    return {
      notFound: true,
    };
  }
  return {
    props: {
      headerData,
      verifyData,
      thankPageData,
      popupData
    },
  };
};
