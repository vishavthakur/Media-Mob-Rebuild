import * as fs from "fs";

const BASE_URL = process?.env?.NEXT_PUBLIC_APP_URL;

const staticPaths = fs
	.readdirSync("pages")
	.filter((staticPage) => {
		return ![
			"api",
			"_app.tsx",
			"_document.tsx",
			"404.tsx",
			"sitemap.xml.tsx",
			"get-my-offers.tsx",
			"gigya-forgot-password.tsx",
			"gigya-login.tsx",
			"gigya-preferences.tsx",
			"gigya-profile-completion.tsx",
			"gigya-register.tsx",
			"gigya-subscribe.tsx",
			"product-offer.tsx",
			"register-card.tsx",
			"thankyou.tsx",
			"verify-card-otp.tsx",
			"prob.tsx",
			"maintenance"
		].includes(staticPage);
	})
	.map((staticPagePath) => {
		return `${BASE_URL}${staticPagePath?.replace(".tsx","")}`;
	});

const Sitemap = () => {
	return null;
};

const allPaths = [...staticPaths];

export const getServerSideProps = async ({ res }) => {
	// const BASE_URL = "http://localhost:3000";

	const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
    <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
      ${allPaths
				.map((url) => {
					return `
            <url>
              <loc>${url}</loc>
              <lastmod>${new Date().toISOString()}</lastmod>
              <changefreq>monthly</changefreq>
              <priority>1.0</priority>
            </url>
          `;
				})
				.join("")}
    </urlset>`;

	res.setHeader("Content-Type", "text/xml");
	res.write(sitemap);
	res.end();

	return {
		props: {},
	};
};

export default Sitemap;
