import React from "react";
import { GetStaticProps } from "next";
import { useRouter } from "next/router";
import Head from "next/head";
import {
  Text,
  Accordion,
  AccordionHeader,
  AccordionItem,
  AccordionPanel,
} from "@components";
import {
  Header,
  Footer,
  InnerBanner,
  SectionBoxed,
} from "src/templates";
import { fetchHelpCenterData } from "../api/helpCentre";
import { fetchHeaderData } from "../api/header";
import { fetchOffersData } from "../api/offers";
import styles from "@styles/HelpCenter.module.scss";
import {Tabs, TabVerticalItem, SeoMeta} from "@templates";
import parse from "html-react-parser";


interface Props {
  headerData: Record<any, any>;
  pageData: Record<any, any>;
  popupData: Record<any, any>;
  host?:Record<any, any>;
}
const HelpCentre: React.FC<Props> = (props: Props) => {
  const router = useRouter();
  const canonicalUrl = (`${process.env.NEXT_PUBLIC_APP_URL?.replace(/\/$/, "")}` + (router.asPath === "/" ? "": router.asPath)).split("?")[0];
  const headerData = props?.headerData;
  const pageData = props?.pageData;
  const defualtTabActive = pageData?.acf_tru_accordion[0]?.blockdata[0].listname;

  const length = pageData?.acf_tru_accordion[0]?.blockdata.length;
  return (
    <>
    <Head>
        <link rel="canonical" href={canonicalUrl} />
      </Head>
      <Header headerData={headerData} offerData={props?.popupData}  host={props?.host}/>
      <SeoMeta 
      title={pageData?.acf_tru_seometa?.[0]?.blockdata?.[0]?.browserList?.[process?.env?.NEXT_PUBLIC_GIGYA_BRAND]?.title}
      description={pageData?.acf_tru_seometa?.[0]?.blockdata?.[0]?.browserList?.[process?.env?.NEXT_PUBLIC_GIGYA_BRAND]?.browserMetaDescription}
      keywords={pageData?.acf_tru_seometa?.[0]?.blockdata?.[0]?.browserList?.[process?.env?.NEXT_PUBLIC_GIGYA_BRAND]?.browserMetaKeywords}
      />
      <InnerBanner
        title={pageData?.acf_tru_inner_header[0]?.blockdata[0]?.titles[0]}
        id="start-of-content"
      />

      {/* <SkipTarget /> */}
      <SectionBoxed className={`py-18 ${styles.HelpCenterTabbing}`}>
        <Tabs>
          {pageData?.acf_tru_accordion?.[0]?.blockdata?.map((item, i) =>(
            <>
            <TabVerticalItem 
                key={`${item.listname}-${i}`} 
                value={i}
                title={item.listname}
                tabAriaLabel={item.listname}
                panelAriaLabel={item.listname}
                style={{ gridRowEnd: length + 3 }}
              >
                {item?.accordionlistdata?.map((accordion,index) => {
                  return (
                    <Text
                        className={styles.AccordionBox}
                      >
                      <Accordion
                        icon={{
                          collapsedIconDetails: (
                            <Text as="div" className={styles.plus}></Text>
                          ),
                          expandedIconDetails: (
                            <Text as="div" className={styles.minus}></Text>
                          ),
                        }}
                      >
                      <AccordionItem
                        key={`accordion_item${index}`}
                        id={index}
                        className={styles.accordionItem}
                      >
                        <AccordionHeader>
                          <Text className={styles.AccordionHeader}>
                            {parse(accordion?.accordiontitle)}
                          </Text>
                        </AccordionHeader>
                        <AccordionPanel>
                          <Text
                            className={styles.AccordionPanel}
                            style={{ margin: 10 }}
                          >
                            {parse(accordion?.accordioncontent)}
                          </Text>
                        </AccordionPanel>
                      </AccordionItem>
                    </Accordion>
                    </Text>
                  );
                })}
              </TabVerticalItem>
          </>
          ))}
        </Tabs>
      </SectionBoxed>
      <Footer footerData={headerData} />
    </>
  );
};
export default React.memo(HelpCentre);

export const getStaticProps: GetStaticProps = async ({locale}) => {
  const [headerData, pageData, popupData] = await Promise.all([
    fetchHeaderData(locale),
    fetchHelpCenterData(locale),
    fetchOffersData(locale)
  ]);
  if (!headerData || !pageData || !popupData) {
    return {
      notFound: true,
    };
  }
  return {
    props: {
      headerData,
      pageData,
      popupData
    },
    revalidate: 7776000,
  };
};