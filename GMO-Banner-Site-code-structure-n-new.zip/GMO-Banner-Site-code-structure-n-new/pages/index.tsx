import React from "react";
import { GetStaticProps } from "next";
import { useRouter } from "next/router";
import Head from "next/head";
import { fetchHeaderData } from "../api/header";
import { fetchOffersData } from "../api/offers";
import { fetchMyOffers } from "../api/myOffres";
import { fetchHomeNewData } from "../api/homenew";
import WithoutLoginPage from "@templates/PageWithoutLogin";
import { serverLogs } from "@util/serverLogs";
import { deviceDetect, mobileModel } from "react-device-detect";
interface Props {
  headerData: Record<any, any>;
  newPageData:Record<any, any>;
  offerPageData?: Record<any, any>;
  myOffers?: Record<any, any>;
  host?: Record<any, any>;
}
const Home: React.FC<Props> = (props: Props) => {
  const router = useRouter();
  const canonicalUrl = (`${process.env.NEXT_PUBLIC_APP_URL?.replace(/\/$/, "")}` + (router.asPath === "/" ? "": router.asPath)).split("?")[0];
  const devicess = deviceDetect(null);
  return (
    <>
     <Head>
        <link rel="canonical" href={canonicalUrl} />
        
      </Head>
     <WithoutLoginPage headerData={props?.headerData} pageData={[]} newPageData={props?.newPageData} offerPageData={props?.offerPageData} host={props?.host}/>
    </>
  );
};
export default Home;

export const getStaticProps: GetStaticProps = async ({ locale }) => {
  serverLogs('inside get server response');
  const [ headerData, offerPageData, myOffers,newPageData] = await Promise.all([
    fetchHeaderData(locale),
    fetchOffersData(locale),
    fetchMyOffers(locale),
    fetchHomeNewData(locale)
  ]);

  if (!newPageData || !headerData) {
    serverLogs("home page data" + JSON.stringify(newPageData) + "header data" + JSON.stringify(headerData));
    return {
      notFound: true,
    };
  }
  serverLogs('fetch the response for home page all api finished');
  serverLogs(`${process.version} node version`);
  return {
    props: {
      headerData,
      offerPageData,
      myOffers,
      newPageData
    },
    revalidate: 7776000,
  };
};
