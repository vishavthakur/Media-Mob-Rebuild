import React from 'react'
import Image from "@templates/ImageConversion";
import Link from 'next/link'
import Style from './../src/styles/ErrorPage.module.scss'
import {SeoMeta, SkipTarget} from "@templates";

interface Props {
    headerData: Record<any, any>;
    pageData: Record<any, any>;
    host: Record<any, any>;
  }



const NotFound = (props: Props) => {
    const headerData = props?.headerData;
  return (
      <>
        <SeoMeta title={`Page not found | ${process?.env?.NEXT_PUBLIC_APP_NAME}`}/>
        <SkipTarget />
        <div className={Style.Error_modules}>
            <div className={Style.Error_modules_icon}>
                <Image src={`/${props?.host?.renderFrom}_basket-logo.svg`} alt="404 Page Not Found" layout="fill" objectFit="contain" />
            </div>
            <h1>404 Page Not Found</h1>
            <p>Sorry, we can’t find the page you’re looking for.</p>
            <Link href="/"><a className="themeBtn">Back to Home</a></Link>
        </div>
      </>
  )
}

export default NotFound
