import React from "react";
import { GetStaticProps } from "next";
import { removeCookies } from 'cookies-next';
import { useSelector, RootStateOrAny, useDispatch } from "react-redux";
import { GigyaObject, GigyaLogout,GigyaLogin as gigyaLoginFn, gigyaLoggedIn } from "@services/Gigya";
import { memeberValidate,getMassOffers } from "@services/Mulesoft";
import { fetchHeaderData } from "../api/header";
import { fetchOffersData } from "../api/offers";
import { fetchMyOffers } from "../api/myOffres";
import { fetchHomeNewData } from "../api/homenew";
import { fetchMassOffers } from "../api/massOffers";
import { Loader } from "@templates";
import WithLoginPage from "@templates/PageWithLogin";
import PageEmailOffers from "@templates/PageEmailOffers";
import { useRouter } from 'next/router';
import { USER_AUTH } from "@redux/actions/authActions";
import {BannerCodes,defaultStores} from "@util/banners";
import { Flash } from '@templates/ErrorNotifaction';
interface Props {
  headerData: Record<any, any>;
  newPageData:Record<any, any>;
  offerPageData?: Record<any, any>;
  myOffers?: Record<any, any>;
  massOffers?: Record<any, any>;
  host?: Record<any, any>;
}
const Offers: React.FC<Props> = (props: Props) => {
  const Auth = useSelector((state: RootStateOrAny) => state.auth);
  const Banner = useSelector((state: RootStateOrAny) => state.banner);
  const dispatch = useDispatch();
  const [userLogin, setuserLogin] = React.useState(false);
  const [emailLogin, setEmailLogin] = React.useState(false);
  const [emailLoginCard, setEmailLoginCard] = React.useState(null);
  const [defaultBanner, setDefaultBanner] = React.useState(null);
  const router = useRouter();
  const { locale } = router;
  //@ts-ignore

  const loginCallBack = (response) => {
    if (response?.profile && response?.response?.status === "OK") {
      setuserLogin(response?.profile);
    }
  };
  const updateCallBack = (response) => {
    console.log(response, "==== register");
  };
  const handleOnLogout = (response) => {
    setuserLogin(null);
  };
  const onLogout = () => {
    removeCookies(`personOffersUniqueId`, { path: '/', domain: `${process.env.NEXT_PUBLIC_COOKIE_DOMAIN}` });
    setuserLogin(null);
    dispatch({
      type: USER_AUTH,
      payload: {
        user: [],
      },
    });
  };
  /***
   * To check the hash exists or not
   */
  const handleEmailLogin = (hash) => {
    if (hash) {
      memeberValidate(hash as string).then((data) => {
        if (data?.error) {
          globalThis.flash(`The link has expired, please sign in to view your current offers.`, "danger");
        
          const timer = setTimeout(() => {
            router.push('/');
          }, 3000);
          return () => clearTimeout(timer);
        }
        else {
         
          setEmailLoginCard(data?.cardNumber);
          setEmailLogin(true);
          setuserLogin(null);
        }
      })
    }
    
  }
 

  React.useEffect( () => {

    const timer = setTimeout( async() => {

      const getAccountInfoResponse = (response) => {
        if (response.status === "OK") {
          if(router?.query?.hash){
            GigyaLogout(onLogout);
            handleEmailLogin(router?.query?.hash);
          }
          else{
            setuserLogin(true);
          }

         
        }
        else{
          if(router?.query?.hash){
            handleEmailLogin(router?.query?.hash);
          }
          else{
            /***
             * Check if region is added in the url
             */
            if(router?.query?.region && defaultStores[(router?.query?.region as string)?.toLocaleLowerCase()] != undefined)
            {
              gigyaLoginFn({value:(router?.query?.region as string)?.toLocaleLowerCase(),langauge:locale});
            }
             /***
             * Check if banner exists in local storage
             */
            else if(Banner){
             gigyaLoginFn({value:JSON.parse(localStorage.getItem("banner")),langauge:locale});
            }
            /***
             * Assign the default value during login
             */
            else{
             gigyaLoginFn({value:(props?.host?.defaultRegion) ? props?.host?.defaultRegion : 'Ontario',langauge:locale});
            }
          }
        }
      /****
           * Set the banner id 
           */
       if(router?.query?.banner && BannerCodes.indexOf(router?.query?.banner as string) !== -1){
        setDefaultBanner(router?.query?.banner);
      }
      else{
        setDefaultBanner("MYO");
      }
      };
       
      if (GigyaObject != undefined) {
       if(gigyaLoggedIn() != undefined && gigyaLoggedIn() !=''){
        let status = {
          status:"OK"
      }
      getAccountInfoResponse(status);
       }
       else{
        GigyaObject.accounts.getAccountInfo({
          callback: getAccountInfoResponse,
          });
       }


        // if(router?.query?.banner){
        //   GigyaObject.accounts.getAccountInfo({
        //     callback: getAccountInfoResponse,
        //     });
        // }
        // else{
        //   if(gigyaLoggedIn()){
        //     let status = {
        //         status:"OK"
        //     }
        //     getAccountInfoResponse(status);
        //   }
        //   else{
        //     let status = {
        //         status:"false"
        //       }
        //     getAccountInfoResponse(status);
        //   }
        // }
       
      }
    }, 3000);
    return () => clearTimeout(timer);
  }, [router?.query]);
  

  return (
    <>
    {!emailLogin ? (<>
      {userLogin ? (<WithLoginPage headerData={props?.headerData} offerPageData={props?.offerPageData} myOffers={props?.myOffers} domainFilters={props?.host} defaultBanner={defaultBanner} massoffers={props?.massOffers?.data}/>
    ):(<><Loader/><Flash/></>)}</>):(<PageEmailOffers cardNumber={emailLoginCard} headerData={props?.headerData} domainFilters={props?.host} offerPageData={props?.offerPageData} myOffers={props?.myOffers} host={props?.host} defaultBanner={defaultBanner} massoffers={props?.massOffers?.data}/>)}
    </>
      
  );
};
export default Offers;

export const getStaticProps: GetStaticProps = async ({locale}) => {
  const [headerData, offerPageData, myOffers,newPageData,massOffers] = await Promise.all([
    fetchHeaderData(locale),
    fetchOffersData(locale),
    fetchMyOffers(locale),
    fetchHomeNewData(locale),
    //fetchMassOffers(locale)
    []
  ]);
  let notFoundPage = false;
  if (!newPageData || !headerData) {
    notFoundPage = true;
  }

  return {
    notFound:notFoundPage,
    props: {
      headerData,
      offerPageData,
      myOffers,
      massOffers,
      newPageData
    },
   revalidate: 7776000,
  };
};
