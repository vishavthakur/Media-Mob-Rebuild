import React from "react";
import { useForm, Controller } from "react-hook-form";
import { GetStaticProps } from "next";
import ReCAPTCHA from "react-google-recaptcha";
import { useRouter } from "next/router";
import { css } from "@emotion/css";
import { Input, TextArea, Row, Col, Container, Text } from "@components";
import { Header, Footer, InnerBanner, SeoMeta, SkipTarget } from "@templates";
import { fetchHeaderData } from "../api/header";
import { fetchContactUsData } from "../api/contactUs";
import parse from "html-react-parser";
import { fetchOffersData } from "../api/offers";
import {DevContact} from "@templates/ContactUs/dev";
import {ProdContact} from "@templates/ContactUs/prod";
import {StgContact} from "@templates/ContactUs/stg";
import styles from "@styles/contactus.module.scss";
interface Props {
  headerData: Record<any, any>;
  pageData: Record<any, any>;
  popupData: Record<any, any>;
  host?: Record<any, any>;
}

const Home: React.FC<Props> = (props: Props) => {
  const router = useRouter();
  const headerData = props?.headerData;
  const pageData = props?.pageData;
  return (
    <>
      <Header headerData={headerData} offerData={props?.popupData} host={props?.host} />
      <SeoMeta 
      title={pageData?.acf_tru_seometa?.[0]?.blockdata?.[0]?.browserList?.[process?.env?.NEXT_PUBLIC_GIGYA_BRAND]?.title}
      description={pageData?.acf_tru_seometa?.[0]?.blockdata?.[0]?.browserList?.[process?.env?.NEXT_PUBLIC_GIGYA_BRAND]?.browserMetaDescription}
      keywords={pageData?.acf_tru_seometa?.[0]?.blockdata?.[0]?.browserList?.[process?.env?.NEXT_PUBLIC_GIGYA_BRAND]?.browserMetaKeywords}
      />
      {pageData?.acf_tru_inner_header[0] &&
        <InnerBanner
          title={pageData?.acf_tru_inner_header[0]?.blockdata[0]?.titles[0]}
        />
      }
      {/* <SkipTarget /> */}
      <>
      {/* <div className={styles.ContactUs + " py-18 contact-us"} aria-label="inner-form" role="form">
        <Container size="lg">
          <>
            <div className="DefaultForm">
              <Row alignItems="flex-start">
                <Col xs={12} md={8}>
                  {pageData?.acf_tru_inner_header[0] &&
                    <div className={styles.TopHeaderText}>
                      <p>
                      {
                       pageData?.acf_tru_inner_header[0]?.blockdata[0]
                          ?.description
                      }
                      </p> 
                    </div>
                  }
                  {Success ? (<div className="thankyouMessage">
                    <h3>Your comment / inquiry was successfully submitted. Thank You! </h3>
                  </div>) : (``)}
                  <form
                    method="POST"
                    id="form1"
                    action="https://sobeys--preprod.my.salesforce.com/servlet/servlet.WebToCase?encoding=UTF-8"
                    onSubmit={handleSubmit(onSubmit)}
                  >
                     <Row>
                    <Col xs={12} sm={6} md={6} lg={6}>
                        <div className="ContactSelect" id="start-of-content">
                          <Controller
                            name={issueType}
                            control={control}
                            rules={{
                              required: "Issue Type is required.",
                            }}
                            render={({ field }) => (
                             
                              <select
                                id="00N1U00000UlXjp"
                                style={{}}
                                title="Issue type"
                                className={css`
                                    border: 1px solid
                                      ${errors[issueType]?.message
                                    ? "#dc3545!important"
                                    : "#f1f1f1"};
                                  `}
                            
                                {...field}
                                onChange={handleInputChange}
                                aria-required="true"
                              >
                                 <option value="">Select Issue Type* </option>
                                 <option value="In-Store Purchase">In-Store Purchase</option>
                                <option value="Online Purchase">Online Purchase</option>
                                <option value="Available Offers">Available Offers</option>
                                <option value="Loyalty Account">Loyalty Account</option>
                                <option value="Loyalty Points">Loyalty Points</option>
                                <option value="Loyalty Card">Loyalty Card</option>
                                <option value="General Inquiries">General Inquiries</option>
                                </select>
                            )}
                          />
                          {errors[issueType] && (
                            <span className="SelectErrorMessage" tabIndex={0}>
                              {errors[issueType].message}
                            </span>
                          )}
                        </div>
                      </Col>
                      <Col xs={12} sm={6} md={6} lg={6}>
                        <div className="ContactSelect">
                          <Controller
                            name={subType}
                            control={control}
                            rules={{
                              required: "Sub Type is required.",
                            }}
                            render={({ field }) => (
                              <select
                                id="00N1U00000VsCWh"
                                style={{}}
                                title="Sub type"
                                className={css`
                                    border: 1px solid
                                      ${errors[subType]?.message
                                    ? "#dc3545!important"
                                    : "#f1f1f1"};
                                  `}
                                {...field}
                                onChange={handleInputChange}
                                aria-required="true"
                              >
                                 <option value="">Select Sub Type* </option>
                                 {subTypeList?.map((listSub,index) => <option key={`sub_type_${index}`} value={listSub}>{listSub}</option>)}
                                </select>
                            )}
                          />
                          {errors[subType] && (
                            <span className="SelectErrorMessage" tabIndex={0}>
                              {errors[subType].message}
                            </span>
                          )}
                        </div>
                      </Col>
                    </Row>
                    <>
                    
                    {(secondStep[0] && secondStep[1] && !contactText) && (<>
                      <Row>
                      <Col xs={12} sm={6} md={6} lg={6}>
                        <Controller
                          name={firstNameSale}
                          control={control}
                          rules={{
                            required: "First name is required.",
                          }}
                          render={({ field }) => (
                            <Input
                              type="text"
                              id="00N1U00000VsCWE"
                              className="form-control"
                              placeholder="First Name*"
                              onKeyUp={formatInput}
                              aria-required="true"
                              errorMessage={
                                errors[firstNameSale] &&
                                errors[firstNameSale].message
                              }
                              {...field}
                            />
                          )}
                        />
                 
                      </Col>
                      <Col xs={12} sm={6} md={6} lg={6}>
                        <Controller
                          name={lastNameSale}
                          control={control}
                          rules={{
                            required: "Last name is required.",
                          }}
                          render={({ field }) => (
                            <Input
                              type="text"
                              id="00N1U00000VsCWL"
                              className="form-control"
                              aria-required="true"
                              placeholder="Last Name*"
                              onKeyUp={formatInput}
                              errorMessage={
                                errors[lastNameSale] &&
                                errors[lastNameSale].message
                              }
                              {...field}
                            />
                          )}
                        />
                      </Col>
                    </Row>
                    <Row>
                      <Col xs={12} sm={6} md={6} lg={6}>
                        <Controller
                          name="email"
                          control={control}
                          rules={{
                            required: "Email is required.",
                            pattern: {
                              value:
                                /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                              message: "Please enter the valid email address.",
                            },
                          }}
                          render={({ field }) => (
                            <Input
                              type="email"
                              isRequired={false}
                              id="email"
                              className="form-control"
                              aria-required="true"
                              placeholder="Email*"
                              onKeyUp={inputChange}
                              errorMessage={
                                errors["email"] && errors["email"].message
                              }
                              {...field}
                            />
                          )}
                        />
                      </Col>
                      <Col xs={12} sm={6} md={6} lg={6}>
                        <Controller
                          name="phone"
                          control={control}
                          rules={{
                            required: "Phone number is required.",
                            pattern: {
                              value: /^[0-9\b]+$/,
                              message: "Please enter the valid phone number",
                            },
                            maxLength: {
                              value: 10,
                              message: "Max 10 numbers are allowed.",
                            },
                          }}
                          render={({ field }) => (
                            <Input
                              type="text"
                              id="phone"
                              className="form-control"
                              onKeyUp={handleNumberChange}
                              aria-required="true"
                              placeholder="Phone*"
                              errorMessage={
                                errors["phone"] && errors["phone"].message
                              }
                              {...field}
                            />
                          )}
                        />
                      </Col>
                    </Row>

                    <Row>
                      <Col xs={12} sm={6} md={6} lg={6}>
                        <div className="ContactSelect">
                          <Controller
                            name={provinceSale}
                            control={control}
                            rules={{
                              required: "Province is required.",
                            }}
                            render={({ field }) => (
                              <select
                                id="00N1U00000VsApl"
                                style={{}}
                                title="Province"
                                aria-required="true"
                                className={css`
                                    border: 1px solid
                                      ${errors[provinceSale]
                                    ? "#dc3545!important"
                                    : "#f1f1f1"};
                                  `}
                                {...field}
                              >
                                <option value="">Select Province* </option>
                                <option value="AB">AB</option>
                                <option value="BC">BC</option>
                                <option value="MB">MB</option>
                                <option value="NB">NB</option>
                                <option value="NL">NL</option>
                                <option value="NS">NS</option>
                                <option value="NT">NT</option>
                                <option value="NU">NU</option>
                                <option value="ON">ON</option>
                                <option value="PE">PE</option>
                                <option value="QC">QC</option>
                                <option value="SK">SK</option>
                                <option value="YT">YT</option>
                                <option value="NF">NF</option>
                              </select>
                            )}
                          />
                          {errors[provinceSale] && (
                            <span className="SelectErrorMessage" tabIndex={0}>
                              {errors[provinceSale].message}
                            </span>
                          )}
                        </div>
                      </Col>
                      <Col xs={12} sm={6} md={6} lg={6}>
                        <div className="ContactSelect">
                          <Controller
                            name={bannerSale}
                            control={control}
                            rules={{
                              required: "Banner is required.",
                            }}
                            render={({ field }) => (
                              <select
                                id="00N1U00000VsCW7"
                                style={{}}
                                title="Banner"
                                aria-required="true"
                                className={css`
                                    border: 1px solid
                                      ${errors[bannerSale]
                                    ? "#dc3545!important"
                                    : "#f1f1f1"};
                                  `}
                                {...field}
                              >
                                 <option value="">Select Banner* </option>
                                <option value="Voila">Voila</option>
                                <option value="Sobeys">Sobeys</option>
                                <option value="Safeway">Safeway</option>
                                <option value="Thrifty Foods">Thrifty Foods</option>
                                <option value="Foodland">Foodland</option>
                                <option value="IGA West">IGA West</option>
                                <option value="IGA">IGA</option>
                                <option value="FreshCo">FreshCo</option>
                                <option value="Chalo">Chalo</option>
                                <option value="Lawtons">Lawtons</option>
                                <option value="Rachelle Berry">Rachelle Bery</option>
                                <option value="Tradition">Tradition</option>
                                <option value="Needs (Fast Fuel)">Needs (Fast Fuel)</option>
                                <option value="Sobeys Liquor">Sobeys Liquor</option>
                                <option value="Safeway Liquor">Safeway Liquor</option>
                                <option value="Thrifty Foods Liquor">Thrifty Foods Liquor</option>
                              </select>
                            )}
                          />
                          {errors[bannerSale] && (
                            <span className="SelectErrorMessage" tabIndex={0}>
                              {errors[bannerSale].message}
                            </span>
                          )}
                        </div>
                      </Col>

                    </Row>
                   
                    <Row>

                      <Col xs={12} sm={6} md={6} lg={6}>
                        <div className="ContactSelect">
                          <Controller
                            name={languageSale}
                            control={control}
                            rules={{
                              required: "Language is required.",
                            }}
                            render={({ field }) => (
                              <select
                                id="00N1U00000VsCWK"
                                style={{}}
                                title="Banner"
                                aria-required="true"
                                className={css`
                                  border: 1px solid
                                    ${errors[languageSale]
                                    ? "#dc3545!important"
                                    : "#f1f1f1"};
                                `}
                                {...field}
                              >
                                <option value="">Select Language*</option>
                                <option value="English">English</option>
                                <option value="French">French</option>
                              </select>
                            )}
                          />
                          {errors[languageSale] && (
                            <span className="SelectErrorMessage" tabIndex={0}>
                              {errors[languageSale].message}
                            </span>
                          )}
                        </div>
                      </Col>
                      <Col xs={12} sm={6} md={6} lg={6}>
                        <Controller
                          name="subject"
                          control={control}
                          rules={{
                            required: "Subject is required.",
                          }}
                          render={({ field }) => (
                            <Input
                              type="text"
                              id="subject"
                              placeholder="Subject*"
                              className="form-control"
                              aria-required="true"
                              onKeyUp={formatInput}
                              errorMessage={
                                errors["subject"] && errors["subject"].message
                              }
                              {...field}
                            />
                          )}
                        />
                      </Col>
                    </Row>
                    <Row>
                      <Col xs={12}>
                        <Controller
                          name="description"
                          control={control}
                          rules={{
                            required: "Description is required.",
                          }}
                          render={({ field }) => (
                            <TextArea
                              minRows={10}
                              resize="none"
                              aria-label="Description"
                              aria-required="true"
                              className="form-control"
                              placeholder="Description*"
                              errorMessage={
                                errors.description &&
                                errors.description.message
                              }
                              {...field}
                            />
                          )}
                        />
                      </Col>
                    </Row>
                    <div className={`captcha-outer`}>
                      <ReCAPTCHA
                        ref={recaptchaRef}
                        sitekey={`${process.env.NEXT_PUBLIC_GOOGLE_RECAPTCHA_SITEKEY}`}
                        onChange={RecaptchaChange}
                        onExpired={RecaptchaExpired}
                        onErrored={RecaptchaExpired}
                        aria-label="captcha"
                      />
                    </div>
                    <input
                      type="submit"
                      value="Submit"
                      disabled={!recaptchaValid || !isValid}
                      className="themeBtn"
                      aria-label="Contact Us"
                      id="contact_us"
                      data-gmt="contact_us"
                      tabIndex={0}
                    />
                    </>)}
                    {(secondStep[0] && secondStep[1] && contactText) &&  (<p tabIndex={0} className="QueryContact">Please reach out directly to the_ LP (TBD) for support with this query. You can reach them at +URL+</p>)}
                    </>
                    <input
                      type="hidden"
                      defaultValue="00D1F000000d7a0"
                      {...register("orgid")}
                    />
                    <input
                      type="hidden"
                      defaultValue="LP"
                      id="00N1U00000UlXji"
                      {...register("00N1U00000UlXji")}
                    />
                    <input
                      type="hidden"
                      defaultValue={`${process.env.NEXT_PUBLIC_CONTACT_REDIRECTURL}`}
                      {...register("retURL")}
                    />
                    <input
                      type="hidden"
                      defaultValue={0}
                      {...register("debug")}
                    />
                    <input
                      type="hidden"
                      defaultValue={""}
                      {...register("debugEmail")}
                    />
                    <input
                      type="hidden"
                      id="recordType"
                      defaultValue={"0121U000000jvAVQAY"}
                      {...register("recordType")}
                    />
                    <input
                      type="hidden"
                      id="external"
                      defaultValue={"1"}
                      {...register("external")}
                    />
                    <input
                      type="hidden"
                      defaultValue={(recaptchaValue) ? recaptchaValue : `{"keyname":"MapleContactUsForm","fallback":"true","orgId":"00D1F000000d7a0","ts":""}`}
                      {...register("captcha_settings")}
                    />
                
                  </form>
                </Col>
                <Col xs={12} md={4}>
                  <div className={styles.sidebar}>
                    {pageData?.acf_tru_content_editor[0] && pageData?.acf_tru_content_editor[0]?.blockdata.map(
                      (data, index) => {
                        return (
                          <div className={styles.SidebarContent} key={`contact_sidebar${index}`}>
                            {data.title && <Text as="h2">{data.title}</Text>}
                            {data.description && (
                              <Text as="div">{parse(data.description)}</Text>
                            )}
                          </div>
                        );
                      }
                    )}
                  </div>
                </Col>
              </Row>
            </div>
          </>

        </Container>
      </div> */}
      </>
      {process?.env?.NEXT_PUBLIC_APP_ENV === "prod"?(<><ProdContact pageData={pageData}/></>):((process?.env?.NEXT_PUBLIC_APP_ENV === "stg")?(<StgContact pageData={pageData}/>):(<DevContact pageData={pageData}/>))}
      <Footer footerData={headerData} />
    </>
  );
};
export default Home;

export const getStaticProps: GetStaticProps = async ({locale}) => {
  const [headerData, pageData, popupData] = await Promise.all([
    fetchHeaderData(locale),
    fetchContactUsData(locale),
    fetchOffersData(locale)
  ]);
  if (!headerData || !pageData || !popupData) {
    return {
      notFound: true,
    };
  }

  return {
    props: {
      headerData,
      pageData,
      popupData
    },
    revalidate: 7776000,
  };
};
