import React from "react";
import { GetStaticProps } from "next";
import {
  MorePlacesToEarn,
  MoreWithEveryShop,
  ReedemForGreatRewards,
} from "@templates/ExploreScene";
import { Header, Footer, DarkInnerBanner, SkipTarget, SeoMeta } from "@templates";
import { fetchExploreSceneData } from "../api/exploreScene";
import { fetchHeaderData } from "../api/header";
import { fetchOffersData } from "../api/offers";
import {getLocalregion} from "@util/helpers";
interface Props {
  headerData: Record<any, any>;
  pageData: Record<any, any>;
  popupData: Record<any, any>;
  host?: Record<any, any>;
}

const ExploreScene: React.FC<Props> = (props: Props) => {
  const headerData = props?.headerData;
  const pageData = props?.pageData;
  const BlackbreadCrumbList = pageData?.acf_tru_inner_header[0].blockdata;
  const truCardsHeading = pageData?.acf_tru_heading;
 const HeadingBodyPostion1 = props?.pageData?.acf_tru_heading?.find((e) => e.position === 'body_section_1');
 const HeadingBodyPostion2 = props?.pageData?.acf_tru_heading?.find((e) => e.position === 'body_section_2');
 const HeadingBodyPostion3 = props?.pageData?.acf_tru_heading?.find((e) => e.position === 'body_section_3');
  const truRewardsCardList = props?.pageData?.acf_tru_cards?.[0]?.blockdata;
  const truRewardsCardRegionalisation = props?.pageData?.acf_tru_cards?.[0]?.card_regionalization??[];
  const brandsProductSlider =
    props?.pageData?.acf_tru_product_slider?.[0]?.blockdata;
    const brandsProductRegionalisation =
    props?.pageData?.acf_tru_product_slider?.[0]?.card_regionalization??[];
  const truInformationBanner = props?.pageData?.acf_tru_cards?.[1]?.blockdata;
  const truInformationRegionalisation = props?.pageData?.acf_tru_cards?.[1]?.card_regionalization??[];
  return (
    <>
      <Header headerData={headerData} offerData={props?.popupData} host={props?.host}/>
      <SeoMeta 
      title={pageData?.acf_tru_seometa?.[0]?.blockdata?.[0]?.browserList?.[process?.env?.NEXT_PUBLIC_GIGYA_BRAND]?.title}
      description={pageData?.acf_tru_seometa?.[0]?.blockdata?.[0]?.browserList?.[process?.env?.NEXT_PUBLIC_GIGYA_BRAND]?.browserMetaDescription}
      keywords={pageData?.acf_tru_seometa?.[0]?.blockdata?.[0]?.browserList?.[process?.env?.NEXT_PUBLIC_GIGYA_BRAND]?.browserMetaKeywords}
      />
      <DarkInnerBanner aria-label="breadcrumb" role="navigation" BlackbreadCrumbList={BlackbreadCrumbList} />
      <SkipTarget />
      {truRewardsCardList  && <MoreWithEveryShop
        truCardsHeading={HeadingBodyPostion1}
        truRewardsCardList={truRewardsCardList}
        regionalisation = {truRewardsCardRegionalisation}
      />}
     {brandsProductSlider && <MorePlacesToEarn
        truCardsHeading={HeadingBodyPostion2}
        brandsProductSlider={brandsProductSlider}
        regionalisation={brandsProductRegionalisation}
      />}
     {truInformationBanner  &&  <ReedemForGreatRewards
        truCardsHeading={HeadingBodyPostion3}
        truInformationBanner={truInformationBanner}
        regionalisation={truInformationRegionalisation}
      />}
     {headerData && <Footer footerData={headerData} />}
    </>
  );
};
export default React.memo(ExploreScene);

export const getStaticProps: GetStaticProps = async ({locale}) => {
  const [headerData, pageData, popupData] = await Promise.all([
    fetchHeaderData(locale),
    fetchExploreSceneData(locale),
    fetchOffersData(locale),
  ]);
  if (!headerData || !pageData || !popupData) {
    return {
      notFound: true,
    };
  }

  return {
    props: {
      headerData,
      pageData,
      popupData,
    },
    revalidate: 7776000,
  };
};
