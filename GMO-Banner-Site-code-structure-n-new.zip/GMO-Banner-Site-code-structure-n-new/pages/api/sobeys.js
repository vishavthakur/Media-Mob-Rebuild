export default async function handler(req, res) {
    try {
        let headers = { 
            "Content-Type": "application/json"
        };
       const data = await makeRequest(req?.query?.url, "GET", headers);
       res.status(200).json(data);
    } catch (error) {
       console.error(error);
       res.status(400).json(error)
    }
}
async function makeRequest(url,method,headers)
{
  try {
    // let bodyData = {};
    let requestParams = {
        method: method,
        headers,
    }
   try{
  const res = await fetch(`${url}`, requestParams);
 if(res.status === 200){
   return {
     "success":true,
     "error":""
   }
 }
  res.status;
   }
   catch (Exception){
     return {
      "success":false,
       "error":Exception.message
     };
   }
}
catch (error) {
    console.error(error);
  }
}
