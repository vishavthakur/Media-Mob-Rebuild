import  {getCookie,setCookies} from 'cookies-next'
export default async function handler(req, res) {
 
  if(req.headers['origin']?.match(process.env.NEXT_PUBLIC_COOKIE_DOMAIN)){
     try {
      let tokenData =  await createUserToken({req, res});
     // console.log(tokenData,"==== token data");
       let headers = { "Content-Type": "application/json" };
       let token = tokenData;
       if(token){
        headers['Authorization'] = `Bearer ${token}`
       }
       if (req.headers['accept-language'])
       {
        headers['Accept-Language'] = req.headers['accept-language'];
       }
       const data = await makeRequest(req.headers['mulesofturl'], req.headers['method'], headers, req.body);
       //return res;
       res.status(200).json(data)
   }
   catch (error) {
       console.error(error);
       res.status(400).json(error)
     }
    }
    else{
      res.status(403).json({'msg':'Forbidden'});
    }
}
async function makeRequest(url,method,headers,body)
{
  try {
    let bodyData = {};
    if (url === "sobeys-oauth-e-api/v1/oauth/token") {
      bodyData = {
          "clientId": `${process.env.NEXT_PUBLIC_MOULESOFT_CLIENTID}`,
          "clientSecret": `${process.env.NEXT_PUBLIC_MOULESOFT_CLIENTSECRET}`,
          "scope": `${process.env.NEXT_PUBLIC_MOULESOFT_SCOPE}`,
          "grantType": `${process.env.NEXT_PUBLIC_MOULESOFT_GRANTTYPE}`,
      }
  }
  else{
    bodyData = body;
  }
  let requestParams = {
    method: method,
      headers,
  }
  if(method !== 'GET') {
    requestParams.body = JSON.stringify(bodyData);
  }
  const res = await fetch(`${process.env.NEXT_PUBLIC_MOULESOFT_BASEURL}${url}`, requestParams);
    // process.exit(1);
    try{
    const json = await res.json();
    if (json.errors) {
        console.error(json.errors);
        throw new Error("Failed to fetch API");
    }

    return json;
  }
  catch (error){
    console.log(error.message);
  }
}
catch (error) {
    console.error(error);
  }
}

/**** 
 * @function createUserToken
 * To create the token
 */
 export async function createUserToken({ req, res }) {
  try {
    let authtoken = getCookie('bmo_tif',{ req, res});
    
    if (authtoken) {
      return Buffer.from(authtoken, 'base64').toString('ascii');
    }
    try {
      const headers = { "Content-Type": "application/json"};
      const resToken = await makeRequest('sobeys-oauth-e-api/v1/oauth/token', "POST", headers, {
        
      });
      if (resToken?.access_token) {
        setCookies(`bmo_tif`, Buffer.from(resToken?.access_token).toString('base64'), { req, res, maxAge: 60 * 10 ,sameSite:true});
        return resToken?.access_token;
      }
      else {
        return JSON.stringify({ "error": true, "message": "please check your credentials" })
      }
    }
    catch (error) {
      console.error(error);
    }
  }
  catch (error) {
    console.error(error);
  }
}