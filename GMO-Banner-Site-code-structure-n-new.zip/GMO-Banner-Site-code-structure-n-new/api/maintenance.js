import { fetchAPI } from "@util/fetchAPI";
import { serverLogs } from "@util/serverLogs";
export const fetchMaintainData = async (context) => {
  serverLogs('Fetch data from maintenance page api started');
    const data = await fetchAPI(
        `
        query MyQuery {
          pageSlug(slug: "maintenance-page",bannerType:"sobeys", lang: "${context}")
        }
        `,
  );
  serverLogs('Fetch data from maintenance page api finished');
    return data;
};
