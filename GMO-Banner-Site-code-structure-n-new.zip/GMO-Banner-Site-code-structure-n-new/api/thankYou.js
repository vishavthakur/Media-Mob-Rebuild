import { fetchAPI } from "@util/fetchAPI";
import { serverLogs } from "@util/serverLogs";
export const thankYouData = async (context) => {
  serverLogs('Fetch data from thank you api started');
    const data = await fetchAPI(
        `
        query MyQuery {
          pageSlug(slug: "thankyou/${process.env.NEXT_PUBLIC_SLUG_WP}/" bannerType:"sobeys",lang: "${context}")
        }
        `,
  );
  serverLogs('Fetch data from thank you api finished');
    return data;
};
