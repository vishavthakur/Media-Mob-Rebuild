import { fetchAPI } from "@util/fetchAPI";
import { serverLogs } from "@util/serverLogs";
export const fetchHomeNewData = async (context) => {
    serverLogs('Fetch data from home api started');
    const data = await fetchAPI(
        `query MyQuery {
            pageSlug(slug: "home/${process.env.NEXT_PUBLIC_SLUG_WP}", bannerType: "sobeys", lang: "${context}")
          }
          `,
    );
    serverLogs('Fetch data from home api finished');
    return data;

};