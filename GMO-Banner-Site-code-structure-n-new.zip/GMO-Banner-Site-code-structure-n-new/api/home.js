import { fetchAPI } from "@util/fetchAPI";
import { serverLogs } from "@util/serverLogs";
export const fetchHomeData = async (context) => {
    serverLogs('Fetch data from home api started');
    const data = await fetchAPI(
        `query MyQuery {
            pageSlug(slug: "home-page",bannerType:"sobeys", lang: "${context}")
          }
          `,
    );
    serverLogs('Fetch data from home api finished');
    return data;
};