import { fetchAPI } from "@util/fetchAPI";
import { serverLogs } from "@util/serverLogs";
export const fetchExploreSceneData = async (context) => {
    serverLogs('Fetch data from explore scene api started');
    const data = await fetchAPI(
        `query MyQuery {
            pageSlug(slug: "explore-scene/${process.env.NEXT_PUBLIC_SLUG_WP}", bannerType: "sobeys", lang: "${context}")
          }
          `,
    );
    serverLogs('Fetch data from explore scene api end');
    return data;
};