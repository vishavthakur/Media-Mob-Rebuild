import { fetchAPI } from "@util/fetchAPI";
import { serverLogs } from "@util/serverLogs";
export const verifyCardData = async (context) => {
  serverLogs('Fetch data from verify card api started');
    const data = await fetchAPI(
        `
        query MyQuery {
          pageSlug(slug: "verify-card" bannerType:"sobeys",lang: "${context}")
        }
        `,
  );
  serverLogs('Fetch data from verify card api finished');
    return data;
};
