import { fetchAPI } from "@util/fetchAPI";
import { serverLogs } from "@util/serverLogs";
export const fetchMassOffers = async (context) => {
  serverLogs('Fetch data from mass offers api started');
let token = await createToekn();
if(token?.access_token){
  let data = await fetchData(token?.access_token);
  return data;
}
 else{
   return {};
 } 
};
async function createToekn(){
  var myHeaders = new Headers();
myHeaders.append("Content-Type", "application/json");

var raw = JSON.stringify({
  "clientId": process.env.NEXT_PUBLIC_MOULESOFT_CLIENTID,
  "clientSecret": process.env.NEXT_PUBLIC_MOULESOFT_CLIENTSECRET,
  "scope": process.env.NEXT_PUBLIC_MOULESOFT_SCOPE,
  "grantType": process.env.NEXT_PUBLIC_MOULESOFT_GRANTTYPE
});

var requestOptions = {
  method: 'POST',
  headers: myHeaders,
  body: raw,
  redirect: 'follow'
};

let res = await fetch(`${process.env.NEXT_PUBLIC_MOULESOFT_BASEURL}sobeys-oauth-e-api/v1/oauth/token`, requestOptions);
const json = await res.json();
if (json.errors) {
    console.error(json.errors);
    throw new Error("Failed to fetch API");
}

return json;

}

async function fetchData(token){
  var myHeaders = new Headers();
myHeaders.append("Content-Type", "application/json");
myHeaders.append("Authorization", `Bearer ${token}`);
myHeaders.append("Accept-Language", "en-CA");
var raw = JSON.stringify({
  "clientId": process.env.NEXT_PUBLIC_MOULESOFT_CLIENTID,
  "clientSecret": process.env.NEXT_PUBLIC_MOULESOFT_CLIENTSECRET,
  "scope": process.env.NEXT_PUBLIC_MOULESOFT_SCOPE,
  "grantType": process.env.NEXT_PUBLIC_MOULESOFT_GRANTTYPE
});

var requestOptions = {
  method: 'GET',
  headers: myHeaders,
  redirect: 'follow'
};

let res = await fetch(`${process.env.NEXT_PUBLIC_MOULESOFT_BASEURL}sobeys-ecommstatic-e-api/v1/cms/content/slide?banner=gmo&storeId=4761&slideType=Hero Mass Offer`, requestOptions);
const json = await res.json();
if (json.errors) {
    console.error(json.errors);
    throw new Error("Failed to fetch API");
}

return json;

}