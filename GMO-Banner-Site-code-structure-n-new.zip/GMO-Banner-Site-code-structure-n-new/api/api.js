const API_URL = process.env.NEXT_PUBLIC_WORDPRESS_SITE_API;

async function fetchAPI(query, { variables } = {}) {
    const headers = { "Content-Type": "application/json" };

    const res = await fetch(API_URL, {
        method: "POST",
        headers,
        body: JSON.stringify({
            query,
            variables,
        }),
    });

    // process.exit(1);
    const json = await res.json();
    if (json.errors) {
        console.error(json.errors);
        throw new Error("Failed to fetch API");
    }

    return json.data;
}

export const fetchAPIFromURL = async (URL = "") => {
    const headers = { "Content-Type": "application/json" };

    // if (process.env.WORDPRESS_AUTH_REFRESH_TOKEN) {
    //   headers[
    //     "Authorization"
    //   ] = `Bearer ${process.env.WORDPRESS_AUTH_REFRESH_TOKEN}`;
    // }
    // console.log(API_URL);
    const res = await fetch(URL, {
        method: "POST",
        headers,
        // body: JSON.stringify({
        //     query,
        //     variables,
        // }),
    });

    // process.exit(1);
    const json = await res.json();
    if (json.errors) {
        console.error(json.errors);
        throw new Error("Failed to fetch API");
    }

    return json.data;
};
