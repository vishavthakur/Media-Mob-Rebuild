import { fetchAPI } from "@util/fetchAPI";
import { serverLogs } from "@util/serverLogs";
export const fetchPrivacyPolicyData = async (context) => {
  serverLogs('Fetch data from privacy policy api started');
    const data = await fetchAPI(
        `query MyQuery {
          pageSlug(slug: "privacy-policy", bannerType:"sobeys",lang: "${context}")
        }
        `,
  );
  serverLogs('Fetch data from privacy policy api finished');
    return data;
};
