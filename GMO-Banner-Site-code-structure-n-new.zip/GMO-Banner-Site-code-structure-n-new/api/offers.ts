import { fetchAPI } from "@util/fetchAPI";
import { serverLogs } from "@util/serverLogs";
export const fetchOffersData = async (context) => {
  serverLogs('Fetch data from offers product api started');
    const data = await fetchAPI(
        `
        query MyQuery {
          pageSlug(slug: "offer-modals/${process.env.NEXT_PUBLIC_SLUG_WP}/",bannerType:"sobeys",lang: "${context}")
        }
        `,
  );
  serverLogs('Fetch data from offers product api finished');
  return data;
  
};
