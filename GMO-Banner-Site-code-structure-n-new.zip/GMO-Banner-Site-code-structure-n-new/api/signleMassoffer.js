import { fetchAPI } from "@util/fetchAPI";
import { serverLogs } from "@util/serverLogs";
export const fetchMassOfferTerms = async (slug,lang) => {
  serverLogs('Fetch data from mass offers terms and conditions page api started');
    const data = await fetchAPI(
        `
        query MyQuery {
          pageSlug(slug: "${slug}",bannerType:"sobeys", lang: "${lang}")
        }
        `,
  );
  serverLogs('Fetch data from maintenance page api finished');
    return data;
};
