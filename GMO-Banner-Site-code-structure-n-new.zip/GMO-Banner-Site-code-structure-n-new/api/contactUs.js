import { fetchAPI } from "@util/fetchAPI";
import { serverLogs } from "@util/serverLogs";
export const fetchContactUsData = async (context) => {
  serverLogs('Fetch data from contact us api started');
    const data = await fetchAPI(
        `
        query MyQuery {
          pageSlug(slug: "contact-us",bannerType:"sobeys", lang: "${context}")
        }
        `,
  );
  serverLogs('Fetch data from contact us api finished');
    return data;
};
