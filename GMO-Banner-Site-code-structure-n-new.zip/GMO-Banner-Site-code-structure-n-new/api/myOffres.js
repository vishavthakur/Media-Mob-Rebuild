import { fetchAPI } from "@util/fetchAPI";
import { serverLogs } from "@util/serverLogs";
export const fetchMyOffers = async (context) => {
  serverLogs('Fetch data from my offers api started');
    const data = await fetchAPI(
        `
        query MyQuery {
          pageSlug(slug: "my-offers/${process.env.NEXT_PUBLIC_SLUG_WP}/",bannerType:"sobeys", lang: "${context}")
        }
        `,
  );
  serverLogs('Fetch data from my offers api finished');
    return data;
};
