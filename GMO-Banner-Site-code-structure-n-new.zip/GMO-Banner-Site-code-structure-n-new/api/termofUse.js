import { fetchAPI } from "@util/fetchAPI";
import { serverLogs } from "@util/serverLogs";
export const fetchTermofUseData = async (context) => {
  serverLogs('Fetch data from term of use api started');
    const data = await fetchAPI(
        `query MyQuery {
          pageSlug(slug: "terms-of-use",bannerType:"sobeys",lang: "${context}")
        }
        `,
  );
  serverLogs('Fetch data from term of use api finished');
    return data;
};
