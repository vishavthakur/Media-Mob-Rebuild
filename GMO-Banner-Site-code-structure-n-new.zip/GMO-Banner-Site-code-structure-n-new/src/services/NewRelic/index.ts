/****************New Relic********************/
/*****Added the New Relic Browser agent for client-side actions*****/
/*********
    This API call sends a browser PageAction event with your user-defined name and optional attributes to dashboards which is useful to track any event that is not already tracked automatically by the browser agent, such as clicking a Subscribe button or accessing a tutorial.
**********/

// @ts-ignore
export const newrelic = global?.window?.newrelic;
// What - Set Custom Attribute
// When - When a user logs in, it would trigger this event
export function setCustomAttribute(webGuid) {
    if(newrelic != undefined){
    newrelic.setCustomAttribute("webGUID", webGuid);
    }
}

// What - Set Banner and Region
// When - When application sets banner and region, it would trigger this event
export function setBannerRegion(webGuid, status) {
    if(newrelic != undefined){
    setCustomAttribute(webGuid);
    newrelic.addPageAction("setBannerRegion",{
        "status": status,
        "promiseTime": new Date().toDateString()
    });
}
}

// What - Banner and Region update
// When - When application updates banner and region, it would trigger this event
export function updateBannerRegion(webGuid, status, banner='') {
    if(newrelic != undefined){
    setCustomAttribute(webGuid);
    newrelic.addPageAction("updateBannerRegion",{
        "status": status,
        "promiseTime": new Date().toDateString(),
        "region": banner
    });
}
}

// What - Display a prompt 
// When - When application displays a prompt, it would trigger this event
export function promptDisplay(webGuid, status, promptName) {
    if(newrelic != undefined){
    setCustomAttribute(webGuid);
    newrelic.addPageAction("promptDisplay",{
        "status": status,
        "promiseTime": new Date().toDateString(),
        "promptName": promptName
    });
}
}

// What - Dismiss prompt 
// When - When application dismisses a prompt, it would trigger this event
export function promptDismiss(webGuid, status, promptName) {
    if(newrelic != undefined){
    setCustomAttribute(webGuid);
    newrelic.addPageAction("promptDismiss",{
        "status": status,
        "promiseTime": new Date().toDateString(),
        "promptName": promptName
    });
}
}

// What - Remind Later Prompt
// When - When application sets a remind later prompt, it would trigger this event
export function promptRemindLater(webGuid, status, promptName) {
    if(newrelic != undefined){
    setCustomAttribute(webGuid);
    newrelic.addPageAction("promptRemindLater",{
        "status": status,
        "promiseTime": new Date().toDateString(),
        "promptName": promptName
    });
}
}

// What - Account verification initiation
// When - When application initiates account verification process, it would trigger this event
export function accountVerificationInitiated(webGuid, status) {
    if(newrelic != undefined){
    setCustomAttribute(webGuid);
    newrelic.addPageAction("accountVerificationInitiated",{
        "status": status,
        "promiseTime": new Date().toDateString()
    });
}
}

// What - Verification code submission
// When - When verification code is submitted to the application, it would trigger this event
export function accountCodeSubmitted(webGuid, status) {
    if(newrelic != undefined){
    setCustomAttribute(webGuid);
    newrelic.addPageAction("accountCodeSubmitted",{
        "status": status,
        "promiseTime": new Date().toDateString()
    });
}
}

// What - Account verification success
// When - When application successfully verifies the account, it would trigger this event
export function accountVerified(webGuid, status) {
    if(newrelic != undefined){
    setCustomAttribute(webGuid);
    newrelic.addPageAction("accountVerified",{
        "status": status,
        "promiseTime": new Date().toDateString()
    });
}
}

// What - Enrolment status (enquire API status code)
// When - When application enquires for an enrolment, it would trigger this event
export function enquireEnrolment(webGuid, status, enrolmentStatusCode='') {
    if(newrelic != undefined){
    setCustomAttribute(webGuid);
    newrelic.addPageAction("enquireEnrolment",{
        "status": status,
        "promiseTime": new Date().toDateString(),
        "enrolmentStatusCode": enrolmentStatusCode
    });
}
}

// What - Points Balance (Request)
// When - When application requests for points' balance, it would trigger this event
export function pointsRequest(webGuid, status) {
    if(newrelic != undefined){
    setCustomAttribute(webGuid);
    newrelic.addPageAction("pointsRequest",{
        "status": status,
        "promiseTime": new Date().toDateString()
    });
}
}

// What - Points Balance (Response)
// When - When application sends a response for points' balance, it would trigger this event
export function pointsResponse(webGuid, status, points='') {
    if(newrelic != undefined){
    setCustomAttribute(webGuid);
    newrelic.addPageAction("pointsResponse",{
        "status": status,
        "promiseTime": new Date().toDateString(),
        "points": points,
    });
}
}

// What - Load offers' events
// When - When application loads offers, it would trigger this event
export function loadOffers(webGuid, status, daysRange, offerStatus, language, pendingOffersCount=0, pendingOffersIds=[], activeOffersCount=0, activeOffersIds=[], redeemedOffersCount=0, redeemedOffersIds=[], expiredOffersCount=0, expiredOffersIds=[]) {
    if(newrelic != undefined){
        setCustomAttribute(webGuid);
        newrelic.addPageAction("getOffers",{
            "status": status,
            "promiseTime": new Date().toDateString(),
            "daysRange": daysRange,
            "offerStatus": offerStatus,
            "language": language,
            "pendingOffersCount": pendingOffersCount,
            "pendingOffersIds": pendingOffersIds,
            "activeOffersCount": activeOffersCount,
            "activeOffersIds": activeOffersIds,
            "redeemedOffersCount": redeemedOffersCount,
            "redeemedOffersIds": redeemedOffersIds,
            "expiredOffersCount": expiredOffersCount,
            "expiredOffersIds": expiredOffersIds
        });    
    }
}
// What - Load member pending offers' events
// When - When application loads members' pending offers, it would trigger this event
export function loadMemberPendingOffers(webGuid, status, daysRange, offerStatus, language, offersCount=0, offersIds=[]) {
    if(newrelic != undefined){
        setCustomAttribute(webGuid);
        newrelic.addPageAction("loadOffers",{
            "status": status,
            "promiseTime": new Date().toDateString(),
            "daysRange": daysRange,
            "offerStatus": offerStatus,
            "language": language,
            "offersCount": offersCount,
            "offersIds": offersIds
        });   
    }
}