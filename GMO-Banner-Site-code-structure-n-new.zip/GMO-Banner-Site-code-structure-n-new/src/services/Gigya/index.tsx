import React from "react";
import styled from '@emotion/styled';
import { useRouter } from 'next/router';
import { getCookie } from 'cookies-next';
import { useSelector, RootStateOrAny } from 'react-redux';
import { Regions } from "@util/banners";
import { Loader } from "@templates"

interface gigyaInterface {
     screenId: string;
     startScreen: string,
     loginCallback?: (e) => void,
     id: string;
     redirectURL?: string;
     overrideStyle?: React.CSSProperties;
     css?: any;
     className?: string;

}
var locale = 'en-ca'; // Global scope for lang used in Gigya screensets

/**
 * @function GigyaObject
 * To return the gigya from window object
 */

//@ts-ignore
export const GigyaObject = global.window?.gigya;
/**
 * @function Gigya
 * To get all the props and return the component
 */

 export const GigyaScreen = ({...props}:gigyaInterface) => {
     const { locale } = useRouter();
     const sitelanguage = (locale==="en")?"en-ca":locale;
     const loginCallback = (login) => {
          loginCallback;
     }
     const Container = styled.div(
          ({ overrideStyle }: gigyaInterface) => ({
               position: "relative",
               width: "100%",
               ...overrideStyle,
          }),
     );

     React.useEffect(() => {
          if (GigyaObject != undefined) {
               if(props.loginCallback){
                    GigyaObject.accounts.showScreenSet({ startScreen: props.startScreen, screenSet: props.screenId, onAfterSubmit: props.loginCallback, containerID: props.id, lang:sitelanguage,context: { region: 'ontario', brand: process.env.NEXT_PUBLIC_GIGYA_BRAND ,locale:sitelanguage} });
               }
               else{
                    GigyaObject.accounts.showScreenSet({ startScreen: props.startScreen, screenSet: props.screenId, containerID: props.id, lang:sitelanguage,context: { region: 'ontario', brand: process.env.NEXT_PUBLIC_GIGYA_BRAND ,locale:sitelanguage} });
               }
          }

     })

     return (
          <>
               <Container id={props.id} {...props}><Loader /></Container>
          </>
     );
}

const areEqual = (prevProps, nextProps) => true;
export const Gigya = React.memo(GigyaScreen,areEqual);
/**** Gigya account *****/

/**
 * @function GigyaLogin
 * To login into the gigya
 */

export const GigyaLogin = (bannerRegion: { value: string,langauge?:string;gl?:string }) => {
     const sitelanguage = (bannerRegion?.langauge==="en")?"en-ca":bannerRegion?.langauge;
     //@ts-ignore
     var gaLinker = decorateUrl();
     //@ts-ignore
     var glLinker = glDecorateUrl();
     GigyaObject.sso.login({
          authFlow: process.env.NEXT_PUBLIC_GIGYA_AUTHFLOW,
          context: { brand: process.env.NEXT_PUBLIC_GIGYA_BRAND, flow: 'login', ga: gaLinker, region: (bannerRegion?.value) ? Regions[bannerRegion?.value] : Regions[process.env.NEXT_PUBLIC_DEFAULT_REGION],locale:sitelanguage,gl:glLinker }
     });
}

/**
 * @function GigyaRegister
 * To register into the gigya
 */
export const GigyaRegister = (bannerRegion: { value: string ,langauge?:string, gl?:string;}) => {
     const sitelanguage = (bannerRegion?.langauge==="en")?"en-ca":bannerRegion?.langauge;
     //@ts-ignore
     var gaLinker = decorateUrl();
     //@ts-ignore
     var glLinker = glDecorateUrl();
     GigyaObject.sso.login({
          authFlow: process.env.NEXT_PUBLIC_GIGYA_AUTHFLOW,
          //redirectURL:`${process.env.NEXT_PUBLIC_REGISTER_REDIRECT_DOMAIN}`,
          context: { brand: process.env.NEXT_PUBLIC_GIGYA_BRAND, region: (bannerRegion?.value) ? Regions[bannerRegion?.value] : Regions['ontario'], flow: 'register', ga: gaLinker,locale:sitelanguage, gl:glLinker }
     });
}

/**
 * @function GigyaLogout
 * To logout from the gigya
 */
export const GigyaLogout = (callBack) => {
     if (GigyaObject != undefined) {
          GigyaObject.accounts.logout({
               callback: callBack,
          });
     }
}

/**
 * @function GigyaValidate
 * To validate the gigya session
 */
export const GigyaValidate = (callBack) => {
     if (GigyaObject != undefined) {
          GigyaObject.accounts.getAccountInfo({ callback: callBack })
     }
}

/***
 * @function checkRolledOut
 */
export const checkRolledOut = (defaultRegion) => {
     let banner_provience = JSON.parse(localStorage.getItem("banner")) ?? "ontario";
     if (banner_provience && GigyaObject != undefined) {
       let rolled_region = defaultRegion?defaultRegion:GigyaObject?.thisScript?.globalConf?.ELM_REGIONS;
       if (rolled_region?.indexOf(Regions[banner_provience]) === -1 && rolled_region != Regions[banner_provience] && banner_provience) {
            return false;
       } else {
            return true;
       }
     }
}

/****
 * Check gigya session is valid or not
 */
export const gigyaLoggedIn = ()=> (getCookie(`glt_${process.env.NEXT_PUBLIC_GIGYA_KEY}`));

