import { ReactJSXElement } from "@emotion/react/types/jsx-namespace";
import parse from "html-react-parser";
import { Text } from "@components";
import dynamic from 'next/dynamic';
import Image from "@templates/ImageConversion";
const OfferType11 = dynamic(() => import('@templates/Offers/OfferType11'))
const OfferType12 = dynamic(() => import('@templates/Offers/OfferType12'))
const OfferType13 = dynamic(() => import('@templates/Offers/OfferType13'))
const OfferType14 = dynamic(() => import('@templates/Offers/OfferType14'))
const OfferType15 = dynamic(() => import('@templates/Offers/OfferType15'))
const OfferType16 = dynamic(() => import('@templates/Offers/OfferType16'))
const OfferType17 = dynamic(() => import('@templates/Offers/OfferType17'))
const OfferType18 = dynamic(() => import('@templates/Offers/OfferType18'))
const OfferType19 = dynamic(() => import('@templates/Offers/OfferType19'))
const OfferType20 = dynamic(() => import('@templates/Offers/OfferType20'))
const OfferType21 = dynamic(() => import('@templates/Offers/OfferType21'))
const OfferType22 = dynamic(() => import('@templates/Offers/OfferType22'))
const OfferType23 = dynamic(() => import('@templates/Offers/OfferType23'))
const OfferType24 = dynamic(() => import('@templates/Offers/OfferType24'))
const OfferType25 = dynamic(() => import('@templates/Offers/OfferType25'))
const OfferType26 = dynamic(() => import('@templates/Offers/OfferType26'))
const OfferType27 = dynamic(() => import('@templates/Offers/OfferType27'))
interface bannerImages {
     bannerInd: string;
     regionalFlag?: string;
}
interface bannerProgress {
     progress: number;
     limit?: number;
}
/****
    * @function getImageName to get the image from url
    * @param urlImage type string
    */
export const getImageName = (urlImage: string) => {
     if (urlImage.indexOf('amd-cdn.azureedge.net') != -1) {
          return urlImage;
     }
     else if (urlImage.indexOf('amdcdnstg.azureedge.net') != -1) {
          return urlImage;
     }
     else if (urlImage.indexOf('amdcdnaka.azureedge.net') != -1) {
          return urlImage;
     }
     else {
          return `/offers/images/${urlImage}`;
     }
}
/***
 * @function GetBannerImage get logo of the banners
 * @param bannerInd type string
 * @param regionalFlag type string
 */
export const GetBannerImage = ({ bannerInd, regionalFlag }: bannerImages) => {
     //    bannerInd="AB";
     //    regionalFlag = "Atlantic";
     let output = "";
     let output1 = "";
     let j = 0;
     for (let i = 0; i <= bannerInd.length - 1; i++) {
          let code = bannerInd.substr(i, 1);
          let store_name = "";
          let store_alt = "";
          let store_name1 = "";

          switch (code) {
               case "A":
                    store_name = "sobeys";
                    store_alt = "Sobeys-Logo";
                    break;
               case "B":
                    //          & bannerInd.indexOf("A")>=0
                    if (regionalFlag == "Atlantic") {
                         store_name1 = "foodland_coop";
                         j++;
                    }
                    store_name = "foodland";
                    store_alt = "foodland-Logo";
                    break;
               case "C":
                    store_name = "safeway";
                    store_alt = "Safeway-Logo";
                    break;
               case "D":
                    store_name = "iga";
                    store_alt = "iga-Logo";
                    break;
               case "E":
                    store_name = "thrifty_foods";
                    store_alt = "thriftyfood-Logo";
                    break;
               case "F":
                    store_name = "sobeys_liquor";
                    store_alt = "sobeysliquor-Logo";
                    break;
               case "G":
                    store_name = "safeway_liquor";
                    store_alt = "Safewayliquor-Logo";
                    break;
               case "H":
                    store_name = "freshco";
                    store_alt = "freshco-Logo";
                    break;
               case "I":
                    store_name = "lawtons";
                    store_alt = "lawtons-Logo";
                    break;
               case "J":
                    store_name = "thrifty_foods_liquor";
                    store_alt = "thriftyfoods-Logo";
                    break;
               default:
                    break;
          }
          // //console.log(store_name);


          // if (store_name.length > 0) {
          //      output += `<span class='banner_item ${store_name} group_${bannerInd.length}'><Image alt='${store_alt}' src='${`https://dev.getmyoffers.ca/wp-content/plugins/sobeys-gmo-integration/assets/images/offer_store_logo/${store_name}_${bannerInd.length}.png`}' layout="fill"/></span>`;
          //      output1 += `<span class='banner_item ${store_name} group_${(bannerInd.length + 1)}'><Image alt='${store_alt}' src='${`https://dev.getmyoffers.ca/wp-content/plugins/sobeys-gmo-integration/assets/images/offer_store_logo/${store_name}_${(bannerInd.length + 1)}.png`}' layout="fill"/></span>`;
          // }

          // if (store_name1.length > 0) {
          //      output += `<span class='banner_item ${store_name1} group_${bannerInd.length}'><Image alt='${store_alt}' src='${`https://dev.getmyoffers.ca/wp-content/plugins/sobeys-gmo-integration/assets/images/offer_store_logo/${store_name1}_${bannerInd.length}.png`}' layout="fill"/></span>`;
          //      output1 += `<span class='banner_item ${store_name1} group_${(bannerInd.length + 1)}'><Image alt='${store_alt}' src='${`https://dev.getmyoffers.ca/wp-content/plugins/sobeys-gmo-integration/assets/images/offer_store_logo/${store_name1}_${(bannerInd.length + 1)}.png`}' layout="fill"/></span>`;
          // }
          if (store_name.length > 0) {
               output += `<span tabindex="0" class='banner_item ${store_name} group_${bannerInd.length}'><Image alt='${store_alt}' src='${`/banner-images/${store_name}.svg`}' layout="fill"/></span>`;
               output1 += `<span tabindex="0" class='banner_item ${store_name} group_${(bannerInd.length + 1)}'><Image alt='${store_alt}' src='${`/banner-images/${store_name}.svg`}' layout="fill"/></span>`;
          }

          if (store_name1.length > 0) {
               output += `<span tabindex="0" class='banner_item ${store_name1} group_${bannerInd.length}'><Image alt='${store_alt}' src='${`/banner-images/${store_name1}.svg`}' layout="fill"/></span>`;
               output1 += `<span tabindex="0" class='banner_item ${store_name1} group_${(bannerInd.length + 1)}'><Image alt='${store_alt}' src='${`/banner-images/${store_name1}.svg`}' layout="fill"/></span>`;
          }

     };
     if (j > 0)
          return <>{parse(output1)}</>;
     else
          return <>{parse(output)}</>;
}
/**** Get number of days in offer expire
 * @function getNumberOfDays
 * @param end type string end date of the offer
 * 
 *****/
export const getNumberOfDays = (end: string) => {
     const date1 = new Date(new Date().toLocaleString('en-US', {
          timeZone: "Canada/Eastern"
        }));
     const date2 = new Date(end);
     // One day in milliseconds
     const oneDay = 1000 * 60 * 60 * 24;
     // Calculating the time difference between two dates
     const diffInTime = date2.getTime() - date1.getTime();

     // Calculating the no. of days between two dates
     const diffInDays = Math.round(diffInTime / oneDay);
     return diffInDays;
};

/******
 * To return the expired days 
 */
export const expiredDaysOffers = (days:number,date:any,dateFull:any) => {
     try{
          const dateoffer = new Date(dateFull).toLocaleDateString();
          const datetoday = new Date().toLocaleDateString();
          if(days < 0){
               if(Math.abs(days) === 1){
                    return Math.abs(days)+" day ago"; 
               }
               else{
                     return Math.abs(days)+" days ago"; 
               }
          }
          else{
               if(days > 1){
                    return days+" days left";
               }
              else{
               if(days === 0 && dateoffer === datetoday){
                  
                    return "Expires Today"; 
               }
               else if(days === 0 && dateoffer != datetoday){
                    return "Expired Today";     
               }
               else{
                    return Math.abs(days)+" day left"; 
               }
                  
              }
          }

}
catch (exception){
     console.log(exception);
}

}

/**** Get date from date string
 * @function getDate
 * @param datestring type string
 ******/

export const getDate = (dateString: string) => {
     const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sept", "Oct", "Nov", "Dec"];
     const date = new Date(new Date(dateString).toLocaleString('en-US', {
          timeZone: "Canada/Eastern"
        }));
     const dateShort = months[date.getMonth()] + " " + ('0' + date.getDate()).slice(-2);
     const dateFull = ("0" + (date.getMonth() + 1)).slice(-2) + "/" + ('0' + date.getDate()).slice(-2) + "/" + (date.getFullYear().toString().substr(-2));
     return { dateShort, dateFull }
}
/**** switch offer on the type of the offer
 * @function SwitchOfferType
 * @param allProps all props of the product
 * @param type type of the offer
 ******/
export const SwitchOfferType = ({ allProps, type }) => {
     switch (type) {
          case "11":
               return (<OfferType11 {...allProps} termsText={`Terms & Conditions`} />);
              
          case "12":
               return (<OfferType12 {...allProps} termsText={`Terms & Conditions`} />);
          case "13":
               return (<OfferType13 {...allProps} termsText={`Terms & Conditions`} />);
           
          case "14":
               return (<OfferType14 {...allProps} termsText={`Terms & Conditions`} />);
         
          case "15":
               return (<OfferType15 {...allProps} termsText={`Terms & Conditions`} />);
             
          case "16":
               return (<OfferType16 {...allProps} termsText={`Terms & Conditions`} />);
              
          case "17":
               return (<OfferType17 {...allProps} termsText={`Terms & Conditions`} />);
              
          case "18":
               return (<OfferType18 {...allProps} termsText={`Terms & Conditions`} />);
       
          case "19":
               return (<OfferType19 {...allProps} termsText={`Terms & Conditions`} />);
           
          case "20":
               return (<OfferType20 {...allProps} termsText={`Terms & Conditions`} />);
        
          case "21":
               return (<OfferType21 {...allProps} termsText={`Terms & Conditions`} />);
            
          case "22":
               return (<OfferType22 {...allProps} termsText={`Terms & Conditions`} />);
     
          case "23":
               return (<OfferType23 {...allProps} termsText={`Terms & Conditions`} />);
         
          case "24":
               return (<OfferType24 {...allProps} termsText={`Terms & Conditions`} />);
             
          case "25":
               return (<OfferType25 {...allProps} termsText={`Terms & Conditions`} />);
           
          case "26":
               return (<OfferType26 {...allProps} termsText={`Terms & Conditions`} />);
         
          case "27":
               return (<OfferType27 {...allProps} termsText={`Terms & Conditions`} />);
           
          default:
               return (<div></div>);
               
     }
}

/****
 *@function GetProgressBarHtml
 * @param progress type number
 * @param limit type number
 */

export const GetProgressBarHtml = ({ progress, limit }: bannerProgress): ReactJSXElement => {
     let data = '';
     for (var i = 1; i <= limit; i++) {
          data += `<span className=${(progress >= i) ? 'active' : 'inactive'}></span>`;
     };
     return (<Text as="div" className="offersCardBrandMultiUseIndicator">{parse(data)} <Text as="span">{(limit - progress)} uses left</Text></Text>);
}
export const GetTransactionLimitHtml = ({ progress, limit }: bannerProgress): ReactJSXElement => {
     let data = '';
     for (var i = 1; i <= limit; i++) {
          data += `<span className=${(progress >= i) ? 'active' : 'inactive'}></span>`;
     };
     return (<Text as="div" className="offersCardBrandMultiUseIndicator">{parse(data)} <Text as="span">Transaction Limit {progress} of {limit} </Text></Text>);
}

export const SplitAmount = function({amount}) {
     var res = amount.replace("$", "");
     res = res*100;
     res = parseInt(res)+"";
     var dollar = parseInt(res.substr(0, res.length-2)) > 0 ? parseInt(res.substr(0, res.length-2)) : 0;
     var cent = parseInt(res.slice(-2)) > 0 ? parseInt(res.slice(-2)) : 0;
     //convert from 0 to 00
     if (cent == 0) {
       cent = 0;
     }
     if(dollar > 0)
     {
          return (<><span className='before'>$</span><span className='data'>{dollar}</span><span className="after">.{(cent == 0)?'00':cent}</span></>
          )
     }
     else{
          return (<><span className="before"></span><span className='data'>{cent}</span><span className='after'>¢</span>
          </>)
     }
     //return {dollar: dollar, cent: cent};
 }