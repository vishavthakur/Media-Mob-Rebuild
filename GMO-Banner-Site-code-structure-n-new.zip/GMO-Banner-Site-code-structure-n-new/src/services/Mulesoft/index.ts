import { setCookies, getCookie, removeCookies } from 'cookies-next';
import {getLocalregion} from "@util/helpers"
import {defaultStoresProvience} from "@util/banners";
import { ChevronsUp } from 'react-feather';

/**** 
 * @function linkAccount
 * @param cardNumber type string
 * @param memberUniqueId type string
 * To link the new user account
 */
export async function linkAccount(cardNumber: string, memberUniqueId: string) {
  //const token = await createUserToken();
  const headers = { "Content-Type": "application/json", "method": "POST", "mulesoftUrl": "sobeys-digital-e-api/v1/member/linkAccount" };
  const res = await makeRequest('/api/mulesoftrequest', "POST", headers, {
    "cardNumber": cardNumber,
    "memberUniqueId": memberUniqueId,
  });
  if (res?.error?.error?.details) {
    await checkTokenValid(res?.error?.error?.details[0].target)
   }
  return checkResponseStatus(res);
}

/**** 
 * @function verifyCode
 * @param accountVerificationCode type string
 * @param memberUniqueId type string
 * To validate the otp
 */
export async function verifyCode(accountVerificationCode: string, memberUniqueId: string) {
  //const token = await createUserToken();
  const headers = { "Content-Type": "application/json", "method": "POST", "mulesoftUrl": "sobeys-digital-e-api/v1/member/verifyCode" };
  const res = await makeRequest('/api/mulesoftrequest', "POST", headers, {
    "accountVerificationCode": accountVerificationCode,
    "memberUniqueId": memberUniqueId,
  });
  if (res?.error?.error?.details) {
    await checkTokenValid(res?.error?.error?.details[0].target)
   }
   return checkResponseStatus(res);
}

/**** 
* @function resendCode
* @param memberUniqueId type string
* To resend the otp
*/
export async function resendCode(memberUniqueId: string) {
  //const token = await createUserToken();
  const headers = { "Content-Type": "application/json", "method": "POST", "mulesoftUrl": "sobeys-digital-e-api/v1/member/resendCode" };
  const res = await makeRequest('/api/mulesoftrequest', "POST", headers, {
    "memberUniqueId": memberUniqueId,
  });
  if (res?.error?.error?.details) {
    await checkTokenValid(res?.error?.error?.details[0].target)
   }
   return checkResponseStatus(res);
}

/**** 
* @function accountHistory
* @param memberUniqueId type string
* @param storeName type string
* @param dollarFlag type bollean
* To get the member history
*/
export async function accountHistory(memberUniqueId: string | string[], storeName: string, dollarFlag?: boolean) {
  //const token = await createUserToken();
  const headers = { "Content-Type": "application/json", "method": "POST", "mulesoftUrl": "sobeys-digital-e-api/v1/member/history/lite" };
  const res = await makeRequest('/api/mulesoftrequest', "POST", headers, {
    "memberUniqueId": memberUniqueId,
    "storeName": storeName,
    "dollarFlag": dollarFlag
  });
  if (res?.error?.error?.details) {
    await checkTokenValid(res?.error?.error?.details[0].target)
   }
   return checkResponseStatus(res);
}

/**** 
* @function accountStatus
* @param cardNumber type string
* To get the account status
*/
export async function accountStatus(cardNumber: string,bypassCheck?:string) {
  //const token = await createUserToken();
  const headers = { "Content-Type": "application/json", "method": "POST", "mulesoftUrl": "sobeys-digital-e-api/v1/member/inquire" };
  const res = await makeRequest('/api/mulesoftrequest', "POST", headers, {
    "cardNumber": cardNumber,
  });
  if (res?.error?.error?.details) {
    await checkTokenValid(res?.error?.error?.details[0].target)
   }
   if(bypassCheck === "true"){
     return {enrollmentStatusCode: 'LP01'};
   }
   else{
   return checkResponseStatus(res);
   }
}

/***
 *@function memeberValidate 
 *@param hash hash url of uid
 */
export async function memeberValidate(hash:string) {
  //const token = await createUserToken();
  const headers = { "Content-Type": "application/json", "method": "POST", "mulesoftUrl": "sobeys-ecommstatic-e-api/v1/banners/validateMember" };
  const res = await makeRequest('/api/mulesoftrequest', "POST", headers, {
    "emailOfferUniqueIdentifier": hash,
  });
  if (res?.error?.error?.details) {
    await checkTokenValid(res?.error?.error?.details[0].target)
   }
   return checkResponseStatus(res);
}
/****
 *@function getMemberOffers
 *@param cardNumber type string
 *@param daysRange type number 
 *@param offerStatus type of offers PENDING | ACTIVE | REDEEMED | EXPIRED
 *@param language type string 
 */
export async function getMemberOffers(cardNumber: string, daysRange: Number, offerStatus: string, language: string) {
  //const token = await createUserToken();
  let offersPayload = null;
  if (offerStatus !== 'all') {
    offersPayload = {
      "cardNumber": cardNumber,
      "daysRange": daysRange,
      "personalizedOfferStatus": offerStatus,
      "preferredLanguage": language

    }
  }
  else {
    offersPayload = {
      "cardNumber": cardNumber,
      "daysRange": daysRange,
      "preferredLanguage": language

    }
  }
  const headers = { "Content-Type": "application/json", "method": "POST", "mulesoftUrl": "sobeys-ecommstatic-e-api/v1/offers/member/all" };
  const res = await makeRequest('/api/mulesoftrequest', "POST", headers, offersPayload);
  if (res?.error?.details) {
    await checkTokenValid(res?.error?.details[0].target)
   }
   return checkResponseStatus(res);
}
/***
 * @function loadMemberOffers
 */
export async function loadMemberOffers(cardNumber: string,offers:[]){
  //const token = await createUserToken();
  const headers = { "Content-Type": "application/json", "method": "PUT", "mulesoftUrl": "sobeys-ecommstatic-e-api/v1/offers/member" };
  let offersPayload = {
    "user_id":"test@test.com",
    "cardNumber": cardNumber,
    "offers": offers
  }
  const res = await makeRequest('/api/mulesoftrequest', "POST", headers, offersPayload);
  if (res?.error?.details) {
    await checkTokenValid(res?.error?.details[0].target)
   }
   return checkResponseStatus(res);
}
/**** 
 * @function createUserToken
 * To create the token
 */
// export async function createUserToken() {
//   return true;
//   try {
//     let authtoken = getCookie('mule_auth_token');
//     if (authtoken) {
//       return authtoken;
//     }
//     try {
//       const headers = { "Content-Type": "application/json", "method": "POST", "mulesoftUrl": "sobeys-oauth-e-api/v1/oauth/token"};
//       const res = await makeRequest('/api/mulesoftrequest', "POST", headers, {
        
//       });
//       if (res?.access_token) {
//         setCookies(`mule_auth_token`, res?.access_token, { path: '/', domain: `${process.env.NEXT_PUBLIC_COOKIE_DOMAIN}`, maxAge: 60 * 10 ,sameSite:true});
//         return res?.access_token;
//       }
//       else {
//         return JSON.stringify({ "error": true, "message": "please check your credentials" })
//       }
//     }
//     catch (error) {
//       console.error(error);
//     }
//   }
//   catch (error) {
//     console.error(error);
//   }
// }

/***
 * @function getMassOffers to get mass offers from wordpress api
 * Get mass offers
 */
 export async function getMassOffers() {
  const region = await getLocalregion();
  const headers = { "Content-Type": "application/json","accept-language":"en-CA", "method": "GET", "mulesoftUrl": "sobeys-ecommstatic-e-api/v1/cms/content/slide?banner="+process.env.NEXT_PUBLIC_MASSOFFER_BANNER+"&storeId="+defaultStoresProvience[region]+"&slideType=Hero Mass Offer" };
  const res = await makeRequest('/api/mulesoftrequest', "POST", headers, '');
  return checkResponseStatus(res);
}
/*****
 * @function makeRequest
 * @param url type string
 * @param method type string
 * @param headers type record<string,string>
 * @param body type json 
 */

export async function makeRequest(url: string, method: string, headers: Record<string, string>, body: Object) {

  try {
    const res = await fetch(`${url}`, {
      method: method,
      headers,
      body: JSON.stringify(body),
    });
    //console.log(await res.json(), "====== response from the api");
    // process.exit(1);
    try{
    const jsonData = await res.json();
    if (jsonData.errors) {
      console.error(jsonData.errors);
      throw new Error("Failed to fetch API");
    }
    else{
    return jsonData;
    }
  }
  catch (e){
    console.log(e.message,"error in api response");
  }
  }
  catch (error) {
    console.error(error);
  }
}
/***
 * 
 */
async function checkTokenValid(res: string) {
  if (res === 'TOKEN_UNAUTHORIZED') {
    
    removeCookies(`mule_auth_token`, { path: '/', domain: `${process.env.NEXT_PUBLIC_COOKIE_DOMAIN}` });
   // router.reload();
    location.reload();
  }
}
/***
 * @function checkResponseStatus
 * To check response not have any internal server error
 */
async function checkResponseStatus(res:Record<any,any>){

if(res?.error?.code === "500" || typeof res !== 'object'){
  res = {
    "error" : {
      "details":[
        {
          "message":"something went wrong"
        }
      ]
    }
  }
}
else{
  res = res
}
return res;
}

/****
 *@function getMemberDetail
 *@param cardNumber type string
 *@param legacy type boolean
 */
 export async function getMemberDetail(cardNumber: string, legacy: Boolean) {
  //const token = await createUserToken();
  let memberPayload = {
      "cardNumber": cardNumber,
      "legacy": legacy,
  }
  
  const headers = { "Content-Type": "application/json", "method": "POST", "mulesoftUrl": "sobeys-ecommstatic-e-api/v1/banners/memberDetail" };
  const res = await makeRequest('/api/mulesoftrequest', "POST", headers, memberPayload);
  if (res?.error?.details) {
    await checkTokenValid(res?.error?.details[0].target)
  }
  if(res?.persoOffersUniqueId) {
    setCookies(`personOffersUniqueId`, res?.persoOffersUniqueId, { path: '/', domain: `${process.env.NEXT_PUBLIC_COOKIE_DOMAIN}`,sameSite:true
  });
  }
   return checkResponseStatus(res);
}