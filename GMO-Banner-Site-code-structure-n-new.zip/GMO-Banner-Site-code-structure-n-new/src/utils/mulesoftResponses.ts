export const responseAccount = {
     'LP00': 'contact',
	'LP02': 'contact',
	'LP03': 'register',
	'LP01': 'verify',
}