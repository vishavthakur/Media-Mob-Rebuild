// @ts-ignore
import { ImageGroup, ImageType } from "./types";
// @ts-ignore
export const extractImageUrlFromImageGroupArray = {
    
};

/**
 * <source
 srcSet={`https://sheridanweb-dev.azurewebsites.net/_next/image?url=https%3A%2F%2Fsheridanwp-dev.azurewebsites.net%2Fwp-content%2Fuploads%2F2021%2F06%2F02-section01-1.webp&w=256&q=75`}
 type="image/webp"
 />

 */
