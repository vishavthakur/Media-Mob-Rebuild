interface dataLayer {
    event?: string,
    event_param?: string;
    param_value?: string
}

export const isObjectEmpty = (obj) => {
    return Object.keys(obj).length === 0;
};
/***
 * To add the Data Layer
 */
export const addDataLayer = ({ event, event_param, param_value }: dataLayer) => {
    //@ts-ignore
    dataLayer.push({
        'event': event,
        'eventParam1': event_param,
        'eventParam2': param_value
    })

}
/****
 * To get the banner id based on the logo name 
 */

export const getBannerId = ({ name }: { name: string }) => {
    switch (name) {
        case "sobeys":
            return "A";
        case "safeway":
            return "C";
        case "foodland":
            return "B";
        case "igawest":
            return "D";
        case "freshco":
            return "H";
        case "thriftyfoods":
            return "E";
        case "iga":
            return "D";
        case "sobeysliquor":
            return "F";
        case "safewayliquor":
            return "G";
        case "thriftyfoodsliquor":
            return "J";
        default:
            return "";
    }
}

export const checkRegionOffers = (host,region) => {
   if(host === "IGAOffers"){
        if(region?.toLowerCase() === "quebec"){
            return true;
        }
        else{
            return false;
        }
   }
   else{
    if(region?.toLowerCase() != "quebec"){
        return true;
    }
    else{
        return false;
    }
   }
}
/***
 * To get region from localstorage
 */

export const getLocalregion = () => {
    
    return typeof window !== 'undefined' ? JSON.parse(localStorage.getItem('banner')) : null
}