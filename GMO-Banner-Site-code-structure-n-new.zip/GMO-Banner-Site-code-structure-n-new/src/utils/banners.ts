export const Regions = {
	'britishcolumbia': 'west',
	'alberta': 'west',
	'saskatchewan': 'west',
	'manitoba': 'west',
	'west': 'west',
	'newfoundlandandlabrador': 'atlantic',
	'newbrunswick': 'atlantic',
	'novascotia': 'atlantic',
	'princeedwardisland': 'atlantic',
	'atlantic': 'atlantic',
	'ontario': 'ontario',
	'quebec': 'quebec'
}

export const RegionsNames = [
	'britishcolumbia',
	'alberta',
	'saskatchewan',
	'manitoba',
	'west',
	'newfoundlandandlabrador',
	'newbrunswick',
	'novascotia',
	'princeedwardisland',
	'atlantic',
	'ontario'
];

export const BannerCodes = [
	"001",
	"004",
	"005",
	"031",
	"033",
	"046",
	"061",
	"063",
	"070",
	"028",
	"072",
	"004"
];

export const defaultStores = {
	'atlantic':'newbrunswick',
	'ontario':'ontario',
	'west':'britishcolumbia',
	'quebec':'quebec'
}
export const defaultStoresProvience = {
	'britishcolumbia': '3038',
	'alberta': '5070',
	'saskatchewan': '4986',
	'manitoba': '3220',
	'newfoundlandandlabrador': '861',
	'newbrunswick': '495',
	'novascotia': '644',
	'princeedwardisland': '628',
	'ontario': '7383',
	'quebec': '4761',
}