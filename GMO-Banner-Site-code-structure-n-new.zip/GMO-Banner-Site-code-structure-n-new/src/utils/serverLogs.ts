export const serverLogs = (text: any) => {
     if (require('fs') != undefined) {
          var fs = require('fs');
          // Data which will write in a file.
          if (process.env.ENABLE_WEBSITE_LOGS === "true") {
               var currentdate = new Date();
               let data = `${text} ${currentdate.getDate() + "/"
                    + (currentdate.getMonth() + 1) + "/"
                    + currentdate.getFullYear() + " @ "
                    + currentdate.getHours() + ":"
                    + currentdate.getMinutes() + ":"
                    + currentdate.getSeconds() + ":" + currentdate.getMilliseconds()}`;
               var currentdate = new Date();
               // Write data in 'Output.txt' .
               fs.appendFile('serverlogs.txt', data + "\n", (err) => {
                    // In case of a error throw err.
                    if (err) throw err;
               })
          }
     }
}