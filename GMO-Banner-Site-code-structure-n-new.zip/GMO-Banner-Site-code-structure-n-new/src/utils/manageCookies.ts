import { setCookies, getCookie, removeCookies } from 'cookies-next';
interface cookieProps{
     type?:string,
     value?: any;
     name?: string;
     counterValue?: any;
}
export const addCookie = ({type,name,value,counterValue}:cookieProps) => {
    
     if (type === "hard")
     {
          setCookies(`counter_${name}`, 4, { path: '/', domain: `${process.env.NEXT_PUBLIC_COOKIE_DOMAIN}`, maxAge: 60 * 60 * 24 * 180,sameSite:true});
          setCookies(name, value, { path: '/', domain: `${process.env.NEXT_PUBLIC_COOKIE_DOMAIN}`, maxAge: 60 * 60 * 24 * 180,sameSite:true });
     }
     else {
         
          setCookies(`counter_${name}`,parseInt(counterValue)+1, { path: '/', domain: `${process.env.NEXT_PUBLIC_COOKIE_DOMAIN}`, maxAge: 60 * 60 * 24 * 180,sameSite:true });
          setCookies(name, value, { path: '/', domain: `${process.env.NEXT_PUBLIC_COOKIE_DOMAIN}`, maxAge: cookieTime(parseInt(counterValue)+1),sameSite:true });     
     }
}

const cookieTime = (value:any) => {
     switch (value)
     {
          case 1:
               return (60 * 60 * 24 * 7);
              
          case 2:
              return (60 * 60 * 24 * 14);
              
          case 3:
              return (60 * 60 * 24 * 30);
              
             
          default:
               return  60 * 60 * 24 * 180;
          
     }
}

export const removeCookie = ({ cookiesRemoved}:{cookiesRemoved:string[]}) => {
     cookiesRemoved?.map((name) => {
          removeCookies(name, {  path: '/', domain: `${process.env.NEXT_PUBLIC_COOKIE_DOMAIN}` })
     })
}