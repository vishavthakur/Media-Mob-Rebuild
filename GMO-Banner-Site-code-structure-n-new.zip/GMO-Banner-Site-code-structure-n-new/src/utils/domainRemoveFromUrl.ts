export const domainRemoveFromUrl = (url:string) => {
    if(!url) return "#!";
    const data = String(url).replace(`${process.env.NEXT_PUBLIC_WORDPRESS_SITE_URL}/wp-content`,'')
      
    return data;
}