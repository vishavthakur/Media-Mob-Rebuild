import { ColorScheme } from "@util/theme";
import { DetailedHTMLProps } from "./types";
export interface PropTypes<T = HTMLDivElement, E = React.ElementType>
    extends Partial<DetailedHTMLProps<T>> {
    /** Disable action and styling **/
    disable?: boolean;

    /** Define Button is of which type i.e Anchor **/
    as?: E;

    /** Theme based color scheme for styling with different colors **/
    colorScheme?: ColorScheme;
}
