import React  from "react";
 const UserTimeGreeting = () => {
  const [greetingText, setGreetingText] = React.useState(null);
  React.useEffect(() => {
    let date = new Date();  
    let hour = date.getHours();
    if (hour < 12) {  
      setGreetingText("Good Morning");  
       } else if (hour < 17) {  
        setGreetingText("Good Afternoon");  
       } else {  
        setGreetingText("Good Evening");  
    }  
  },[])
    
  return (<>{greetingText}</>)
} 
export const UserTime = React.memo(UserTimeGreeting)