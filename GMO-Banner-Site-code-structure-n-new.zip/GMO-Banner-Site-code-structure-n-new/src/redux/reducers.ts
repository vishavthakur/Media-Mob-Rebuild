import counterReducer from './reducers/counterReducer';
import bannerReducer from './reducers/bannerReducer';
import authReducer from './reducers/authReducer';
import accountReducer from './reducers/accountReducer';
import linkageReducer from './reducers/linkageReducer';
import userAccessReducer from './reducers/userAccessReducer';
import { combineReducers } from 'redux';

const rootReducer = combineReducers({
     //counter: counterReducer,
     banner: bannerReducer,
     auth: authReducer,
     account: accountReducer,
     accountLinkage: linkageReducer,
     userAccess:userAccessReducer
});

export default rootReducer;