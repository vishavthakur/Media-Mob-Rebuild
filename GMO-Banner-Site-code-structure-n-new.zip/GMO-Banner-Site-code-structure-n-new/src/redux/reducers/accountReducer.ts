import {USER_ACCOUNT} from '../actions/authActions';

const AccountReducer = (state, { payload, type }) => {
     switch (type) {
          case USER_ACCOUNT:
               return { ...state, value:payload };
         default:
             return {...state};
     }
 };
 
 export default AccountReducer;