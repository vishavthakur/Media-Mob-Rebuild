import {USER_AUTH} from '../actions/authActions';
const AuthReducer = (state, { payload, type }) => {
     switch (type) {
          case USER_AUTH:
               return { ...state, value:payload.user };
         default:
             return {...state};
     }
 };
 
 export default AuthReducer;