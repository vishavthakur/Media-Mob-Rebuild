import {USER_ACCESS} from '../actions/authActions';

const UserAccessReducer = (state, { payload, type }) => {
     switch (type) {
          case USER_ACCESS:
               return { ...state, value:payload };
         default:
             return {...state};
     }
 };
 
 export default UserAccessReducer;