import {BANNER_LOCATION} from '../actions/counterActions';

 const bannerReducer = (state, { payload, type }) => {
    switch (type) {
         case BANNER_LOCATION:
          return { ...state, value:payload.location };
        default:
            return {...state};
    }
};

export default bannerReducer;