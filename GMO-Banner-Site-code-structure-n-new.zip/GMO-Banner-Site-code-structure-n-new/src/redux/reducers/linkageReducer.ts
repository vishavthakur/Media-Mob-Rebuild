import {LINKAGE_ACCOUNT} from '../actions/authActions';

const LinkageReducer = (state, { payload, type }) => {
     switch (type) {
          case LINKAGE_ACCOUNT:
               return { ...state, value:payload };
         default:
             return {...state};
     }
 };
 
 export default LinkageReducer;