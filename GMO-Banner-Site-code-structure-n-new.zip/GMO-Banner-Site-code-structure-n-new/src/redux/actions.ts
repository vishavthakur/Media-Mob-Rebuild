//export { increase, decrease } from "@redux/slices/counter";

export const increase = () => {
     return;
}