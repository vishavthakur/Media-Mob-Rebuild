export const USER_AUTH = "USER_AUTH";
export const USER_ACCOUNT = "USER_ACCOUNT";
export const LINKAGE_ACCOUNT = "LINKAGE_ACCOUNT";
export const USER_ACCESS = "USER_ACCESS";