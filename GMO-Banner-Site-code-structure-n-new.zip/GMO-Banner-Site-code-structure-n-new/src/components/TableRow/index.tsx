import React from "react";
import styled from "@emotion/styled";
import { PropTypes } from "@util/propType";

/**
 * @function EmotionTableRow
 * styled table row
 */
export const EmotionTableRow = styled("tr")((props) => ({
    display: "table-row",
}));

/**
 * @function TableRow
 * To get all the props and return the component
 */
export const TableRow = React.forwardRef<
    HTMLTableRowElement,
    React.PropsWithChildren<Omit<PropTypes<HTMLTableRowElement>, "className">>
>(({ children, ...props }, ref) => {
    return (
        <EmotionTableRow {...props} ref={ref}>
            {children}
        </EmotionTableRow>
    );
});

/**
 * defaultProps - To define default values for component props
 */
TableRow.defaultProps = {
    id: "table-row",
};
