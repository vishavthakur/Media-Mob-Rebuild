import * as React from "react";
import Image from "next/image";
import styled from "@emotion/styled";
import { alpha } from "@util/Theme/colorManipulator";
import { isObjectEmpty } from "@util/assertion";
import { defaultTheme, Theme, useThemeMode } from "src/context/ThemeProvider";
import {
    InputPropType as inputType,
    InputWrapper,
} from "@components/InputWrapper";
import { PropTypes } from "@util/propType";
import classNames from "classnames";
import { fontSizes, spacing } from "@util/units";
import { X } from "react-feather";
import { empty } from "@apollo/client";

interface InputPropType
    extends Omit<
            inputType<"password" | "text" | "email" | "tel">,
            "isChecked" | "ref"
        >,
        Pick<
            PropTypes<HTMLInputElement>,
            "className" | "style" | "colorScheme"
        > {
    /** To add Input border radius **/
    borderRadius?: number;

    /** Caption for the information of field **/
    label?: string;

    /**** Ref for input element */
    ref?: React.Ref<HTMLInputElement>;

    /** Input sizes can be of 3 types: 'sm - small view of Input size' , 'md - medium view of Input size' and 'lg - large view of Input size **/
    size?: "sm" | "md" | "lg";
    maxLength?:number,
}

/**
 * @object InputSizeProps
 * This object is used define the sizes of Input
 */

const InputSizeProps = {
    label: {
        sm: {
            fontSize: fontSizes["sm"],
        },
        md: {
            fontSize: fontSizes["md"],
        },
        lg: {
            fontSize: fontSizes["lg"],
        },
    },
    input: {
        sm: {
            fontSize: fontSizes["xs"],
            padding: `${spacing["xs"]} ${spacing["sm"]}`,
        },
        md: {
            fontSize: fontSizes["sm"],
            padding: `${spacing["sm"]} ${spacing["md"]}`,
        },
        lg: {
            fontSize: fontSizes["md"],
            padding: `${spacing["md"]} ${spacing["lg"]}`,
        },
    },
};

/**
 * @function getPropsByVariant
 * This function is used to pass the color scheme, variant and the emotion theme
 */
const getPropsByVariant = ({ variant, colorScheme, theme }) => {
    const colorInPalette = theme.palette[colorScheme];

    const variants = colorInPalette && {
        outline: {
            main: {
                border: `1px solid ${colorInPalette.main}`,
                backgroundColor: theme.palette.common.transparent,
                color: theme.palette.typography.primary,
                "&::placeholder": {
                    color: theme.palette.typography.primary,
                },
            },
            error: {
                border: `1px solid ${theme.palette.error.main}`,
                color: theme.palette.error.main,
                "&::placeholder": {
                    color: theme.palette.error.main,
                },
            },
        },
        solid: {
            main: {
                border: `1px solid ${colorInPalette.main}`,
                backgroundColor: colorInPalette.main,
                color: colorInPalette.contrastText,
                "&::placeholder": {
                    color: colorInPalette.contrastText,
                },
            },
            error: {
                backgroundColor: theme.palette.error.main,
                color: colorInPalette.contrastText,
                border: "none",
            },
        },

        ghost: {
            main: {
                backgroundColor: alpha(colorInPalette.main, 0.2),
                color: colorInPalette.main,
                border: `1px solid ${alpha(colorInPalette.main, 0.5)}`,
                "&::placeholder": {
                    color: colorInPalette.main,
                },
            },
            error: {
                backgroundColor: alpha(theme.palette.error.main, 0.2),
                border: `1px solid ${theme.palette.error.main}`,
                color: theme.palette.error.main,
                "&::placeholder": {
                    color: theme.palette.error.main,
                },
            },
        },
    };

    return colorInPalette && variants[variant];
};

/**
 * @function StyledInputLabelProps
 * This function that takes all props and theme(passed by the emotion itself) as a argument returns object of its types
 */
type StyledInputLabelProps = {
    theme?: Theme;
    errorMessage?: string|JSX.Element;
} & Partial<InputPropType>;

/**
 * @function StyledInputProps
 * This function that takes all props and theme(passed by the emotion itself) as a argument returns object of its types
 */
type StyledInputProps = {
    theme?: Theme;
    errorMessage?: string|JSX.Element;
} & Partial<InputPropType>;

/**
 * @function StyledInputWrapperProps
 * This function that takes all props and theme(passed by the emotion itself) as a argument returns object of its types
 */
type StyledInputWrapperProps = {
    overrideStyle?: React.CSSProperties;
} & Partial<InputPropType>;

/**
 * @function useColorVariant
 *  This function is use to provide, theme, colorscheme, variant
 */
const useColorVariant = (theme, variant, colorScheme) => {
    if (isObjectEmpty(theme)) {
        theme = defaultTheme;
    }
    return getPropsByVariant({
        variant,
        colorScheme,
        theme,
    });
};

/**
 * @function EmotionInput
 * This function is used to wrap the Inner Item for style
 */
export const EmotionInput = styled(InputWrapper)(
    ({
        theme,
        variant,
        colorScheme,
        errorMessage,
        size,
        ...props
    }: StyledInputProps) => {
        const fontSizeBySize = InputSizeProps?.input[size]?.fontSize;
        const paddingBySize = InputSizeProps?.input[size]?.padding;
        return {
            padding: InputSizeProps.input.md.padding,
            fontSize: InputSizeProps.input.md.fontSize,
            width: "100%",
            paddingRight: props.icon && "25px",
            borderRadius: props.borderRadius,
            outline: "none",
            border: theme.palette.paper.border,
            backgroundColor:
                variant === "solid"
                    ? `${theme.palette.paper.background}`
                    : "transparent",
            color: `${theme.palette.paper.text}`,
            "&:placeholder ": {
                color: `${theme.palette.paper.text}`,
            },
            cursor: props.isReadOnly ? "text" : "default",
            pointerEvents: props.disable && "none",
            ...(colorScheme &&
                useColorVariant(theme, variant, colorScheme).main),
            opacity: props.disable ? "0.5" : "1",
            "&:focus": {
                outline: "none",
            },
            ...(errorMessage && {
                border: `1px solid ${theme.palette.error.main}`,
                color: theme.palette.error.main,
                ...useColorVariant(theme, variant, colorScheme)?.error,
            }),
            ...(paddingBySize && { padding: paddingBySize }),
            ...(fontSizeBySize && { fontSize: fontSizeBySize }),
        };
    },
);

/**
 * @function EmotionInputWrapper
 * This function is used to wrap the Inner Input Items for style
 */
export const EmotionInputWrapper = styled.div(
    ({ overrideStyle }: StyledInputWrapperProps) => ({
        position: "relative",
        width: "100%",
        ...overrideStyle,
    }),
);

/**
 * @function EmotionInputIcon
 * This function is used to wrap the Icon Item for style
 */
export const EmotionInputIcon = styled.div((props) => ({
    position: "absolute",
    top: "50%",
    right: "20px",
    transform: "translateY(-50%)",
    width: "20px",
    display: "flex",
}));

/**
 * @function EmotionErrorInput
 * This function is used to wrap the Inner Input Field for style
 */
export const EmotionErrorInput = styled.div((props: StyledInputProps) => ({
    color: props.theme.palette.error.main,
    fontSize: InputSizeProps?.label[props.size]?.fontSize,
    marginTop: "5px",
}));

/**
 * @function EmotionInputLabel
 * This function is used to wrap the Label Item for style
 */
export const EmotionInputLabel = styled.div(
    ({ theme, errorMessage, size }: StyledInputLabelProps) => {
        return {
            paddingBottom: "10px",
            fontSize: InputSizeProps?.label[size]?.fontSize,
            display: "inline-flex",
            color:
                errorMessage !== ""
                    ? theme.palette.error.main
                    : theme.palette.typography.primary,
        };
    },
);

export const Input = React.forwardRef<
    HTMLInputElement,
    React.PropsWithChildren<InputPropType>
>(
    (
        {
            id,
            errorMessage,
            name,
            value,
            type,
            onChange,
            onKeyUp,
            placeholder,
            isRequired,
            label,
            icon,
            disable,
            className,
            style,
            size,
            maxLength,
            ...props
        },
        ref,
    ) => {
        const { themeMode } = useThemeMode();
        return (
            <EmotionInputWrapper
                className={classNames(className)}
                overrideStyle={style}
            >
                
                    {label && (
                        <EmotionInputLabel
                            size={size}
                            errorMessage={errorMessage}
                        >{`${label}${
                            isRequired ? "*" : ""
                        }`}</EmotionInputLabel>
                    )}
                    <EmotionInputWrapper>
                        <EmotionInput
                            id={id}
                            data-input-error={errorMessage!==""?true:false}
                            ref={ref}
                            value={value}
                            maxLength={maxLength}
                            name={name}
                            type={type}
                            size={size}
                            placeholder={placeholder}
                            isReadOnly
                            disable={disable}
                            onChange={disable ? undefined : onChange}
                            onKeyUp={disable ? undefined : onKeyUp}
                            isRequired={isRequired}
                            errorMessage={errorMessage}
                            {...props}
                        />
                        <EmotionInputIcon>
                            {icon &&
                                (themeMode === "light" ? (
                                    <X size="16px" />
                                ) : (
                                    <X size="16px" color="#fff" />
                                ))}
                            {/* {icon?.image?.mediaItemUrl && (
                                    <Image
                                        id={icon?.id}
                                        src={icon?.image?.mediaItemUrl}
                                        alt={icon?.image?.altText}
                                        width={
                                            icon?.image?.mediaDetails?.width ||
                                            10
                                        }
                                        height={
                                            icon?.image?.mediaDetails?.height ||
                                            10
                                        }
                                        layout="fixed"
                                    />
                                )} */}
                        </EmotionInputIcon>
                    </EmotionInputWrapper>
                    {errorMessage && (
                        <div className="i-error-main" tabIndex={0}>
                            <EmotionErrorInput size={size} className="i-error">
                                {errorMessage}
                            </EmotionErrorInput>
                        </div>
                    )}
                
            </EmotionInputWrapper>
        );
    },
);

/**
 * defaultProps - To define default values for component props
 */
Input.defaultProps = {
    id: "input",
    variant: "solid",
    borderRadius: 4,
    isReadOnly: false,
    disable: false,
    value: "",
    name: "",
    errorMessage: "",
    size: "md",
    isRequired:false
};
