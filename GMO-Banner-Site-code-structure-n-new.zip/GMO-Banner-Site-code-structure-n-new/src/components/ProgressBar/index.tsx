import React from "react";
import styled from "@emotion/styled";
import { Theme } from "../../context/ThemeProvider";
import { PropTypes } from "../../utils/propType";
import { Property } from "../../utils/types";
import { cx as classNames } from "@emotion/css";

interface ProgressBarPropType extends PropTypes<HTMLDivElement> {
    max?: number;

    min?: number;

    label?: string | number;

    value?: number;

    width?: Property.Width;

    backgroundColor?: string;

    showSteps?: boolean;

    startPoint?: number | string;

    endPoint?: number | string;

    midPoint?: number | string;
}

type StyleProgressProps = {
    theme?: Theme;
    overrideStyle?: PropTypes["style"];
} & Partial<ProgressBarPropType>;

export const EmotionProgressBar = styled("progress", {
    shouldForwardProp: (props: string) => {
        return !["colorScheme", "overrideStyle", "as"].includes(props);
    },
})(
    ({
        theme,
        colorScheme,
        overrideStyle,
        width,
        backgroundColor,
    }: StyleProgressProps) => {
        return {
            marginRight: 10,
            width: width,
            position: "relative",
            alignSelf: "center",
            WebkitAppearance: "none",
            "::-webkit-progress-bar": {
                height: 10,
                borderRadius: 20,
                backgroundColor: "#eee",
            },
            "::-webkit-progress-value": {
                height: 10,
                borderRadius: 20,
                backgroundColor: backgroundColor
                    ? backgroundColor
                    : colorScheme && theme?.palette[colorScheme]?.main,
            },
            ...overrideStyle,
        };
    },
);

type StyledContainerProps = {
    overrideStyle?: PropTypes["style"];
    theme?: Theme;
} & Partial<ProgressBarPropType>;

const EmotionContainer = styled("div")(
    ({ overrideStyle, width }: StyledContainerProps) => {
        return {
            width,
            display: "inline-flex",
            flexDirection: "column",
            position: "relative",
            justifyContent: "center",
            alignContent: "center",
            alignItems: "center",
            fontSize: 16,
            ...overrideStyle,
        };
    },
);

type StyledProgressDotProps = {
    overrideStyle?: PropTypes["style"];
    theme?: Theme;
} & Partial<ProgressBarPropType>;

const EmotionProgressDot = styled("div")(
    ({ colorScheme, theme, overrideStyle }: StyledProgressDotProps) => {
        return {
            width: "25px",
            height: "25px",
            borderRadius: "50%",
            lineHeight: "27px",

            backgroundColor: colorScheme
                ? colorScheme && theme?.palette[colorScheme]?.main
                : "#eee",
            fontSize: "12px",
            fontWeight: 400,
            color: "#1f75c4",
            position: "absolute",
            top: "-3px",
            ...overrideStyle,
        };
    },
);

type StyledProgressLabelProps = {
    overrideStyle?: PropTypes["style"];
    theme?: Theme;
} & Partial<ProgressBarPropType>;

/**
 * @function EmotionProgressLabel
 * This function is used to wrap the Label Item for style
 */
export const EmotionProgressLabel = styled.label(
    ({ overrideStyle }: StyledProgressLabelProps) => {
        return {
            paddingBottom: "15px",
            display: "inline-flex",
            justifyContent: "center",
            fontSizes: 16,
            color: "#555",
            ...overrideStyle,
        };
    },
);

export const ProgressBar = React.forwardRef<
HTMLDivElement,
    React.PropsWithChildren<ProgressBarPropType>
>(
    (
        {
            id,
            children,
            className,
            colorScheme,
            max,
            min,
            showSteps,
            label,
            value,
            width,
            style,
            startPoint,
            endPoint,
            midPoint,
            backgroundColor,
            ...props
        },
        ref,
    ) => {
        return (
            <EmotionContainer
                id={id}
                className={classNames(className)}
                ref={ref}
                overrideStyle={style}
                {...props}
            >
                {label && (
                    <EmotionProgressLabel colorScheme={colorScheme}>
                        {label}
                    </EmotionProgressLabel>
                )}
                <div style={{ position: "relative" }}>
                    <EmotionProgressBar
                        colorScheme={colorScheme}
                        value={value}
                        max={100}
                        min={0}
                        startPoint={startPoint}
                        midPoint={midPoint}
                        endPoint={endPoint}
                        label={label}
                        width={width}
                        backgroundColor={backgroundColor}
                    />
                    {showSteps && (
                        <div>
                            <EmotionProgressDot
                                backgroundColor={backgroundColor}
                                colorScheme={colorScheme}
                                value={value}
                                min={min}
                                startPoint={startPoint}
                                data-active-dot={
                                    value >= 0 ? "actve" : "inactive"
                                }
                                style={{
                                    left: 5,
                                    ...(value >= 0 && {
                                        backgroundColor: backgroundColor,
                                    }),
                                }}
                            >
                                <span
                                    style={{
                                        position: "relative",
                                        bottom: -20,
                                        left: 5,
                                    }}
                                >
                                    {startPoint}
                                </span>
                            </EmotionProgressDot>
                            <EmotionProgressDot
                                backgroundColor={backgroundColor}
                                colorScheme={colorScheme}
                                midPoint={midPoint}
                                value={value}
                                max={max}
                                data-active-dot={
                                    value >= 50 ? "actve" : "inactive"
                                }
                                style={{
                                    left: "45%",
                                    top: -3,
                                    ...(value >= 50 && {
                                        backgroundColor: backgroundColor,
                                    }),
                                }}
                            >
                                <span
                                    style={{
                                        position: "relative",
                                        bottom: -20,
                                    }}
                                >
                                    {midPoint}
                                </span>
                            </EmotionProgressDot>
                            <EmotionProgressDot
                                backgroundColor={backgroundColor}
                                colorScheme={colorScheme}
                                endPoint={endPoint}
                                value={value}
                                max={max}
                                data-active-dot={
                                    value === 100 ? "actve" : "inactive"
                                }
                                style={{
                                    top: -3,
                                    right: 15,
                                    ...(value === 100 && {
                                        backgroundColor: backgroundColor,
                                    }),
                                }}
                            >
                                <span
                                    style={{
                                        position: "relative",
                                        bottom: -20,
                                    }}
                                >
                                    {endPoint}
                                </span>
                            </EmotionProgressDot>
                        </div>
                    )}
                    {value && (
                        <div
                            style={{
                                width: "5px",
                                height: "16px",
                                lineHeight: "27px",
                                backgroundColor: "#fff",
                                position: "absolute",
                                left: value * 5.60,
                                top: "-1px",
                            }}
                        />
                    )}
                </div>
                {children}
            </EmotionContainer>
        );
    },
);

ProgressBar.defaultProps = {
    value: 0,
    max: 100,
    width: "200px",
    showSteps: true,
};
