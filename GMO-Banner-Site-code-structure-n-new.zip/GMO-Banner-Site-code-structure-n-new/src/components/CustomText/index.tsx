import { Text } from '../Text';
export const CustomText = ({ children, as }) =>{
    return(
        <Text as={as} style={{ fontSize: 'inherit', color: 'inherit' }}>
            {children}
        </Text>
    )
} 