import * as React from "react";
import Image from "next/image";
import { cx as classNames } from "@emotion/css";
import { ButtonPropType, Button, EmotionButtonIcon } from "../Button";
import styled from "@emotion/styled";
import { Theme, useThemeMode } from "src/context/ThemeProvider";
import { useOnClickOutside } from "@util/hooks/useOnOutsideClick";
import { PaperPropType, Paper } from "@components/Paper";
import { ChevronUp, ChevronDown } from "react-feather";
import { PropTypes } from "@util/propType";
interface Position {
    vertical: "bottom" | "top";
    horizontal: "right" | "left";
}
export interface ButtonDropdownPropType<T> extends ButtonPropType {
    iconPosition?: DropdownIcon;

    /** Array of List Items **/
    list?: T[];

    /** Event on Button Toogle **/
    onButtonToggle?: (on: boolean) => void;

    /** Disable Button **/
    disable?: boolean;

    /** Additional card classes **/
    cardClasses?: string;

    /** ButtonDropdown Label **/
    label: string;

    /** for passing position of buttondropdown**/
    position?: Position;

    /** it is used to display whatever you include between the opening and closing tags when invoking a component**/
    children?: (item: T) => React.ReactNode;

    /** To add shadow effect **/
    elevation?: boolean;

    /** Radius to rounds the corners of an element from outer border edge **/
    borderRadius?: number;
    /** icon to pass when  **/
    toggleUp?: JSX.Element;

    toggleDown?: JSX.Element;

    /** To define a string that labels the current element **/
    "aria-label"?: string;
}

/** ButtonProps for buttondropdown**/

export type ButtonDropDownProps = {
    /** Id should be unique **/
    id: string;
} & Pick<ButtonDropdownPropType<unknown>, "disable" | "iconPosition" | "style">;

/** PaperProps for buttondropdown**/

export type PaperProps = {
    theme?: Theme;
    overrideStyle?: PropTypes["style"];
    children: React.ReactNode;
    elevation?: boolean;
    borderRadius?: number;
} & Partial<PaperPropType>;

export interface DropdownIcon {
    onClose: string;
    onOpen: string;
}

/**
 * @function ButtonDropdownConatiner
 * This function is used to style the container of the component
 */

const ButtonDropdownConatiner = styled("div")(
    ({ overrideStyle }: { overrideStyle?: PropTypes["style"] }) => {
        return {
            position: "relative",
            height: "fit-content",
            ...overrideStyle,
        };
    },
);

/**
 * @function EmotionButtonPaper
 * This function is used style the background of buttonDropdown
 */

const EmotionButtonPaper = styled(Paper)(
    ({
        overrideStyle,
        position,
        elevation,
        theme,
    }: PaperProps & { position: Position }) => {
        return {
            display: "flex",
            flexDirection: "column",
            position: "absolute",
            width: "100%",
            top: position.vertical === "bottom" ? "100%" : 0,
            [position.horizontal]: 0,
            boxShadow: elevation && theme.shadows[1],
            padding: 0,
            border: 0,
            zIndex: 99,
            margin: 0,
            fontFamily: "Roboto",
            fontSize: "1rem",
            lineHeight: 1.5,
            letterSpacing: 1.5,
            borderRadius: 0,
            backgroundColor: "#b8b5b5",
            ...overrideStyle,
        };
    },
);

/**
 * @function EmotionButtonDropdown
 * This function is used to style the button
 */

const EmotionButtonDropdown = styled(Button)(
    ({ overrideStyle }: { overrideStyle: PropTypes["style"] }) => {
        return {
            whiteSpace: "nowrap",
            ...overrideStyle,
        };
    },
);

enum MarginDirection {
    left = "Left",
    right = "Right",
}

const getButtonIcon = (
    icon: JSX.Element,
    marginSide: MarginDirection,
): JSX.Element => (
    <EmotionButtonIcon marginSide={marginSide}>{icon}</EmotionButtonIcon>
);

/**
 * * The Trailing comma in `<T,>` is added due to contraints of the `.tsx` file extention.
 * * You can read about this here
 * * https://wanago.io/2020/02/17/typescript-generics-discussing-naming-conventions/#:~:text=identity(%27Hello%20world!%27)%3B-,Arrow%20functions,-We%20can%20also
 */
const ButtonDropdownComponent = <T,>(
    {
        id,
        className,
        disable,
        list,
        onButtonToggle,
        children,
        cardClasses,
        label,
        "aria-label": ariaLabel,
        variant,
        position,
        elevation,
        toggleDown,
        toggleUp,
        ...otherProps
    }: ButtonDropdownPropType<T>,
    Btnref: React.ForwardedRef<HTMLDivElement>,
) => {
    // Created a ref that we add to the element for which we want to detect outside clicks
    const ref: React.RefObject<HTMLDivElement> = React.useRef();

    // State for our modal
    const [isOpen, setToggle] = React.useState(false);

    const changeToggle = (e) => {
        onButtonToggle && onButtonToggle(!isOpen); // testing
        if (isOpen) {
            setToggle(false);
        }
    };

    const onClickButton = () => {
        onButtonToggle && onButtonToggle(!isOpen);
        setToggle(!isOpen);
    };

    const insdeClick = (e) => {
        if (e.target.id === "Dropdown_button_id") {
            return;
        }
    };

    useOnClickOutside(
        ref,
        (e) => changeToggle(e),
        (e) => insdeClick(e),
    );

    const { themeMode } = useThemeMode();
    const toggleActive = isOpen ? 'active' : '';
    return (
        <ButtonDropdownConatiner
            id={id}
            className={classNames(className)}
            ref={ref}
            overrideStyle={otherProps.style}
        >
            <div onClick={onClickButton} onKeyDownCapture={onClickButton}>
                <EmotionButtonDropdown
                    variant={variant}
                    disable={disable}
                    startIcon={otherProps.startIcon}
                    endIcon={otherProps.endIcon}
                    overrideStyle={otherProps.style}
                    id="Dropdown_button_id"
                    className={toggleActive}
                    tabIndex={0}
                    aria-haspopup="true"
                    aria-label={ariaLabel}
                >
                    {label}

                    {isOpen
                        ? getButtonIcon(toggleUp, MarginDirection.left)
                        : getButtonIcon(toggleDown, MarginDirection.left)}
                </EmotionButtonDropdown>
                {isOpen && (
                    <EmotionButtonPaper
                        id="Button_dropdown_list_id"
                        key="testid"
                        ref={Btnref}
                        className={classNames(cardClasses)}
                        elevation={elevation}
                        
                        position={position}
                    >
                        {list?.map((item) => {
                            return children && children(item);
                        })}
                    </EmotionButtonPaper>
                )}
            </div>
        </ButtonDropdownConatiner>
    );
};

/**
 * This helper interface is created to make the Component Generic with Forword Ref support
 */
interface TypesafeForwordRefComponent {
    <T>(
        props: ButtonDropdownPropType<T> & {
            ref?: React.ForwardedRef<HTMLDivElement>;
        },
    ): ReturnType<typeof ButtonDropdownComponent>;
    defaultProps?: Partial<ButtonDropdownPropType<unknown>> | undefined;
}

/**
 * ButtonDropdown Component
 */
export const ButtonDropdown = React.forwardRef(
    ButtonDropdownComponent,
    // Type assessertion is Required for Generic component
    // For more info visit https://fettblog.eu/typescript-react-generic-forward-refs/
) as unknown as TypesafeForwordRefComponent;

/**
 * defaultProps - To define default values for component props
 */
ButtonDropdown.defaultProps = {
    variant: "solid",
    label: "DropdownList",
    position: {
        vertical: "bottom",
        horizontal: "left",
    },
    elevation: true,
    list: [],
    borderRadius: 0,
    toggleUp: <ChevronUp />,
    toggleDown: <ChevronDown />,
    "aria-label": "button" || "",
};
