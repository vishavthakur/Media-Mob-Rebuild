import * as React from "react";
import classNames from "classnames";
import { Property, ImageType } from "@util/types";
import styled from "@emotion/styled";
import { isObjectEmpty } from "../../utils/assertion";
import { defaultTheme, Theme, useThemeMode } from "src/context/ThemeProvider";
import { alpha } from "@util/Theme/colorManipulator";
import { PropTypes } from "@util/propType";
import Image from "next/image";
import { Paper } from "@components/Paper";
import { CustomImage } from "@components/CustomImage";

interface CardPropType extends Omit<PropTypes, "ref"> {
    /** Additional Header HTML content **/
    header?: string | JSX.Element;
    /** Card variations can be of 4 types: 'solid - filled layout' and 'outline - bordered layout **/
    /*** | "ghost" | "dot" removed because of using paper  */
    variant?: "solid" | "outline";

    /** Additional Footer HTML content **/
    footer?: string | JSX.Element;

    /** Variations for alignment of content inside card container **/
    alignItems?: Property.AlignItem;

    /** Variations for alignment of content inside card container **/
    justifyContent?: Property.JustifyElemnent;

    /** Additional background color */
    backgroundColor?: string;

    /** Additional Height  */
    minHeight?: Property.MinHeight;

    /** horizontal the card **/
    horizontal?: boolean;

    /** To add hover effect to the card */
    isHover?: boolean;

    /** Additional border- radius color to card **/
    borderRadius?: number;

    /* Border */
    border?: boolean;

    /* Box shadow*/
    elevation?: boolean;

    /* vertical align row or column*/
    vertical?: boolean;

    ref?: React.Ref<HTMLDivElement>;
}

/**
 * @function getPropsByVariant
 * This function is used to pass the color scheme, variant and the emotion theme
 */
const getPropsByVariant = ({ variant, colorScheme, theme }) => {
    const colorInPalette = theme.palette[colorScheme];

    const variants = {
        outline: colorInPalette && {
            main: {
                border: `1px solid ${colorInPalette.main}`,
                backgroundColor: theme.palette.common.transparent,
                color: colorInPalette.main,
            },
        },
        solid: colorInPalette && {
            main: {
                backgroundColor: colorInPalette.main,
                color: colorInPalette.contrastText,
            },
        },
        dot: colorInPalette && {
            main: {
                backgroundColor: colorInPalette.main,
            },
        },
        ghost: colorInPalette && {
            main: {
                backgroundColor: alpha(colorInPalette.main, 0.2),
                color: colorInPalette.main,
            },
        },
    };

    return variants[variant] || variants.solid;
};

/**
 * @function StyledBadge
 * This function that takes all props and theme(passed by the emotion itself) as a argument returns object of its types
 */

type StyledCardProps = {
    theme?: Theme;
    hide?: boolean;
    overrideStyle?: React.CSSProperties;
} & Partial<CardPropType>;

/**
 * @function EmotionCard
 * This function is used to wrap the component for style
 */
export const EmotionCard = styled("div", {
    shouldForwardProp: (props: string) =>
        ![
            "elevation",
            "colorScheme",
            "disable",
            "overrideStyle",
            "fullWidth",
            "justifyContent",
            "alignItems",
            "border",
            "vertical",
            "backgroundColor",
            "isHover",
            "borderRadius",
            "horizontal",
        ].includes(props),
})(
    ({
        theme,
        border,
        elevation,
        justifyContent,
        vertical,
        variant,
        colorScheme,
        hide,
        isHover,
        alignItems,
        borderRadius,
        overrideStyle,
        backgroundColor,
    }: StyledCardProps) => {
        if (isObjectEmpty(theme)) {
            theme = defaultTheme;
        }
        const { themeMode } = useThemeMode();
        const colorInPalette = theme.palette[colorScheme];
        const propsByVariant = getPropsByVariant({
            variant,
            theme,
            colorScheme,
        });
        return {
            backgroundColor:
                themeMode === "light"
                    ? theme.palette.common.white
                    : theme.palette.paper.background,
            display: `${hide ? "none" : "flex"}`,
            flexDirection: `${vertical ? "row" : "column"}`,
            flexWrap: "wrap",

            border: `${
                border && colorScheme
                    ? `1px solid ${theme.palette[colorScheme].main}`
                    : ` ${theme.palette.paper.border}`
            }`,
            borderRadius: `${borderRadius ? borderRadius : ""}`,
            boxShadow: elevation ? `${theme.shadows[3]}` : "",
            alignItems: alignItems,
            justifyContent: justifyContent,
            alignContent: "center",
            ...(propsByVariant && propsByVariant.main),
            "&:hover": isHover && {
                backgroundColor: theme.palette.paper.hover,
            },
            ...(colorScheme && {
                "&:hover": isHover && {
                    backgroundColor: `${alpha(colorInPalette?.main, 0.2)}`,
                },
            }),
            cursor: isHover && "pointer",
            ...overrideStyle,
        };
    },
);

export const Card = React.forwardRef<
    HTMLDivElement,
    React.PropsWithChildren<CardPropType>
>(
    (
        {
            id,
            header,
            style,
            footer,
            children,
            className,
            backgroundColor,
            ...props
        },
        ref,
    ) => (
        <EmotionCard
            id={id}
            overrideStyle={style}
            ref={ref}
            className={classNames(className)}
            backgroundColor={backgroundColor}
            {...props}
        >
            {header}
            {children}
            {footer}
        </EmotionCard>
    ),
);

Card.defaultProps = {
    elevation: false,
    vertical: false,
    disable: false,
    horizontal: false,
    isHover: false,
    border: false,
    borderRadius: 0,
    // backgroundColor: "#3e3d3d"
};
