import React, { useContext } from "react";
import { PropTypes } from "@util/propType";
import styled from "@emotion/styled";
import { Property } from "@util/types";
import { AccordionItemContext } from "./AccordionItem";

export interface AccordionPanelPropType extends Omit<PropTypes, "as"> {
    /** placement of icon**/
    iconAlignment?: Property.DisplayDirection;

    /**Prop to provide spacing between accordians from bottom*/
    spacing?: boolean;
}

/**
 *  EmotionAccordionContentPanel component
 */
const EmotionAccordionContentPanel = styled("div")(
    ({ isExpanded }: { isExpanded: boolean }) => {
        return {
            display: "flex",
            flexDirection: "column",
            overflow: "hidden",
            marginTop: isExpanded && "10px",
            maxHeight: 0,
            transition: "all 200ms ease-in-out",
            willChange: "max-height",
        };
    },
);
const ICON_CHANGE_DELAY_DURATION = 200; // delay duration in ms
export const AccordionPanelMobile: React.FC = ({ children }) => {
    const ctx = useContext(AccordionItemContext);
    const accordionPanelRef = React.useRef<HTMLDivElement>();
    const isMount = React.useRef<boolean>(true);

    React.useEffect(() => {
        let timmer;
        if (!isMount.current) {
            const isOpen = ctx.isExpanded;
            const accordion_panel = accordionPanelRef.current;
            if (isOpen) {
                accordion_panel.style.maxHeight = `${accordion_panel.scrollHeight}px`;
            } else {
                accordion_panel.style.maxHeight = `${accordion_panel.scrollHeight}px`;
            }

            timmer = setTimeout(
                (open) => {
                    if (open) {
                        accordion_panel.style.overflow = "visible";
                        accordion_panel.style.maxHeight = "none";
                    } else {
                        accordion_panel.style.overflow = "hidden";
                        accordion_panel.style.maxHeight = `0`;
                    }
                },
                ICON_CHANGE_DELAY_DURATION,
                isOpen,
            );
        }
        return () => {
            isMount.current = false;
            timmer && clearTimeout(timmer);
        };
    }, [ctx.isExpanded]);

    return (
        <EmotionAccordionContentPanel
            isExpanded={ctx.isExpanded}
            ref={accordionPanelRef}
        >
            {children}
        </EmotionAccordionContentPanel>
    );
};
