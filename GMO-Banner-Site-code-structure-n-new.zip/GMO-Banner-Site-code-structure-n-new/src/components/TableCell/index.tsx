/* eslint-disable prettier/prettier */
import * as React from "react";
import { Property } from "@util/types";
import styled from "@emotion/styled";
import { PropTypes } from "@util/propType";

interface TableCellPropType
    extends Omit<PropTypes<HTMLTableCellElement>, "className"> {
    /** Number of columns a cell should span **/
    colSpan?: number;

    /** Number of rows a cell should span **/
    rowSpan?: number;

    /** Alignment of the content */
    textAlign?: Property.TextAlign;

    /** Vertical position for alignment of items **/
    verticalAlignment: Property.Alignment;

    /** Variations to add cell type -  th stands for table head and td - stands for table data */
    as: "th" | "td";
}

/**
 * @function StyledTableCell
 * To style the table head and td
 */

export const EmotionTableCell = styled("th")(() => ({
    display: "table-cell",
}));

/**
 * @function TableCell
 * To get the props and return the component with style
 */
export const TableCell = React.forwardRef<
    HTMLTableCellElement,
    React.PropsWithChildren<TableCellPropType>
>(({ children, colSpan, rowSpan, as, ...props }, ref) => {
    //const table = React.useContext(TableContext);

    // const variant = table.variant;
    return (
        <EmotionTableCell
            colSpan={colSpan}
            rowSpan={rowSpan}
            ref={ref}
            as={as}
            {...props}
        >
            {children}
        </EmotionTableCell>
    );
});

/**
 * defaultProps - To define default values for component props
 */
TableCell.defaultProps = {
    colSpan: undefined,
    rowSpan: undefined,
    as: "td",
    textAlign: "left",
    verticalAlignment: "middle",
};
