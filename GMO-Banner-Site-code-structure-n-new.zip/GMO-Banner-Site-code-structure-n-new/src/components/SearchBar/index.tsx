import * as React from "react";
import { cx as classNames } from "@emotion/css";
import { ImageType } from "@util/types";
import { PropTypes } from "@util/propType";
import styled from "@emotion/styled";
import Image from "next/image";
import { isObjectEmpty } from "../../utils/helpers";
import { defaultTheme, Theme, useThemeMode } from "src/context/ThemeProvider";
import { alpha } from "@util/Theme/colorManipulator";
import { Search } from "react-feather";
import { theme } from "@util/theme";

interface SearchbarPropType
    extends Omit<PropTypes, "disbale" | "as" | "onChange" | "onSubmit"> {
    /** Provide user a hint or what kind of information is expected to enter in field **/
    placeholder?: string;

    /** Icon allows the end user to search data with the help of a hint **/
    icon?: any;

    /** Fill Style search Icon **/
    iconFillRight?: boolean;

    /** Fill Style search Icon **/
    iconFillLeft?: boolean;

    /** Fill Style search Icon **/
    iconFillRightOut?: boolean;

    /** Fill Style search Icon **/
    iconFillLeftOut?: boolean;

    /** Dowpdown icon from outside the component **/
    SearchDropdown?: string;

    /** Caption for the information of field **/
    //labelName?: string;

    /** To add Input border radius **/
    borderRadius?: number;

    /** ONCHANGE **/
    onChange?: (event: React.ChangeEvent<HTMLInputElement>) => void;

    /** ONSUBMIT **/
    onSubmit?: (value: string) => void;

    /** Variations for search layout: contained- filled layout, outline- bordered layout **/
    variant?: "solid" | "outline" | "ghost";
}

/**
 * @function getPropsByVariant
 * This function is used to pass the color scheme, variant and the emotion theme
 */

const getPropsByVariant = ({ variant, colorScheme, theme }) => {
    const colorInPalette = theme.palette[colorScheme];
    const variants = {
        solid: colorInPalette && {
            main: {
                borderColor: colorInPalette.main,
                color: colorInPalette.contrastText,
                "&::placeholder": {
                    color: colorInPalette.contrastText,
                },
                backgroundColor: colorInPalette.main,
            },
        },
        outline: colorInPalette && {
            main: {
                border: `1px solid ${colorInPalette.main}`,
                backgroundColor: theme.palette.common.transparent,
                color: colorInPalette.main,
                "&::placeholder": {
                    color: colorInPalette.main,
                },
            },
        },
        ghost: {
            main: {
                backgroundColor: alpha(colorInPalette.main, 0.2),
                color: colorInPalette.main,
                border: `1px solid ${alpha(colorInPalette.main, 0.5)}`,
                "&::placeholder": {
                    color: colorInPalette.main,
                },
            },
        },
    };

    return variants[variant] || variants.solid;
};

/**
 * EmotionSearchbarContainer component
 */

const EmotionSearchbarContainer = styled("div")(
    ({ overrideStyle }: { overrideStyle: React.CSSProperties }) => {
        return {
            position: "relative",
            width: "100%",
            ...overrideStyle,
        };
    },
);

/**
 * EmotionSearchForm component
 */
const EmotionSearchForm = styled("form")(
    ({
        iconFillLeftOut,
        iconFillRightOut,
    }: {
        iconFillLeftOut?: SearchbarPropType["iconFillLeftOut"];
        iconFillRightOut?: SearchbarPropType["iconFillRightOut"];
    }) => {
        return {
            position: "relative",
            display: "flex",
            flexWrap: "wrap",
            WebkitBoxAlign: "stretch",
            msFlexAlign: "stretch",
            alignItems: "stretch",
            overflow: "hidden",
            width: "100%",
            ...((iconFillLeftOut || iconFillRightOut) && {
                overflow: "visible",
                flexDirection: iconFillLeftOut ? "row-reverse" : "row",
            }),
        };
    },
);

/**
 *EmotionSearchInput component
 */
const EmotionSearchInput = styled("input")(
    ({
        iconFillLeft,
        iconFillRight,
        iconFillLeftOut,
        iconFillRightOut,
        theme,
        variant,
        colorScheme,
        //labelName,
        borderRadius,
    }: {
        iconFillLeft?: SearchbarPropType["iconFillLeft"];
        iconFillRight?: SearchbarPropType["iconFillRight"];
        iconFillLeftOut?: SearchbarPropType["iconFillLeftOut"];
        iconFillRightOut?: SearchbarPropType["iconFillRightOut"];
        theme?: Theme;
        variant?: SearchbarPropType["variant"];
        colorScheme?: PropTypes["colorScheme"];
        borderRadius?: SearchbarPropType["borderRadius"];
        //labelName?: SearchbarPropType["labelName"];
    }) => {
        if (isObjectEmpty(theme)) {
            theme = defaultTheme;
        }
        const propsByVariant = getPropsByVariant({
            variant,
            theme,
            colorScheme,
        });
        return {
            ...((iconFillLeftOut || iconFillRightOut) && { width: "86%" }),
            ...(iconFillLeft && { paddingLeft: 60 }),
            ...(iconFillRight && { paddingright: 20 }),
            border: "1px solid grey",
            fontSize: "16px",
            lineHeight: "16px",
            width: "100%",
            padding: "15px",
            outline: "none",
            borderRadius: borderRadius,
            color: `${theme.palette.paper.text}`,
            "&:placeholder ": {
                color: `${theme.palette.paper.text}`,
            },
            "&:focus": {
                outline: "none",
                borderColor: theme.palette.paper.border,
            },
            ...(propsByVariant && propsByVariant.main),
        };
    },
);

/**
 * EmotionIconWrapper component
 */
const EmotionIconWrapper = styled("span")(
    ({
        iconFillLeftOut,
        iconFillRightOut,
        iconFillRight,
        iconFillLeft,
    }: {
        iconFillLeftOut?: SearchbarPropType["iconFillLeftOut"];
        iconFillRightOut?: SearchbarPropType["iconFillRightOut"];
        iconFillRight?: SearchbarPropType["iconFillRight"];
        iconFillLeft?: SearchbarPropType["iconFillLeft"];
        theme?: Theme;
        variant?: SearchbarPropType["variant"];
        colorScheme?: PropTypes["colorScheme"];
    }) => {
        return {
            ...(iconFillLeftOut ||
            iconFillRightOut ||
            iconFillRight ||
            iconFillLeft
                ? {
                      display: "flex",
                      justifyContent: "center",
                      marginRight: "1px",
                      right: 0,
                      height: "100%",
                      width: "50px",
                      borderLeft: 0,
                  }
                : {
                      position: "absolute",
                      top: "50%",
                      transform: "translateY(-50%)",
                      right: "10px",
                      cursor: "pointer",
                  }),
            ...(iconFillLeftOut && { left: 0 }),
            ...(iconFillRightOut && { right: 0 }),
            ...(iconFillLeft && { right: "auto", left: 0 }),
            ...(iconFillRight && { right: 0, left: "auto" }),
        };
    },
);

/**
 * Searchbar component
 */

const SearchBar = React.forwardRef<HTMLDivElement, SearchbarPropType>(
    (
        {
            id,
            placeholder,
            icon,
            className,
            variant,
            iconFillRight,
            iconFillLeft,
            iconFillRightOut,
            iconFillLeftOut,
            style,
            onClick,
            onChange,
            onSubmit,
            //labelName,
            colorScheme,
            borderRadius,
        },
        ref,
    ) => {
        const inputRef = React.useRef(null);
        const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
            event.preventDefault();
            onSubmit && onSubmit(inputRef?.current?.value);
        };
        const { themeMode } = useThemeMode();
        return (
            <EmotionSearchbarContainer
                className={classNames(className)}
                overrideStyle={style}
                ref={ref}
            >
                <EmotionSearchForm
                    onSubmit={handleSubmit}
                    iconFillLeftOut={iconFillLeftOut}
                    iconFillRightOut={iconFillRightOut}
                >
                    <EmotionSearchInput
                        id={id}
                        ref={inputRef}
                        placeholder={placeholder}
                        onChange={onChange}
                        iconFillLeft={iconFillLeft}
                        iconFillRight={iconFillRight}
                        iconFillLeftOut={iconFillLeftOut}
                        iconFillRightOut={iconFillRightOut}
                        colorScheme={colorScheme}
                        variant={variant}
                        //labelName={labelName}
                        borderRadius={borderRadius}
                    />

                    <EmotionIconWrapper
                        iconFillLeftOut={iconFillLeftOut}
                        iconFillRightOut={iconFillRightOut}
                        iconFillRight={iconFillRight}
                        iconFillLeft={iconFillLeft}
                    >
                        {icon && icon !== "" ? (
                            icon
                        ) : themeMode === "light" ? (
                            <Search size="16px" />
                        ) : (
                            <Search size="16px" color="#fff" />
                        )}
                        {/* <Image
                                id={icon?.id}
                                src={icon?.image?.mediaItemUrl}
                                alt={icon?.image?.altText}
                                width={icon?.image?.mediaDetails?.width || 15}
                                height={icon?.image?.mediaDetails?.height || 15}
                                onClick={onClick}
                            /> */}
                    </EmotionIconWrapper>
                </EmotionSearchForm>
            </EmotionSearchbarContainer>
        );
    },
);

/**
 * defaultProps - To define default values for component props
 */

SearchBar.defaultProps = {
    variant: "solid",
    colorScheme: "primary",
    placeholder: "search",
    borderRadius: 4,
};

export default SearchBar;
