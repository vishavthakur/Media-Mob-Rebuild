import * as React from "react";
import classNames from "classnames";
import { PropTypes } from "@util/propType";
import styled from "@emotion/styled";
import { Property } from "../../utils/types";
import { Paper } from "@components/Paper";

type navigationSectionType = "header" | "footer";

type OmitProps = "onClick" | "disable" | "ref";

export interface NavigationSectionPropType
    extends Omit<
        PropTypes<navigationSectionType | HTMLDivElement | HTMLElement>,
        OmitProps
    > {
    /** Additional backgruund color to section **/
    backgroundColor?: string;

    /**** Ref for input element */
    ref?: React.Ref<HTMLDivElement>;
}
/**
 * @function StyledNavigationSection
 * This function that takes all props and theme(passed by the emotion itself) as a argument returns object of its types
 */
const StyledNavigationSection = ({
    overrideStyle,
}: StyledNavigationSectionProp) => {
    return {
        display: "flex" as Property.DisplayInside,
        flexDirection: "column" as Property.FlexDirection,
        padding: "20px" as Property.Padding,
        ...overrideStyle,
    };
};

interface StyledNavigationSectionProp {
    overrideStyle?: React.CSSProperties;
}

/**
 * @function EmotionNavigationSection
 * This function is used to wrap the component for style
 */
export const EmotionNavigationSection = styled(Paper, {
    shouldForwardProp: (props: string) =>
        ![
            "elevation",
            "colorScheme",
            "disable",
            "overrideStyle",
            "fullWidth",
            "justifyContent",
            "alignItems",
            "backgroundColor",
            "borderRadius",
            "as",
        ].includes(props),
})(StyledNavigationSection);

export const NavigationSection = React.forwardRef<
    HTMLDivElement,
    React.PropsWithChildren<NavigationSectionPropType>
>(({ id, children, className, backgroundColor, style, as, ...props }, ref) => (
    <EmotionNavigationSection
        id={id}
        as={as}
        backgroundColor={backgroundColor}
        className={classNames(className)}
        overrideStyle={style}
        {...props}
        ref={ref}
    >
        {children}
    </EmotionNavigationSection>
));

/**
 * defaultProps - To define default values for component props
 */
NavigationSection.defaultProps = {
    id: "navigation_section",
    backgroundColor: "transparent",
    as: "header",
};
