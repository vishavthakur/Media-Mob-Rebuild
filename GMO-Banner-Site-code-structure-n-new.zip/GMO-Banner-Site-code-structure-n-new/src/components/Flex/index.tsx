import React from "react";
import styled from "@emotion/styled";
import { Property } from "@util/types";
import { cx as classNames } from "@emotion/css";
import { PropTypes } from "@util/propType";
import { getResponsiveCssProperty } from "@util/getBreakpoint";

interface FlexPropType
    extends Pick<PropTypes, "id" | "style" | "className" | "children"|"tabIndex" | "aria-label"> {
    /** Alignment of items */
    alignItems?: Property.AlignItem;

    /** Types for aligns a flex container’s lines within when there is extra space in the cross-axis **/
    justifyContent?: Property.ContentJustification;

    /** Types to add direction of the elements **/
    flexDirection?:
        | {
              sm?: Property.FlexDirection;
              lg?: Property.FlexDirection;
              md?: Property.FlexDirection;
              xs?: Property.FlexDirection;
          }
        | Property.FlexDirection;

    /** flexible items should wrap or not **/
    flexWrap?:
        | {
              sm?: Property.FlexWrap;
              lg?: Property.FlexWrap;
              md?: Property.FlexWrap;
              xs?: Property.FlexWrap;
          }
        | Property.FlexWrap;
}

export type StyledFlexProps = {
    overrideStyle?: React.CSSProperties;
} & Partial<FlexPropType>;

/**
 * @function StyledFlex
 * This function that takes all props and theme(passed by the emotion itself) as a argument returns object of its types
 */

const StyledFlex = ({
    alignItems,
    justifyContent,
    flexDirection,
    flexWrap,
    overrideStyle,
}: StyledFlexProps) => {
    return {
        alignItems,
        justifyContent,

        ...(flexDirection &&
            getResponsiveCssProperty({
                flexDirection: flexDirection,
                flexWrap: flexWrap,
            })),

        display: "flex",
        ...overrideStyle,
    };
};

/**
 * @function EmotionFlex
 * This function is used to wrap the component for style
 */
export const EmotionFlex = styled("div", {
    shouldForwardProp: (props: string) => {
        return ![
            "alignItems",
            "flexDirection",
            "justifyContent",
            "flexWrap",
            "overrideStyle",
        ].includes(props);
    },
})(StyledFlex);

/**
 * @function Flex
 * This function is used to create Flex Component in which we wrap EmotionFlex
 */
export const Flex = React.forwardRef<
    HTMLDivElement,
    React.PropsWithChildren<FlexPropType>
>(
    (
        {
            alignItems,
            justifyContent,
            flexDirection,
            flexWrap,
            children,
            className,
            style,
            ...props
        },
        ref,
    ) => (
        <EmotionFlex
            className={classNames(className)}
            alignItems={alignItems}
            justifyContent={justifyContent}
            flexDirection={flexDirection}
            flexWrap={flexWrap}
            overrideStyle={style}
            ref={ref}
            {...props}
        >
            {children}
        </EmotionFlex>
    ),
);

/**
 * defaultProps - To define default values for component props
 */
Flex.defaultProps = {
    alignItems: "center",
    justifyContent: "center",
    flexDirection: {
        sm: "row",
        lg: "row",
        md: "row",
        xs: "column",
    },
    flexWrap: `wrap`,
};
