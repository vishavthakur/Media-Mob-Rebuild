import styled from "@emotion/styled";
import { cx as classNames } from "@emotion/css";
import React, { Children } from "react";
import isPropValid from "@emotion/is-prop-valid";
import { defaultTheme, Theme } from "src/context/ThemeProvider";
import { fontSizes } from "@util/units";
import { isObjectEmpty } from "../../utils/helpers";
import { PropTypes } from "@util/propType";
import { TableContext } from "./tabelContext";

interface TablePropType
    extends Omit<
        PropTypes<HTMLTableElement>,
        "as" | "onClick" | "colorScheme"
    > {
    /** Add TableCell and TableRow from the outside to show header of table */
    header?: JSX.Element | React.ReactNode;

    /** Add TableCell and TableRow from the outside to show body content of table */
    body?: JSX.Element | React.ReactNode;

    /** Additional max height */
    maxHeight?: string;

    /** To define a string that labels the current element **/
    "aria-label"?: string;

    /** To define a string that describe the current element **/
    "aria-describedby"?: string;

    /** Variation for layout of table : bordered - show border style layout and  striped -  show odd even color layout**/
    variant: "bordered" | "striped";

    /** Additional sizes */
    size: "sm" | "md" | "lg";
}
/**
 * @function tableSizeVariants
 * This function is to get the font sizes on the base of size props
 */
const tableSizeVariants = {
    sm: {
        fontSize: fontSizes["sm"],
    },
    md: {
        fontSize: fontSizes["md"],
    },
    lg: {
        fontSize: fontSizes["lg"],
    },
};
/**
 * @function tableStyleVariants
 * This function is to get variant prop and return style on bases of that
 */
const tableStyleVariants = (variant, theme) => {
    // const colorInPalette = theme.palette[colorScheme];
    const variants = {
        bordered: {
            main: {
                border: `1px solid ${theme.palette.paper.border}`,
                cursor: "pointer",
                "& thead": {
                    "& th": {
                        border: "0",
                        borderBottom: `1px solid ${theme.palette.paper.border}`,
                        padding: "15px",
                    },
                    "& td": {
                        border: "0",
                        borderBottom: `1px solid ${theme.palette.paper.border}`,
                    },
                },
                "& tbody": {
                    "& th": {
                        border: "0",
                        borderBottom: `1px solid ${theme.palette.paper.border}`,
                    },
                    "& td": {
                        border: "0",
                        borderBottom: `1px solid ${theme.palette.paper.border}`,
                        padding: "15px",
                    },
                    "& tr": {
                        "&:hover": {
                            backgroundColor: theme.palette.paper.hover,
                        },
                    },
                },
            },
        },
        striped: {
            main: {
                border: `1px solid ${theme.palette.paper.border}`,
                "& thead": {
                    "& th": {
                        border: "0",
                        padding: "15px",
                        borderBottom: `2px solid ${theme.palette.paper.border}`,
                    },
                    "& td": {
                        border: "0",
                    },
                },
                "& tbody": {
                    "& tr": {
                        "&:nth-of-type(odd)": {
                            backgroundColor: theme.palette.paper.background,
                            color: theme.palette.paper.text,
                        },
                        "&:nth-of-type(even)": {
                            backgroundColor: "transparent",
                        },
                    },
                    "& th": {
                        border: "0",
                    },
                    "& td": {
                        border: "0",
                        padding: "15px",
                        borderBottom: `none`,
                    },
                },
            },
        },
    };

    return variants[variant] || variants.bordered;
};

/**
 * @function EmotionTextAreaError
 * This function is used to wrap the error message for style
 */
export const EmotionTableWrapper = styled.div((props) => ({
    overflowX: "auto",
}));

/**
 * @function TableRootProps
 * This function is to add the additional props
 */
interface TableRootProps extends TablePropType {
    theme?: Theme;
    overrideStyle?: React.CSSProperties;
}
/**
 * @function TableRootProps
 * This function to get all props and return style on bases of that
 */
const EmotionTable = styled("table", {
    //shouldForwardProp: (props) => isPropValid(props),
})((props: Partial<TableRootProps>) => {
    if (isObjectEmpty(props.theme)) {
        props.theme = defaultTheme;
    }
    const propsByVariant = tableStyleVariants(props.variant, props.theme);
    return {
        maxHeight: props.maxHeight,
        textAlign: "left",
        width: "100%",
        display: "table",
        borderCollapse: "collapse",
        fontsize: tableSizeVariants[props.size]?.fontSize,
        ...(propsByVariant && propsByVariant.main),
        ...props.overrideStyle,
    };
});
/**
 * @function Table
 * Main table component
 */
export const Table = React.forwardRef<
    HTMLTableElement,
    React.PropsWithChildren<TablePropType>
>(({ header, body, style, className, variant, size, ...props }, ref) => {
    const table = React.useMemo(() => ({ variant, size }), [variant, size]);
    return (
        <>
            <TableContext.Provider value={table}>
                <EmotionTableWrapper>
                    <EmotionTable
                        ref={ref}
                        overrideStyle={style}
                        variant={variant}
                        {...props}
                        className={classNames(className)}
                    >
                        <thead>{header}</thead>
                        <tbody>{body}</tbody>
                    </EmotionTable>
                </EmotionTableWrapper>
            </TableContext.Provider>
        </>
    );
});
/** Default props for table */
Table.defaultProps = {
    id: "Table",
    "aria-label": "mainTable",
    className: "parentTableClass",
    maxHeight: "500px",
    variant: "bordered",
    size: "lg",
};
