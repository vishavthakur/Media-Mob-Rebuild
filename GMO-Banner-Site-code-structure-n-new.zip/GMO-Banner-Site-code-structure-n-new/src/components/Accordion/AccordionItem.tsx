import React, { createContext, useContext } from "react";
import useToggle from "@util/Toggle";
import classNames from "classnames";
import { PropTypes } from "@util/propType";
import styled from "@emotion/styled";
import { ImageType } from "@util/types";
import { ChevronDown, ChevronUp } from "react-feather";
import { AccordionContext } from "./Accordion";
import { useThemeMode } from "src/context/ThemeProvider";
export interface AccordionItemPropType extends Omit<PropTypes, "as"> {
    /** Icon show the content of Accordion **/
    expandIcon?: JSX.Element | ImageType;

    /** Icon hide the content of Accordion **/
    collapseIcon?: JSX.Element | ImageType;

    /**Prop to provide spacing between accordians from bottom*/
    spacing?: boolean;
}

export const AccordionItemContext = createContext<{
    isExpanded: boolean;
    toggleExpand: () => void;
    icon: {
        expandedIconDetails: JSX.Element | ImageType;
        collapsedIconDetails: JSX.Element | ImageType;
    };
} | null>(null);

const StyledAccordionContainer = ({ overrideStyle, spacing }) => {
    return {
        ":first-child": {
            borderTop: "1px solid #d0d0d0",
        },
        borderRight: " 1px solid #d0d0d0",
        borderBottom: " 1px solid #d0d0d0",
        borderLeft: "1px solid #d0d0d0",
        ...(spacing && {
            marginBottom: "10px",
        }),
        ...overrideStyle,
    };
};

const EmotionAccordionContainer = styled("div")(StyledAccordionContainer);

export const AccordionItem: React.FC<{
    spacing?: AccordionItemPropType["spacing"];
    expandIcon?: AccordionItemPropType["expandIcon"];
    collapseIcon?: AccordionItemPropType["collapseIcon"];
    style?: PropTypes["style"];
    className?: PropTypes["className"];
    id: PropTypes["id"];
}> = ({
    children,
    spacing,
    style,
    className,
    id,
    expandIcon,
    collapseIcon,
}) => {
    const [isExpanded, toggleExpand] = useToggle(false);
    const accordionCtx = useContext(AccordionContext);
    const { themeMode } = useThemeMode();

    return (
        <AccordionItemContext.Provider
            value={{
                isExpanded,
                toggleExpand,
                icon: {
                    collapsedIconDetails: collapseIcon ||
                        accordionCtx?.icon?.collapsedIconDetails || (
                            <ChevronDown
                                color={themeMode === "light" ? "#555" : "#fff"}
                            />
                        ),
                    expandedIconDetails: expandIcon ||
                        accordionCtx?.icon?.expandedIconDetails || (
                            <ChevronUp
                                color={themeMode === "light" ? "#555" : "#fff"}
                            />
                        ),
                },
            }}
        >
            <EmotionAccordionContainer
                spacing={spacing}
                id={`accordion_${id}`}
                overrideStyle={style}
                className={classNames(className)}
            >
                {children}
            </EmotionAccordionContainer>
        </AccordionItemContext.Provider>
    );
};
