import React, { createContext } from "react";

import { ImageType } from "@util/types";
export interface AccordionProps {
    icon?: AccordionContextType["icon"];
}
interface AccordionContextType {
    icon: {
        expandedIconDetails: JSX.Element | ImageType;
        collapsedIconDetails: JSX.Element | ImageType;
    };
}

export const AccordionContext = createContext<AccordionContextType | null>(
    null,
);

export const Accordion: React.FC<AccordionProps> = ({
    children,
    icon = null,
}) => {
    return (
        <AccordionContext.Provider value={{ icon }}>
            {children}
        </AccordionContext.Provider>
    );
};
