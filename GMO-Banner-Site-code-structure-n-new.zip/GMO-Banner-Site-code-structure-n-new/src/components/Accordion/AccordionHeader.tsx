import React, { useContext } from "react";
import { PropTypes } from "@util/propType";
import styled from "@emotion/styled";
import Image from "@templates/ImageConversion"
import { ImageType, Property } from "@util/types";
import { Theme } from "src/context/ThemeProvider";
import { AccordionItemContext } from "./AccordionItem";
import { useThemeMode } from "src/context/ThemeProvider";

export interface AccordionHeaderPropType extends Omit<PropTypes, "as"> {
    /** placement of icon**/
    iconAlignment?: Property.DisplayDirection;
}

const ICON_CHANGE_DELAY_DURATION = 200; // delay duration in ms

const EmotionAccordionContent = styled("div")(
    ({
        iconAlignment,
        theme,
        disable,
    }: {
        theme?: Theme;
        iconAlignment: AccordionHeaderPropType["iconAlignment"];

        disable: boolean;
    }) => {
        return {
            display: "flex",
            cursor: "pointer",
            padding: "26px 20px",
            transition: `all ${ICON_CHANGE_DELAY_DURATION * 3}ms ease-in-out`,
            flexDirection: iconAlignment === "rtl" ? "row-reverse" : "row",
            backgroundColor: theme.palette.paper.background,
            ...(iconAlignment && {
                justifyContent: "space-between",
            }),
            ...(disable && {
                opacity: "0.6",
                cursor: "not-allowed",
            }),
        };
    },
);

export const AccordionHeader: React.FC<{
    iconAlignment?: AccordionHeaderPropType["iconAlignment"];
    disable?: PropTypes["disable"];
}> = ({ children, iconAlignment, disable }) => {
    const itemCtx = useContext(AccordionItemContext);
    const isMount = React.useRef<boolean>(true);
    const { themeMode } = useThemeMode();
    const getIcon = () =>
        itemCtx.isExpanded
            ? itemCtx.icon.expandedIconDetails
            : itemCtx.icon.collapsedIconDetails;
    const [CurrentIcon, setCurrentIcon] = React.useState(getIcon);
    const accordion_header_ref = React.useRef<HTMLDivElement>();

    React.useEffect(() => {
        let timmer;
        if (!isMount.current) {
            timmer = setTimeout(() => {
                setCurrentIcon(getIcon());
            }, ICON_CHANGE_DELAY_DURATION);
        }
        return () => {
            isMount.current = false;
            timmer && clearTimeout(timmer);
        };
    }, [itemCtx.isExpanded, themeMode]);

    return (
        <EmotionAccordionContent
            iconAlignment={iconAlignment}
            disable={disable}
            onClick={disable ? undefined : () => itemCtx.toggleExpand()}
            onKeyPress={disable ? undefined : () => itemCtx.toggleExpand()}
            tabIndex={-1}
            ref={accordion_header_ref}
            aria-expanded={itemCtx.isExpanded ? true : false}
            role="button"
            className="AccordionHeader"
        >
            {children}
            <div
                style={
                    iconAlignment === "rtl"
                        ? { marginRight: "auto" }
                        : { marginLeft: "auto" }
                }
            >
                {typeof CurrentIcon !== "function" &&
                (CurrentIcon as ImageType).id ? (
                    <Image
                       // id={(CurrentIcon as ImageType).id}
                        src={(CurrentIcon as ImageType).image.mediaItemUrl}
                        height={
                            (CurrentIcon as ImageType).image?.mediaDetails
                                ?.height || "15px"
                        }
                        width={
                            (CurrentIcon as ImageType).image?.mediaDetails
                                ?.width || "15px"
                        }
                    />
                ) : (
                    CurrentIcon
                )}
            </div>
        </EmotionAccordionContent>
    );
};
