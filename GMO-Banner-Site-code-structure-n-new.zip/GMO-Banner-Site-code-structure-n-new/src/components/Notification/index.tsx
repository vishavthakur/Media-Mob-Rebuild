import React from "react";
import styled from "@emotion/styled";
import { defaultTheme, Theme, useThemeMode } from "src/context/ThemeProvider";
import { ImageType, Property } from "@util/types";
import { PropTypes } from "@util/propType";
import { isObjectEmpty } from "@util/helpers";
import { alpha } from "@util/Theme/colorManipulator";
import classNames from "classnames";
import Image from "@templates/ImageConversion"
import { X } from "react-feather";

interface NotificationPropType extends Omit<PropTypes, "as" | "disable"> {
    /** Additional border radius in px | % **/
    borderRadius?: Property.BorderRadius;

    /** Custom icon before text from outside the component **/
    startIcon?: ImageType;

    /** Custom icon after text from outside the component **/
    endIcon?: ImageType;

    closeIcon?: any;

    /** Types to align the items **/
    alignItems?: Property.AlignItem;

    /** Types for aligns a flex container’s lines within when there is extra space in the cross-axis **/
    justifyContent: Property.JustifyElemnent;

    /** Variations for notification layout: contained- filled layout,  outline- bordered layout **/
    variant: "contained" | "outline" | "ghost";
}
const getPropsByVariant = ({ variant, colorScheme, theme }) => {
    const colorInPalette = theme.palette[colorScheme];
    const variants = {
        contained: colorInPalette && {
            main: {
                backgroundColor: `${colorInPalette.main}`,
                border: `1px solid ${colorInPalette.main}`,
                color: colorInPalette.contrastText,
            },
        },
        outline: colorInPalette && {
            main: {
                backgroundColor: ` transparent`,
                border: `1px solid ${colorInPalette.main}`,
                color: colorInPalette.main,
            },
        },
        ghost: {
            main: {
                backgroundColor: alpha(colorInPalette.main, 0.2),
                color: colorInPalette.main,
                border: `1px solid ${alpha(colorInPalette.main, 0.5)}`,
                "&::placeholder": {
                    color: colorInPalette.main,
                },
            },
        },
    };

    return variants[variant];
};

export type StyledNotificationProps = {
    theme?: Theme;
    overrideStyle?: React.CSSProperties;
} & Partial<NotificationPropType>;

/**
 * @function StyledNotification
 * This function that takes all props and theme(passed by the emotion itself) as a argument returns object of its types
 */
const StyledNotification = ({
    alignItems,
    justifyContent,
    variant = "outline",
    borderRadius,
    theme,
    colorScheme,
    overrideStyle,
}: StyledNotificationProps) => {
    if (isObjectEmpty(theme)) {
        theme = defaultTheme;
    }
    const propsByVariant = getPropsByVariant({
        variant,
        colorScheme,
        theme,
    });
    return {
        alignItems,
        justifyContent,
        variant,
        borderRadius,
        position: "relative" as Property.Position,
        display: "flex",
        ...(propsByVariant && propsByVariant.main),
        ...overrideStyle,
    };
};
/**
 * @MarginDirection Constant used for declaration of margin to image
 **/
enum MarginDirection {
    left = "Left",
    right = "Right",
}

/**
 * @function StyledNotificationLeftImage
 * This function that takes all props and theme(passed by the emotion itself) as a argument returns object of its types
 */
const StyledNotificationImage = ({
    marginSide,
}: {
    marginSide: MarginDirection;
}) => {
    return {
        margin: 0,
        [`margin${marginSide}`]: 10,
        width: "20px",
        display: "inline-flex",
        alignSelf: "center",
    };
};

/**
 * @function EmotionNotificationImage
 * This function is used to wrap the component style for Image
 */
export const EmotionNotificationImage = styled("span")(StyledNotificationImage);

/**
 * 
 * @param image ImageType
 * @returns JSX.Element

 * @description Takes image object of type ImageType and return notification images JSX Element
 */
const getNotificationImage = (
    icon: ImageType,
    marginSide: MarginDirection,
): JSX.Element => (
    <EmotionNotificationImage marginSide={marginSide}>
        <Image
            //id={icon?.id}
            src={icon?.image?.mediaItemUrl}
            alt={icon?.image?.altText}
            height={icon?.image?.mediaDetails?.height}
            width={icon?.image?.mediaDetails?.width}
            layout="fixed"
        />
    </EmotionNotificationImage>
);

/**
 * @function StyledNotificationIcon
 * This function that takes all props and theme(passed by the emotion itself) as a argument returns object of its types
 */
const StyledNotificationIcon = () => {
    return {
        display: "inline-flex",
        position: "absolute" as Property.Position,
        right: "5px",
        top: "5px",
        cursor: "pointer",
    };
};

/**
 * @function EmotionalNotification
 * This function is used to wrap the component style for Notification
 */
export const EmotionalNotification = styled("div")(StyledNotification);

/**
 * @function EmotionNotificationIcon
 * This function is used to add style for modal close icon
 */
export const EmotionNotificationIcon = styled("div")(StyledNotificationIcon);

/**
 * @function Notification
 * This function is used to create Notification Component in which we wrap EmotionNotification
 */
export const Notification = React.forwardRef<
    HTMLDivElement,
    React.PropsWithChildren<NotificationPropType>
>(
    (
        {
            children,
            startIcon,
            endIcon,
            closeIcon,
            className,
            style,
            onClick,
            ...props
        },
        ref,
    ) => {
        const { themeMode } = useThemeMode();
        return (
            <EmotionalNotification
                className={classNames(className)}
                ref={ref}
                {...props}
                overrideStyle={style}
            >
                {startIcon?.image?.mediaItemUrl &&
                    getNotificationImage(startIcon, MarginDirection.right)}
                {children}
                {endIcon?.image?.mediaItemUrl &&
                    getNotificationImage(endIcon, MarginDirection.left)}

                <EmotionNotificationIcon onClick={onClick}>
                    {closeIcon && closeIcon !== "" ? (
                        closeIcon
                    ) : themeMode === "light" ? (
                        <X size="16px" />
                    ) : (
                        <X size="16px" color="#fff" />
                    )}
                    {/* <Image
                        id={closeIcon?.id}
                        src={closeIcon?.image?.mediaItemUrl}
                        alt={closeIcon?.image?.altText}
                        width={closeIcon?.image?.mediaDetails?.width || 15}
                        height={closeIcon?.image?.mediaDetails?.height || 15}
                        onClick={onClick}
                    /> */}
                </EmotionNotificationIcon>
            </EmotionalNotification>
        );
    },
);

/**
 * defaultProps - To define default values for component props
 */
Notification.defaultProps = {
    variant: "outline",
    justifyContent: "flex-start",
    alignItems: "center",
    colorScheme: "primary",
    borderRadius: 5,
    id: "notification_component",
};
