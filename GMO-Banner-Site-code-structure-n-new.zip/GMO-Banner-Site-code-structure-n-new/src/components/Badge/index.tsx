import * as React from "react";
import styled from "@emotion/styled";
import { isObjectEmpty } from "../../utils/assertion";
import { defaultTheme, Theme } from "src/context/ThemeProvider";
import { PropTypes } from "@util/propType";
import { alpha } from "@util/Theme/colorManipulator";
import classNames from "classnames";

interface BadgePropType
    extends Pick<PropTypes, "id" | "className" | "colorScheme" | "style"> {
    /** Add badge text and count to display badge */
    content: string | number;

    /** Radius to rounds the corners of badge from outer border in number **/
    borderRadius?: number;

    /** To show badge or not **/
    show?: boolean;

    /** To show max count **/
    max?: number;

    /** Badge variations can be of 4 types: 'solid - filled layout', 'dot - dot info style layout' and 'outline - bordered layout', 'ghost - to show transculant style layout' **/
    variant?: "solid" | "dot" | "outline" | "ghost";
}

type StyleBadgeProps = {
    isChildrenNull?: boolean;
    theme?: Theme;
    overrideStyle?: React.CSSProperties;
} & Partial<BadgePropType>;

/**
 * @function getPropsByVariant
 * This function is used to pass the color scheme, variant and the emotion theme
 */
const getPropsByVariant = ({ variant, colorScheme, theme }) => {
    const colorInPalette = theme.palette[colorScheme];

    const variants = {
        outline: colorInPalette && {
            main: {
                border: `1px solid ${colorInPalette.main}`,
                backgroundColor: theme.palette.common.transparent,
                color: colorInPalette.main,
            },
        },
        solid: colorInPalette && {
            main: {
                backgroundColor: colorInPalette.main,
                color: colorInPalette.contrastText,
            },
        },
        dot: colorInPalette && {
            main: {
                backgroundColor: colorInPalette.main,
            },
        },
        ghost: colorInPalette && {
            main: {
                backgroundColor: alpha(colorInPalette.main, 0.2),
                color: colorInPalette.main,
            },
        },
    };

    return variants[variant] || variants.solid;
};

/**
 * @function StyledBadge
 * This function that takes all props and theme(passed by the emotion itself) as a argument returns object of its types
 */

/**
 * @function EmotionBadge
 * This function is used to wrap the badge component for style
 */
export const EmotionBadge = styled("div", {
    shouldForwardProp: (props: string) => {
        return ![
            "colorScheme",
            "variant",
            "elevation",
            "disable",
            "alignItems",
            "borderRadius",
            "size",
            "justifyContent",
            "minWidth",
            "fullWidth",
            "overrideStyle",
            "show",
            "isChildrenNull",
        ].includes(props);
    },
})(
    ({
        borderRadius,
        show,
        theme,
        variant,
        colorScheme,
        isChildrenNull,
        overrideStyle,
    }: StyleBadgeProps) => {
        if (isObjectEmpty(theme)) {
            theme = defaultTheme;
        }

        const propsByVariant = getPropsByVariant({
            variant,
            theme,
            colorScheme,
        });
        return {
            borderRadius,
            display: `${show ? "inline-flex" : "none"}`,
            flexDirection: "row",
            flexWrap: "wrap",
            justifyContent: "center",
            alignContent: "center",
            alignItems: "center",
            fontSize: 10,
            height: borderRadius * 2,
            minWidth: borderRadius * 2,
            padding: `${variant !== "dot" ? "0 6px" : ""}`,
            textAlign: "center",
            verticalAlign: "baseline",
            ...(propsByVariant && propsByVariant.main),

            position: `${isChildrenNull ? "absolute" : "relative"}`,
            right: `${isChildrenNull ? "0" : "unset"}`,
            top: `${isChildrenNull ? "0" : "unset"}`,
            transform: `${
                isChildrenNull ? "scale(1) translate(50%, -50%)" : "unset"
            }`,
            ...overrideStyle,
        };
    },
);

export const Badge = React.forwardRef<
    HTMLDivElement,
    React.PropsWithChildren<BadgePropType>
>(
    (
        {
            id,
            children,
            className,
            show,
            max,
            content,
            variant,
            style,
            ...props
        },
        ref,
    ) => (
        <div
            style={{
                display: "inline - flex",
                position: "relative",
            }}
            className={classNames(className)}
        >
            <EmotionBadge
                id={id}
                ref={ref}
                show={show}
                isChildrenNull={true}
                variant={variant}
                overrideStyle={style}
                {...props}
            >
                {variant !== "dot" && (max ?? content)}
            </EmotionBadge>
            {children}
        </div>
    ),
);

/**
 * defaultProps - To define default values for component props
 */
Badge.defaultProps = {
    show: true,
    borderRadius: 10,
    variant: "solid",
    content: "Tag",
};
