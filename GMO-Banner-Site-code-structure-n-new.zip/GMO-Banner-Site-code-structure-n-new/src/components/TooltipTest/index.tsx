import * as React from "react";
import { cx as classNames } from "@emotion/css";
import { Property } from "@util/types";
import { PropTypes } from "@util/propType";
import { Theme, defaultTheme } from "src/context/ThemeProvider";
import { spacing, fontSizes } from "@util/units";
import styled from "@emotion/styled";
import { keyframes } from "@emotion/react";
import { isObjectEmpty } from "../../utils/helpers";
interface TooltipPropType extends Omit<PropTypes, "onClick" | "as"> {
    title?: string; //add comment - tooltipTitle

    /** Additional width of tooltip without px **/
    width?: Property.Width;

    /** Wrapping of text for tooltip **/
    wrapText?: boolean;

    /** Tooltip sizes can be of 3 types: 'sm - small view of Tooltip size' , 'md - medium view of Tooltip size' and 'lg - large view of Tooltip size **/
    size?: "sm" | "md" | "lg";

    /** Variations for position of tooltip: 'top' | 'bottom' | 'left' | 'right'  **/
    position?: Property.TooltipPlacement;

    /** To disable the whole element **/
    disable?: boolean;

    children?: any;

    arrow?: boolean;

    /** Add Space Between Tooltip Box and Element **/
    toolTipSpace?: number;
}
const composeCallbacks = (...callbacks) => {
    return (...args) => {
        const fns = callbacks.filter(Boolean);
        for (const callback of fns) callback(...args);
    };
};

const mergeRefs = (...refs) => {
    const filteredRefs = refs.filter(Boolean);
    if (!filteredRefs.length) return null;
    if (filteredRefs.length === 0) return filteredRefs[0];
    return (inst) => {
        for (const ref of filteredRefs) {
            if (typeof ref === "function") {
                ref(inst);
            } else if (ref) {
                ref.current = inst;
            }
        }
    };
};

const getPropsByPosition = ({ position }) => {
    const toolTipHorizontalAnimation = keyframes`
         0% {
             visibility: hidden;
             opacity: 0;
             transform: translate(-50%, -10%);
            }
     
      100% {
        visibility: visible;
        opacity: 1;
          transform: translate(-50%, 0%);
        }
        `;

    const toolTipVerticalAnimation = keyframes`
    0% {
        visibility: hidden;
             opacity: 0;
        transform: translate(10%, -50%);
    }
    100% {
        visibility: visible;
        opacity: 1;
        transform: translate(0, -50%);
    }
    `;

    const positions = {
        top: {
            left: "50%",
            transform: "translateX(-50%)",
            bottom: "calc(100% + 6px)",
            animation: `${toolTipHorizontalAnimation} 200ms ease forwards`,
            animationDelay: "300ms",
            top: "unset !important",

            /// If arrow true then implement after
            "&::after": {
                top: "100%",
                left: "50%",
                transform: "translateX(-50%)",
                width: "0",
                height: "0",
                //missing border =  border colors
            },
        },
        bottom: {
            left: "50%",
            transform: "translateX(-50%)",
            top: "calc(100% + 6px)",
            animation: `${toolTipHorizontalAnimation} 200ms ease forwards`,
            animationDelay: "300ms",
            bottom: "unset !important",
            /// If arrow true then implement after
            "&::after": {
                bottom: "100%",
                left: "50%",
                transform: "translateX(-50%)",
                width: "0",
                height: "0",
                //missing border =  border colors
            },
        },
        left: {
            right: "calc(100% + 6px)",
            top: "50%",
            animation: `${toolTipVerticalAnimation} 200ms ease forwards`,
            animationDelay: "300ms",
            left: "unset !important",
            /// If arrow true then implement after
            "&::after": {
                top: "50%",
                left: "100%",
                transform: " translateY(-50%)",
                width: 0,
                height: 0,
                //missing border =  border colors
            },
        },
        right: {
            left: "calc(100% + 6px)",
            top: "50%",
            animation: `${toolTipVerticalAnimation} 200ms ease forwards`,
            animationDelay: "300ms",
            /// If arrow true then implement after
            "&::after": {
                top: "50%",
                right: "100%",
                transform: "translateY(-50%)",
                width: "0",
                height: "0",
                //missing border =  border colors
            },
        },
    };
    return positions[position] || positions.top;
};

const tooltipSizeProps = {
    sm: {
        fontSize: fontSizes["xsmall"],
        padding: `${spacing["xsmall"]} ${spacing["small"]}`,
    },
    md: {
        fontSize: fontSizes["small"],
        padding: `${spacing["small"]} ${spacing["medium"]}`,
    },
    lg: {
        fontSize: fontSizes["medium"],
        padding: `${spacing["medium"]} ${spacing["large"]}`,
    },
};

export type StyledTooltipWapperProps = {
    theme?: Theme;
    overrideStyle?: React.CSSProperties;
    bottom?: {
        bottom: number;
        left: number;
    };
    left?: {
        left: number;
        top: number;
    };
    right?: {
        left: number;
        top: number;
    };
    top?: {
        top: number;
        left: number;
    };
    rightEnd?: {
        top: number;
        left: number;
    };
    rightStart?: {
        top: number;
        left: number;
    };
    leftStart?: {
        top: number;
        left: number;
    };
    leftEnd?: {
        top: number;
        left: number;
    };
    topStart?: {
        top: number;
        left: number;
    };
    topEnd?: {
        top: number;
        left: number;
    };
    bottomStart?: {
        top: number;
        left: number;
    };
    bottomEnd?: {
        top: number;
        left: number;
    };
} & Partial<TooltipPropType>;
/****
 * @function StyledTooltipWrapper
 * function to style the wrapper for tooltip
 */

const StyledTooltipWrapper = ({
    overrideStyle,
    position,
    size,
    bottom,
    left,
    right,
    top,
    rightStart,
    rightEnd,
    leftStart,
    leftEnd,
    topEnd,
    topStart,
    bottomEnd,
    bottomStart,
    theme,
    colorScheme,
}: // bottomEnd,
StyledTooltipWapperProps) => {
    const fontSizeBySize = tooltipSizeProps[size]?.fontSize;
    const paddingBySize = tooltipSizeProps[size]?.padding;
    if (isObjectEmpty(theme)) {
        theme = defaultTheme;
    }
    return {
        display: "inline-block",
        backgroundColor: colorScheme
            ? theme.palette[colorScheme].main
            : theme.palette.paper.background,
        color: colorScheme
            ? theme.palette[colorScheme].contrastText
            : theme.palette.paper.text,
        borderRadius: "6px",
        padding: ".25rem .5rem",
        zIndex: 9999,
        cursor: "pointer",
        position: "absolute" as Property.Position,
        transformOrigin: "left center",
        ...(position === "top" ? { top: top?.top, left: top.left } : ``),
        ...(position == "bottom"
            ? { top: bottom?.bottom, left: bottom.left }
            : ``),
        ...(position == "left" ? { left: left?.left, top: left.top } : ``),
        ...(position == "right" ? { left: right?.left, top: right.top } : ``),
        ...(position == "rightEnd"
            ? { left: rightEnd?.left, top: rightEnd?.top }
            : ``),
        ...(position == "rightStart"
            ? { left: rightStart?.left, top: rightStart?.top }
            : ``),
        ...(position == "leftEnd"
            ? { left: leftEnd?.left, top: leftEnd?.top }
            : ``),
        ...(position == "leftStart"
            ? { left: leftStart?.left, top: leftStart?.top }
            : ``),
        ...(position === "topEnd"
            ? { top: topEnd?.top, left: topEnd?.left }
            : ``),
        ...(position === "topStart"
            ? { top: topStart?.top, left: topStart?.left }
            : ``),
        ...(position == "bottomEnd"
            ? {
                  top: bottomEnd?.top,
                  left: bottomEnd?.left,
              }
            : ``),
        ...(position == "bottomStart"
            ? { top: bottomStart?.top, left: bottomStart?.left }
            : ``),
        ...(paddingBySize && { padding: paddingBySize }),
        ...(fontSizeBySize && { fontSize: fontSizeBySize }),
        ...overrideStyle,
    };
};

export const EmotionTooltipWrapper = styled("div")(StyledTooltipWrapper);
export const EmotionTooltip = styled("div")(``);

export const TooltipTest: React.FC<TooltipPropType> = ({
    children,
    title,
    className,
    toolTipSpace,
    style,
    ...props
}: TooltipPropType) => {
    const [active, setActive] = React.useState(false);
    const [
        {
            top,
            left,
            right,
            bottom,
            rightStart,
            rightEnd,
            leftStart,
            leftEnd,
            topEnd,
            topStart,
            bottomEnd,
            bottomStart,
        },
        setPosition,
    ] = React.useState({
        top: {
            top: 0,
            left: 0,
        },
        left: {
            left: 0,
            top: 0,
        },
        right: {
            left: 0,
            top: 0,
        },
        rightEnd: {
            left: 0,
            top: 0,
        },
        rightStart: {
            left: 0,
            top: 0,
        },
        leftEnd: {
            left: 0,
            top: 0,
        },
        leftStart: {
            left: 0,
            top: 0,
        },
        topEnd: {
            left: 0,
            top: 0,
        },
        topStart: {
            left: 0,
            top: 0,
        },
        bottomEnd: {
            left: 0,
            top: 0,
        },
        bottomStart: {
            left: 0,
            top: 0,
        },
        bottom: {
            bottom: 0,
            left: 0,
        },
    });
    const trigger = React.useRef<HTMLDivElement>(null);
    const tip = React.useRef<HTMLDivElement>(null);

    const show = () => setActive(true);
    const hide = () => setActive(false);

    const child =
        typeof children === "string" ? (
            <span>{children}</span>
        ) : (
            React.Children.only(children)
        );

    React.useEffect(() => {
        if (active && trigger && trigger.current && tip && tip.current) {
            const triggerEl = trigger.current.getBoundingClientRect();
            const tipEl = tip.current.getBoundingClientRect();
            setPosition({
                top: {
                    top:
                        triggerEl.y < 50
                            ? triggerEl.y +
                              window.pageYOffset +
                              triggerEl.height +
                              toolTipSpace
                            : triggerEl.y +
                              window.pageYOffset -
                              tipEl.height -
                              toolTipSpace,
                    left:
                        triggerEl.x +
                        window.pageXOffset +
                        (triggerEl.width - tipEl.width) / 2,
                },
                topStart: {
                    top:
                        triggerEl.y > 20
                            ? triggerEl.y +
                              window.pageYOffset -
                              tipEl.height -
                              toolTipSpace
                            : window.pageYOffset +
                              triggerEl.y +
                              triggerEl.height +
                              toolTipSpace,
                    left: triggerEl.x + window.pageXOffset,
                },
                topEnd: {
                    top:
                        triggerEl.y > 20
                            ? window.pageYOffset +
                              triggerEl.y -
                              tipEl.height -
                              toolTipSpace
                            : window.pageYOffset +
                              triggerEl.y +
                              triggerEl.height +
                              toolTipSpace,
                    left:
                        window.pageXOffset +
                        triggerEl.x +
                        (triggerEl.width - tipEl.width),
                },
                left: {
                    left:
                        triggerEl.x < 50
                            ? triggerEl.x +
                              window.pageXOffset +
                              triggerEl.width +
                              toolTipSpace
                            : triggerEl.x +
                              window.pageXOffset -
                              tipEl.width -
                              toolTipSpace,
                    top: triggerEl.y + window.pageYOffset,
                },

                leftStart: {
                    top: window.pageYOffset + triggerEl.y,
                    left:
                        triggerEl.x > 20
                            ? triggerEl.x +
                              window.pageXOffset -
                              tipEl.width -
                              toolTipSpace
                            : triggerEl.x +
                              window.pageXOffset +
                              triggerEl.width +
                              toolTipSpace,
                },
                leftEnd: {
                    top:
                        triggerEl.y +
                        window.pageYOffset +
                        triggerEl.height -
                        tipEl.height,
                    left:
                        triggerEl.x > 20
                            ? triggerEl.x +
                              window.pageXOffset -
                              tipEl.width -
                              toolTipSpace
                            : triggerEl.x +
                              window.pageXOffset +
                              triggerEl.width +
                              toolTipSpace,
                },
                right: {
                    left:
                        window.screen.width -
                            (window.pageXOffset +
                                triggerEl.x +
                                triggerEl.width) <
                        100
                            ? triggerEl.x +
                              window.pageXOffset -
                              tipEl?.width -
                              toolTipSpace
                            : triggerEl.x +
                              window.pageXOffset +
                              triggerEl.width +
                              toolTipSpace,

                    top: triggerEl.y + window.pageYOffset,
                },

                rightStart: {
                    top: triggerEl.y + window.pageYOffset,
                    left:
                        window.screen.width - (triggerEl.x + triggerEl.width) <
                        100
                            ? triggerEl.x +
                              window.pageXOffset -
                              tipEl.width -
                              toolTipSpace
                            : window.pageXOffset +
                              triggerEl.x +
                              triggerEl.width +
                              toolTipSpace,
                },
                rightEnd: {
                    top:
                        triggerEl.y +
                        window.pageYOffset +
                        triggerEl.height -
                        tipEl.height,
                    left:
                        window.screen.width -
                            (window.pageXOffset +
                                triggerEl.x +
                                triggerEl.width) >
                        30
                            ? window.pageXOffset +
                              triggerEl.x +
                              triggerEl.width +
                              toolTipSpace
                            : window.pageXOffset +
                              triggerEl.x -
                              triggerEl.width -
                              toolTipSpace,
                },
                bottom: {
                    bottom:
                        window.screen.height -
                            (triggerEl.top + triggerEl.height) <
                        170
                            ? triggerEl.y +
                              window.pageYOffset -
                              triggerEl.height -
                              toolTipSpace
                            : triggerEl.y +
                              window.pageYOffset +
                              triggerEl.height +
                              toolTipSpace,
                    left:
                        triggerEl.x +
                        window.pageXOffset +
                        (triggerEl.width - tipEl.width) / 2,
                },
                bottomStart: {
                    top:
                        window.screen.height -
                            (triggerEl.top + triggerEl.height) >
                        170
                            ? triggerEl.y +
                              window.pageYOffset +
                              triggerEl.height +
                              toolTipSpace
                            : triggerEl.y +
                              window.pageYOffset -
                              triggerEl.height -
                              toolTipSpace,
                    left: triggerEl.x + window.pageXOffset,
                },
                bottomEnd: {
                    top:
                        window.screen.height -
                            (triggerEl.top + triggerEl.height) >
                        170
                            ? triggerEl.y +
                              window.pageYOffset +
                              triggerEl.height +
                              toolTipSpace
                            : triggerEl.y +
                              window.pageYOffset -
                              triggerEl.height -
                              toolTipSpace,
                    left:
                        window.pageXOffset +
                            triggerEl.x +
                            triggerEl.width -
                            tipEl.width >
                        0
                            ? window.pageXOffset +
                              triggerEl.x +
                              triggerEl.width -
                              tipEl.width
                            : window.pageXOffset + triggerEl.x,
                },
            });
        }
    }, [active, trigger, tip]);

    return (
        <>
            {active && (
                <EmotionTooltipWrapper
                    className={classNames(className)}
                    top={top}
                    left={left}
                    right={right}
                    bottom={bottom}
                    rightStart={rightStart}
                    rightEnd={rightEnd}
                    leftStart={leftStart}
                    leftEnd={leftEnd}
                    topStart={topStart}
                    topEnd={topEnd}
                    bottomStart={bottomStart}
                    bottomEnd={bottomEnd}
                    toolTipSpace={toolTipSpace}
                    ref={tip}
                    overrideStyle={style}
                    {...props}
                >
                    {title}
                </EmotionTooltipWrapper>
            )}
            {React.cloneElement(child, {
                ...child.props,
                ref: mergeRefs(child.ref, trigger),
                onMouseEnter: child.props["onMouseEnter"]
                    ? composeCallbacks(child.props.onMouseEnter, show)
                    : show,
                onMouseLeave: child.props["onMouseLeave"]
                    ? composeCallbacks(child.props.onMouseLeave, hide)
                    : hide,
            })}
        </>
    );
};

TooltipTest.defaultProps = {
    toolTipSpace: 5,
};
