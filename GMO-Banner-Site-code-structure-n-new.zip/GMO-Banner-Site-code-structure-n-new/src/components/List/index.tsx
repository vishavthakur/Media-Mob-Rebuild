import * as React from "react";
import { cx as classNames } from "@emotion/css";
import { Property } from "@util/types";
import { PropTypes } from "@util/propType";
import { Theme } from "src/context/ThemeProvider";
import styled from "@emotion/styled";
import { Paper } from "@components/Paper";
export interface ListPropType
    extends Omit<
        PropTypes<HTMLDivElement, "ul" | "ol">,
        "colorScheme" | "disable" | "onClick"
    > {
    /** Additional max height */
    maxHeight?: Property.MaxHeight;

    /** For providing className in Parent Component  **/
    parentClass?: string;

    /** To Make List Scrollable **/
    scrollable?: boolean;

    /** Radius to rounds the corners of an element from outer border edge **/
    borderRadius?: number;
}

type ListParentProps = {
    theme?: Theme;
    overrideStyle?: React.CSSProperties;
} & Partial<ListPropType>;

/**
 * @function StyledList
 * This function that takes all props and theme(passed by the emotion itself) as a argument returns object of its types
 */
const StyledList = () => {
    return {
        width: "100%",
        margin: "0",
        padding: "0",
        listStyle: "none",
    };
};

/**
 * @function EmotionListParent
 * This function that takes all props and theme(passed by the emotion itself) as a argument returns object of its types
 * it is used to style the parent div element in list
 */
const EmotionListParent = styled(Paper, {
    shouldForwardProp: (props: string) => {
        return ![
            "colorScheme",
            "overrideStyle",
            "errorMessage",
            "disable",
            "borderRadius",
            "scrollable",
            "maxHeight",
            "alignItems",
        ].includes(props);
    },
})(
    ({
        maxHeight,
        scrollable,
        borderRadius,
        overrideStyle,
    }: ListParentProps) => {
        return {
            width: "100%",
            maxHeight,
            borderRadius,
            ...(scrollable && { overflowY: "scroll" }),
            ...overrideStyle,
        };
    },
);

/**
 * @function EmotionList
 * This function is used to style the ul element of list
 */
const EmotionList = styled("ul", {
    shouldForwardProp: (props: string) => {
        return ![
            "alignItems",
            "colorScheme",
            "overrideStyle",
            "errorMessage",
            "disable",
            "borderRadius",
            "scrollable",
            "maxHeight",
        ].includes(props);
    },
})(StyledList);

/**
 * List Component
 */
export const List = React.forwardRef<
    HTMLDivElement,
    React.PropsWithChildren<ListPropType>
>(({ id, parentClass, className, style, children, ...props }, ref) => (
    <>
        <EmotionListParent
            id={id}
            // key={"fishfi"}
            borderRadius={0}
            className={classNames(parentClass)}
            {...props}
            ref={ref}
            overrideStyle={style}
        >
            <EmotionList key={"listKey"} className={classNames(className)}>
                {children}
            </EmotionList>
        </EmotionListParent>
    </>
));

/**
 * defaultProps - To define default values for component props
 */

List.defaultProps = {
    scrollable: false,
    maxHeight: "400px",
    // borderRadius: 5,
};
