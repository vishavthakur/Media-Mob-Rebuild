import React from "react";
import styled from "@emotion/styled";
import { isObjectEmpty } from "../../utils/helpers";
import { defaultTheme, Theme } from "src/context/ThemeProvider";
import { Property } from "@util/types";
import { PropTypes } from "@util/propType";
import classNames from "classnames";

interface DividerPropType
    extends Omit<PropTypes<HTMLHRElement>, "as" | "onClick" | "disable"> {
    /** Width for the Border Prop */
    width?: Property.Width;

    /** Height for the Border Prop */
    height?: Property.Height;

    /** Bottom BorderWidth for the Border Prop */
    borderBottomWidth?: string;
    /** Left BorderWidth for the Border Prop */
    borderLeftWidth?: string;

    /** Variations for divider style type **/
    variant: "solid" | "dashed" | "dotted";

    /** Orientation for the Border **/
    orientation: "horizontal" | "vertical";
}

/**
 * @function getPropsByVariant
 * This function is used to pass the color scheme, variant and the emotion theme
 */

const getPropsByVariant = ({ variant, colorScheme, orientation, theme }) => {
    const colorInPalette = theme.palette[colorScheme];

    const variants = {
        solid: colorInPalette && {
            main: {
                borderStyle: `solid`,
                borderColor: `${colorInPalette.main}`,
            },
        },
        dashed: colorInPalette && {
            main: {
                borderStyle: `dashed`,
                borderColor: `${colorInPalette.main}`,
            },
        },
        dotted: colorInPalette && {
            main: {
                borderStyle: `dotted`,
                borderColor: `${colorInPalette.main}`,
            },
        },
    };
    const orientations = {
        horizontal: {
            main: {
                //orientation: `horizontal`,
                borderTopWidth: `0px`,
                borderRightWidth: `0px`,
                borderLeftWidth: `0px`,
            },
        },
        vertical: {
            main: {
                display: "inline-flex",
                margin: `0 5px`,
                alignItems: "center",
                width: "fit-content",
                //orientation: `vertical`,
                borderTopWidth: `0px`,
                borderRightWidth: `0px`,
                borderBottomWidth: `0px`,
            },
        },
    };

    // const orientations = {
    //     horizontal: {
    //         main: {
    //             // orientation: `horizontal`,
    //             // borderBottom: "2px solid black",
    //             borderBottomWidth: `0 0 1px 0`,
    //         },
    //     },

    //     vertical: {
    //         main: {
    //             // orientation: `vertical`,
    //             // borderLeft: "2px solid black",
    //             borderLeftWidth: `0 0 0 1px`,
    //             height: `100%`,
    //         },
    //     },
    // };

    return {
        borderStyle: variants[variant].main,
        orientationStyle: orientations[orientation].main,
    };
};

type StyledDividerProps = {
    theme?: Theme;
    overrideStyle?: React.CSSProperties;
} & Partial<DividerPropType>;

/**
 * @function StyledDivider
 * This function that takes all props and theme(passed by the emotion itself) as a argument returns object of its types
 */
const StyledDivider = ({
    colorScheme,
    width,
    height,
    borderBottomWidth,
    borderLeftWidth,
    variant,
    orientation,
    theme,
    overrideStyle,
}: StyledDividerProps) => {
    if (isObjectEmpty(theme)) {
        theme = defaultTheme;
    }
    const propsByVariant = getPropsByVariant({
        variant,
        colorScheme,
        orientation,
        theme,
    });

    return {
        colorScheme,
        width,
        height,
        borderBottomWidth,
        borderLeftWidth,
        theme,
        ...(propsByVariant && propsByVariant.borderStyle),
        ...(propsByVariant && propsByVariant.orientationStyle),
        ...overrideStyle,
    };
};

/**
 * @function EmotionDivider
 * This function is used to wrap the component for style
 */
export const EmotionDivider = styled("hr")(StyledDivider);

/**
 * @function Divider
 * This function is used to create Divider Component in which we wrap EmotionDivider
 */
export const Divider = React.forwardRef<
    HTMLHRElement,
    React.PropsWithChildren<DividerPropType>
>(
    (
        {
            colorScheme,
            className,
            // height,
            // width,
            // borderBottomWidth,
            // borderLeftWidth,
            variant,
            // orientation,
            style,
            ...props
        },
        ref,
    ) => (
        <EmotionDivider
            className={classNames(className)}
            ref={ref}
            colorScheme={colorScheme}
            // height={height}
            // width={width}
            // borderBottomWidth={borderBottomWidth}
            // borderLeftWidth={borderLeftWidth}
            variant={variant}
            // orientation={orientation}
            overrideStyle={style}
            {...props}
        />
    ),
);

/**
 * defaultProps - To define default values for component props
 */
Divider.defaultProps = {
    variant: "solid",
    orientation: "horizontal",
    colorScheme: "primary",
    width: "100%",
    height: "initial",
    id: "divider_component",
    borderBottomWidth: "2px",
};
