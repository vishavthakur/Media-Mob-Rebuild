import * as React from "react";
import {
    ChevronLeft,
    ChevronRight,
    ChevronsLeft,
    ChevronsRight,
} from "react-feather";
import { defaultTheme, Theme, useThemeMode } from "src/context/ThemeProvider";
import { isObjectEmpty } from "../../utils/helpers";
import { cx as classNames } from "@emotion/css";
import { PropTypes } from "@util/propType";
import styled from "@emotion/styled";
import { alpha } from "@util/Theme/colorManipulator";
import { IconBox } from "@components/IconBox";
import { ImageType } from "@util/types";
import { Text } from "@components/Text";
import { fontSizes, PaginationSize } from "@util/units";

export interface PaginationPropType
    extends Pick<PropTypes, "className" | "disable" | "colorScheme" | "style"> {
    /** Current active page */
    currentPage: number;

    /** Reverse the order of items **/
    totalPages: number;

    /** Page Size */
    pageSize?: number;

    /** Types to get the next page **/
    goToNextPage: () => void;

    /** Types to get the previous page **/
    goToPreviousPage: () => void;

    /** Types to change  page **/
    changePage: (pageIndex: number) => void;

    /** variants for pagination **/
    variant?: "solid" | "outline" | "ghost";

    /** to display selected page number **/
    //selected?: boolean;

    /** Size for pagination **/
    size?: "small" | "medium" | "large";
}

/**
 * @function getPropsByVariant
 * This function is used to pass the color scheme, variant and the emotion theme
 */

const getPropsByVariant = ({ variant, colorScheme, theme }) => {
    const colorInPalette = theme.palette[colorScheme];
    const variants = {
        solid: colorInPalette && {
            main: {
                color: colorInPalette.main,
                border: "none",
            },

            hover: {
                backgroundColor: alpha(
                    theme.palette.paper.hover,
                    theme.palette.action.hoverOpacity,
                ),
                color: theme.palette.typography?.primary,
            },
            selected: {
                backgroundColor: colorInPalette.main,
                color: colorInPalette.contrastText,
                "&:hover": {
                    backgroundColor: colorInPalette.main,
                    color: colorInPalette.contrastText,
                },
            },
        },
        outline: colorInPalette && {
            main: {
                border: `1px solid ${alpha(theme.palette.action.hover, 0.5)}`,
                backgroundColor: theme.palette.common.transparent,
                color: theme.palette.typography.primary,
            },
            hover: {
                backgroundColor: alpha(
                    theme.palette.action.hover,
                    theme.palette.action.hoverOpacity,
                ),
                "&:hover": {
                    backgroundColor: alpha(
                        theme.palette.action.hover,
                        theme.palette.action.hoverOpacity,
                    ),
                },
            },
            selected: {
                backgroundColor: theme.palette.common.transparent,
                border: `1px solid ${colorInPalette.main}`,
                color: colorInPalette.main,
                "&:hover": {
                    backgroundColor: theme.palette.common.transparent,
                },
            },
        },
        ghost: {
            main: {
                backgroundColor: "transparent",
                color: theme.palette.typography.primary,
                border: `1px solid ${alpha(theme.palette.action.hover, 0.5)}`,
            },
            hover: {
                backgroundColor: alpha(
                    theme.palette.action.hover,
                    theme.palette.action.hoverOpacity,
                ),
            },
            selected: {
                backgroundColor: alpha(
                    colorInPalette.main,
                    theme.palette.action.hoverOpacity,
                ),
                "&:hover": {
                    backgroundColor: alpha(
                        colorInPalette.main,
                        theme.palette.action.hoverOpacity,
                    ),
                },
                color: theme.palette.typography?.primary,
                borderColor: colorInPalette.main,
            },
        },
    };

    return variants[variant] || variants.solid;
};

/**
 * @function tooltipSizeProps
 * This function is used to change sizes
 */

const propsBySize = {
    small: {
        fontSize: fontSizes["xsmall"],
        width: PaginationSize.small,
        height: PaginationSize.small,
    },

    medium: {
        fontSize: fontSizes["small"],
        width: PaginationSize.medium,
        height: PaginationSize.medium,
    },

    large: {
        fontSize: fontSizes["medium"],
        width: PaginationSize.large,
        height: PaginationSize.large,
    },
};
/**
 * @function iconWrapper
 * This function is used to wrap the icons
 */

const iconWrapper = (id: string, iconUrl: string): ImageType => {
    return {
        id,
        image: {
            altText: "dropdownicon",
            mediaItemUrl: iconUrl,
            mediaDetails: {
                width: "20px",
                height: "20px",
            },
        },
    };
};
/**
 * @function getPaginationRecords
 * Render the output according to the data
 */
const getPaginationRecords = (
    totalPages: number,
    changePage: (index: number) => void,
    selectedIndex: number,
    pageSize: number,
    colorScheme,
    variant,
    size,
    disable,
): JSX.Element[] => {
    return getPaginationOptions(pageSize, selectedIndex, totalPages).map(
        ({ label, value }) => {
            return (
                <EmotionRootLi
                    variant={variant}
                    colorScheme={colorScheme}
                    disable={disable}
                    selected={value === selectedIndex}
                    onClick={() => {
                        value !== selectedIndex && changePage(value);
                    }}
                    size={size}
                    key={label}
                >
                    {label}
                </EmotionRootLi>
            );
        },
    );
};

/**
 * @function getPaginationOptions
 * Logic for pagination genration
 */
const getPaginationOptions = (listLength = 10, currentPage = 0, totalPages) => {
    const offset = Math.ceil(listLength / 2);
    let start = currentPage - offset;
    let end = currentPage + offset;
    start = end - start > listLength ? start + 1 : start;

    if (totalPages <= listLength) {
        start = 0;
        end = totalPages;
    } else if (currentPage <= offset) {
        start = 0;
        end = listLength;
    } else if (currentPage + offset >= totalPages) {
        start = totalPages - listLength;
        end = totalPages;
    }

    return range(start, end).map((value) => ({
        label: value + 1,
        value,
    }));
};

function range(start: number, end: number): number[] {
    return Array.from({ length: end - start }).map((_, i) => i + start);
}

/**
 * @function StyledPaginationProps
 * this fuction to add additional props
 */
type StyledPaginationProps = {
    overrideStyle?: React.CSSProperties;
} & Partial<PaginationPropType>;
/**
 * @function EmotionPaginationContainer
 * this fuction to take all props and return the styled container
 */
const EmotionPaginationContainer = styled("div")(
    ({ ...props }: StyledPaginationProps) => {
        return {
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            marginTop: 50,
            ...props.overrideStyle,
        };
    },
);
/**
 * @function EmotionPaginationLable
 * this fuction to used to diaplay number of pages text
 */
const EmotionPaginationLable = styled(Text)(() => {
    return {
        fontSize: "16px",
        fontFamily: "sans-serif",
        flexShrink: 0,
    };
});

/**
 * @function EmotionPagination
 * this fuction to get all props and return the style for pagination
 */
const EmotionPagination = styled("ul")(() => {
    return {
        margin: 0,
        listStyle: "none",
        boxSizing: "border-box",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        flexWrap: "wrap",
    };
});
const EmotionRootLi = styled("li")(
    ({
        theme,
        variant,
        colorScheme,
        disable,
        selected,
        size,
    }: {
        theme?: Theme;
        variant?: PaginationPropType["variant"];
        colorScheme?: PropTypes["colorScheme"];
        disable?: PropTypes["disable"];
        selected?: boolean;
        size?: PaginationPropType["size"];
    }) => {
        if (isObjectEmpty(theme)) {
            theme = defaultTheme;
        }
        const propsByVariant = getPropsByVariant({
            variant,
            theme,
            colorScheme,
        });
        const SizeProps = propsBySize[size];
        return {
            userSelect: "none",
            fontWeight: 600,
            cursor: "pointer",
            fontSize: "16px",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            borderRadius: "50%",
            border: "1px solid rgb(206, 206, 206)",
            margin: " 0 0.2rem",
            color: "#fff",
            transition: "all 200ms ease-in-out",
            fontFamily: "Courier New",
            "&:active,&:hover": {
                ...(propsByVariant && propsByVariant.hover),
            },
            ...SizeProps,
            ...(propsByVariant && propsByVariant.main),
            ...(selected && propsByVariant.selected),
            ...(disable && {
                pointerEvents: "none",
                color: "grey",
                opacity: 0.6,
                "&:hover": {
                    background: "unset",
                    color: theme.palette.paper.hover,
                },
            }),
        };
    },
);

/**
 * @function Pagination
 * this fuction to get all props and return the final pagination component
 */

export const Pagination = React.forwardRef<
    HTMLDivElement,
    React.PropsWithChildren<PaginationPropType>
>(
    (
        {
            totalPages,
            goToNextPage,
            goToPreviousPage,
            changePage,
            currentPage,
            colorScheme,
            variant,
            pageSize,
            size,
            disable,
            style,
            className,
        },
        ref,
    ) => {
        const { themeMode } = useThemeMode();
        return (
            <EmotionPaginationContainer
                className={classNames(className)}
                overrideStyle={style}
                ref={ref}
            >
                <EmotionPaginationLable>
                    PAGE {currentPage + 1} OF {totalPages}
                </EmotionPaginationLable>
                <EmotionPagination>
                    <EmotionRootLi
                        colorScheme={colorScheme}
                        variant={variant}
                        disable={currentPage === 0 || disable}
                        onClick={() => changePage(0)}
                        size={size}
                        key="first"
                    >
                        {themeMode === "light" ? (
                            <ChevronsLeft color="#222" />
                        ) : (
                            <ChevronsLeft color="#fff" />
                        )}
                        {/* first */}
                    </EmotionRootLi>

                    <EmotionRootLi
                        colorScheme={colorScheme}
                        variant={variant}
                        disable={currentPage === 0 || disable}
                        onClick={goToPreviousPage}
                        size={size}
                        key="previous"
                    >
                        {themeMode === "light" ? (
                            <ChevronLeft color="#222" />
                        ) : (
                            <ChevronLeft color="#fff" />
                        )}
                        {/* first */}
                    </EmotionRootLi>
                    {/**prev */}
                    {getPaginationRecords(
                        totalPages,
                        changePage,
                        currentPage,
                        pageSize,
                        colorScheme,
                        variant,
                        size,
                        disable,
                    )}

                    <EmotionRootLi
                        colorScheme={colorScheme}
                        variant={variant}
                        disable={currentPage === totalPages - 1 || disable}
                        onClick={goToNextPage}
                        size={size}
                        key="next"
                    >
                        {themeMode === "light" ? (
                            <ChevronRight color="#222" />
                        ) : (
                            <ChevronRight color="#fff" />
                        )}
                        {/* first */}
                    </EmotionRootLi>
                    {/**Next */}

                    <EmotionRootLi
                        colorScheme={colorScheme}
                        variant={variant}
                        disable={currentPage === totalPages - 1 || disable}
                        onClick={() => changePage(totalPages - 1)}
                        size={size}
                        key="last"
                    >
                        {themeMode === "light" ? (
                            <ChevronsRight color="#222" />
                        ) : (
                            <ChevronsRight color="#fff" />
                        )}
                    </EmotionRootLi>
                    {/**Last */}
                </EmotionPagination>
            </EmotionPaginationContainer>
        );
    },
);

/**
 * defaultProps - To define default values for component props
 */
Pagination.defaultProps = {
    colorScheme: "primary",
    variant: "solid",
    size: "small",
    pageSize: 3,
};
