import * as React from "react";
import { PropTypes } from "@util/propType";
import { Theme } from "src/context/ThemeProvider";
interface RadioContextProps extends Pick<PropTypes, "id" | "colorScheme"> {
    value?: string | number;

    onChange?: (event: React.ChangeEvent<HTMLInputElement>) => void;
    variant?: "outline" | "solid";
    theme?: Theme;
    vertical?: boolean;
}
export const RadioContext = React.createContext<RadioContextProps | undefined>(
    null,
);
