import React from "react";
import { PropTypes } from "@util/propType";
import { cx as classNames } from "@emotion/css";
import styled from "@emotion/styled";
import { RadioContext } from "./radioContext";
import { Text } from "@components/Text";

export interface RadioProp
    extends Pick<PropTypes, "id" | "colorScheme" | "style"> {
    /**** Title for the group */
    title?: string;
    /** Variation for layout of table : bordered - show border style layout and  striped -  show odd even color layout**/
    variant?: "outline" | "solid";
    /**** Default value for radio button */
    value?: string | number;
    /**** on change event for radio button */
    onChange?: (event: React.ChangeEvent<HTMLInputElement>) => void;
    /*** display direction  */
    vertical?: boolean;
    /**** ClassName  ****/
    className?: string;
}
/**** Emotion label  */
const EmotionLabel = styled(Text)((props) => {
    return {
        display: "flex",
        alignItems: "flex-start",
        flexDirection: "row",
    };
});

/****
 * @function StyledRadioWrapper
 * styled radio wrapper additional props
 *
 *
 * */
export type StyledRadioWrapper = {
    overrideStyle?: React.CSSProperties;
} & Partial<RadioProp>;
/****
 * @function RadioWrapper
 * styled radio wrapper to get all props and pass to providers
 *
 *
 * */
const RadioWrapper = styled("div")(({ ...props }: StyledRadioWrapper) => ({
    flexDirection: props.vertical ? "column" : "row",
    display: "flex",
    ...props.overrideStyle,
}));

export const RadioGroup = React.forwardRef<
    HTMLDivElement,
    React.PropsWithChildren<RadioProp>
>(
    (
        {
            children,
            title,
            variant,
            onChange,
            value,
            colorScheme,
            className,
            style,
            vertical,
            ...props
        },
        ref,
    ) => {
        const [valueRG, setValue] = React.useState(value);

        const handleChange = (event) => {
            setValue(event.target.value);
            if (onChange) {
                onChange(event.target.value);
            }
        };

        return (
            <RadioContext.Provider
                value={{
                    onChange: handleChange,
                    value: valueRG,
                    variant,
                    colorScheme,
                    vertical,
                }}
            >
                <RadioWrapper
                    {...props}
                    className={classNames(className)}
                    overrideStyle={style}
                    vertical={vertical}
                    ref={ref}
                >
                    <EmotionLabel>{title}</EmotionLabel>
                    {children}
                </RadioWrapper>
            </RadioContext.Provider>
        );
    },
);

/*** Default props for the radio group */
RadioGroup.defaultProps = {
    variant: "outline",
    colorScheme: "primary",
    vertical: false,
};
