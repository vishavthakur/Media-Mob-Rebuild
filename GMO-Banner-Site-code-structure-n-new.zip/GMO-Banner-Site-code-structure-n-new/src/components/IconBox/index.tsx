import * as React from "react";
import classNames from "classnames";
import { Tooltip } from "../Tooltip";
import styled from "@emotion/styled";
import { PropTypes } from "@util/propType";
import { ImageType } from "@util/types";
import { defaultTheme, Theme } from "src/context/ThemeProvider";
import { isObjectEmpty } from "@util/assertion";
import Image from "@templates/ImageConversion"
import { TooltipPropType } from "../Tooltip";
import { Phone } from "react-feather";

interface IconBoxPropType
    extends Omit<PropTypes, "as">,
        Pick<TooltipPropType, "width" | "title" | "position"> {
    /** Add icon image outside the component **/
    icon: ImageType;

    /** Provide variations for style: contained - filled layout and  outline -  bordered layout **/
    variant?: "outline" | "solid";

    /** To define a string that labels the current element **/
    "aria-label": string;

    /** Radius to rounds the corners of an element from outer border edge **/
    borderRadius?: number;
}

/**
 * @function getPropsByVariant
 * This function is used to pass the color scheme, variant and the emotion theme
 */
const getPropsByVariant = ({ variant, colorScheme, theme }) => {
    const colorInPalette = theme.palette[colorScheme];

    const variants = {
        outline: colorInPalette && {
            main: {
                border: `1px solid ${colorInPalette.main}`,
                backgroundColor: theme.palette.common.transparent,
                color: colorInPalette.main,
            },
        },
        solid: colorInPalette && {
            main: {
                backgroundColor: colorInPalette.main,
                color: colorInPalette.contrastText,
            },
        },
    };

    return variants[variant] || variants.solid;
};
/**
 * @function StyledIconProps
 * This function that takes all props and added the additional props
 */
type StyledIconProps = {
    theme?: Theme;
    overrideStyle?: React.CSSProperties;
} & Partial<IconBoxPropType>;

/**
 * @function StyledIconBox
 * This function that takes all props and theme(passed by the emotion itself) as a argument returns object of its types
 */
const StyledIconBox = ({
    theme,
    disable,
    borderRadius,
    variant,
    colorScheme,
    overrideStyle,
}: StyledIconProps) => {
    if (isObjectEmpty(theme)) {
        theme = defaultTheme;
    }

    const propsByVariant = getPropsByVariant({
        variant,
        theme,
        colorScheme,
    });
    return {
        borderRadius,
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        opacity: disable ? theme.palette.action.disabledOpacity : 1,
        cursor: disable ? theme.palette.action.cursor : "pointer",
        width: variant && colorScheme && "26px",
        height: variant && colorScheme && "26px",
        ...(propsByVariant && propsByVariant.main),
        ...overrideStyle,
    };
};

/**
 * @function EmotionIconBox
 * This function is used to wrap the component for style
 */
export const EmotionIconBox = styled("div")(StyledIconBox);

export const IconBox = React.forwardRef<
    HTMLDivElement,
    React.PropsWithChildren<IconBoxPropType>
>(
    (
        {
            id,
            title,
            "aria-label": ariaLabel,
            position,
            width,
            className,
            disable,
            variant,
            icon,

            style,
            onClick,
            ...props
        },
        ref,
    ) =>
        title && title ? (
            <Tooltip
                className={classNames(className)}
                title={title}
                position={position}
                width={width}
                disable={disable}
                size="sm"
            >
                <EmotionIconBox
                    id={id}
                    onClick={disable ? undefined : onClick}
                    variant={variant}
                    disable={disable}
                    overrideStyle={style}
                    {...props}
                    ref={ref}
                >
                    {icon?.image?.mediaItemUrl && (
                        <Image
                            //id={icon?.id}
                            src={icon?.image?.mediaItemUrl}
                            alt={icon?.image?.altText}
                            width={icon?.image?.mediaDetails?.width}
                            height={icon?.image?.mediaDetails?.height}
                            layout="fixed"
                        />
                    )}
                </EmotionIconBox>
            </Tooltip>
        ) : (
            <EmotionIconBox
                id={id}
                disable={disable}
                ref={ref}
                aria-label={ariaLabel}
                onClick={disable ? undefined : onClick}
                variant={variant}
                overrideStyle={style}
                className={classNames(className)}
                {...props}
            >
                {icon?.image?.mediaItemUrl && (
                    <Image
                        //id={icon?.id}
                        src={icon?.image?.mediaItemUrl}
                        alt={icon?.image?.altText}
                        width={icon?.image?.mediaDetails?.width}
                        height={icon?.image?.mediaDetails?.height}
                        layout="fixed"
                    />
                )}
            </EmotionIconBox>
        ),
);

/**
 * defaultProps - To define default values for component props
 */
IconBox.defaultProps = {
    id: "iconBox",
    position: "top",
    borderRadius: 0,
    disable: false,
    colorScheme: "primary",
};
