import * as React from "react";
import classNames from "classnames";
import { ImageType, Property } from "@util/types";
import { PropTypes } from "@util/propType";
import styled from "@emotion/styled";
import { keyframes } from "@emotion/react";
import { Paper } from "@components";
import Image from "next/image";
import { BreakPoints } from "@util/units";
import { useThemeMode } from "src/context/ThemeProvider";
import { X } from "react-feather";
import { FocusScope } from '@react-aria/focus'


interface ModalPropType
  extends Pick<
    PropTypes<HTMLDivElement | HTMLButtonElement>,
    "id" | "onClick" | "className" | "style"
  > {
  /** To add Border radius to modal box  **/
  borderRadius?: number;

  /** To add box shaddow effect to the modal box **/
  elevation?: boolean;

  /** Variations for placement of modal along the screen  **/
  position?: Property.ModalPosition;

  /** Additional background color to modal overlay **/
  overlayColor?: string;

  /** Additional background color to modal box **/
  backgroundColor?: string;

  /** Icon to close the modal **/
  closeIcon?: any;

  /** To provide greater z-stack order of element **/
  zIndex?: number;

  /** To hidebackdrop styling **/
  hideBackdrop?: boolean;

  /** To add sizes for modal **/
  size?: "sm" | "md" | "lg" | "xl" | "fullscreen";
  /**** Custom id for the popup body  */
  idbody?: string;
}

/**
 * @function getPropsByPosition
 * This function is used to pass position variant to modal box
 */
const getPropsByPosition = ({ position }) => {
  const positions = {
    middle: {
      top: "0",
      left: "0",
      minHeight: "calc(100% - (20px * 2))",
      margin: "20px auto",
    },
    topLeft: {
      marginLeft: "15px",
      marginTop: 20,
      marginBottom: 20,
      marginRight: "auto",
    },
    topRight: {
      marginRight: "15px",
      left: "unset",
      marginTop: 20,
      marginBottom: 20,
      marginLeft: "auto",
    },
    bottomLeft: {
      position: "absolute" as Property.Position,
      left: "15px",
      bottom: "15px",
    },
    bottomRight: {
      position: "absolute" as Property.Position,
      right: "15px",
      bottom: "15px",
    },
  };
  return positions[position] || positions.middle;
};
/**
 * @function getPropsBySize
 * This function is used to pass size variant to modal box
 */
const getPropsBySize = ({ size }) => {
  const sizes = {
    sm: {
      maxWidth: "100%",
      [`@media ${BreakPoints.tabletS}`]: {
        maxWidth: "450px",
      },
    },
    md: {
      maxWidth: "90%",
      [`@media ${BreakPoints.mobileL}`]: {
        maxWidth: "450px",
      },
      [`@media ${BreakPoints.tabletS}`]: {
        maxWidth: "600px",
      },
    },
    lg: {
      maxWidth: "90%",
      [`@media ${BreakPoints.mobileL}`]: {
        maxWidth: "450px",
      },
      [`@media ${BreakPoints.tabletS}`]: {
        maxWidth: "600px",
      },
      [`@media ${BreakPoints.laptop}`]: {
        maxWidth: "800px",
      },
    },
    xl: {
      maxWidth: "90%",
      [`@media ${BreakPoints.tabletS}`]: {
        maxWidth: "500",
      },
      [`@media ${BreakPoints.tablet}`]: {
        maxWidth: "800px",
      },
      [`@media ${BreakPoints.laptop}`]: {
        maxWidth: "1040px",
      },
    },
    fullscreen: {
      maxWidth: "100%",
      margin: 0,
      left: 0,
      right: 0,
      bottom: 0,
    },
  };
  return sizes[size] || sizes.fullscreen;
};

/**
 * @function StyledModalProps
 * This function that takes all props and theme(passed by the emotion itself) as a argument returns object of its types
 */
type StyledModalProps = {
  overrideStyle?: React.CSSProperties;
} & Partial<ModalPropType>;

/**
 * @function StyledModal
 * This function that takes all props and theme(passed by the emotion itself) as a argument returns object of its types
 */
const StyledModal = ({ zIndex, overlayColor }: ModalPropType) => {
  const fadeInFromNone = keyframes`
    0% {
        opacity: 0;
    }
    100% {
        opacity: 1;
    }
    `;
  return {
    position: "fixed" as Property.Position,
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: overlayColor,
    animation: `${fadeInFromNone} 500ms ease-in-out`,
    zIndex: zIndex,
    overflowY: "scroll" as Property.OverflowY,
  };
};

/**
 * @function StyledModalWrapper
 * This function that takes all props and theme(passed by the emotion itself) as a argument returns object of its types
 */
const StyledModalWrapper = ({
  size,
  position,
  overrideStyle,
}: StyledModalProps) => {
  const propsByPosition = getPropsByPosition({
    position,
  });
  const propsBySize = getPropsBySize({
    size,
  });
  return {
    position: "relative" as Property.Position,
    transform: "none",
    width: "100%",
    display: "flex",
    alignItems: "center",
    ...propsByPosition,
    ...propsBySize,
    ...overrideStyle,
  };
};

/**
 * @function StyledModalInner
 * This function that takes all props and theme(passed by the emotion itself) as a argument returns object of its types
 */
const StyledModalInner = ({ borderRadius }: ModalPropType) => {
  return {
    position: "relative" as Property.Position,
    width: "100%",
    flexDirection: "column" as Property.FlexDirection,
    alignItems: "flex-start",
    padding: "15px 20px",
    borderRadius: borderRadius,
  };
};

/**
 * @function StyledModalIcon
 * This function that takes all props and theme(passed by the emotion itself) as a argument returns object of its types
 */
const StyledModalIcon = () => {
  return {
    display: "inline-flex",
    position: "absolute" as Property.Position,
    right: "15px",
    top: "15px",
    cursor: "pointer",
  };
};

/**
 * @function EmotionModal
 * This function is used to wrap the Inner styling
 */
export const EmotionModal = styled("div")(StyledModal);

/**
 * @function EmotionModalInner
 * This function is used to add style for modal box
 */
export const EmotionModalInner = styled(Paper)(StyledModalInner);

/**
 * @function EmotionModalWrapper
 * This function is used to add style for modal box
 */
export const EmotionModalWrapper = styled("div")(StyledModalWrapper);

/**
 * @function EmotionModalIcon
 * This function is used to add style for modal close icon
 */
export const EmotionModalIcon = styled("button")(StyledModalIcon);

export const Modal = React.forwardRef<
  HTMLDivElement,
  React.PropsWithChildren<ModalPropType>
>(
  (
    {
      id,
      children,
      closeIcon,
      className,
      elevation,
      hideBackdrop,
      onClick,
      style,
      overlayColor,
      position,
      size,
      zIndex,
      backgroundColor,
      ...props
    },
    ref
  ) => {
    React.useEffect(() => {
      const bodyElem = document.querySelector("body");
      if (bodyElem) {
        bodyElem.style.overflow = "hidden";
      }
      return () => {
        if (bodyElem) {
          bodyElem.style.overflow = "";
        }
      };
    }, []);
    const onCloseClick = (e) => {
      const bodyElem = document.querySelector("body");
      if (bodyElem) {
        bodyElem.style.overflow = "";
      }
      onClick(e);
    };
    const { themeMode } = useThemeMode();
    return (
      <EmotionModal
        overlayColor={overlayColor}
        zIndex={zIndex}
        id={props?.idbody}
        role="dialog"
        aria-modal="true"
        onClick={
          hideBackdrop
            ? (
                e:
                  | React.MouseEvent<HTMLButtonElement, MouseEvent>
                  | React.MouseEvent<HTMLDivElement, MouseEvent>
              ) => {
                // close modal when outside of modal is clicked
                onCloseClick(e);
              }
            : undefined
        }
      >
        <EmotionModalWrapper
          position={position}
          size={size}
          overrideStyle={style}
          data-modal="modal-wrapper"
          className="Modal_Outer"
        >
          <FocusScope contain autoFocus restoreFocus>
          <EmotionModalInner
            className={classNames(className)}
            elevation={elevation}
            id={id}
            {...props}
            onClick={(e) => {
              e.stopPropagation();
            }}
            backgroundColor={backgroundColor}
            ref={ref}
          >
            <EmotionModalIcon role="button" onClick={onCloseClick} className="ModalcloseIcon" aria-label="click here to close">
              {closeIcon && closeIcon !== "" ? (
                closeIcon
              ) : themeMode === "light" ? (
                <X size="16px" />
              ) : (
                <X size="16px" color="#fff" />
              )}
              {/* <Image
                                    id={closeIcon?.id}
                                    src={closeIcon?.image?.mediaItemUrl}
                                    alt={closeIcon?.image?.altText}
                                    width={
                                        closeIcon?.image?.mediaDetails?.width
                                    }
                                    height={
                                        closeIcon?.image?.mediaDetails?.height
                                    }
                                    layout="fixed"
                                /> */}
            </EmotionModalIcon>
            {children}
          </EmotionModalInner>
          </FocusScope>
        </EmotionModalWrapper>
      </EmotionModal>
    );
  }
);

/**
 * defaultProps - To define default values for component props
 */
Modal.defaultProps = {
  id: "modal",
  borderRadius: 3,
  elevation: false,
  position: "middle",
  overlayColor: "rgba(0, 0, 0, 0.3)",
  hideBackdrop: true,
  backgroundColor: "",
  children: "Modal Component",
  size: "sm",
};
