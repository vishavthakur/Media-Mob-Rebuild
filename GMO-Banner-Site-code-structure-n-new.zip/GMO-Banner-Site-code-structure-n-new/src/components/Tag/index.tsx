import styled from "@emotion/styled";
import { isObjectEmpty } from "../../utils/helpers";
import React from "react";
import { defaultTheme, Theme } from "src/context/ThemeProvider";
import { Size } from "@util/theme";
import { ImageType, Property } from "@util/types";
import { spacing, fontSizes } from "@util/units";
import { PropTypes } from "@util/propType";
import classNames from "classnames";
import Image from "@templates/ImageConversion";
interface TagPropType extends Omit<PropTypes, "onClick" | "as" | "disable"> {
    /** Additional border BorderRadius in px | % **/
    borderRadius?: Property.BorderRadius;

    /** Tag sizes can be of 3 types: 'sm - small view of tag size' , 'md - medium view of tag size' and 'lg - large view of tag size **/
    size: Size;

    /** Custom icon before text from outside the component **/
    startIcon?: ImageType;

    /** Custom icon after text from outside the component **/
    endIcon?: ImageType;
    
    /** Close icon used to close the tag **/
    closeIcon?: ImageType;

    /** Variation for layout of  Tag: contained - filled layout, outline -  bordered layout **/
    variant: "contained" | "outline";
}

/**
 * @function tagSizeProps
 * This function is used to pass the Button Size
 */
const tagSizeProps = {
    sm: {
        fontSize: fontSizes["xs"],
        padding: `${spacing["xxs"]} ${spacing["sm"]}`,
    },
    md: {
        fontSize: fontSizes["sm"],
        padding: `${spacing["xxs"]} ${spacing["md"]}`,
    },
    lg: {
        fontSize: fontSizes["md"],
        padding: `${spacing["xs"]} ${spacing["lg"]}`,
    },
};

/**
 * @function getPropsByVariant
 * This function is used to pass the color scheme, variant and the emotion theme
 */
const getPropsByVariant = ({ variant, colorScheme, theme }) => {
    const colorInPalette = theme.palette[colorScheme];
    const variants = {
        contained: colorInPalette && {
            main: {
                backgroundColor: colorInPalette.main,
                border: `1px solid ${colorInPalette.main}`,
                color: colorInPalette.contrastText,
            },
        },
        outline: colorInPalette && {
            main: {
                border: `1px solid ${colorInPalette.main}`,
                color: colorInPalette.main,
            },
        },
    };

    return variants[variant] || variants.contained;
};
/**
 * @function StyledTagProps
 * This function that to pass additional props
 */
type StyledTagProps = {
    theme?: Theme;
    overrideStyle?: React.CSSProperties;
} & Partial<TagPropType>;
/**
 * @function StyledBadge
 * This function that takes all props and theme(passed by the emotion itself) as a argument returns object of its types
 */
const StyledTag = ({
    colorScheme = "primary",
    variant,
    borderRadius,
    theme,
    size,
    overrideStyle,
}: StyledTagProps) => {
    if (isObjectEmpty(theme)) {
        theme = defaultTheme;
    }
    const fontSizeBySize = tagSizeProps[size]?.fontSize;
    const paddingBySize = tagSizeProps[size]?.padding;
    const propsByVariant = getPropsByVariant({
        variant,
        theme,
        colorScheme,
    });
    return {
        display: "inline-flex",
        textDecoration: "none",
        padding: tagSizeProps.md.padding,
        fontSize: tagSizeProps.md.fontSize,
        borderRadius: borderRadius ?? theme.shape.borderRadius,
        textAlign: "center",
        color: "grey",
        border: "1px solid red",
        transition: "all 0.5s ease",
        cursor: "pointer",
        ...(propsByVariant && propsByVariant.main),
        ...(paddingBySize && { padding: paddingBySize }),
        ...(fontSizeBySize && { fontSize: fontSizeBySize }),
        ...overrideStyle,
    };
};

/**
 * @MarginDirection Constant used for declaration of margin to image
 **/
enum MarginDirection {
    left = "Left",
    right = "Right",
}
/**
 * @function StyledTagImage
 * This function that takes all props and theme(passed by the emotion itself) as a argument returns object of its types
 */
const StyledTagImage = ({ marginSide }: { marginSide: MarginDirection }) => {
    return {
        margin: 0,
        [`margin${marginSide}`]: 10,
        width: "20px",
    };
};
/**
 * @function EmotionTagImage
 * This function is used to wrap the right icon style of tag
 */
export const EmotionTagImage = styled("span")(StyledTagImage);

/**
 * 
 * @param image ImageType
 * @returns JSX.Element

 * @description Takes image object of type ImageType and return notification images JSX Element
 */
const getTagImage = (
    icon: ImageType,
    marginSide: MarginDirection,
): JSX.Element => (
    <EmotionTagImage marginSide={marginSide}>
        <Image
            //id={icon?.id}
            src={icon?.image?.mediaItemUrl}
            alt={icon?.image?.altText}
            height={icon?.image?.mediaDetails?.height}
            width={icon?.image?.mediaDetails?.width}
            layout="responsive"
        />
    </EmotionTagImage>
);

/**
 * @function EmotionTag
 * This function is used to wrap the component for style
 */
export const EmotionTag = styled("div")(StyledTag);

/**
 * @function Tag
 * This function is used to create Tag Component
 */
export const Tag = React.forwardRef<
    HTMLDivElement,
    React.PropsWithChildren<TagPropType>
>(
    (
        {
            children,
            colorScheme,
            variant,
            startIcon,
            className,
            endIcon,
            closeIcon,
            style,
            ...props
        },
        ref,
    ) => (
        <EmotionTag
            colorScheme={colorScheme}
            variant={variant}
            borderRadius={"50px"}
            overrideStyle={style}
            {...props}
            ref={ref}
            className={classNames(className)}
        >
            {startIcon?.image?.mediaItemUrl &&
                getTagImage(startIcon, MarginDirection.right)}
            {children}
            {endIcon?.image?.mediaItemUrl &&
                getTagImage(endIcon, MarginDirection.left)}
            {closeIcon?.image?.mediaItemUrl &&
                getTagImage(closeIcon, MarginDirection.left)}
        </EmotionTag>
    ),
);

/**
 * defaultProps - To define default values for component props
 */
Tag.defaultProps = {
    variant: "contained",
    colorScheme: "primary",
    borderRadius: "20px",
    size: "md",
    id: "tag_component",
};
