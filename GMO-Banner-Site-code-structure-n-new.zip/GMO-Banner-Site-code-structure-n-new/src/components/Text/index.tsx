import * as React from "react";
import classNames from "classnames";
import { Property } from "@util/types";
import styled from "@emotion/styled";
import { PropTypes } from "@util/propType";
import { isObjectEmpty, isUndefined } from "@util/assertion";
import { defaultTheme, Theme } from "src/context/ThemeProvider";

interface TextPropType extends Omit<PropTypes, "disable"> {
    /** Additional font size (px) */
    fontSize?: string;

    /** Additional font weight in 100-900 */
    fontWeight?: number;

    /** Additional text decoration properties **/
    textDecoration?: Property.TextDecoration;

    /** Additional text decoration properties **/
    //textTransform?: Property.TextTransform;

    /** No. of line to show with ...dots  **/
    lineClamp?: string;

    /** For text clipping - When used inside flex please define min-width with the element **/
    isTruncate?: boolean;

    /** Variant for  alignment of content to container */
    textAlign?: Property.TextAlign;

    /** Style the font view **/
    fontStyle?: Property.FontStyle;

    /** To unwrap the text **/
    noWrap?: boolean;

    /** To add Word Break Property **/
    wordBreak?: Property.wordBreak

    /**Provides Line Height to the Text **/
    lineHeight?: string;
}

export type StyledTextProps = {
    isChildrenNull?: boolean;
    theme?: Theme;
    textTransformation?: string;
    overrideStyle?: React.CSSProperties;
} & Partial<TextPropType>;


export const EmotionText = styled("div")(
    
    ({
        isTruncate,
        wordBreak,
        lineHeight,
        theme,
        textAlign,
        fontStyle,
        fontSize,
        textDecoration,
        textTransformation,
        fontWeight,
        noWrap,
        lineClamp,
        overrideStyle,
        colorScheme,
    }: StyledTextProps) => {
        if (isObjectEmpty(theme)) {
            theme = defaultTheme;
        }
        return {
            textAlign,
            fontStyle,
            fontSize,
            fontWeight,
            textDecoration,
            textTransformation,
            wordBreak,
            lineHeight,
            color: colorScheme
                ? theme.palette[colorScheme].main
                : theme.palette.typography.primary,
            whiteSpace:
                isTruncate || noWrap
                    ? ("nowrap" as Property.whiteSpace)
                    : ("normal" as Property.whiteSpace),
            textOverflow: isTruncate && "ellipsis",
            overflow: (isTruncate || !isUndefined(lineClamp)) && "hidden",
            ["-webkit-line-clamp"]: !isUndefined(lineClamp) && lineClamp,
            ["-webkit-box-orient"]: !isUndefined(lineClamp) && "vertical",
            display: !isUndefined(lineClamp) && "-webkit-box", // Note - Neccessary to add "-webkit-box" while using lineClamp propperty
            ...overrideStyle,
        };
    }

);
export const Text = React.forwardRef<
    HTMLDivElement,
    React.PropsWithChildren<TextPropType>
>(
    (
        { id, className, colorScheme, onClick, as, children, style, wordBreak, lineHeight, ...props },
        ref,
    ) => (
        <EmotionText
            id={id}
            overrideStyle={style}
            onClick={onClick}
            colorScheme={colorScheme}
            className={classNames(className)}
            as={as}
            ref={ref}
            wordBreak={wordBreak}
            lineHeight={lineHeight}
            {...props}
        >
            {children}
        </EmotionText>
    ),
);

/**
 * defaultProps - To define default values for component props
 */
Text.defaultProps = {
    textAlign: "left",
    // fontSize: "18px",
    noWrap: false,
    isTruncate: false,
    lineClamp: undefined,
    as: "div",
    lineHeight: "normal"
};
