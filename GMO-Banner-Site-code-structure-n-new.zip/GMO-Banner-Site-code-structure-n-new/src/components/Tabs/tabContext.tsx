import * as React from "react";
import { PropTypes } from "@util/propType";
import { Theme } from "src/context/ThemeProvider";
interface TabContextProps
    extends Pick<PropTypes, "id" | "colorScheme" | "disable"> {
    onChange?: (event: React.ChangeEvent<HTMLInputElement>) => void;
    variant?: "bordered" | "solid";
    theme?: Theme;
    vertical?: boolean;
    value?: number;
}
export const TabContext = React.createContext<TabContextProps | undefined>(
    null,
);
