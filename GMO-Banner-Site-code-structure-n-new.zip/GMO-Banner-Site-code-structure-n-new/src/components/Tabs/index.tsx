import * as React from "react";
import classNames from "classnames";
import { PropTypes } from "@util/propType";
import styled from "@emotion/styled";
import { TabContext } from "./tabContext";
import { Property } from "@util/types";
import { BreakPoints } from "@util/units";

interface TabsPropType
    extends Pick<
        PropTypes<HTMLDivElement>,
        "id" | "className" | "style" | "ref" | "colorScheme"
    > {
    /** Ref for tab element **/
    ref?: React.Ref<HTMLDivElement>;

    /** To show initial selected item of tab element */
    selected?: number;

    /**  To style the tab element - Solid: "for filled layout" and "bordered" for the border layout */
    variant?: "solid" | "bordered";

    /** To show vertical orientation */
    vertical?: boolean;
}

type StyledTabsProps = {
    overrideStyle?: React.CSSProperties;
} & Partial<TabsPropType>;

/**
 * @function StyledTab
 * This function that takes all props and theme(passed by the emotion itself) as a argument returns object of its types
 */
const StyledTabs = ({ overrideStyle, vertical }: StyledTabsProps) => {
    return {
        display: "flex",
        margin: "0px",
        flexDirection: "column" as Property.FlexDirection,
        "& > div > button:last-child": {
            "&:after": vertical ? { background: "transparent" } : ``,
        },
        [`@media ${BreakPoints.mobileL}`]: {
            flexDirection: (vertical
                ? "row"
                : "column") as Property.FlexDirection,
        },
        ...overrideStyle,
    };
};

/**
 * @function EmotionTab
 * This function is used to wrap the right icon style of tag
 */
export const EmotionTabs = styled("div")(StyledTabs);

export const Tabs = React.forwardRef<
    HTMLDivElement,
    React.PropsWithChildren<TabsPropType>
>(
    (
        {
            children,
            className,
            style,
            selected,
            colorScheme,
            vertical,
            variant,
            ...props
        },
        ref,
    ) => {
        const [indexValue, setIndexData] = React.useState(selected);
        const onHandleClick = (event: React.SyntheticEvent) => {
            const eventTarget = event.target as HTMLButtonElement;
            if (
                eventTarget &&
                eventTarget?.getAttribute("dataindex") != undefined
            ) {
                const indexData = eventTarget?.getAttribute("dataindex");
                setIndexData(parseInt(indexData));
            }
        };

        return (
            <TabContext.Provider
                value={{
                    value: indexValue,
                    variant: variant,
                    colorScheme: colorScheme,
                    vertical: vertical,
                }}
            >
                <EmotionTabs
                    {...props}
                    ref={ref}
                    vertical={vertical}
                    onClick={onHandleClick}
                    onFocus={onHandleClick}
                    className={classNames(className)}
                    overrideStyle={style}
                >
                    {children}
                </EmotionTabs>
            </TabContext.Provider>
        );
    },
);

/**
 * defaultProps - To define default values for component props
 */

Tabs.defaultProps = {
    id: "tab_component",
    variant: "solid",
    colorScheme: "primary",
    vertical: false,
};
