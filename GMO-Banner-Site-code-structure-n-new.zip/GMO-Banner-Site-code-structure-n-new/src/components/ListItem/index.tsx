import * as React from "react";
import { cx as classNames } from "@emotion/css";
import styled from "@emotion/styled";
import { Property } from "@util/types";
import { PropTypes } from "@util/propType";
import { isObjectEmpty } from "../../utils/helpers";
import { defaultTheme, Theme } from "src/context/ThemeProvider";
import { Paper } from "@components/Paper";
interface ListItemPropType
    extends Omit<
        PropTypes<HTMLLIElement | HTMLDivElement>,
        "colorScheme" | "disable" | "onMouseEnter"
    > {
    /** Types to align the items **/
    alignItems?: Property.AlignItem;

    /** Types to place the content **/
    justifyContent?: Property.JustifyElemnent;

    /** for showing selected List Item **/
    isSelected?: boolean;

    /** Radius to rounds the corners of an element from outer border edge **/
    borderRadius?: number;
}
type ListItemProps = {
    theme?: Theme;
    overrideStyle?: React.CSSProperties;
} & Partial<ListItemPropType>;

/**
 * @function EmotionListItem
 * This function is used to wrap the component for style
 */
const EmotionListItem = styled(Paper, {
    shouldForwardProp: (props: string) => {
        return ![
            "isSelected",
            "elevation",
            "colorScheme",
            "disable",
            "overrideStyle",
            "borderRadius",
            "maxHeight",
            "scrollable",
            "alignItems",
        ].includes(props);
    },
})(
    ({
        alignItems,
        justifyContent,
        isSelected,
        theme,
        overrideStyle,
    }: ListItemProps) => {
        if (isObjectEmpty(theme)) {
            theme = defaultTheme;
        }

        return {
            cursor: "pointer",
            display: "flex",
            alignItems: alignItems,
            alignContent: justifyContent,
            fontSize: "14px",
            padding: 5,
            ...(isSelected && {
                backgroundColor: theme.palette.action.selected,
            }),
            "&:hover": !isSelected && {
                backgroundColor: !isSelected && theme.palette.action.hover,
            },
            ...overrideStyle,
        };
    },
);

/**
 * ListItem Component
 */
export const ListItem = React.forwardRef<
    HTMLDivElement,
    React.PropsWithChildren<ListItemPropType>
>(({ id, className, children, style, ...props }, ref) => (
    <EmotionListItem
        id={id}
        key={id}
        overrideStyle={style}
        as="li"
        borderRadius={0}
        className={classNames(className)}
        {...props}
        ref={ref}
    >
        {children}
    </EmotionListItem>
));

/**
 * defaultProps - To define default values for component props
 */
ListItem.defaultProps = {
    justifyContent: "center",
    alignItems: "center",
    isSelected: false,
};
