import React from "react";
import styled from "@emotion/styled";
import { Property } from "@util/types";
import { PropTypes } from "@util/propType";
import { Paper } from "@components/Paper";
import classNames from "classnames";

interface RowPropType extends Pick<PropTypes, "id" | "style" | "className"> {
    /** Reverse the order of items **/
    reverse?: boolean;

    /** Types to align the items **/
    alignItems?: Property.AlignItem;

    /** Types to place the content **/
    justifyContent?: Property.ContentJustification;

    /** Additional backgruund color for row **/
    backgroundColor?: string;

    /** Additional border radius to round the corner of element in number **/
    borderRadius?: number;
}

/**
 * @function StyledRowProps
 * This function that takes all props and theme(passed by the emotion itself) as a argument returns object of its types
 */
// type StyledRowProps = {
//     overrideStyle?: React.CSSProperties;
// } & Partial<RowPropType>;

// const StyledRow = ({
//     reverse,
//     alignItems,
//     justifyContent,
//     backgroundColor,
//     borderRadius,
//     overrideStyle,
// }: StyledRowProps) => {

//     return {
//         reverse,
//         alignItems,
//         justifyContent,
//         backgroundColor,
//         borderRadius,
//         ...overrideStyle,
//     };
// };

/**
 * @function EmotionRow
 * This function is used to wrap the component for style
 */
export const EmotionRow = styled(Paper)(
    ({
        overrideStyle,
        alignItems,
        justifyContent,
        reverse,
    }: {
        overrideStyle: React.CSSProperties;
        alignItems?: RowPropType["alignItems"];
        justifyContent?: RowPropType["justifyContent"];
            reverse?: RowPropType["reverse"];
        borderRadius?:RowPropType["borderRadius"];
    }) => ({
        alignItems: alignItems,
        justifyContent: justifyContent,
        flexWrap: "wrap",
        marginLeft:" -15px",
        marginRight: "-15px",
        flexDirection: reverse ? "row-reverse" : "row",
        ...overrideStyle,
    }),
);

/**
 * @function Row
 * This function is used to create Row Component
 */
export const Row = React.forwardRef<
    HTMLDivElement,
    React.PropsWithChildren<RowPropType>
>(
    (
        {
            id,
            children,
            alignItems,
            className,
            style,
            justifyContent,
            borderRadius,
            backgroundColor,
            ...props
        },
        ref,
    ) => (
        <EmotionRow
            id={id}
            ref={ref}
            backgroundColor={backgroundColor}
            borderRadius={borderRadius}
            className={classNames(className)}
            alignItems={alignItems}
            justifyContent={justifyContent}
            overrideStyle={style}
            {...props}
        >
            {children}
        </EmotionRow>
    ),
);

/**
 * defaultProps - To define default values for component props
 */
Row.defaultProps = {
    justifyContent: "flex-start",
    alignItems: "center",
    reverse: false,
    backgroundColor: "unset",
    borderRadius: 0,
};
