import * as React from "react";
import styled from "@emotion/styled";
import { PropTypes } from "@util/propType";
import { cx as classNames } from "@emotion/css";
import { Property } from "@util/types";
import { getResponsiveCssProperty } from "@util/getBreakpoint";
interface FlexItemPropType
    extends Pick<PropTypes, "id" | "className" | "style"> {
    /** Order property controls the order in which they appear in the flex container **/
    order?: number;

    /** Types to align the items**/
    alignSelf?:
        | {
              sm?: Property.AlignSelf;
              lg?: Property.AlignSelf;
              md?: Property.AlignSelf;
              xs?: Property.AlignSelf;
          }
        | Property.AlignSelf;

    /** Specify how much the flexible item will grow **/
    flexGrow?:
        | {
              sm?: Property.FlexGrow;
              lg?: Property.FlexGrow;
              md?: Property.FlexGrow;
              xs?: Property.FlexGrow;
          }
        | Property.FlexGrow;

    /** Specify how much the flexible item will shrink **/
    flexShrink?:
        | {
              sm?: number;
              lg?: number;
              md?: number;
              xs?: number;
          }
        | Property.FlexShrink;

    /** Specify the initial length of a flexible item. **/
    flexBasis?:
        | {
              sm?: Property.FlexBasis;
              lg?: Property.FlexBasis;
              md?: Property.FlexBasis;
              xs?: Property.FlexBasis;
          }
        | Property.FlexBasis;
}

/**
 * @function StyledFlexItemPropType
 * This function to add patial prop types
 */
type StyledFlexItemProps = {
    overrideStyle?: React.CSSProperties;
} & Partial<FlexItemPropType>;

/**
 * @function StyledFlexItem
 * This function that takes all props and theme(passed by the emotion itself) as a argument returns object of its types
 */
const StyledFlexItem = ({
    flexGrow,
    flexShrink,
    flexBasis,
    order,
    alignSelf,
    overrideStyle,
}: StyledFlexItemProps) => {
    return {
        ...((flexBasis || flexGrow || flexShrink || alignSelf) &&
            getResponsiveCssProperty({
                flexBasis,
                maxWidth: flexBasis,
                flexGrow,
                alignSelf,
                flexShrink,
            })),
        order,
        ...overrideStyle,
    };
};

/**
 * @function EmotionFlexItem
 * This function is used to wrap the component for style
 */
export const EmotionFlexItem = styled("div")(StyledFlexItem);
export const FlexItem = React.forwardRef<
    HTMLDivElement,
    React.PropsWithChildren<FlexItemPropType>
>(({ id, children, className, style, ...props }, ref) => (
    <EmotionFlexItem
        id={id}
        ref={ref}
        className={classNames(className)}
        overrideStyle={style}
        {...props}
    >
        {children}
    </EmotionFlexItem>
));

/**
 * defaultProps - To define default values for component props
 */
FlexItem.defaultProps = {
    
    flexGrow: {
        sm: 1,
        lg: 1,
        md: 1,
        xs: 1,
    },
    flexShrink: {
        sm: 0,
        lg: 0,
        md: 0,
        xs: 0,
    },
    flexBasis: {
        xs: "auto",
        sm: "auto",
        md: "auto",
        lg: "auto",
    },
    alignSelf: {
        xs: "flex-start",
        sm: "flex-start",
        md: "flex-start",
        lg: "flex-start",
    },
    order: 0,
};
