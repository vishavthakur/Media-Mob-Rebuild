import * as React from "react";
import { ImageType } from "@util/types";
import { PropTypes } from "@util/propType";
import styled from "@emotion/styled";
import { DetailedHTMLProps } from "@util/types";

export interface InputPropType<T>
    extends Omit<DetailedHTMLProps<HTMLInputElement>, "className" | "type"> {
    /* Input type */
    type?: T;

    // /** Display error message and error styling **/
    errorMessage?: string | JSX.Element;

    // /** Input value **/
    value?: string;

    // /** Input name **/
    name?: string;

    // /** User can read text only and can't perform action **/
    isReadOnly?: boolean;

    // /** Required field **/
    isRequired?: boolean;

    // /** If true, checked for the checkbox and radio input type **/
    isChecked?: boolean;

    /**defined onChange event to pass fixed Event Target Issue */
    onChange?: (event: React.ChangeEvent<HTMLInputElement>) => void;

    // /** Provide user a hint or what kind of information is expected to enter in field **/
    //placeholder?: string;

    // /** Icon allows the end user to input data with the help of a hint **/
    icon?: any;

    // /** To add Input border radius **/
    borderRadius?: number;

    // /** Caption for the information of field **/
    label?: string;

    // /** Event occurs for change value of an element **/
    // onChange?: (event: React.ChangeEvent<HTMLInputElement>) => void;

    // /** Event occurs on key press **/
    // onKeyUp?: (event: React.KeyboardEvent<HTMLInputElement>) => void;

    // /** Event occurs on blur of an element **/
    // onBlur?: (event: React.FocusEvent<HTMLInputElement>) => void;

    // /** Event occurs on focus of an element **/
    // onFocus?: (event: React.FocusEvent<HTMLInputElement>) => void;

    // /** Input variations can be of 3 types: 'solid - filled layout',  'outline - bordered layout', 'ghost - to show transculant style layout' **/
    variant?: "solid" | "outline" | "ghost";

    // /** Aria Invalid to show invalid data **/
    ariaInvalid?: boolean;

    // /** Aria describedby for input to describe the purpose of Input **/
    ariaDescribedby?: string;

    /*disable input */
    disable?: boolean;
}

/**
 * @function EmotionInput
 * This function is used to wrap the Inner Item for style
 */
export const EmotionInput = styled("input")(``);

export const InputWrapper = React.forwardRef<
    HTMLInputElement,
    React.PropsWithChildren<
        InputPropType<
            "text" | "email" | "password" | "radio" | "checkbox" | "tel"
        >
    >
>(
    (
        {
            id,
            name,
            value,
            type,
            onChange,
            onKeyUp,
            placeholder,
            isRequired,
            disable,
            isReadOnly,
            ariaInvalid,
            ariaDescribedby,
            ...props
        },
        ref,
    ) => (
        <>
            <EmotionInput
                aria-invalid={ariaInvalid}
                aria-describedby={ariaDescribedby}
                id={id}
                value={value}
                ref={ref}
                name={name}
                type={type}
                placeholder={placeholder}
                readOnly={isReadOnly}
                disabled={disable}
                onChange={disable ? undefined : onChange}
                onKeyUp={disable ? undefined : onKeyUp}
                required={isRequired}
                {...props}
            />
        </>
    ),
);

/**
 * defaultProps - To define default values for component props
 */
InputWrapper.defaultProps = {
    id: "input",
    type: "text",
    variant: "solid",
    isReadOnly: false,
    disable: false,
    isRequired: false,
    value: "",
    name: "",
};
