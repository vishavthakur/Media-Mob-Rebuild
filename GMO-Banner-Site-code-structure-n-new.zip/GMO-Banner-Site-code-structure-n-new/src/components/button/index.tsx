import styled from "@emotion/styled";
import { isObjectEmpty } from "../../utils/helpers";
import React from "react";
import { defaultTheme, Theme } from "src/context/ThemeProvider";
import { cx as classNames } from "@emotion/css";
import { alpha } from "@util/Theme/colorManipulator";
import { Property } from "@util/types";
import { spacing, fontSizes } from "@util/units";
import { PropTypes } from "@util/propType";

export interface ButtonPropType extends PropTypes<HTMLButtonElement> {
    /** Button variations can be of 4 types: 'solid - filled layout', 'link - text link layout ' and 'outline - bordered layout' , 'text -  Text link style with hover layout  **/
    variant?: "solid" | "outline" | "text" | "link";

    /** To add shadow effect **/
    elevation?: boolean;

    /** Button sizes can be of 3 types: 'sm - small view of button size' , 'md - medium view of button size' and 'lg - large view of button size **/
    size?: "sm" | "md" | "lg";

    /** Custom icon place before text from outside the component **/
    startIcon?: JSX.Element;

    /** Custom icon place after text from outside the component **/
    endIcon?: JSX.Element;

    /** Radius to rounds the corners of an element from outer border edge **/
    borderRadius?: number;

    /** Additonal width of button **/
    minWidth?: Property.MinWidth;

    /** Alignment of item inside button */
    alignItems?: Property.AlignItem;

    /** To define a string that labels the current element **/
    "aria-label"?: string;

    /** Justify position for elements inside button */
    justifyContent?: Property.JustifyElemnent;

    /** for fullwidth button */
    fullWidth?: boolean;
}

/**
 * @object buttonSizeProps
 * This object is used define the sizes of button
 */

const buttonSizeProps = {
    sm: {
        fontSize: fontSizes["xs"],
        padding: `${spacing["xxs"]} ${spacing["sm"]}`,
    },
    md: {
        fontSize: fontSizes["sm"],
        padding: `${spacing["xs"]} ${spacing["md"]}`,
    },
    lg: {
        fontSize: fontSizes["md"],
        padding: `${spacing["sm"]} ${spacing["lg"]}`,
    },
};

/**
 * @function getPropsByVariant
 * This function is used to pass the color scheme, variant and the emotion theme
 */

const getPropsByVariant = ({ variant, colorScheme, theme }) => {
    const colorInPalette = theme.palette[colorScheme];
    const variants = {
        outline: colorInPalette && {
            main: {
                border: `1px solid ${colorInPalette.main}`,
                backgroundColor: theme.palette.common.transparent,
                color: colorInPalette.main,
            },
            hover: {
                backgroundColor: alpha(
                    colorInPalette.main,
                    theme.palette.action.hoverOpacity,
                ),
            },
        },

        solid: colorInPalette && {
            main: {
                border: `1px solid ${colorInPalette.main}`,
                backgroundColor: colorInPalette.main,
                color: theme.palette.common.white,
            },

            hover: {
                border: `1px solid ${colorInPalette.main}`,
                transition: colorInPalette.transition,
                backgroundColor: colorInPalette.hover,
            },
        },

        text: colorInPalette && {
            main: {
                border: "none",
                backgroundColor: theme.palette.common.transparent,
                color: colorInPalette.main,
            },
            hover: {
                backgroundColor: alpha(
                    colorInPalette.main,
                    theme.palette.action.hoverOpacity,
                ),
            },
        },

        link: colorInPalette && {
            main: {
                backgroundColor: theme.palette.common.transparent,
                color: colorInPalette.main,
                border: "none",
                padding: "0",
            },
            hover: {
                textDecoration: "underline",
                color: colorInPalette.main,
            },
        },
    };

    return variants[variant] || variants.solid;
};

export type StyledButtonProps = {
    isChildrenNull?: boolean;
    theme?: Theme;
    overrideStyle?: PropTypes["style"];
} & Partial<ButtonPropType>;

/**
 * @function StyledButton
 * This function that takes all props and theme(passed by the emotion itself) as a argument returns object of its types
 */

const StyledButton = ({
    theme,
    overrideStyle,
    colorScheme,
    variant,
    elevation,
    disable,
    alignItems,
    borderRadius,
    size,
    justifyContent,
    minWidth,
    fullWidth,
}: StyledButtonProps) => {
    if (isObjectEmpty(theme)) {
        theme = defaultTheme;
    }

    const fontSizeBySize = buttonSizeProps[size]?.fontSize;
    const paddingBySize = buttonSizeProps[size]?.padding;
    const propsByVariant = getPropsByVariant({
        variant,
        theme,
        colorScheme,
    });
    return {
        display: "flex",
        textDecoration: "none",
        alignItems: `${alignItems}`,
        justifyContent: `${justifyContent}`,
        fontWeight: 500,
        opacity: disable ? theme.palette.action.disabledOpacity : 1,
        padding: buttonSizeProps.md.padding,
        fontSize: buttonSizeProps.md.fontSize,
        borderRadius: borderRadius ?? theme.shape.borderRadius,
        // fontFamily: theme.typography.fontFamily,
        boxShadow: elevation && theme.shadows[1],
        width: fullWidth ? "100%" : "auto",
        minWidth,
        cursor: disable ? theme.palette.action.cursor : "pointer",
        ...(propsByVariant && propsByVariant.main),
        ...(paddingBySize && { padding: paddingBySize }),
        ...(fontSizeBySize && { fontSize: fontSizeBySize }),
        "&:hover": !disable && {
            boxShadow: elevation ? theme.shadows[2] : undefined,
            ...(propsByVariant && propsByVariant.hover),
        },

        ...overrideStyle,
    };
};

enum MarginDirection {
    left = "Left",
    right = "Right",
}
/**
 * @function StyledButtonIcon
 * This function that takes all props and theme(passed by the emotion itself) as a argument returns object of its types
 */
const StyledButtonIcon = ({ marginSide }: { marginSide: MarginDirection }) => {
    return {
        margin: 0,
        [`margin${marginSide}`]: 10,
    };
};

/**
 * @function EmotionButton
 * This function is used to wrap the component for style
 */

const EmotionButton = styled("button", {
    shouldForwardProp: (props: string) => {
        return ![
            "colorScheme",
            "variant",
            "elevation",
            "disable",
            "alignItems",
            "borderRadius",
            "size",
            "justifyContent",
            "minWidth",
            "fullWidth",
            "overrideStyle",
            "as",
        ].includes(props);
    },
})(StyledButton);

/**
 * @function EmotionButtonIcon
 * This function is used to wrap the component for style
 */
export const EmotionButtonIcon = styled("span")(StyledButtonIcon);

/**
 * 
it returns icon as jsx element
 */
const getButtonIcon = (
    icon: JSX.Element,
    marginSide: MarginDirection,
): JSX.Element => (
    <EmotionButtonIcon marginSide={marginSide}>{icon}</EmotionButtonIcon>
);

/**
 * Button Component
 */

export const Button = React.forwardRef<
    HTMLButtonElement,
    React.PropsWithChildren<ButtonPropType>
>(
    (
        {
            children,
            startIcon,
            endIcon,
            id,
            "aria-label": ariaLabel,
            colorScheme,
            variant,
            className,
            style,
            elevation,
            ...props
        },
        ref,
    ) => (
        <EmotionButton
            colorScheme={colorScheme}
            variant={variant}
            id={id}
            elevation={elevation}
            {...props}
            aria-label={ariaLabel}
            ref={ref}
            className={classNames(className)}
            overrideStyle={style}
        >
            {startIcon && getButtonIcon(startIcon, MarginDirection.right)}
            {children}
            {endIcon && getButtonIcon(endIcon, MarginDirection.left)}
        </EmotionButton>
    ),
);

/**
 * defaultProps - To define default values for component props
 */
Button.defaultProps = {
    colorScheme: "primary",
    variant: "outline",
    alignItems: "center",
    justifyContent: "center",
    elevation: false,
    "aria-label": "button" || "",
    fullWidth: false,
};
