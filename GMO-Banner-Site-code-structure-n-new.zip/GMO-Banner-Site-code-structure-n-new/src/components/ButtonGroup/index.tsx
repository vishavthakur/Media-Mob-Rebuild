import * as React from "react";
import classNames from "classnames";
import { PropTypes } from "@util/propType";
import styled from "@emotion/styled";
import { Theme } from "src/context/ThemeProvider";

interface ButtonGroupPropType
    extends Pick<PropTypes, "className" | "colorScheme" | "id" | "style"> {
    /** Button Group variations can be of 4 types: 'solid - filled layout', 'link - text link layout ' and 'outline - bordered layout' , 'text -  Text link style with hover layout  **/
    variant?: "solid" | "outline" | "text" | "link";

    /** To add ButtonGroup radius with rounded corner in number **/
    borderRadius: number;

    /** To show button group row-wise: horizontally and column-wise: vertically  **/
    vertical: boolean;

    /** To apply different border color **/
    borderColor?: string;
}

type StyledButtonGroupProps = {
    theme?: Theme;
    overrideStyle?: React.CSSProperties;
} & Partial<ButtonGroupPropType>;

const EmotionButtonGroupParent = styled.div(
    ({
        vertical,
        borderRadius,
        borderColor,
        overrideStyle,
    }: StyledButtonGroupProps) => ({
        display: "inline-flex",
        flexDirection: vertical ? "column" : "row",
        ...overrideStyle,
        ["& .groupclass"]: {
            borderRadius: borderRadius,
            minWidth: "100px",
            boxShadow: "none",
            borderColor: borderColor,
            ":hover": {
                boxShadow: "none",
            },
            "&:not(:last-of-type)": {
                borderTopRightRadius: vertical ? "" : 0,
                borderBottomLeftRadius: vertical && 0,
                borderBottomRightRadius: 0,
                borderRightColor: vertical ? "" : "transparent",
                borderBottomColor: vertical && "transparent",
            },
            "&:not(:first-of-type)": {
                borderTopLeftRadius: 0,
                borderTopRightRadius: vertical && 0,
                borderBottomLeftRadius: vertical ? "" : 0,
            },
        },
    }),
);

export const ButtonGroup = React.forwardRef<
    HTMLDivElement,
    React.PropsWithChildren<StyledButtonGroupProps>
>(
    (
        {
            id,

            variant,
            className,
            style,
            children,
            ...props
        },
        ref,
    ) => {
        return (
            <EmotionButtonGroupParent
                id={id}
                role="buttonGroup"
                className={classNames(className)}
                ref={ref}
                {...props}
                overrideStyle={style}
            >
                {React.Children.map(children, (child) => {
                    if (!React.isValidElement(child)) {
                        return null;
                    }
                    return React.cloneElement(child, {
                        variant,
                        className: "groupclass",
                    });
                })}
            </EmotionButtonGroupParent>
        );
    },
);
ButtonGroup.defaultProps = {
    id: "buttongroup",
    variant: "solid",
    colorScheme: "primary",
    borderRadius: 4,
    vertical: false,
};
