import * as React from "react";
import Image from "@templates/ImageConversion";
import { cx as classNames } from "@emotion/css";
import { List, ListItem } from "@components";
import { useOnClickOutside } from "@util/hooks/useOnOutsideClick";
import { useBoolean } from "@util/hooks/useBoolean";
import DropdownDown from "public/dropdown.svg";
import DropdownUp from "public/dropdown_up.svg";
import { PropTypes } from "@util/propType";
import styled from "@emotion/styled";
import { isObjectEmpty } from "../../utils/helpers";
import { defaultTheme, Theme, useThemeMode } from "src/context/ThemeProvider";
import { alpha } from "@util/Theme/colorManipulator";
import { fontSizes, spacing } from "@util/units";
import { ChevronUp, ChevronDown } from "react-feather";

export type OptionType = {
    id: string;
    name: string;
};

export interface SelectPropType extends Omit<PropTypes, "as" | "onChange"> {
    /** to define placeholder text */
    placeholder?: string;

    /** To add Input border radius **/
    borderRadius?: number;

    /** Trigger an action when click on dropdown **/
    onChange?: (val: string) => void;

    /** currently selected item's id**/
    selected?: string;

    /** options for the selection **/
    options: OptionType[];

    /** To show error message **/
    errorMessage?: string;

    /** to provide custom element for each item **/
    renderItem?: (option: OptionType) => React.ReactNode;

    /** Tetarea variations can be of 3 types: 'solid - filled layout',  'outline - bordered layout',**/
    variant?: "solid" | "outline" | "ghost";

    /** To apply className to nested components',**/
    classes?: Partial<
        Record<
            | "root"
            | "selectContainerWrapper"
            | "selectInput"
            | "selectText"
            | "selectIcon"
            | "selectOptions"
            | "selectList"
            | "selectListItem"
            | "selectErrorBox"
            | "selectActiveItem",
            string
        >
    >; //Here we have to define our all classes so while using component we will get autocomplete to apply our css

    /** SelectOption  sizes can be of 3 types: 'sm - small view of SelectOption  size' , 'md - medium view of SelectOption  size' and 'lg - large view of Textarea  size **/
    size?: "sm" | "md" | "lg";
}

const SelectSizeProps = {
    label: {
        sm: {
            fontSize: fontSizes["sm"],
        },
        md: {
            fontSize: fontSizes["md"],
        },
        lg: {
            fontSize: fontSizes["lg"],
        },
    },
    input: {
        sm: {
            fontSize: fontSizes["xs"],
            padding: `${spacing["xs"]} ${spacing["sm"]}`,
        },
        md: {
            fontSize: fontSizes["sm"],
            padding: `${spacing["sm"]} ${spacing["md"]}`,
        },
        lg: {
            fontSize: fontSizes["md"],
            padding: `${spacing["md"]} ${spacing["lg"]}`,
        },
    },
};
/**
 * @function getPropsByVariant
 * This function is used to pass the color scheme, variant and the emotion theme
 */
const getPropsByVariant = ({ variant, colorScheme, theme }) => {
    const colorInPalette = theme.palette[colorScheme];

    const variants = colorInPalette && {
        outline: {
            main: {
                border: `1px solid ${colorInPalette.main}`,

                color: colorInPalette.main,
            },
            error: {
                border: `1px solid ${theme.palette.error.main}`,
                color: theme.palette.error.main,
            },
        },

        solid: {
            main: {
                border: `1px solid ${colorInPalette.main}`,
                backgroundColor: colorInPalette.main,
                color: colorInPalette.contrastText,
            },
            error: {
                backgroundColor: theme.palette.error.main,
                color: colorInPalette.contrastText,
                border: "none",
            },
        },
        ghost: {
            main: {
                backgroundColor: alpha(colorInPalette.main, 0.2),
                color: colorInPalette.main,
                border: `1px solid ${alpha(colorInPalette.main, 0.5)}`,
                "&:placeholder ": {
                    color: colorInPalette.main,
                },
            },
            error: {
                backgroundColor: alpha(theme.palette.error.main, 0.2),
                border: `1px solid ${theme.palette.error.main}`,
                color: theme.palette.error.main,
            },
        },
    };

    return colorInPalette && variants[variant];
};

/**
 * This compoennt is a root Emotion component for the Select component
 */
const EmotionSelectContainer = styled("div")(
    /**
     * This function that takes all props and theme(passed by the emotion itself) as a argument returns object of its types
     */
    ({ overrideStyle }: { overrideStyle: React.CSSProperties }) => ({
        width: "100%",

        ...overrideStyle,
    }),
);

/**
 * This compoennt is a wrapper for selection and options
 */
const EmotionSelectContainerWrapper = styled("div")(() => ({
    position: "relative",
    // ...(disable && {
    //     opacity: 0.6,
    //     pointerEvents: "none",
    // }),
}));

/**
 * @function useColorVariant
 *  This function is use to provide, theme, colorscheme, variant
 */
const useColorVariant = (theme, variant, colorScheme) => {
    if (isObjectEmpty(theme)) {
        theme = defaultTheme;
    }
    return getPropsByVariant({
        variant,
        colorScheme,
        theme,
    });
};

/**
 * This is selection component
 */
const EmotionSelectInput = styled("div", {
    shouldForwardProp: (props: string) => {
        return ![
            "errorMessage",
            "colorScheme",
            "borderRadius",
            "maxheight",
            "disable",
            "alignItems",
            "size",
        ].includes(props);
    },
})(
    ({
        theme,
        errorMessage,
        disable,
        colorScheme,
        variant,
        size,
    }: {
        errorMessage: string;
        theme?: Theme;
        disable: boolean;
        colorScheme: PropTypes["colorScheme"];
        variant: SelectPropType["variant"];
        size?: string;
    }) => {
        if (isObjectEmpty(theme)) {
            theme = defaultTheme;
        }

        return {
            backgroundColor: "transparent",
            borderColor: theme.palette.paper.border,
            color: theme.palette.paper.text,
            borderRadius: variant && "4px",
            display: "flex",
            fontSize: SelectSizeProps?.input[size]?.fontSize,
            // borderBottom: "2px solid grey",
            cursor: "pointer",
            // pointerEvents: "pointer",
            ...(variant && {
                padding: SelectSizeProps?.input[size]?.padding,
                ...useColorVariant(theme, variant, colorScheme).main,
            }),

            ...(disable && {
                opacity: 0.6,
                pointerEvents: "none",
            }),
            ...(errorMessage && {
                borderBottom: `1px solid ${theme.palette.error.main}`,
                color: theme.palette.error.main,
                ...useColorVariant(theme, variant, colorScheme)?.error,
            }),
        };
    },
);

/**
 * Selection text component
 */
const EmotionSelectText = styled("div")(
    ({
        theme,
        errorMessage,
        size,
    }: {
        errorMessage: string;
        theme?: Theme;
        size?: string;
    }) => {
        if (isObjectEmpty(theme)) {
            theme = defaultTheme;
        }
        return {
            fontSize: SelectSizeProps?.label[size]?.fontSize,
            display: "inline-flex",
            color: "inherit",
            flex: 1,
            whiteSpace: "nowrap",
            overflow: "hidden",
        };
    },
);

/**
 * Icon component
 */
const EmotionSelectIcon = styled("div")(() => ({
    display: "flex",
    //width: "10px",
    marginLeft: "10px",
    alignItems: "center",
    verticalAlign: "middle",
    flexShrink: 0,
}));

/**
 * Select options component
 */
const EmotionSelectOptions = styled("div", {
    shouldForwardProp: (props: string) => {
        return ![
            "errorMessage",
            "colorScheme",
            "borderRadius",
            "maxheight",
            "scrollable",
            "disable",
            "alignItems",
        ].includes(props);
    },
})(({ theme }) => {
    if (isObjectEmpty(theme)) {
        theme = defaultTheme;
    }
    return {
        position: "absolute",
        top: "100%",
        right: 0,
        width: "100%",
        padding: 0,
        margin: 0,
        marginTop: 5,
        boxShadow: "rgba(0, 0, 0, 0.24) 0px 3px 8px",
        maxHeight: "300px",
        overflowY: "scroll",
        zIndex: 1,
        borderRadius: "4px",
        overflow: "hidden auto",
    };
});

/**
 * Select Error component
 */
const EmotionSelectErrorBox = styled("div")(({ theme }: { theme?: Theme }) => {
    if (isObjectEmpty(theme)) {
        theme = defaultTheme;
    }
    return {
        color: theme.palette.error.main,
        fontSize: "14px",
        lineHeight: "14px",
        marginTop: "5px",
        fontFamily: "sans-serif",
    };
});

/**
 * Select Component
 */
const   Select = React.forwardRef<HTMLDivElement, SelectPropType>(
    (
        {
            id,
            placeholder,
            onChange,
            selected,
            options,
            renderItem,
            errorMessage,
            className,
            style,
            disable,
            colorScheme,
            variant,
            classes,
            size,
        },
        ref,
    ) => {
        const [isDropdownOpen, { off: closeDropdown, toggle: toggelDropdown }] =
            useBoolean(false);
          const handleDropdown = () => {

          }
        const elementRef = React.useRef<HTMLDivElement | null>(null);
        const [localSelected, setLocalSelected] =
            React.useState<OptionType["id"]>();

        React.useEffect(() => {
            localSelected !== selected && setLocalSelected(selected);
        }, [selected]);
     
        useOnClickOutside(elementRef, closeDropdown);

        const handleOptionClick = React.useCallback(
            (option: OptionType) => {
                closeDropdown();
                if (localSelected === option.id) return;
                onChange && onChange(option.id);
                selected === undefined && setLocalSelected(option.id);
            },
            [localSelected, selected],
        );

        const selectedLabel = React.useMemo(() => {
            if (localSelected)
                return options.find((option) => option.id === localSelected)
                    ?.name;
            else return placeholder;
        }, [localSelected]);
        //const { themeMode } = useThemeMode();

        return (
            <EmotionSelectContainer
                className={classNames(className, classes?.root)}
                overrideStyle={style}
                ref={elementRef}
            >
                <EmotionSelectContainerWrapper ref={ref} className={classes?.selectContainerWrapper}>
                    <EmotionSelectInput
                        variant={variant}
                        size={size}
                        colorScheme={colorScheme}
                        disable={disable}
                        onClick={toggelDropdown}
                        onKeyDown={toggelDropdown}
                        errorMessage={errorMessage}
                        className={classes?.selectInput}
                    >
                        <EmotionSelectText
                            size={size}
                            errorMessage={errorMessage}
                            className={classes?.selectText}
                            tabIndex={0}
                        >
                            {selectedLabel}
                        </EmotionSelectText>
                        <EmotionSelectIcon className={classes?.selectIcon}>
                            {/* <img
                                id={`select_img_${id}`}
                                src={isDropdownOpen ? DropdownUp : DropdownDown}
                                alt={`select-icon-${id}`}
                            /> */}

                            {isDropdownOpen ? (
                                  <Image src="/icons/arrow-dropup-black.svg" alt="icon arrow up" height={10} width={10} />
                            ) : (
                                <Image src="/icons/arrow-dropdown-black.svg" alt="icon arrow up" height={10} width={10} />
                            )}
                        </EmotionSelectIcon>
                    </EmotionSelectInput>
                    {isDropdownOpen && (
                        <EmotionSelectOptions
                            className={classes?.selectOptions}
                        >
                            <List id={`option-container-${id}`} className={classes?.selectList}>
                                {options.map((option,index) => (
                                    <ListItem
                                    className={classNames(classes?.selectListItem, localSelected === option.id ? classes?.selectActiveItem : '') }
                                        key={`itemKey-${option.id}`}
                                        id={`item-${option.id}`}
                                        isSelected={localSelected === option.id}
                                        onClick={() =>
                                            handleOptionClick(option)
                                        }
                                        onKeyPress={
                                            () =>
                                            handleOptionClick(option)
                                        }
                                        tabIndex={0}
                                    >
                                        {renderItem
                                            ? renderItem(option)
                                            : option.name}
                                    </ListItem>
                                ))}
                            </List>
                        </EmotionSelectOptions>
                    )}
                </EmotionSelectContainerWrapper>
                {errorMessage && (
                    <EmotionSelectErrorBox className={classes?.selectErrorBox}>
                        {errorMessage}
                    </EmotionSelectErrorBox>
                )}
            </EmotionSelectContainer>
        );
    },
);

/**
 * defaultProps - To define default values for component props
 */
Select.defaultProps = {
    placeholder: "Please Select",
    options: [
        { id: "1", name: "Option 1" },
        { id: "2", name: "Option 2" },
        { id: "3", name: "Option 3" },
    ],
    colorScheme: "primary",
    size: "md",
};

export default Select;
