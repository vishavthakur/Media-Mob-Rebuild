import Image from "@templates/ImageConversion";
import parse from "html-react-parser";
import { Text } from '@components';
import { SectionBoxed } from '@templates';
interface cardProps{
    title?: string,
    subTitle?: string;
    className?: string;
    description?: string;
    actionButtons?: any;
    topRightImage?: {src:string,dimensions:{width:number,height:number},alt:string},
    topLeftImage?: {src:string,dimensions:{width:number,height:number},alt:string},
}
export const FooterAboveCard = (props:cardProps) =>{
    const { className } = props;
    return(
        <SectionBoxed className={`${className} FooterAboveCard`}>
            <Text as="div" className="FooterAboveCardContent"> 
                <Text as="h2">{props?.title}</Text>
                <Text as="h3">{parse(props?.subTitle)}</Text>
                <Text as="p" colorScheme="accent">{props?.description}</Text>
                <Text as="div" className="FooterAboveCardContentButton offers-footer-top">
                    {props?.actionButtons && props?.actionButtons.map((action, index) => {
                        return ((action?.url?.target === "_blank")?(<><a tabIndex={0} key={index} href={action?.url?.url} target={action?.url?.target} aria-label={action?.arialabel} id={action?.buttonId} data-gtm={action?.datagmt} className={`themeBtn  ${(index === 0) ? 'white' : 'outline'}`}>{action?.label}
                            {/* <button aria-label={action?.arialabel} id={action?.buttonId} data-gtm={action?.datagmt} className="themeBtn white">{action?.label}</button> */}

                        </a><span className="open-new">Opens in a new tab</span></>):(<><a key={index}  href={action?.url?.url} target={action?.url?.target} aria-label={action?.arialabel} id={action?.buttonId} data-gtm={action?.datagmt} className="themeBtn outline">
                            {/* <button aria-label={action?.arialabel} id={action?.buttonId} data-gtm={action?.datagmt} className="themeBtn white">{action?.label}</button> */}{action?.label}
                            </a></>) )
                    })}
                </Text>

                <Text className="element-position-top-right">
                    <Image 
                        src={props?.topRightImage?.src} 
                        height={120}
                        width={120}
                        // alt={props?.topRightImage?.alt} 
                        objectFit="contain" 
                        role="presentation"
                    />
                </Text>
                <Text className="element-position-left-bottom">
                    <Image 
                        src={props?.topLeftImage?.src} 
                        height={207}
                        width={207}
                        // alt={ props?.topLeftImage?.alt} 
                        objectFit="contain" 
                        role="presentation"
                    />
                </Text>
            </Text>
        </SectionBoxed>
    )
}