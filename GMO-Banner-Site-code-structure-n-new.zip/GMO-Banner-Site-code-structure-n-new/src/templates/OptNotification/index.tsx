import React from 'react'
import { setCookies, checkCookies } from 'cookies-next';
import classes from './OptNotification.module.scss';
import { useSelector, RootStateOrAny } from "react-redux";
import Bus from "@util/Bus";
import Image from "@templates/ImageConversion";
interface OptNotification {
  image?: JSX.Element,
  text?: string,
  link?: string,
  headerData?: any;
  onClose?: React.MouseEventHandler<HTMLButtonElement>
}

export const OptNotification: React.FC<OptNotification> = ({ image, text, link, onClose, headerData }) => {

  const [bannerOptin, setBannerOptin] = React.useState([]);
  const [optNotification, setOptNotification] = React.useState({});
  const userAccount = useSelector((state: RootStateOrAny) => state.auth);
  const bannerSelected = useSelector((state: RootStateOrAny) => state.banner);
  const bannerMap = (banner: string) => {
    switch (banner) {
      case "sobeyscom":
        return "sobeys";
      case "thriftyliquor":
        return "thriftyfoodsliquor";
      default:
        return banner;

    }
  }
  
  React.useEffect(() => {
    
    let dataBanner = [];
    // if (!getCookie('hide_optin')) {
      setBannerOptin([]);
      if (userAccount?.value?.subscriptions != undefined) {
      
        Object?.keys(userAccount?.value?.subscriptions)?.map((type) => {
          let allBanner = headerData?.acf_tru_taxonomy[0]?.blockdata?.filter(
            (data) => (data?.slug).replaceAll("-", "") === bannerSelected?.value
          );
          allBanner?.[0]?.header_image?.filter((data) => {
         
            if ((userAccount?.value?.subscriptions[type]?.optin?.email?.isSubscribed === false && userAccount?.value.subscriptions[type]?.optin?.email?.tags?.[0].includes("Source: " + type) && data?.logo_label?.replace(/[^A-Z0-9]/ig, "")?.toLowerCase() === bannerMap(type?.toLowerCase())) || (userAccount?.value?.subscriptions[type]?.eFlyer?.email?.isSubscribed === false && userAccount?.value.subscriptions[type]?.eFlyer?.email?.tags?.[0].includes("Source: " + type) && data?.logo_label?.replace(/[^A-Z0-9]/ig, "")?.toLowerCase() === bannerMap(type?.toLowerCase()))) {
              let cookieName = `${(data?.logo_label)?.replaceAll(" ","")}_hide_optin`;
              if(!checkCookies(cookieName)){
              setOptNotification({});
              dataBanner.push([true, data?.subscription_url, data?.url, data?.logo_label]);
              setBannerOptin(dataBanner);
              }
            }
          })
        });
      }
    // }
  }, [userAccount?.value, bannerSelected]);
  React.useEffect(() => {
    Bus.once('hideOpt', ({ type }) => {
      setBannerOptin([]);
    });
  }, [])
  const handleClick = (index,label) => {

    setOptNotification({ ...optNotification, [index]: !optNotification[index] });
    setCookies(`${label?.replaceAll(" ","")}_hide_optin`, 1, { path: '/', domain: `${process.env.NEXT_PUBLIC_COOKIE_DOMAIN}`, maxAge: 60 * 60 * 24 * 1095,sameSite:true });
  }
  return (
    <>
      {bannerOptin?.length > 0 &&
        <div className={classes.OptNotificationOuter + " OptNotificationSection"}>
          {bannerOptin?.map((data, index) =>
            <>
              {!optNotification[index] &&
                <div className={classes.OptNotification}>
                  {data?.[2] && <a tabIndex={0} href={!link ? void (0) : link} className={classes.OptNotification__image}>
                    <Image src={data?.[2]} alt={data?.[3]} width={98} height={98}></Image>
                  </a>}
                  <p tabIndex={0}>{headerData?.acf_tru_heading?.[0]?.blockdata?.[0]?.heading} {data?.[3]}. <strong><a target="_blank" href={`${data?.[1]}`}>{headerData?.acf_tru_heading?.[0]?.blockdata?.[0]?.sub_heading}</a></strong></p>
                  <button
                    onClick={() => handleClick(index,data?.[3])}
                    role="button"
                    aria-label="click here to close"
                    className={classes.OptNotification__close}
                  >
                    <svg width="12" height="13" viewBox="0 0 12 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path fillRule="evenodd" clipRule="evenodd" d="M11.6481 0.351372C11.5375 0.239974 11.406 0.151565 11.261 0.0912321C11.1161 0.0308995 10.9607 -0.000161219 10.8037 -0.000161219C10.6467 -0.000161219 10.4913 0.0308995 10.3464 0.0912321C10.2014 0.151565 10.0699 0.239974 9.95928 0.351372L5.99929 4.30557L2.04901 0.351372C1.82429 0.126131 1.51922 -0.000611732 1.20104 -0.000975776C0.882868 -0.00133982 0.577604 0.124706 0.352363 0.349432C0.127122 0.574158 0.00036483 0.879152 7.86017e-07 1.19733C-0.000363258 1.5155 0.125742 1.82079 0.350468 2.04604L4.31046 5.99927L0.350468 9.95445C0.125742 10.1797 -0.000363258 10.485 7.86017e-07 10.8032C0.00036483 11.1213 0.127122 11.4263 0.352363 11.6511C0.577604 11.8758 0.882868 12.0018 1.20104 12.0015C1.51922 12.0011 1.82429 11.8744 2.04901 11.6491L5.99929 7.6949L9.95928 11.6491C10.184 11.8731 10.4886 11.9986 10.8058 11.998C11.1231 11.9975 11.4271 11.8709 11.6511 11.6462C11.875 11.4215 12.0005 11.117 12 10.7997C11.9995 10.4825 11.8728 10.1784 11.6481 9.95445L7.69783 5.99927L11.6481 2.04604C11.8718 1.82076 11.9974 1.51617 11.9974 1.1987C11.9974 0.881237 11.8718 0.576648 11.6481 0.351372Z" fill="currentColor" />
                    </svg>
                  </button>
                </div>
              }

            </>
          )}
        </div>
      }
    </>
  )
}