import React from "react";
import Image from "@templates/ImageConversion";
import { Row, Col, Text, Card } from "@components";
import { SectionBoxed, SectionTitle } from "@templates";
import { useSelector, RootStateOrAny } from "react-redux";
import {getLocalregion} from "@util/helpers";
import styles from "./MoreWithEveryShop.module.scss";
import parse from "html-react-parser";
import Link from "next/link";

export const MoreWithEveryShop = (props) => {
  const { truCardsHeading, truRewardsCardList } = props;
  const bannerSelected = useSelector((state: RootStateOrAny) => state.banner);
  const [showCard,setShowCard] = React.useState(false);
  React.useEffect(() => {
   if(props?.regionalisation?.length === 0 || props?.regionalisation?.includes(getLocalregion())){
    setShowCard(true);
   }
   else{
    setShowCard(false);
  }
  },[props.regionalisation,bannerSelected?.value]);
  return (
    <>
    {showCard &&
      <SectionBoxed className={styles.sceneRewardsList}>
        <Row>
          <Col xs={12}>
            {truCardsHeading?.blockdata[0] && (
              <SectionTitle
                aboveTitle={
                  truCardsHeading?.blockdata[0]?.sub_heading
                    ? parse(truCardsHeading?.blockdata[0]?.sub_heading)
                    : ""
                }
                title={
                  truCardsHeading?.blockdata[0]?.heading
                    ? parse(truCardsHeading?.blockdata[0]?.heading)
                    : ""
                }
              />
            )}
          </Col>
        </Row>
        <Row alignItems="stretch" className={styles.rewardsCardRow}>
          {truRewardsCardList &&
            truRewardsCardList.map((item, index) => (
              <Col
                xs={12}
                sm={6}
                md={4}
                className="rewardsCard"
                key={`reward_${item}`}
              >
                <Card className="rewardsCardContent">
                  {item?.cardimages[0] && (
                    <Text as="div" className="icon">
                      <Image
                        src={item?.cardimages[0]?.desktopimage?.src}
                        alt={item?.cardimages[0]?.desktopimage?.alt}
                        height={
                          item?.cardimages[0]?.desktopimage?.dimensions?.height
                        }
                        width={
                          item?.cardimages[0]?.desktopimage?.dimensions?.width
                        }
                      />
                    </Text>
                  )}
                  {item.cardtitle && (
                    <Text as="h3" colorScheme="primary">
                      {parse(item.cardtitle)}
                    </Text>
                  )}
                  {item.card_discription && (
                    <Text as="p" colorScheme="accent">
                      {parse(item.card_discription)}
                    </Text>
                  )}

                  {!item.card_actionproperty[0]?.label ? (
                    ""
                  ) : (
                    <Link
                      href={
                        item.card_actionproperty[0]?.link?.url
                          ? item.card_actionproperty[0]?.link?.url
                          : "#"
                      }
                    >
                      {item.card_actionproperty[0]?.label && (
                        <a target={item?.card_actionproperty?.[0]?.link?.target} aria-label={item.card_actionproperty[0]?.arialabel} >{parse(item.card_actionproperty[0]?.label)}</a>
                      )}
                    </Link>
                  )}
                </Card>
              </Col>
            ))}
        </Row>
      </SectionBoxed>
}
    </>
  );
};
