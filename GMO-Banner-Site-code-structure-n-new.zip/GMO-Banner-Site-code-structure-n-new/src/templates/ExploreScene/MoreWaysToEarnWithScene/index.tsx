import { Col } from "@components";
import {
  SectionFluid,
  SectionTitle,
  SlickCircleNextArrow,
  SlickCirclePrevArrow,
} from "@templates";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import styles from "./MoreWaysToEarnWithScene.module.scss";

import React from "react";
import { Row } from "@components";
import { EarnMoreWithSceneCard } from "@templates/EarnMoreWithSceneCard";

const allMassOffers = [
  {
    imageUrl: "/earn-while-you-shop-online-with-rakuten.svg",
    headlineText: "Earn while you shop online with Rakuten.",
    descriptionText: "Only Scene+ members can earn up to 20% more cash back in Scene+ Points with Rakuten.",
    ctaLabel: "Learn More",
    ctaUrl: "#",
  },
  {
    imageUrl: "/hot-daily-deals-with-expedi.svg",
    headlineText: "Hot Daily Deals with Expedia.",
    descriptionText: "Check out our daily hotel deals and start planning your next getway today.",
    ctaLabel: "Learn More",
    ctaUrl: "link",
  },
  {
    imageUrl: "/save-on-your-snacks.svg",
    headlineText: "Save on your snacks!",
    descriptionText: "Spend 500 Scene+ Points for $5 off your favourite movie snacks and drinks at Cineplex.",
    ctaLabel: "Learn More",
    ctaUrl: "link",
  },

  {
    imageUrl: "/hot-daily-deals-with-expedi.svg",
    headlineText: "Earn 15x Bonus Scene+ Points at Harvey’s.",
    descriptionText: "15x Bonus Scene+ Points. Now that’s a beautiful thing.",
    ctaLabel: "Learn More",
    ctaUrl: "link",
  },
];

export const MoreWaysToEarnWithScene = (props) => {
  const {title, belowTitle} = props;

  let MassSlider = {
    centerMode: true,
    centerPadding: "13%",
    slidesToShow: 3,
    nextArrow: <SlickCircleNextArrow />,
    prevArrow: <SlickCirclePrevArrow />,
    dots: false,
    responsive: [
      {
        breakpoint: 1499,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,
          centerPadding: "13%",
        },
      },
      {
        breakpoint: 1299,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,
          centerPadding: "10%",
        },
      },
      {
        breakpoint: 1199,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
          centerPadding: "15%",
        },
      },
      {
        breakpoint: 991,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          centerPadding: "25%",
        },
      },
      {
        breakpoint: 576,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          centerPadding: "80px",
        },
      },
      {
        breakpoint: 479,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          centerPadding: "0px",
        },
      },
    ],
  };

  return (
    <SectionFluid className={styles.MoreWaysToEarnWithScene}>
      <Row>
          <Col md={12}>
           {title && <SectionTitle
              className={styles.MoreWaysToEarnWithSceneTitle}
              title={title}
              belowTitle={belowTitle}
            />}
          </Col>
        </Row>
      <Slider
        {...MassSlider}
        className="brandCard personalizeArrow arrow-in-bottom"
      > 
        {allMassOffers.map((MassCards) => (
          <EarnMoreWithSceneCard
            imageUrl={MassCards.imageUrl}
            headlineText={MassCards.headlineText}
            descriptionText={MassCards.descriptionText}
            ctaLabel={MassCards.ctaLabel}
            ctaUrl={MassCards.ctaUrl}
          />
        ))}
      </Slider>
    </SectionFluid>
  );
};
