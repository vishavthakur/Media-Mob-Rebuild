import React from "react";
import Link from "next/link";
import Image from "@templates/ImageConversion";
import {getLocalregion} from "@util/helpers";
import { useSelector, RootStateOrAny } from "react-redux";
import { Row, Col, Text } from "@components";
import {
  SectionFluid,
  SlickCircleNextArrow,
  SlickCirclePrevArrow,
} from "@templates";
import parse from "html-react-parser";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

export const MorePlacesToEarn = (props) => {
  const { truCardsHeading, brandsProductSlider } = props;
  const bannerSelected = useSelector((state: RootStateOrAny) => state.banner);
  const [showCard,setShowCard] = React.useState(false);
  let brandSlider = {
    centerMode: false,
    dots: false,
    infinite: true,
    speed: 500,
    slidesToShow: 9,
    slidesToScroll: 1,
    centerPadding: "15px",
    nextArrow: <SlickCircleNextArrow />,
    prevArrow: <SlickCirclePrevArrow />,
    responsive: [
      {
        breakpoint: 1299,
        settings: {
          centerMode: false,
          slidesToShow: 6,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 5,
          centerMode: true,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 767,
        settings: {
          slidesToShow: 4,
          centerMode: true,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 576,
        settings: {
          slidesToShow: 1,
          centerMode: true,
          slidesToScroll: 1,
          centerPadding: "140px",
        },
      },
      {
        breakpoint: 479,
        settings: {
          slidesToShow: 1,
          centerMode: true,
          slidesToScroll: 1,
          centerPadding: "110px",
        },
      },
      {
        breakpoint: 413,
        settings: {
          slidesToShow: 1,
          centerMode: true,
          slidesToScroll: 1,
          centerPadding: "100px",
        },
      },
    ],
  };
  /***
   * Remove aria labels for the accessibility
   */
  React.useEffect(() => {
    const timer = setTimeout(() => {
      document.querySelectorAll('.slick-slide').forEach(b=>b.removeAttribute('aria-hidden'))
      document.querySelectorAll('.slick-slide.slick-cloned .explore-slide').forEach(b=>b.setAttribute('tabindex', '-1'))
    }, 500);
    return () => clearTimeout(timer);
  }, []);
/*** 
 * Check the regionalisation
 */
 React.useEffect(() => {
  if(props?.regionalisation?.length === 0 || props?.regionalisation?.includes(getLocalregion())){
   setShowCard(true);
  }
  else{
    setShowCard(false);
  }
 },[props.regionalisation,bannerSelected?.value]);
  return (
    <>
    {showCard &&  <SectionFluid className="particaptingSection">
      <Row>
        <Col xs={12}>
          {truCardsHeading?.blockdata[0]?.heading && <Text as="h3" className="participatingTitle">
           {parse(truCardsHeading?.blockdata[0]?.heading)}
            </Text>}
        </Col>
      </Row>
      <Slider
        {...brandSlider}
        className="brandCard arrow-in-bottom personalizeArrow"
      >
        {brandsProductSlider &&
          brandsProductSlider?.map((brands, index) => (
            <Text as="div" className="brandImage" key={`barnd_slider${index}`}>
              {/* <Link
                href={
                  brands?.imagegroup[0]?.link?.url
                    ? brands?.imagegroup[0]?.link?.url
                    : "#!"
                }
              > */}
                <div className="explore-slide"
                  
                  // target={
                  //   brands?.imagegroup[0]?.link?.target
                  //     ? brands?.imagegroup[0]?.link?.target
                  //     : "_self"
                  // }
                >
                  <Image 
                    src={brands?.imagegroup[0]?.image?.src}
                    width={brands?.imagegroup[0]?.image?.dimensions?.width}
                    height={brands?.imagegroup[0]?.image?.dimensions?.height}
                    alt={brands?.imagegroup[0]?.image?.alt}
                  />
                </div>
             
            </Text>
          ))}
      </Slider>
    </SectionFluid>}
   
    </>
  );
};
