import React from "react";
import Link from "next/link";
import Image from "@templates/ImageConversion";
import { useSelector, RootStateOrAny } from "react-redux";
import { Row, Col, Text } from "@components";
import { SectionBoxed, SectionTitle } from "@templates";
import {getLocalregion} from "@util/helpers";
import parse from "html-react-parser";

import styles from "./ReedemForGreatRewards.module.scss";

export const ReedemForGreatRewards = (props) => {
  const { truCardsHeading, truInformationBanner } = props;
  const bannerSelected = useSelector((state: RootStateOrAny) => state.banner);
  const [showCard,setShowCard] = React.useState(false);
  React.useEffect(() => {
   if(props?.regionalisation?.length === 0 || props?.regionalisation?.includes(getLocalregion())){
    setShowCard(true);
   }
   else{
    setShowCard(false);
  }
  },[props.regionalisation,bannerSelected?.value]);
  return (
    <>
    {showCard && 
    <SectionBoxed className={styles.reedemSection + " py-18"}>
      {truCardsHeading && (
        <SectionTitle
          className={styles.reedemSectionTitle}
          title={truCardsHeading?.blockdata[0]?.heading ? parse(truCardsHeading?.blockdata[0]?.heading):''}
          belowTitle={truCardsHeading?.blockdata[0]?.description?parse(truCardsHeading?.blockdata[0]?.description): ''}
        />
      )}
      <Row style={{ alignItems: "stretch" }}>
        {truInformationBanner &&
          truInformationBanner.map((item, index) => (
            <Col sm={4} key={index} className={styles.reedemSectionCol}>
              <Text as="div" className={styles.reedemCard}>
                {item?.cardtitle && (
                  <Text as="h3">{parse(item?.cardtitle)}</Text>
                )}
                {item?.card_discription && (
                  <Text as="p">{parse(item?.card_discription)}</Text>
                )}
                {item?.card_actionproperty[0] && (
                  <div className="redeem-btn-outer">
                  <Link href={item?.card_actionproperty?.[0]?.link?.url}>
                 <a className="themeBtn white redeem" target={item?.card_actionproperty[0]?.link?.target} aria-label={item?.card_actionproperty[0]?.arialabel} id={item?.card_actionproperty[0]?.buttonId} data-gtm={item?.card_actionproperty[0]?.datagmt}>
                    {item?.card_actionproperty[0]?.label}
                  </a>
                  </Link>
                  {(item?.card_actionproperty?.[0]?.link?.target === "_blank")&& <><span className="open-new">Opens in a new tab</span></> }
                  </div>
                )}
                <Link
                  href={
                    item?.card_actionproperty[1]?.link?.url
                      ? item?.card_actionproperty[1]?.link?.url
                      : "#"
                  }
                >
                  {item?.card_actionproperty[1]?.link.title && (
                    <a className={`simple-link ${styles.link}`} target={item?.card_actionproperty[1]?.link?.target}>
                      {parse(item?.card_actionproperty[1]?.label)}
                    </a>
                  )}
                </Link>
                <div className={styles.bgWrap}>
                  <Image
                    src={item?.cardimages[0]?.desktopimage?.src}
                    alt={item?.cardimages[0]?.desktopimage?.alt}
                    layout="fill"
                    objectFit="contain"
                  />
                </div>
              </Text>
            </Col>
          ))}
      </Row>
    </SectionBoxed> }
    </>
  );
};
