import React, { useEffect, useState } from 'react';
import Image from 'next/image';
import { domainRemoveFromUrl } from '@util/domainRemoveFromUrl';
interface Props {
	src?: any;
	alt?: any;
	type?: any;
	className?: any;
	height?: any;
	width?: any;
	imagetype?: any;
    layout?:any;
    objectFit?:any;
	role?:any;
}
const Index: React.FC<Props> = ({ src, alt, className, height, width, role, imagetype, objectFit}: Props) => {
	return (<>

		{src?.match(/\.(jpeg|jpg|gif|png)$/) != null ?

			height ?				
			<Image src={src}
				alt={alt}
				height={height}
				width={width}
				className={className}
				priority={true}
				{...(role ? {role}:{})}
				// role={role ? role : ""}
			/>
			:
			<Image src={src}
				alt={alt}
				layout="fill"
				className={className}
                objectFit={objectFit}
				priority={true}
				{...(role ? {role}:{})}
			/>
			:
			
			src?.match('uploads/') ? (
				height ?				
				<Image src={`/api/svgurl${domainRemoveFromUrl(src)}`}
				alt={alt}
				height={height}
				width={width}
				className={className}
				priority={true}
				{...(role ? {role}:{})}
			/>
			:
			<Image src={`/api/svgurl${domainRemoveFromUrl(src)}`}
				alt={alt}
				layout="fill"
				className={className}
				priority={true}
				{...(role ? {role}:{})}
			/>) :
			height ?				
			<Image src={src}
				alt={alt}
				height={height}
				width={width}
				className={className}
				priority={true}
				{...(role ? {role}:{})}
			/>
			:
			<Image src={src}
				alt={alt}
				layout="fill"
				className={className}
				unoptimized={true}
				priority={true}
				{...(role ? {role}:{})}
			/>

		}

	</>);
}
export default Index;