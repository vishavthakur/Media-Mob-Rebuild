import React from "react";
import Image from "@templates/ImageConversion";
import { Breadcrumb, Container, Row, Col, Text, Flex } from "@components";
import parse from "html-react-parser";

const breadCrumbList = [
  { id: "1", to: "/", label: "Home" },
];

export const DarkInnerBanner = (props) => {
  const { BlackbreadCrumbList } = props;
  return (
    <Text
      as="div"
      className="DarkBreadCrumb"
      aria-label="breadcrumb"
      role="navigation"
    >
      <Container size="lg" className="DarkInnerBanner">
        <Row>
          <Col xs={12}>
            <Text as="div">
              {breadCrumbList && (
                <Breadcrumb className="BreadcrumbItem">
                  {breadCrumbList.map(({ to, label }, i, { length }) => (
                    <li>
                      {" "}
                      <a
                        key={to}
                        href={to}
                        style={{
                          pointerEvents: "unset",
                          textDecoration: "none",
                        }}
                      >
                        {label}
                        <Text as="div" className="BreadcrumbImage">
                          <Image
                            src="/icons/breadcrumbs-arrow-white.svg"
                            alt="breadcrumb arrow"
                            width="7"
                            height="9"
                            layout="fixed"
                          />
                        </Text>
                      </a>
                    </li>
                  ))}
                </Breadcrumb>
              )}
              <Flex
                justifyContent="flex-start"
                alignItems="flex-start"
                className="HeadingImageSection"
                aria-label="Scene is Here"
              >
                {/* <Image
                  src={BlackbreadCrumbList[0]?.imagegroup[0]?.image.src}
                  alt={BlackbreadCrumbList[0]?.imagegroup[0]?.image.alt}
                  width={
                    BlackbreadCrumbList[0]?.imagegroup[0]?.image.dimensions
                      ?.width
                  }
                  height={
                    BlackbreadCrumbList[0]?.imagegroup[0]?.image.dimensions
                      ?.height
                  }
                  layout="fixed"
                /> */}
                {BlackbreadCrumbList[0].titles[0] && (
                  <Text as="h1">
                    {parse(BlackbreadCrumbList[0]?.titles[0])}
                  </Text>
                )}
              </Flex>
              {BlackbreadCrumbList[0].description && (
                <Text as="p">{parse(BlackbreadCrumbList[0]?.description)}</Text>
              )}
            </Text>
          </Col>
        </Row>
      </Container>
    </Text>
  );
};
