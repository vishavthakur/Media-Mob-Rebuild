import React from "react";
import Image from "@templates/ImageConversion";
import Link from "next/link";
import parse from "html-react-parser";
import { BreakPoints } from "@util/units";
import { useSelector, RootStateOrAny } from "react-redux";
import { Container, Row, Col, Flex, Text } from "@components";
import { CookiePolicy } from "@templates";
import {
	setCookies,
	removeCookies,
	getCookie,
	getCookies
} from "cookies-next";
interface pageData {
	footerData?: any;
}
export const Footer = React.forwardRef<
	HTMLDivElement,
	React.PropsWithChildren<pageData>
>(({ children, ...props }, ref) => {
	
	const bannerSelected = useSelector((state: RootStateOrAny) => state.banner);
	const [locationLogo, setLocationLogo] = React.useState(null);
	const footerData = props?.footerData?.acf_tru_footer;
	const cookieValue = footerData?.[0]?.blockdata?.[0]?.wp_reset_cookie_value;
	const cookieAll = footerData?.[0]?.blockdata?.[0]?.wp_reset_cookie_all;
	/****
	 * Handle the logo's on location change
	 * @function locationChangeLogo
	 * @param location type string
	 */
	const locationChangeLogo = (location: string) => {
		let locationlogo =
			props?.footerData?.acf_tru_taxonomy[0]?.blockdata?.filter(
				(data) => (data?.slug).replaceAll("-", "") === location
			);
		setLocationLogo(locationlogo);
	};
	React.useEffect(() => {
		if (bannerSelected?.value) {
			locationChangeLogo(bannerSelected?.value);
		}
	}, [bannerSelected]);

	/***
	 * To reset all the cookies
	 */
	React.useEffect(() => {
		if (cookieValue === getCookie("wp_reset_cookie_value")) {
		} else {
			let allCookies = Object.keys(getCookies());
			allCookies.forEach((data) => {
				if (data.includes("hide_optin")) {
					removeCookies(data, {
						path: "/",
						domain: process.env.NEXT_PUBLIC_COOKIE_DOMAIN,
					});
				}

			})
			setCookies("wp_reset_cookie_value", cookieValue, { path: '/', domain: `${process.env.NEXT_PUBLIC_COOKIE_DOMAIN}`, maxAge: 60 * 60 * 24 * 1095, sameSite: true });
			console.log("cookie removed");
		}
		/****
		 * To Reset all cookies
		 */
		if(cookieAll != ''){
			if (cookieAll === getCookie("wp_reset_all_cookie")) {
			} else {
				let allCookies = Object.keys(getCookies());
				allCookies.forEach((data) => {
					if (!data.includes("_ga") && !data.includes("gig_") && !data.includes("_gid") && !data.includes("glt_") && !data.includes("hide_optin")) {
						removeCookies(data, {
							path: "/",
							domain: process.env.NEXT_PUBLIC_COOKIE_DOMAIN,
						});
					}
	
				})
				setCookies("wp_reset_all_cookie", cookieAll, { path: '/', domain: `${process.env.NEXT_PUBLIC_COOKIE_DOMAIN}`, maxAge: 60 * 60 * 24 * 1095, sameSite: true });
				
			}
		}
	}, [cookieValue,cookieAll]);
	return (
		<>
			<Text as="footer" className="Footer">
				<Container size="fluid" style={{ width: 1730 }}>
					<Row>
						<Col md={7}>
							<Text
								as="div"
								className="FooterLogosList"
								style={{
									[`@media ${BreakPoints.tablet}`]: {
										justifyContent: "flex-start",
									},
								}}
							>
								<ul>
									{!locationLogo ? (
										<></>
									) : (
										<>
											{locationLogo[0]?.footer_image?.map((data, index) => (
												<li key={`logo_footer_index_${index}`}>
													{data?.logo_url ? (<Link href={data?.logo_url}>
														<a target={data?.logo_link_target} aria-label={data?.logo_aria_label}>
															<Image
																src={data?.url}
																alt={data?.alt}
																width={data?.width}
																height={data?.height}
															></Image>
														</a>
													</Link>) : (
														<Image
															src={data?.url}
															alt={data?.alt}
															width={data?.width}
															height={data?.height}
														></Image>
													)}
												</li>
											))}
										</>
									)}
								</ul>
							</Text>
						</Col>
						<Col md={5}>
							<Flex
								justifyContent="center"
								style={{
									[`@media ${BreakPoints.tablet}`]: {
										justifyContent: "flex-end",
									},
								}}
							>
								<Text as="ul" className="footer-nav">
									{footerData[0]?.blockdata[0].acf_tru_menu[0]?.blockdata.map(
										(footerLink, index) => (
											<Text key={index} as="li">
												<Link href={footerLink?.url}>
													<a>{footerLink?.label}</a>
												</Link>
											</Text>
										)
									)}
								</Text>
							</Flex>
							<Text as="p" colorScheme="accent" className="copyright">
								{parse(
									footerData[0]?.blockdata[0].acf_tru_text[0]?.data?.ptext
								)}
							</Text>
						</Col>
					</Row>
				</Container>
			</Text>
			<CookiePolicy
				title={footerData[0]?.blockdata[0]?.acf_tru_information_banner?.[0]?.blockdata?.[0]?.title}
				description={footerData[0]?.blockdata?.[0]?.acf_tru_information_banner?.[0]?.blockdata?.[0]?.description}
				learnMoreText={footerData[0]?.blockdata?.[0]?.acf_tru_information_banner?.[0]?.blockdata?.[0]?.action_properties?.[0]?.label}
				target={footerData[0]?.blockdata?.[0]?.acf_tru_information_banner?.[0]?.blockdata?.[0]?.action_properties?.[0]?.url.target}
				learnMore={footerData[0]?.blockdata?.[0]?.acf_tru_information_banner?.[0]?.blockdata?.[0]?.action_properties?.[0]?.url?.url}
				closeText={footerData[0]?.blockdata?.[0]?.acf_tru_information_banner?.[0]?.blockdata?.[0]?.action_properties?.[1]?.label}
			/>
		</>
	);
});
