import React from "react";
import Image from "@templates/ImageConversion";
import Link from "next/link";
import { Text } from "@components";
import parse from "html-react-parser";
export const EarnMoreWithSceneCard = (props) => {
  const { imageUrl, headlineText, descriptionText, ctaLabel, ctaUrl, ctaId, ariaLabel,imageAlt } = props;
  return (
    <>
      <Text className="MassOffersBox">
        <Text className="MassOffersBoxImage">
          {imageUrl && (
            <Image
              src={imageUrl}
              alt={imageAlt}
              width="450"
              height="200"
            />
          )}
        </Text>
        <Text className="MassOffersBoxContent">
          {headlineText && (
            <Text as="h3" textAlign="center">
              {headlineText}
            </Text>
          )}
        </Text>
        <Text className="MassOffersBoxDescription">
          {descriptionText && (
            <Text as="p" textAlign="center">
              {descriptionText}
            </Text>
          )}
        </Text>
        {ctaUrl &&  <Text className="MassOffersBoxButton">
          <Link href={ctaUrl}>
            <a target="_blank" className="themeBtn" id={ctaId} aria-label={ariaLabel} >{parse(ctaLabel)}</a>
          </Link>
          <span className="open-new">Opens in a new tab</span>
        </Text>}
       
      </Text>
    </>
  );
};
