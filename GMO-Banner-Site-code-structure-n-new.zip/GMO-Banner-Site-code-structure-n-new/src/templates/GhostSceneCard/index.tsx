import React from "react";
import { useForm, Controller } from "react-hook-form";
import { useSelector, RootStateOrAny } from "react-redux";
import NumberFormat from "react-number-format";
import { AlertCircle } from "react-feather";
interface pageData {
  onSubmit?: (event: React.FormEvent<HTMLFormElement>) => void;
  handleChange?: (event: React.FormEvent<HTMLFormElement>) => void;
  errorResponse?: string;
}
/**
 * @function SceneCard
 * To render the scene card
 *
 */
export const GhostSceneCard = React.forwardRef<
  HTMLDivElement,
  React.PropsWithChildren<pageData>
>(({ children, errorResponse, ...props }, ref) => {
  const Auth = useSelector((state: RootStateOrAny) => state.auth);
  const [defaultCardNumber, setDefaultCardNumber] = React.useState(null);
  const onFormSubmit = (data) => {
    
    props.onSubmit(data);
  };
  const handleInputChange = (e) => {
    if (e.value.length < 10) {
      const timer = setTimeout(() => {
        setError("cardnumber", {
          type: "manual",
          message: "Please enter 10 digit card number",
        });
      });
      return () => clearTimeout(timer);

    }
    else {
    }
    props.handleChange(e);
  };
  const {
    register,
    handleSubmit,
    control,
    formState: { errors, isValid },
    setValue,
    setError,
    clearErrors
  } = useForm({ mode: "all" });
  /****
   * To get the value from the user account
   */
  React.useEffect(() => {
    if (Auth?.value?.lpCardNumber) {
      setValue("cardnumber", (Auth?.value?.lpCardNumber).substr(6))
    }
  }, [Auth?.value]);

  /***
  *@function HandleChangeCard
  * to handle the card length on change
  */
  const HandleChangeCard = (e) => {
    if (e.value.length < 10) {
      const timer = setTimeout(() => {
        setError("cardnumber", {
          type: "manual",
          message: "Please enter 10 digit card number",
        });
      });
      return () => clearTimeout(timer);

    }
    else {
    }
  }
  return (
    <div className="">

      <div className="field-box-main">
        <form onSubmit={handleSubmit(onFormSubmit)}>
          <div className="input-box">
         
            <Controller
              control={control}
              {...register('cardnumber', {
                required: "Card number is required",

              })}
              
              render={({
                field
              }) => (
                <NumberFormat
                className="varifyInputNo"
                  format="604646 ### ### ### #"
                  key="card-number-field"
                  readOnly={true}
                  allowEmptyFormatting={true}
                  onValueChange={(e) =>
                    props.handleChange
                      ? handleInputChange(e)
                      : HandleChangeCard(e)
                  }
                  {...field}
                />
              )}
            />
           
            {errors.cardnumber && (
              <div className="error error-icon">
                <AlertCircle style={{ marginRight: "5px" }} size="12px" />
                {errors.cardnumber.message}
              </div>
            )}
            {errorResponse && !errors.cardnumber && (
              <div className="error error-icon">
                <AlertCircle style={{ marginRight: "5px" }} size="12px" />
                {errorResponse}
              </div>
            )}
          </div>
          <div className={((errors?.cardnumber?.message)?.length > 0) && `disable-submit`}>
            {children}
          </div>
        </form>
      </div>
    </div>
  );
});
