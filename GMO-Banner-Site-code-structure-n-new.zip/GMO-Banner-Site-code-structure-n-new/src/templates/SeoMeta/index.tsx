import Head from "next/head";
import { deviceDetect, mobileModel } from "react-device-detect";
type Props = {
    title?: string;
    keywords?: string;
    description?: string;
};

export const SeoMeta = ({ title, keywords, description }: Props) => {
    const devicess = deviceDetect(null);
    return (
        <Head>
            {devicess?.os === "iOS" && <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=0" />}
        {devicess?.os != "iOS" && <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=2.0" />}
            <meta name="keywords" content={keywords} />
            <meta name="description" content={description} />
            <meta charSet="utf-8" />
            <title>{title}</title>
        </Head>
    );
}

SeoMeta.defaultProps = {
    title: process.env.NEXT_PUBLIC_APP_NAME,
    keywords: "",
    description: "",
};
