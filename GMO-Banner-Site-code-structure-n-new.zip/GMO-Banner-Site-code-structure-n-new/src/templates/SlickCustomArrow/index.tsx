/ Slick Custom Arrow /
export const HeroNextArrow = (props) =>{
    const { className, style, onClick } = props;
    return(
        <div 
            className={className} 
            style={{ 
                ...style, 
                background: 'rgba(0, 0, 0, 0.5)', 
                right: '0px', 
                borderRadius: '50px 0px 0px 50px',
              }}
            onClick={onClick}
        >
            <svg
                style={{ 
                    position: 'absolute', 
                    top: '50%', 
                    left: '50%',
                    transform: 'translate(-20%, -50%)'
                }}  
                xmlns="http://www.w3.org/2000/svg" fill="#fff" width="15.97" height="28.563" viewBox="0 0 15.97 28.563">
              <path className="cls-1" d="M1907.06,397.594l-12.44-12.487a1.783,1.783,0,0,0-2.52,2.523l11.21,11.246-11.21,11.246a1.783,1.783,0,0,0,2.52,2.524l12.44-12.53A1.814,1.814,0,0,0,1907.06,397.594Z" transform="translate(-1891.62 -384.625)"/>
            </svg>


        </div>
    )
}
export const HeroPrevArrow = (props) =>{
    const { className, style, onClick } = props;
    return(
        <div 
            className={className} 
            style={{ 
                ...style, 
                background: 'rgba(0, 0, 0, 0.5)', 
                left: '0px', 
                zIndex: '1',
                borderRadius: '0px 50px 50px 0px'
            }}
            onClick={onClick}
        >
            <svg
            style={{ 
                position: 'absolute', 
                top: '50%', 
                left: '50%',
                transform: 'translate(-90%, -50%)'
            }}
            xmlns="http://www.w3.org/2000/svg" fill="#fff" width="15.969" height="28.563" viewBox="0 0 15.969 28.563">
                <path className="cls-1" d="M12.942,397.594l12.44-12.487A1.781,1.781,0,0,1,27.9,387.63l-11.2,11.246,11.2,11.246a1.781,1.781,0,0,1-2.514,2.524l-12.44-12.53A1.811,1.811,0,0,1,12.942,397.594Z" transform="translate(-12.438 -384.625)"/>
            </svg>
        </div>
    )
}

export const SlickCircleNextArrow = (props) =>{
    const { className, style, onClick } = props;
    return(
        <div 
            className={className} 
            style={{ 
                ...style, 
                background: '#fff',
                border: 'solid 1px #ddd',                 
                width: '50px', 
                height: '50px',
                borderRadius: '100%'
                
              }}
            onClick={onClick}
        >
           <div className="NextArrow"></div>            
        </div>
    )
}
export const SlickCirclePrevArrow = (props) =>{
    const { className, style, onClick } = props;
    return(
        <div 
            className={className} 
            style={{ 
                ...style, 
                background: '#fff',
                border: 'solid 1px #ddd',                
                width: '50px', 
                height: '50px',
                borderRadius: '100%',
                zIndex: '1'               
            }}
            onClick={onClick}
        >
            <div className="PrevArrow"></div>
        </div>
    )
}