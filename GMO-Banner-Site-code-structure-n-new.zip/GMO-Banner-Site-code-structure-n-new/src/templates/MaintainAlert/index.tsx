import React from "react";
import { getCookie,setCookies } from "cookies-next";
interface maintainProp {
    headline?:any,
    enableAlert?:string,
}
export const MaintainAlert = React.forwardRef<
HTMLDivElement,
React.PropsWithChildren<maintainProp>
    >(({ children, ...props }, ref) => {
        const [maintainAlert, setMaintainAlert] = React.useState(false);
        React.useEffect(() => {
         if(props?.enableAlert === "1"){
             if(!getCookie('maintain_alert_bar')){
                setMaintainAlert(true);
             }
          
         }
        },[props?.enableAlert]);
        const handleMaintainAlert = () => {
            setMaintainAlert(false);
            setCookies("maintain_alert_bar", 1, { path: '/', domain: `${process.env.NEXT_PUBLIC_COOKIE_DOMAIN}`, sameSite: true });

        }
    return(
<>
{maintainAlert && <div className="maninten-alert-main">
		<div className="maninten-alert-text">
			<p className="maninten-alert-description"><img role="presentation" src="/maintenance-image.svg" alt="maintenance"/>{props?.headline?.title}</p>
      <a href="javascript:void(0)" className="maintain-alert-close" onClick={() => handleMaintainAlert()}><img role="button" src="/close-alert.svg" alt="close icon"/></a>
      </div>
	</div>}

</>  
    )
})