import React, { useState } from "react";
import {Container, Text, Row, Col } from "@components";
import { setCookies, getCookie } from 'cookies-next';
interface cookieProps {
    title: string,
    description: string,
    learnMoreText: string,
    target: string,
    learnMore: string,
    closeText: string,
}
export const CookiePolicy = (props: cookieProps) => {
    const [policyCookie, setPolicyCookie] = useState(false);
    React.useEffect(() => {
        let cookieData = getCookie('policy-cookie');
        if (!cookieData) {
            setPolicyCookie(true);
        }
        return () => {

        }
    }, []);
    const handleCookieClick = () => {
        setCookies(`policy-cookie`, 1, { path: '/', domain: `${process.env.NEXT_PUBLIC_COOKIE_DOMAIN}`, maxAge: 60 * 60 * 24 * 1095 ,sameSite:true});
        setPolicyCookie(false);
    }
    return (
        <>
            {policyCookie && <Text className={"cookie_policy"}>
            <Container size="fluid" style={{ width: 1765 }}>
                <Row className={"cookieRow"}>
                    <Col
                        sm={12} md={10} lg={10}
                        className={"cookie_left_col"}
                    >
                        <div className={"col_left"}>
                            <h2>{props?.title}</h2>
                            <p> {props?.description
                            }<a href={props?.learnMore} target={props?.target}>{props?.learnMoreText}</a></p>
                        </div>
                    </Col>
                    <Col
                        sm={12} md={2} lg={2}
                        className={"cookie_right_col"}>
                        <div className={"col_right"}>
                            <a onClick={() => handleCookieClick()} onKeyPress={() => handleCookieClick()} tabIndex={0} className={"themeBtn"}>{props?.closeText}</a>
                        </div>
                    </Col>
                </Row>
                </Container>
            </Text>}
        </>
    );
};
export default CookiePolicy;