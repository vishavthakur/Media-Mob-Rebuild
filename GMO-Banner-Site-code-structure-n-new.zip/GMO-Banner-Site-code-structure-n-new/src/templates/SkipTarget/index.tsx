import React from 'react'

export const SkipTarget = () =>{
  return (
    <div id="start-of-content" role="complementary" aria-label="Main content Begins Here">
        <label className="d-none">Content Starts Here </label>
    </div>
  )
}
