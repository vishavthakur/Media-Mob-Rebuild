import React from "react";
import { Col, Text } from "@components";
import Image from "@templates/ImageConversion";

export const ProductOffers = () => {
  return (
    <>
          <Col md={3} sm={4}>
            <div>
              <Text as="div" className="ProductOffer">
                <Text as="header" className="ProductOfferHeader">
                  <Text className="Image">
                    <Image
                      src="/scene-plus.svg"
                      alt="breadcrumb arrow"
                      width="20"
                      height="20"
                      layout="fixed"
                    />
                  </Text>
                  <Text as="p">5,000</Text>
                  <Text as="span" className="tag pts">
                    PTS
                  </Text>
                </Text>
                <Text as="div" className="ProductOfferThumb">
                  <Text as="p" colorScheme="accent">
                    Expires <span>Dec 20</span>
                  </Text>

                  <Text as="div" className="ProductOfferThumbImg">
                    <Image
                      src="/product1-1.svg"
                      alt="breadcrumb arrow"
                      width="140"
                      height="140"
                      layout="fixed"
                    />
                  </Text>
                </Text>

                <Text as="div" className="ProductOfferContent">
                  <Text as="h3" colorScheme="accent">
                    <span>When you buy 3 </span> Hamburger Helper Sides, Betty
                    Crocker Potatoes, or Annie's Pasta, 141-240g.
                  </Text>
                </Text>

                <Text as="div" className="ProductOfferBrand">
                  <Text as="div" className="ProductOfferBrandInner">
                    <Text as="span">
                      <Image
                        src="/sobeys-3.svg"
                        alt="breadcrumb arrow"
                        width="48"
                        height="15"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/foodland-3.svg"
                        alt="breadcrumb arrow"
                        width="62"
                        height="12"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/safeway-3.svg"
                        alt="breadcrumb arrow"
                        width="62"
                        height="20"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/iga-4.svg"
                        alt="breadcrumb arrow"
                        width="31"
                        height="20"
                        layout="fixed"
                      />
                    </Text>
                  </Text>
                  <button className="linkText">Terms & Conditions</button>
                </Text>
              </Text>
            </div>
          </Col>
          <Col md={3} sm={4}>
            <div>
              <Text as="div" className="ProductOffer">
                <Text as="header" className="ProductOfferHeader">
                  <Text as="span" className="tag save">
                    Save
                  </Text>
                  <Text as="p">
                    99<sup>%</sup>Off
                  </Text>
                </Text>
                <Text as="div" className="ProductOfferThumb">
                  <Text as="p" colorScheme="accent">
                    Expires <span>Dec 20</span>
                  </Text>

                  <Text as="div" className="ProductOfferThumbImg">
                    <Image
                      src="/product1-1.svg"
                      alt="breadcrumb arrow"
                      width="140"
                      height="140"
                      layout="fixed"
                    />
                  </Text>
                </Text>

                <Text as="div" className="ProductOfferContent">
                  <Text as="h3" colorScheme="accent">
                    <span>When you buy 3 </span> Hamburger Helper Sides, Betty
                    Crocker Potatoes, or Annie's Pasta, 141-240g.
                  </Text>
                </Text>

                <Text as="div" className="ProductOfferBrand">
                  <Text as="div" className="ProductOfferBrandInner">
                    <Text as="span">
                      <Image
                        src="/sobeys-3.svg"
                        alt="breadcrumb arrow"
                        width="48"
                        height="15"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/foodland-3.svg"
                        alt="breadcrumb arrow"
                        width="62"
                        height="12"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/safeway-3.svg"
                        alt="breadcrumb arrow"
                        width="62"
                        height="20"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/iga-4.svg"
                        alt="breadcrumb arrow"
                        width="31"
                        height="20"
                        layout="fixed"
                      />
                    </Text>
                  </Text>
                  <button className="linkText">Terms & Conditions</button>
                </Text>
              </Text>
            </div>
          </Col>
          <Col md={3} sm={4}>
            <div>
              <Text as="div" className="ProductOffer">
                <Text as="header" className="ProductOfferHeader">
                  <Text as="span" className="tag save">
                    Save
                  </Text>
                  <Text as="p">99 c</Text>
                </Text>
                <Text as="div" className="ProductOfferThumb">
                  <Text as="p" colorScheme="accent">
                    Expires <span>Dec 20</span>
                  </Text>

                  <Text as="div" className="ProductOfferThumbImg">
                    <Image
                      src="/product1-1.svg"
                      alt="breadcrumb arrow"
                      width="140"
                      height="140"
                      layout="fixed"
                    />
                  </Text>
                </Text>

                <Text as="div" className="ProductOfferContent">
                  <Text as="h3" colorScheme="accent">
                    <span>When you buy 3 </span> Hamburger Helper Sides, Betty
                    Crocker Potatoes, or Annie's Pasta, 141-240g.
                  </Text>
                </Text>

                <Text as="div" className="ProductOfferBrand">
                  <Text as="div" className="ProductOfferBrandInner">
                    <Text as="span">
                      <Image
                        src="/sobeys-3.svg"
                        alt="breadcrumb arrow"
                        width="48"
                        height="15"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/foodland-3.svg"
                        alt="breadcrumb arrow"
                        width="62"
                        height="12"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/safeway-3.svg"
                        alt="breadcrumb arrow"
                        width="62"
                        height="20"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/iga-4.svg"
                        alt="breadcrumb arrow"
                        width="31"
                        height="20"
                        layout="fixed"
                      />
                    </Text>
                  </Text>
                  <button className="linkText">Terms & Conditions</button>
                </Text>
              </Text>
            </div>
          </Col>
          <Col md={3} sm={4}>
            <div>
              <Text as="div" className="ProductOffer">
                <Text as="header" className="ProductOfferHeader">
                  <Text as="span" className="tag buyOnegetOne">
                    BUY 1 GET 1
                  </Text>
                  <Text as="p">Free</Text>
                </Text>
                <Text as="div" className="ProductOfferThumb">
                  <Text as="p" colorScheme="accent">
                    Expires <span>Dec 20</span>
                  </Text>

                  <Text as="div" className="ProductOfferThumbImg">
                    <Image
                      src="/product1-1.svg"
                      alt="breadcrumb arrow"
                      width="140"
                      height="140"
                      layout="fixed"
                    />
                  </Text>
                </Text>

                <Text as="div" className="ProductOfferContent">
                  <Text as="h3" colorScheme="accent">
                    <span>When you buy 3 </span> Hamburger Helper Sides, Betty
                    Crocker Potatoes, or Annie's Pasta, 141-240g.
                  </Text>
                </Text>

                <Text as="div" className="ProductOfferBrand">
                  <Text as="div" className="ProductOfferBrandInner">
                    <Text as="span">
                      <Image
                        src="/sobeys-3.svg"
                        alt="breadcrumb arrow"
                        width="48"
                        height="15"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/foodland-3.svg"
                        alt="breadcrumb arrow"
                        width="62"
                        height="12"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/safeway-3.svg"
                        alt="breadcrumb arrow"
                        width="62"
                        height="20"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/iga-4.svg"
                        alt="breadcrumb arrow"
                        width="31"
                        height="20"
                        layout="fixed"
                      />
                    </Text>
                  </Text>
                  <button className="linkText">Terms & Conditions</button>
                </Text>
              </Text>
            </div>
          </Col>
          <Col md={3} sm={4}>
            <div>
              <Text as="div" className="ProductOffer">
                <Text as="header" className="ProductOfferHeader">
                  <Text as="p">
                    $99 <sup>99</sup>ea
                  </Text>
                </Text>
                <Text as="div" className="ProductOfferThumb">
                  <Text as="p" colorScheme="accent">
                    Expires <span>Dec 20</span>
                  </Text>

                  <Text as="div" className="ProductOfferThumbImg">
                    <Image
                      src="/product1-1.svg"
                      alt="breadcrumb arrow"
                      width="140"
                      height="140"
                      layout="fixed"
                    />
                  </Text>
                </Text>

                <Text as="div" className="ProductOfferContent">
                  <Text as="h3" colorScheme="accent">
                    <span>When you buy 3 </span> Hamburger Helper Sides, Betty
                    Crocker Potatoes, or Annie's Pasta, 141-240g.
                  </Text>
                </Text>

                <Text as="div" className="ProductOfferBrand">
                  <Text as="div" className="ProductOfferBrandInner">
                    <Text as="span">
                      <Image
                        src="/sobeys-3.svg"
                        alt="breadcrumb arrow"
                        width="48"
                        height="15"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/foodland-3.svg"
                        alt="breadcrumb arrow"
                        width="62"
                        height="12"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/safeway-3.svg"
                        alt="breadcrumb arrow"
                        width="62"
                        height="20"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/iga-4.svg"
                        alt="breadcrumb arrow"
                        width="31"
                        height="20"
                        layout="fixed"
                      />
                    </Text>
                  </Text>
                  <button className="linkText">Terms & Conditions</button>
                </Text>
              </Text>
            </div>
          </Col>
          <Col md={3} sm={4}>
            <div>
              <Text as="div" className="ProductOffer">
                <Text as="header" className="ProductOfferHeader">
                  <Text as="span" className="tag buyOnegetOne">
                    BUY 1 GET 1
                  </Text>
                  <Text as="p">
                    $99<sup>99</sup> off
                  </Text>
                </Text>
                <Text as="div" className="ProductOfferThumb">
                  <Text as="p" colorScheme="accent">
                    Expires <span>Dec 20</span>
                  </Text>

                  <Text as="div" className="ProductOfferThumbImg">
                    <Image
                      src="/product1-1.svg"
                      alt="breadcrumb arrow"
                      width="140"
                      height="140"
                      layout="fixed"
                    />
                  </Text>
                </Text>

                <Text as="div" className="ProductOfferContent">
                  <Text as="h3" colorScheme="accent">
                    <span>When you buy 3 </span> Hamburger Helper Sides, Betty
                    Crocker Potatoes, or Annie's Pasta, 141-240g.
                  </Text>
                </Text>

                <Text as="div" className="ProductOfferBrand">
                  <Text as="div" className="ProductOfferBrandInner">
                    <Text as="span">
                      <Image
                        src="/sobeys-3.svg"
                        alt="breadcrumb arrow"
                        width="48"
                        height="15"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/foodland-3.svg"
                        alt="breadcrumb arrow"
                        width="62"
                        height="12"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/safeway-3.svg"
                        alt="breadcrumb arrow"
                        width="62"
                        height="20"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/iga-4.svg"
                        alt="breadcrumb arrow"
                        width="31"
                        height="20"
                        layout="fixed"
                      />
                    </Text>
                  </Text>
                  <button className="linkText">Terms & Conditions</button>
                </Text>
              </Text>
            </div>
          </Col>
          <Col md={3} sm={4}>
            <div>
              <Text as="div" className="ProductOffer">
                <Text as="header" className="ProductOfferHeader">
                  <Text as="span" className="tag buyOnegetOne">
                    BUY 1 GET 1
                  </Text>
                  <Text as="p">
                    99<sup>%</sup> off
                  </Text>
                </Text>
                <Text as="div" className="ProductOfferThumb">
                  <Text as="p" colorScheme="accent">
                    Expires <span>Dec 20</span>
                  </Text>

                  <Text as="div" className="ProductOfferThumbImg">
                    <Image
                      src="/product1-1.svg"
                      alt="breadcrumb arrow"
                      width="140"
                      height="140"
                      layout="fixed"
                    />
                  </Text>
                </Text>

                <Text as="div" className="ProductOfferContent">
                  <Text as="h3" colorScheme="accent">
                    <span>When you buy 3 </span> Hamburger Helper Sides, Betty
                    Crocker Potatoes, or Annie's Pasta, 141-240g.
                  </Text>
                </Text>

                <Text as="div" className="ProductOfferBrand">
                  <Text as="div" className="ProductOfferBrandInner">
                    <Text as="span">
                      <Image
                        src="/sobeys-3.svg"
                        alt="breadcrumb arrow"
                        width="48"
                        height="15"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/foodland-3.svg"
                        alt="breadcrumb arrow"
                        width="62"
                        height="12"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/safeway-3.svg"
                        alt="breadcrumb arrow"
                        width="62"
                        height="20"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/iga-4.svg"
                        alt="breadcrumb arrow"
                        width="31"
                        height="20"
                        layout="fixed"
                      />
                    </Text>
                  </Text>
                  <button className="linkText">Terms & Conditions</button>
                </Text>
              </Text>
            </div>
          </Col>
          <Col md={3} sm={4}>
            <div>
              <Text as="div" className="ProductOffer">
                <Text as="header" className="ProductOfferHeader">
                  <Text as="span" className="tag save">
                    SAVE
                  </Text>
                  <Text as="p">
                    99<sup>%</sup> off
                  </Text>
                </Text>
                <Text as="div" className="ProductOfferThumb">
                  <Text as="p" colorScheme="accent">
                    Expires <span>Dec 20</span>
                  </Text>

                  <Text as="div" className="ProductOfferThumbImg">
                    <Image
                      src="/product-offer.svg"
                      alt="breadcrumb arrow"
                      width="140"
                      height="140"
                      layout="fixed"
                    />
                  </Text>
                </Text>

                <Text as="div" className="ProductOfferContent">
                  <Text as="h3" colorScheme="accent">
                    <span>When you buy 3 </span> Hamburger Helper Sides, Betty
                    Crocker Potatoes, or Annie's Pasta, 141-240g.
                  </Text>
                </Text>

                <Text as="div" className="ProductOfferBrand">
                  <Text as="div" className="ProductOfferBrandInner">
                    <Text as="span">
                      <Image
                        src="/sobeys-3.svg"
                        alt="breadcrumb arrow"
                        width="48"
                        height="15"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/foodland-3.svg"
                        alt="breadcrumb arrow"
                        width="62"
                        height="12"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/safeway-3.svg"
                        alt="breadcrumb arrow"
                        width="62"
                        height="20"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/iga-4.svg"
                        alt="breadcrumb arrow"
                        width="31"
                        height="20"
                        layout="fixed"
                      />
                    </Text>
                  </Text>
                  <button className="linkText">Terms & Conditions</button>
                </Text>
              </Text>
            </div>
          </Col>
          <Col md={3} sm={4}>
            <div>
              <Text as="div" className="ProductOffer">
                <Text as="header" className="ProductOfferHeader">
                  <Text as="span" className="tag save">
                    Save
                  </Text>
                  <Text as="p">%9 off</Text>
                </Text>
                <Text as="div" className="ProductOfferThumb">
                  <Text as="p" colorScheme="accent">
                    Expires <span>Dec 20</span>
                  </Text>

                  <Text as="div" className="ProductOfferThumbImg">
                    <Image
                      src="/product-offer.svg"
                      alt="breadcrumb arrow"
                      width="140"
                      height="140"
                      layout="fixed"
                    />
                  </Text>
                </Text>

                <Text as="div" className="ProductOfferContent">
                  <Text as="h3" colorScheme="accent">
                    <span>When you buy 3 </span> Hamburger Helper Sides, Betty
                    Crocker Potatoes, or Annie's Pasta, 141-240g.
                  </Text>
                </Text>

                <Text as="div" className="ProductOfferBrand">
                  <Text as="div" className="ProductOfferBrandInner">
                    <Text as="span">
                      <Image
                        src="/sobeys-3.svg"
                        alt="breadcrumb arrow"
                        width="48"
                        height="15"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/foodland-3.svg"
                        alt="breadcrumb arrow"
                        width="62"
                        height="12"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/safeway-3.svg"
                        alt="breadcrumb arrow"
                        width="62"
                        height="20"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/iga-4.svg"
                        alt="breadcrumb arrow"
                        width="31"
                        height="20"
                        layout="fixed"
                      />
                    </Text>
                  </Text>
                  <button className="linkText">Terms & Conditions</button>
                </Text>
              </Text>
            </div>
          </Col>
          <Col md={3} sm={4}>
            <div>
              <Text as="div" className="ProductOffer">
                <Text as="header" className="ProductOfferHeader">
                  <Text as="div" className="ProductOfferHeaderLeft">
                    <Text className="Image">
                      <Image
                        src="/scene-plus.svg"
                        alt="breadcrumb arrow"
                        width="20"
                        height="20"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="p">5,000</Text>
                    <Text as="span" className="tag pts">
                      PTS
                    </Text>
                  </Text>

                  <Text as="div" className="ProductOfferHeaderRight">
                    <Text as="span" className="ProductOfferHeaderRightSignIcon">
                      +
                    </Text>
                    <Text as="p">
                      $99<sup>99</sup>ea
                    </Text>
                  </Text>
                </Text>

                <Text as="div" className="ProductOfferThumb">
                  <Text as="p" colorScheme="accent">
                    Expires <span>Dec 20</span>
                  </Text>

                  <Text as="div" className="ProductOfferThumbImg">
                    <Image
                      src="/product1-1.svg"
                      alt="breadcrumb arrow"
                      width="140"
                      height="140"
                      layout="fixed"
                    />
                  </Text>
                </Text>

                <Text as="div" className="ProductOfferContent">
                  <Text as="h3" colorScheme="accent">
                    <span>When you buy 3 </span> Hamburger Helper Sides, Betty
                    Crocker Potatoes, or Annie's Pasta, 141-240g.
                  </Text>
                </Text>

                <Text as="div" className="ProductOfferBrand">
                  <Text as="div" className="ProductOfferBrandInner">
                    <Text as="span">
                      <Image
                        src="/sobeys-3.svg"
                        alt="breadcrumb arrow"
                        width="48"
                        height="15"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/foodland-3.svg"
                        alt="breadcrumb arrow"
                        width="62"
                        height="12"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/safeway-3.svg"
                        alt="breadcrumb arrow"
                        width="62"
                        height="20"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/iga-4.svg"
                        alt="breadcrumb arrow"
                        width="31"
                        height="20"
                        layout="fixed"
                      />
                    </Text>
                  </Text>
                  <button className="linkText">Terms & Conditions</button>
                </Text>
              </Text>
            </div>
          </Col>
          <Col md={3} sm={4}>
            <div>
              <Text as="div" className="ProductOffer">
                <Text as="header" className="ProductOfferHeader">
                  <Text as="div" className="ProductOfferHeaderLeft">
                    <Text className="Image">
                      <Image
                        src="/scene-plus.svg"
                        alt="breadcrumb arrow"
                        width="20"
                        height="20"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="p">5,000</Text>
                    <Text as="span" className="tag pts">
                      PTS
                    </Text>
                  </Text>

                  <Text as="div" className="ProductOfferHeaderRight">
                    <Text as="span" className="ProductOfferHeaderRightSignIcon">
                      +
                    </Text>
                    <Text as="span" className="tag save">
                      Save
                    </Text>
                    <Text as="p">
                      99<sup>%</sup>
                    </Text>
                  </Text>
                </Text>
                <Text as="div" className="ProductOfferThumb">
                  <Text as="p" colorScheme="accent">
                    Expires <span>Dec 20</span>
                  </Text>

                  <Text as="div" className="ProductOfferThumbImg">
                    <Image
                      src="/product1-1.svg"
                      alt="breadcrumb arrow"
                      width="140"
                      height="140"
                      layout="fixed"
                    />
                  </Text>
                </Text>

                <Text as="div" className="ProductOfferContent">
                  <Text as="h3" colorScheme="accent">
                    <span>When you buy 3 </span> Hamburger Helper Sides, Betty
                    Crocker Potatoes, or Annie's Pasta, 141-240g.
                  </Text>
                </Text>

                <Text as="div" className="ProductOfferBrand">
                  <Text as="div" className="ProductOfferBrandInner">
                    <Text as="span">
                      <Image
                        src="/sobeys-3.svg"
                        alt="breadcrumb arrow"
                        width="48"
                        height="15"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/foodland-3.svg"
                        alt="breadcrumb arrow"
                        width="62"
                        height="12"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/safeway-3.svg"
                        alt="breadcrumb arrow"
                        width="62"
                        height="20"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/iga-4.svg"
                        alt="breadcrumb arrow"
                        width="31"
                        height="20"
                        layout="fixed"
                      />
                    </Text>
                  </Text>
                  <button className="linkText">Terms & Conditions</button>
                </Text>
              </Text>
            </div>
          </Col>
          <Col md={3} sm={4}>
            <div>
              <Text as="div" className="ProductOffer">
                <Text as="header" className="ProductOfferHeader">
                  <Text as="div" className="ProductOfferHeaderLeft">
                    <Text className="Image">
                      <Image
                        src="/scene-plus.svg"
                        alt="breadcrumb arrow"
                        width="20"
                        height="20"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="p">5,000</Text>
                    <Text as="span" className="tag pts">
                      PTS
                    </Text>
                  </Text>
                  <Text as="div" className="ProductOfferHeaderRight">
                    <Text as="span" className="ProductOfferHeaderRightSignIcon">
                      +
                    </Text>
                    <Text as="span" className="tag save">
                      Save
                    </Text>
                    <Text as="p">
                      $99<sup>99</sup>
                    </Text>
                  </Text>
                </Text>
                <Text as="div" className="ProductOfferThumb">
                  <Text as="p" colorScheme="accent">
                    Expires <span>Dec 20</span>
                  </Text>

                  <Text as="div" className="ProductOfferThumbImg">
                    <Image
                      src="/product1-1.svg"
                      alt="breadcrumb arrow"
                      width="140"
                      height="140"
                      layout="fixed"
                    />
                  </Text>
                </Text>

                <Text as="div" className="ProductOfferContent">
                  <Text as="h3" colorScheme="accent">
                    <span>When you buy 3 </span> Hamburger Helper Sides, Betty
                    Crocker Potatoes, or Annie's Pasta, 141-240g.
                  </Text>
                </Text>

                <Text as="div" className="ProductOfferBrand">
                  <Text as="div" className="ProductOfferBrandInner">
                    <Text as="span">
                      <Image
                        src="/sobeys-3.svg"
                        alt="breadcrumb arrow"
                        width="48"
                        height="15"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/foodland-3.svg"
                        alt="breadcrumb arrow"
                        width="62"
                        height="12"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/safeway-3.svg"
                        alt="breadcrumb arrow"
                        width="62"
                        height="20"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/iga-4.svg"
                        alt="breadcrumb arrow"
                        width="31"
                        height="20"
                        layout="fixed"
                      />
                    </Text>
                  </Text>
                  <button className="linkText">Terms & Conditions</button>
                </Text>
              </Text>
            </div>
          </Col>
          <Col md={3} sm={4}>
            <div>
              <Text as="div" className="ProductOffer">
                <Text as="header" className="ProductOfferHeader">
                  <Text as="div" className="ProductOfferHeaderLeft">
                    <Text as="span" className="tag save">
                      Save
                    </Text>
                    <Text as="p">$1.00</Text>
                  </Text>
                  <Text as="div" className="ProductOfferHeaderRight">
                    <Text as="span" className="ProductOfferHeaderRightSignIcon">
                      |
                    </Text>
                    <Text as="p">$3.00 ea</Text>
                  </Text>
                </Text>
                <Text as="div" className="ProductOfferThumb">
                  <Text as="p" colorScheme="accent">
                    Expires <span>Dec 20</span>
                  </Text>
                  <Text as="div" className="ProductOfferThumbImg">
                    <Image
                      src="/product1-1.svg"
                      alt="breadcrumb arrow"
                      width="140"
                      height="140"
                      layout="fixed"
                    />
                  </Text>
                </Text>

                <Text as="div" className="ProductOfferContent">
                  <Text as="h3" colorScheme="accent">
                    <span>When you buy 3 </span> Hamburger Helper Sides, Betty
                    Crocker Potatoes, or Annie's Pasta, 141-240g.
                  </Text>
                </Text>

                <Text as="div" className="ProductOfferBrand">
                  <Text as="div" className="ProductOfferBrandInner">
                    <Text as="span">
                      <Image
                        src="/sobeys-3.svg"
                        alt="breadcrumb arrow"
                        width="48"
                        height="15"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/foodland-3.svg"
                        alt="breadcrumb arrow"
                        width="62"
                        height="12"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/safeway-3.svg"
                        alt="breadcrumb arrow"
                        width="62"
                        height="20"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/iga-4.svg"
                        alt="breadcrumb arrow"
                        width="31"
                        height="20"
                        layout="fixed"
                      />
                    </Text>
                  </Text>
                  <button className="linkText">Terms & Conditions</button>
                </Text>
              </Text>
            </div>
          </Col>
          <Col md={3} sm={4}>
            <div>
              <Text as="div" className="ProductOffer">
                <Text as="header" className="ProductOfferHeader">
                  <Text as="div" className="ProductOfferHeaderLeft">
                    <Text as="span" className="tag save">
                      Save
                    </Text>
                    <Text as="p">
                      99<sup>%</sup>
                    </Text>
                  </Text>
                  <Text as="div" className="ProductOfferHeaderRight">
                    <Text as="span" className="ProductOfferHeaderRightSignIcon">
                      |
                    </Text>
                    <Text as="p">$99 ea</Text>
                  </Text>
                </Text>
                <Text as="div" className="ProductOfferThumb">
                  <Text as="p" colorScheme="accent">
                    Expires <span>Dec 20</span>
                  </Text>
                  <Text as="div" className="ProductOfferThumbImg">
                    <Image
                      src="/product1-1.svg"
                      alt="breadcrumb arrow"
                      width="140"
                      height="140"
                      layout="fixed"
                    />
                  </Text>
                </Text>
                <Text as="div" className="ProductOfferContent">
                  <Text as="h3" colorScheme="accent">
                    <span>When you buy 3 </span> Hamburger Helper Sides, Betty
                    Crocker Potatoes, or Annie's Pasta, 141-240g.
                  </Text>
                </Text>
                <Text as="div" className="ProductOfferBrand">
                  <Text as="div" className="ProductOfferBrandInner">
                    <Text as="span">
                      <Image
                        src="/sobeys-3.svg"
                        alt="breadcrumb arrow"
                        width="48"
                        height="15"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/foodland-3.svg"
                        alt="breadcrumb arrow"
                        width="62"
                        height="12"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/safeway-3.svg"
                        alt="breadcrumb arrow"
                        width="62"
                        height="20"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/iga-4.svg"
                        alt="breadcrumb arrow"
                        width="31"
                        height="20"
                        layout="fixed"
                      />
                    </Text>
                  </Text>
                  <button className="linkText">Terms & Conditions</button>
                </Text>
              </Text>
            </div>
          </Col>
          <Col md={3} sm={4}>
            <div>
              <Text as="div" className="ProductOffer">
                <Text as="header" className="ProductOfferHeader">
                  <Text as="p">Custom Offer</Text>
                </Text>
                <Text as="div" className="ProductOfferThumb">
                  <Text as="p" colorScheme="accent">
                    Expires <span>Dec 20</span>
                  </Text>

                  <Text as="div" className="ProductOfferThumbImg">
                    <Image
                      src="/product1-1.svg"
                      alt="breadcrumb arrow"
                      width="140"
                      height="140"
                      layout="fixed"
                    />
                  </Text>
                </Text>

                <Text as="div" className="ProductOfferContent">
                  <Text as="h3" colorScheme="accent">
                    <span>When you buy 3 </span> Hamburger Helper Sides, Betty
                    Crocker Potatoes, or Annie's Pasta, 141-240g.
                  </Text>
                </Text>

                <Text as="div" className="ProductOfferBrand">
                  <Text as="div" className="ProductOfferBrandInner">
                    <Text as="span">
                      <Image
                        src="/sobeys-3.svg"
                        alt="breadcrumb arrow"
                        width="48"
                        height="15"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/foodland-3.svg"
                        alt="breadcrumb arrow"
                        width="62"
                        height="12"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/safeway-3.svg"
                        alt="breadcrumb arrow"
                        width="62"
                        height="20"
                        layout="fixed"
                      />
                    </Text>
                    <Text as="span">
                      <Image
                        src="/iga-4.svg"
                        alt="breadcrumb arrow"
                        width="31"
                        height="20"
                        layout="fixed"
                      />
                    </Text>
                  </Text>
                  <button className="linkText">Terms & Conditions</button>
                </Text>
              </Text>
            </div>
          </Col>
    </>
  );
};
