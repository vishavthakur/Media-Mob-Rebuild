import React from "react";
import { useForm } from "react-hook-form";
import { useSelector, RootStateOrAny } from "react-redux";
import { Gigya } from "@services/Gigya";
interface pageData {
  onSubmit?: (event: React.FormEvent<HTMLFormElement>) => void;
  handleChange?: (event: React.FormEvent<HTMLFormElement>) => void;
  errorResponse?: string;
}
/**
 * @function SceneCard
 * To render the scene card
 *
 */
 const SceneCardForm = React.forwardRef<
  HTMLDivElement,
  React.PropsWithChildren<pageData>
>(({ children, errorResponse, ...props }, ref) => {
  const Auth = useSelector((state: RootStateOrAny) => state.auth);
  const onFormSubmit = (data) => {
    props.onSubmit(data);
  };
  const handleInputChange = (e) => {
    props.handleChange(e);
  };
  const {
    register,
    handleSubmit,
    control,
    formState: { errors, isValid },
  } = useForm({ mode: "all" });
  return (
    <div className="field-box-main ">
      <div className="SceneCardPopup addCardPopup">
        <Gigya
          overrideStyle={{
            margin: "20px",
          }}
          screenId={`${process.env.NEXT_PUBLIC_GIGYA_BANNER}-ProfileUpdate`}
          startScreen="gigya-add-card-screen"
          id="login-dev-new"
          key="test"
        />
      </div>
    </div>
  );
});

export const SceneCard = React.memo(SceneCardForm);
