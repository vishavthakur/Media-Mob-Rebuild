import React, { useEffect } from "react";
import { Menu } from "react-feather";
import Router, { useRouter } from "next/router";
import { useSelector, RootStateOrAny, useDispatch } from "react-redux";
import Link from "next/link";
import Image from "@templates/ImageConversion";
import {defaultStores, Regions, RegionsNames} from "@util/banners";
import {Client, PlaceType2} from "@googlemaps/google-maps-services-js";
import { Flash } from '@templates/ErrorNotifaction';
import {
  Container,
  Row,
  Col,
  Text,
  Modal,
  List,
  ListItem,
  Flex,
} from "@components";
import {
  GigyaLogout,
  GigyaLogin,
  GigyaObject,
  GigyaRegister,
  checkRolledOut,
} from "@services/Gigya";
import {
  CustomProgressbar,
  Loader,
  AccountLinking,
  OptNotification,
  MaintainAlert
} from "@templates";
import Select from "@components/Select";
import { USER_AUTH, USER_ACCOUNT } from "../../redux/actions/authActions";
import { BANNER_LOCATION } from "../../redux/actions/counterActions";
import { BreakPoints } from "@util/units";
import { useOnClickOutside } from "@util/hooks/useOnOutsideClick";
import { accountHistory, getMemberDetail } from "@services/Mulesoft";
import Bus from "@util/Bus";
import en from "lang/en";
import fr from "lang/fr";
import { NavDropdown } from "@templates/NavDropdown";
import {addDataLayer} from "@util/helpers"
import { updateBannerRegion, pointsRequest, pointsResponse, setCustomAttribute } from "@services/NewRelic";
import { getCookie, removeCookies,setCookies } from "cookies-next";
import { FocusScope } from '@react-aria/focus';
import useWindowSize from '@util/hooks/useWindowSize';
interface pageData {
  headerData?: Record<any, any>;
  offerData?: Record<any, any>;
  host?: Record<any, any>;
}

/**
 * @function Header
 * To get the data from api and render header
 */
const HeaderData = React.forwardRef<
  HTMLDivElement,
  React.PropsWithChildren<pageData>
  >(({ children, ...props }, ref) => {
    /*** Google map client */
    const client = new Client({});
    const { width } = useWindowSize();
    const router = useRouter();
    const { locale } = router;
  const Auth = useSelector((state: RootStateOrAny) => state.auth);
  const userPrevilages = useSelector(
    (state: RootStateOrAny) => state.userAccess
  );

  const userAccount = useSelector((state: RootStateOrAny) => state.account);
  const bannerSelected = useSelector((state: RootStateOrAny) => state.banner);
  const [userLogin, setuserLogin] = React.useState(null);
  const [intializeUser, setIntializeUser] = React.useState(false);
  const [barCodeModal, setBarCodeModal] = React.useState(false);
  const { 0: popup2 } = props?.headerData?.acf_tru_modal;
  const menu = props?.headerData?.acf_tru_menu;
  const logo = props?.headerData?.acf_tru_image;
  const logoText = props?.headerData?.acf_tru_text?.[0]?.blockdata?.[0]?.ptext;
  const imagePopupSecond = popup2.blockdata[0]?.image_group[0];
  const [secondModal, setSecondModal] = React.useState(false);
  const [maintainModal, setMaintainModal] = React.useState(false);
  const [notification, setNotification] = React.useState(false);
  const [notificationMobile, setNotificationMobile] = React.useState(false);
  const [hideNotification, setHideNotification] = React.useState(false);
  const [op, setOp] = React.useState("");
  const [showNavBar, setShowNavbar] = React.useState(false);
  const [pointsCached, setPointsCached] = React.useState(null);
  const [locationLogo, setLocationLogo] = React.useState(null);
  const [bannerListRegion, setBannerListRegion] = React.useState(null);
  const [bannerRegionModal, setBannerRegionModal] = React.useState(false);
  const pointsBreakDownMin = userAccount?.value?.nextThreshold - 10;
  const pointsAverage =
    ((1000 - userAccount?.value?.pointsToNextThreshold) / 1000) * 100;
  const option: { id: string; name: string }[] =
    props?.headerData?.acf_tru_taxonomy[0]?.blockdata?.length > 0
      ? props?.headerData?.acf_tru_taxonomy[0]?.blockdata?.map((data) => {
        return { id: (data?.slug).replaceAll("-", ""), name: data?.name };
      })
      : [
        { id: "alberta", name: "Alberta" },
        { id: "britishcolumbia", name: "British Columbia" },
        { id: "manitoba", name: "Manitoba" },
        {
          id: "newfoundland and labrador",
          name: "Newfoundland and labrador",
        },
        { id: "newbrunswick", name: "New Brunswick" },
        { id: "novascotia", name: "Nova Scotia" },
        { id: "ontario", name: "Ontario" },
        { id: "princeedwardisland", name: "Prince edward island" },
        { id: "saskatchewan", name: "Saskatchewan" },
      ];
  const defaultRegion = (props?.host?.defaultRegion) ? props?.host?.defaultRegion : 'ontario';
  const t = locale === "en" ? en : fr;

  /***
   * Maintainance Popup and alerts data and settings
   */
   const maintainanceBar = props?.headerData?.acf_tru_information_banner?.[0]?.blockdata?.[0];
   const maintanancePopup = props?.headerData?.acf_tru_modal?.[1]?.blockdata?.[0];
   const maintananceAlert = props?.headerData?.acf_tru_footer?.[0]?.blockdata?.[0]?.tru_enable_maintainance_alert;
   const maintananceAlertPopup = props?.headerData?.acf_tru_footer?.[0]?.blockdata?.[0]?.tru_enable_maintainance_popup;
   /****
    * Check if the maintainance popup enable
    */
   React.useEffect(() => {
   if(maintananceAlertPopup === "1"){
     if(!getCookie('hide_maintein_modal')){
      setMaintainModal(true);
      setSecondModal(false);
     }
   
  }
   },[maintananceAlertPopup])
  /****
   * Handle the logo's on location change
   * @function locationChangeLogo
   * @param location type string
   */
  const locationChangeLogo = (location: string) => {
    let locationlogo =
      props?.headerData?.acf_tru_taxonomy[0]?.blockdata?.filter(
        (data) => (data?.slug).replaceAll("-", "") === location
      );
    setLocationLogo(locationlogo);
  }
  /*** On banner change in redux chnage the logo of headers */
  React.useEffect(() => {
    if (bannerSelected?.value) {
      locationChangeLogo(bannerSelected?.value);
      setOp(bannerSelected?.value);
      /*** Check region rolled out or not */
      //@ts-ignore
      const rolledOutRegion = (props?.host?.rolledOut.length > 0) ? props?.host?.rolledOut : gigya?.thisScript?.globalConf?.ELM_REGIONS;
      if (
        rolledOutRegion.indexOf(Regions[bannerSelected?.value]) === -1 &&
        rolledOutRegion != Regions[bannerSelected?.value]
      ) {
        /**** 
         * Hardcode liquor offers
         */
        if(props?.host?.showrolledpopup){
       
        setHideNotification(true);
        /*** Redirect to home page if offer page shows rolled out  */
        if(router.pathname === "/offers"){
          router.push("/");
        }
        else{
          setSecondModal(true);
        }
        }
      } else {
        setSecondModal(false);
        setHideNotification(false);
        setBannerListRegion(props?.host?.banners[Regions[bannerSelected?.value]]);
        if ((props?.host?.banners[Regions[bannerSelected?.value]]).length === 0) {
          onLocationChange(props?.host?.defaultRegion);
        }
      }
    }
  }, [bannerSelected?.value])
  /***
   * @function notificationRef
   * Disable notification bell click on outside
   */
  const notificationRef = React.useRef();
  const notificationRefMobile = React.useRef();
  const bellRef = React.createRef();
  useOnClickOutside(notificationRef, () => setNotification(false));
  useOnClickOutside(notificationRefMobile, () => setNotificationMobile(false));
  useOnClickOutside(bellRef, () => setNotification(false));

  /***
   * @function setPoints
   * Disable Point container click on outside
   * set active class if condition true
   */
  const [pointsWrapper, setPointsWrapper] = React.useState(false);
  const [pointsWrapperMobile, setPointsWrapperMobile] = React.useState(false);
  const pointsRef = React.useRef();
  const pointsRefMobile = React.useRef();

  useOnClickOutside(pointsRef, () => setPointsWrapper(false));
  useOnClickOutside(pointsRefMobile, () => {
    document.body.classList.remove('points-open');
   return setPointsWrapperMobile(false)
  
  });
  const pointsActive = pointsWrapper ? "active" : "";
  /****
   * @function onNavbarChange
   * On click navabar on mobile oprn drawer
   */

   const onNavbarChange = () => {
    setShowNavbar(true);
    setTimeout(() => {
      document.body.classList.toggle("open-nav");
    }, 500)
  };

  const onNavbarClose = () =>{
    document.body.classList.toggle("open-nav");
    setShowNavbar(false);
  }

  const onNavbarKeyDown = (e: React.KeyboardEvent<HTMLSpanElement>) => {
    if (e.key === 'Enter') { // key code of the keybord key
      document.querySelector("body").classList.remove("open-nav");
      setShowNavbar(true);
      console.log('enter')
    }
  }

const closeNavOnFocus =(event) => {
      if (event.key === 'Enter') { // key code of the keybord key
        event.preventDefault();
        document.querySelector("body").classList.remove("open-nav");
        setShowNavbar(false);
      }
}

  /****
   * @function showNotification
   * open notifaction on click
   */
  const showNotification = () => {
    setNotification(!notification);
  };
/****
   * @function showNotificationMobile
   * open notifaction on click
   */
 const showNotificationMobile = () => {
  setNotificationMobile(!notificationMobile);
};
  /***
   * @function dispatch
   * to use the redux
   */
  const dispatch = useDispatch();

  /****
   * @constant ServicesList
   * To define the logged in user menu
   */

  const ServicesList: { id: string; arialabel: string;  datagmt: string; buttonid:string; Services: string; PageLink: string }[] = [
    { id: "1", arialabel: "My Profile", datagmt:"my_profile", buttonid:"my-profile", Services: "My Profile", PageLink: "/my-profile" },
    { id: "3", arialabel: "Sign Out", datagmt:"sign_out", buttonid:"sign_out", Services: "Sign Out", PageLink: "" },
  ];
  const ServicesListCard: { id: string; arialabel: string;  datagmt: string; buttonid:string; Services: string; PageLink: string }[] = [
    { id: "1", arialabel: "My Profile", datagmt:"my_profile", buttonid:"my-profile", Services: "My Profile", PageLink: "/my-profile" },
    { id: "2", arialabel: "Loyalty Card", datagmt:"loyalty_card", buttonid:"loyalty_card", Services: "Loyalty Card", PageLink: "" },
    { id: "3", arialabel: "Sign Out", datagmt:"sign_out", buttonid:"sign_out", Services: "Sign Out", PageLink: "" },
  ];

  /***
   * @function handleLogin
   * @param region
   * TO handle the login if hash exists in the url
   */
  const handleLogin = async (e) => {
    e.preventDefault();
    const queryParams = new URLSearchParams(location.search);
    let gl = '';
    if(e?.target?.href.indexOf('_gl=') !== -1){
    const glLink = e?.target?.href?.substring(e?.target?.href?.indexOf('_gl=')+1);
    if(glLink){
      gl = glLink.replace("gl=","");
    }
     }
    if (queryParams.has("hash")) {
      queryParams.delete("hash");
      await router.replace(router.pathname);
      GigyaLogin({ value: op,langauge:locale,gl:gl });
    } else {
      GigyaLogin({ value: op,langauge:locale,gl:gl });
    }
    // return false;
  };

  /***
   * @function handleRegister
   * @param region
   * TO handle the login if hash exists in the url
   */

  const handleRegister = async (e) => {
    e.preventDefault();
    const queryParams = new URLSearchParams(location.search);
    let gl = '';
    if(e?.target?.href.indexOf('_gl=') !== -1){
    const glLink = e?.target?.href?.substring(e?.target?.href?.indexOf('_gl=')+1);
    if(glLink){
      gl = glLink.replace("gl=","");
    }
  }
    if (queryParams.has("hash")) {
      queryParams.delete("hash");
      await router.replace(router.pathname);
      GigyaRegister({ value: op,langauge:locale,gl:gl });
    } else {
      GigyaRegister({ value: op,langauge:locale,gl:gl });
    }
  };





  /****
   * @constant LanguageSwitcher
   * To define the languages coming from the api
   */
    const LanguageSwitcher = [{
    "name":"en"
    },
      {
      "name":"fr"
    }];
  React.useEffect(() => {

    const elem = document.getElementById("mobileMenuRight") as HTMLInputElement;

    elem.addEventListener("keypress", (event)=> {
        if (event.key === 'Enter') { // key code of the keybord key
          event.preventDefault();
          document.querySelector("body").classList.add("open-nav");
        }
      });

    /****  Remove class from body *****/
    document.querySelector("body").classList.remove("open-nav");
    setPointsCached(localStorage?.getItem("points_cached"));
    const timer = setTimeout(() => {
      /****
       * @function getLocationInfo
       * To get the locatiomn data from the api based on lat and lng
       * @param lat
       * @param lng
       */
      const getLocationInfo = async ({ lat, lng }) => {
        let banner = localStorage.getItem("banner");
        try {
          const latlng = {
            lat: parseFloat(lat),
            lng: parseFloat(lng),
          };
          try{
          //@ts-ignore
          var geocoder= new google.maps.Geocoder();
          geocoder.geocode( { 'location': latlng}, function(results, status) {
            if (status == 'OK') {
            results?.[0]?.address_components.forEach((data) => {
              if((data.types).includes('administrative_area_level_1')){
                let porvience_to_add = RegionsNames.includes(((data?.long_name)?.replaceAll(" ",""))?.toLowerCase())
            ? ((data?.long_name)?.replaceAll(" ",""))?.toLowerCase()
            : defaultRegion;
              onLocationChange(porvience_to_add);
              locationChangeLogo(porvience_to_add);
              localStorage.setItem("banner", JSON.stringify(porvience_to_add));
               return true;
              }
            })
            } else {
             console.log("error fetching user location");
            }
          });
        }
        catch (Exception){
          console.log(Exception);
        }
          return true;
        }
        catch(e){
        console.log(e,"loaction error")
        }
      
      };

      /****
       * @function getLocation
       * To ask the user to provide location access from browser
       */
      const getLocation = () => {
        if (!navigator.geolocation) {
        } else {
          navigator.geolocation.getCurrentPosition(
            (position) => {
              // if(!getCookie('manually_region_changed')){
              getLocationInfo({
                lat: position.coords.latitude,
                lng: position.coords.longitude,
              });
            // }
            },
            (err) => { 
              if(localStorage.getItem("banner") != undefined)
              {
              //onLocationChange(JSON.parse(localStorage.getItem("banner")));
              } 
              console.log('error geolocation',err)}
          );
        }
      };
      if (props?.host?.renderFrom !== 'IGAOffers' && !router?.query?.region) {
        if(!localStorage.getItem("banner") || localStorage.getItem("banner") == undefined ){
          getLocation();
        }
        
      }
      else if(router?.query?.region && defaultStores[(router?.query?.region as string)?.toLocaleLowerCase()] != undefined){
        onLocationChange(defaultStores[(router?.query?.region as string)?.toLocaleLowerCase()]);
      }
      else{
     
      }


      /*** get value from local storage */
      let banner_provience = JSON.parse(localStorage.getItem("banner"));
      if (banner_provience && GigyaObject != undefined) {
        setOp(banner_provience);
        onLocationChange(banner_provience);
        locationChangeLogo(banner_provience);
      } else {
        localStorage.setItem("banner", JSON.stringify(defaultRegion));
        dispatch({
          type: BANNER_LOCATION,
          payload: {
            location: defaultRegion,
          },
        });
      }

      /*** Get account response  */
      const getAccountInfoResponse = (response) => {
        if (response.status === "OK") {
          /****
           * Check for the optin banner show or not
           */
          
        /*** 
         * End for check the optin banner
         */
          setIntializeUser(true);
          setuserLogin(response?.profile); 
          if(getCookie('personOffersUniqueId') == undefined && response?.data?.scene?.cardNumber) {
            getMemberDetail(response?.data?.scene?.cardNumber, false);
          }
          //@ts-ignore
          dataLayer.push({
            event: "gigyaUID",
            gigyaID: response?.UID})
          setCustomAttribute(Auth?.value?.guid)
          dispatch({
            type: USER_AUTH,
            payload: {
              /**** Lp card number not coming from response so added empty here or can be changed from url */
              user: {
                guid: response?.UID,
                lpCardNumber:response?.data?.scene?.cardNumber,
                lpLinkedStatus: response?.data?.scene?.linkedStatus,
                enrollementStatusGigya: response?.data?.scene?.enrollmentStatus,
                ...response?.profile,
                subscriptions:response.subscriptions
              },
            },
          });
        } else {
          removeCookies(`personOffersUniqueId`, { path: '/', domain: `${process.env.NEXT_PUBLIC_COOKIE_DOMAIN}` });
          setIntializeUser(true);
          //@ts-ignore
          dataLayer.push({
            event: "gigyaUID",
            gigyaID: ""})
        }
      };
      if (GigyaObject != undefined) {
        GigyaObject.accounts.getAccountInfo({
          callback: getAccountInfoResponse,
        });
      }
    }, 300);
    return () => clearTimeout(timer);
  }, [router?.query?.region]);

  /****
   * To get the user points for the card
   */
  React.useEffect(() => {
    if (userPrevilages?.value?.card) {
      pointsRequest(getCookie("personOffersUniqueId"), "success");  // initiated newRelic pointsRequest event
      accountHistory(Auth?.value?.guid, "Global", true).then((data) => {
        if (!data?.error) {
          pointsResponse(getCookie("personOffersUniqueId"), "success", data.pointBalance);   // initiated newRelic pointsResponse event
          dispatch({
            type: USER_ACCOUNT,
            payload: {
              ...data,
            },
          });
        } else{
          pointsResponse(getCookie("personOffersUniqueId"), data?.error?.code);   // initiated newRelic pointsResponse event
        }
      });
    }
  }, [userPrevilages?.value?.card, Auth?.value?.guid]);

  /****
   * To handle the event emitter incase notification not need to show
   */
  React.useEffect(()=> {
    Bus.once('hideNotification', ({type}) => {
      setHideNotification(true);
      Bus.removeAllListeners;
    });
    Bus.once('showNotification', ({type}) => {
      setHideNotification(false);
      Bus.removeAllListeners;
    });
    
  },[])
  /****
   * @function handleOnLogout
   * On user logout redirect to home page
   */
  const handleOnLogout = () => {
    removeCookies(`personOffersUniqueId`, { path: '/', domain: `${process.env.NEXT_PUBLIC_COOKIE_DOMAIN}` });
    setuserLogin(null);
    dispatch({
      type: USER_AUTH,
      payload: {
        user: [],
      },
    });
    /***
     * Added logout data layer
     */
    //@ts-ignore
    dataLayer.push({
      event: "gigyaUID",
      gigyaID: ""});
    Bus.emit('hideflash', ({ type:"suspended" }));
    Bus.emit('hideOpt', ({ type:"hideopt" }));
    Router.push("/");
  };
/***
 * change location manually
 */
const onLocationManualyChnage = (e:string) => {
  //setCookies("manually_region_changed", 1, { path: '/', domain: `${process.env.NEXT_PUBLIC_COOKIE_DOMAIN}`, sameSite: true });
  onLocationChange(e);
  return true;
}
  /****
   * @function onLocationChange
   * On location change set the banner value
   */
  const onLocationChange = (e: string) => {
    setOp(e);
    locationChangeLogo(e);
    updateBannerRegion(getCookie("personOffersUniqueId"), "success", JSON.stringify(e));   //initiated newRelic updateBannerRegion event
    localStorage.setItem("banner", JSON.stringify(e));
    dispatch({
      type: BANNER_LOCATION,
      payload: {
        location: e,
      },
    });
  };

  /****
   * @function handleProfileClick
   * to take the user to profile page
   */
  const handleProfileClick = (link) => {
    Router.push(link);
  };

  /****
   * @function handleLoyalityClick
   * to show the loyalty card popup
   */
  const handleLoyalityClick = () => {
    addDataLayer({event:"loyalty_card",event_param:Auth?.value?.lpCardNumber});
    setBarCodeModal(true);
  };

  const handleNotificationClick = () => {
    
    if (userPrevilages?.value?.ghost) {
      Bus.emit('notificationClick', ({ type:"ghostCard" }));
    } else {
      Bus.emit('notificationClick', ({ type:"verifyCard" }));
    }
  };
  const handleAddCardClick = () => {
    Bus.emit('notificationClick', ({ type:"addCard" }));
    };
    /***
     * @function changeLanguage
     */
    const changeLanguage = (e) => {
      const locale = e;
      router.push(router.pathname, router.asPath, { locale });
    };
    useEffect(() => {
      const listener = event => {
        if (event.code === "Tab") {
          document.querySelectorAll('a[href], button, a, input, .SelectBoxText, .pointContainer, textarea, MassOffersBoxButton a').forEach(item => {    
              item.classList.add('tab');   
              document.addEventListener("click", function(){
                  item.classList.remove('tab');    
              })          
           })
        }
      };       
      document.addEventListener("keydown", listener);        
      return () => {
        document.removeEventListener("keydown", listener);
      };
  }, []);

  /***
   * @function handleMaintainClick
   * To set the cookie for session if the maintainance popup visible
   */
  const handleMaintainClick = () => {
    setCookies("hide_maintein_modal", 1, { path: '/', domain: `${process.env.NEXT_PUBLIC_COOKIE_DOMAIN}`, sameSite: true });
    setMaintainModal(false);
  }
  const curLang = router?.locale;

  return (
    <>
      <Text as="header" className="Header" aria-label="header" role="banner">
        <MaintainAlert headline={maintainanceBar} enableAlert={maintananceAlert}/>
        <Text as="div" className="Header-Top-Bar">
          <Text as="div" className="ErrorNotificationOuter">
          <Flash />
          </Text>
          <Container size="fluid" style={{ width: 1765 }}>
            <Row>
              <Col xs={6} sm={6} className="TopBar-left">
                <Text as="div" className="TopBar">
                  <Text as="div" className="NavSelect">
                    <img
                      src="/icons/location-icon.svg"
                      width="17px"
                      height="20px"
                      alt="icon location"
                    />
                    <span style={{}} className="d-none-xs">
                      {" "}
                      {t.yourRegion}:
                    </span>
                    <Select
                      tabIndex={0}
                      placeholder={(props?.host?.defaultRegion) ? props?.host?.defaultRegion : 'Ontario'}
                      options={option}
                      selected={op ? op : defaultRegion}
                      className={"selectRetailer"}
                      style={{ color: "#aaaaaa", textTransform: "capitalize" }}
                      onChange={(e) => onLocationManualyChnage(e)}
                      classes={{ root:"selectroot",selectInput:"inputSelect", selectContainerWrapper:"selectContainerWrapper",selectText:"SelectBoxText", selectIcon:"SelectBoxIcon",selectOptions:"SelectDropdownContainer",selectList:"SelectDropdownUl",selectListItem:"selectListItem", selectActiveItem:"selectActiveItem"}}
                    />
                  </Text>
                </Text>
              </Col>
              <Col xs={6} sm={6} className="TopBar-right">
                <Text as="div" className="topbarlang">
              <Text as="ul">
                   {LanguageSwitcher &&
                        LanguageSwitcher.map((data, index) => {
                          return (
                            <Text as="li" key={`mobile_lang_switcher${index}`}>
                           
                              <a tabIndex={0} className={data.name === locale ? `active` : ``} onClick={() => changeLanguage(data.name) }>
                                {data.name}
                              </a>
                          
                              </Text>
                          );
                        })}
                    </Text>
                </Text>
                {intializeUser && (
                  <>
                    {userLogin && (
                      <>
                        {userAccount?.value &&
                          !userAccount?.value?.error &&
                          userPrevilages?.value?.points && (
                            <>
                            <Text
                              as="div"
                            className="showOnMobile dropdown mobilePoints"
                            ref={pointsRefMobile}
                            >
                              <Text as="div" className="PopupProgress" >
                                <Text
                                tabIndex={0}
                                  as="div"
                                  className={`pointContainer ${(pointsWrapperMobile)?'active':''}`}
                                  onClick={() => {
                                    setPointsWrapperMobile(!pointsWrapperMobile)
                                    document.body.classList.toggle('points-open');
                                  }
                                  }
                                >
                                  <img
                                    className="logo-symbol"
                                    src="/points-dot-top-menu.svg"
                                    alt="points"
                                  />
                                  <Text
                                    as="div"
                                    colorScheme="accent"
                                    className="price"
                                  >
                                    ${userAccount?.value?.dollarValue}{" "}
                                  </Text>
                                  <Text
                                    as="div"
                                    colorScheme="accent"
                                    className="points"
                                  >
                                    {(userAccount?.value?.pointBalance).toLocaleString()}
                                    {" "}PTS
                                  </Text>
                                </Text>
                                {pointsWrapperMobile && (
                                  <>
                                 
                                  <Text
                                    as="div"

                                    className="dropdownPopup"
                                  >
                                    <Text as="h4">
                                      {t.sanpNext}
                                    </Text>
                                    {userAccount?.value
                                      ?.pointsToNextThreshold && (
                                        <Text as="p" colorScheme="accent">
                                          {t.youAre}{" "}
                                          {(userAccount?.value?.pointsToNextThreshold).toLocaleString()}
                                          {" "}{t.pts} {t.away_from} $
                                          {userAccount?.value?.nextThreshold}{" "}
                                        </Text>
                                      )}
                                    {props?.headerData?.acf_tru_button?.length >
                                      0 &&
                                      props?.headerData?.acf_tru_button[0]
                                        ?.blockdata[0] && (
                                        <Link
                                          href={
                                            props?.headerData
                                                    ?.acf_tru_button[0]
                                                    ?.blockdata[0]?.link?.url
                                          }
                                        >
                                          <a
                                            target={
                                              props?.headerData
                                                ?.acf_tru_button[0]
                                                ?.blockdata[0]?.link?.target
                                            }
                                            className="simple-link"
                                          >
                                            {
                                              props?.headerData
                                                ?.acf_tru_button[0]
                                                ?.blockdata[0]?.link?.title
                                            }
                                          </a>
                                        </Link>
                                      )}
                                    <CustomProgressbar
                                      className="small"
                                      points={`${userAccount?.value?.pointBalance
                                          ? userAccount?.value?.pointBalance
                                          : ""
                                        }`}
                                      currentPoints={
                                        userAccount?.value?.pointBalance
                                          ? userAccount?.value?.pointBalance
                                          : 0
                                      }
                                      minValue={`${Number.isNaN(
                                        userAccount?.value?.dollarValue
                                      )
                                          ? 0
                                          : userAccount?.value?.dollarValue
                                        }`}
                                      midValue={`${Number.isNaN(
                                        userAccount?.value?.nextThreshold
                                      )
                                          ? 0
                                          : userAccount?.value?.nextThreshold
                                        }`}
                                      maxValue={`${Number.isNaN(
                                        userAccount?.value?.nextThreshold
                                      )
                                          ? 0
                                          : userAccount?.value?.nextThreshold +
                                          10
                                        }`}
                                      barValue={
                                        pointsAverage > 0 ? pointsAverage : 10
                                      }
                                      cachedPoints={pointsCached}
                                      showAnimation={false}
                                    />
                                  </Text>
                                 </>  
                                )}
                              </Text>
                            </Text>
                            {pointsWrapperMobile && <Text as="div" className="dropdownPopupOverlay"> </Text>}
                            
</>
                          )}
                      </>
                    )}
                  </>
                )}
              </Col>
            </Row>
          </Container>
        </Text>

        <Text as="div" className="NavigationBar">
          <Container size="fluid" style={{ width: 1730 }}>
            <Row className="NavigationBarRow">
              <Text
                className="NavigationBarLeft"
                style={{ alignItems: "center", display: "flex" }}
              >
                <Text as="div" className="Basketlogo">
                  {logo[0].blockdata[0]?.image && (
                    <Link href="/">
                      <a className="logo" aria-label="Home Mobile Heading" tabIndex={0} id={`main-logo`}>
                        <Image
                          src={logo[0].blockdata[0].image.src}
                          alt={logo[0].blockdata[0].image.alt}
                          width={logo[0].blockdata[0].image.dimensions?.width}
                          height={logo[0].blockdata[0].image.dimensions?.height}
                          text-align="left"
                          className="Scene My offer logo"
                        />
                      </a>
                    </Link>
                  )}
                </Text>
                <Text as="div" className="MyGroceryOffersLogo">
                  <Text as="div" className="logo">
                    <Link href="/">
                      <a tabIndex={0} id={`main-logo-text`}>
                        <h2>{logoText}</h2>
                      </a>
                    </Link>
                  </Text>
                  <Text as="div" className="LogosBrandNames">
                    <ul>
                      {!locationLogo ? (
                        <></>
                      ) : (
                        <>
                          {locationLogo[0]?.header_image?.map((data,index) => (
                              <li key={`logo_header_index_${index}`}>
                              {data?.logo_url ?(<Link href={data?.logo_url}>
                                <a target={data?.logo_link_target} aria-label={data?.logo_aria_label} id={`logo_${index}`}>
                              <Image
                                src={data?.url}
                                alt={data?.alt}
                                width={data?.width}
                                height={data?.height}
                              ></Image>
                              </a>
                              </Link>):(
                                <span aria-label="Scene Logo">
                                <Image
                                  src={data?.url}
                                  alt={data?.alt}
                                  width={data?.width}
                                  height={data?.height}
                                ></Image>
                              </span>
                              ) }
                            </li>
                          ))}
                        </>
                      )}
                    </ul>
                  </Text>
                </Text>
              </Text>
              <Text className="NavigationBarRight">
                <Flex
                  justifyContent="flex-end"
                  style={{
                    display: "flex",
                    alignContent: "end",
                    [`@media ${BreakPoints.tablet}`]: {
                      display: "none",
                    },
                  }}
                  className="mobileMenuRight"
                >
                  {userLogin && !hideNotification &&
                    userPrevilages?.value != undefined &&
                    Auth?.value?.lpCardNumber &&
                    Auth?.value?.lpLinkedStatus != true &&
                    (Auth?.value?.enrollementStatusGigya == "LP01" ||
                      Auth?.value?.enrollementStatusGigya == undefined) &&
                    !userPrevilages?.value?.closed &&
                    Auth?.value?.enrollementStatusGigya != "LP00" && (
                      <div
                      ref={notificationRefMobile}
                        className="NotifactionBell"
                        onClick={() => setNotificationMobile(!notificationMobile)}
                      >
                        <img
                          src="/icons/notif.svg"
                          alt="Notifaction Bell Icon"
                          width="17px"
                          height="20px"
                        />
                        <span>1</span>
                        {notificationMobile && (
                          <div className="NotificationTooltip">
                            <h6>{t.notificationLabel}</h6>
                            <p>
                              {userPrevilages?.value?.ghost
                                ? `${t.registerText}`
                                : `${t.verifyText}`}{" "}
                              {t.verifyNotificationText}{" "}
                              <a  onClick={handleNotificationClick}>
                              {t.notificationButtonText}
                              </a>
                            </p>
                          </div>
                        )}
                      </div>
                    )}
                  {/***
                   * Add card popup notification
                   */}

                  {userLogin && !hideNotification && !Auth?.value?.lpCardNumber && (
                    <div
                     ref={notificationRefMobile}
                      className="NotifactionBell"
                      onClick={showNotificationMobile}
                    >
                      <img src="/icons/notif.svg" alt="Notifaction Bell Icon" width="17px" height="20px" />
                      <span>1</span>
                      {notificationMobile && (
                        <div className="NotificationTooltip">
                          <h6>{t.notificationLabel}</h6>
                          <p>
                            {t.notificationAddCard}{" "}
                            <a  onClick={handleAddCardClick}>{t.notificationButtonText}</a>
                          </p>
                        </div>
                      )}
                    </div>
                  )}
                  <span 
                    onClick={onNavbarChange} 
                    tabIndex={0} 
                    role="button" 
                    onKeyDown={(e) => onNavbarKeyDown(e)}
                    id="mobileMenuRight"
                    aria-label="Click here to open mobile menu"
                  >
                    <Menu color="#000" />
                  </span>
                </Flex>
                {width > 991 && <Flex
                  justifyContent="flex-start"
                  className="MenuSlide"
                  style={{
                    // display: showNavBar ? "flex" : "flex",
                    [`@media ${BreakPoints.tablet}`]: {
                      display: "flex",
                      justifyContent: "flex-end",
                    },
                  }}
                >
                  <Text className="Menus">
                    <Text className="MenuHeader">
                      <Text as="div" className="Basketlogo">
                        {logo?.[0]?.blockdata?.[0]?.image && (
                          <Link href="/">
                            <a className="logo">
                              <Image
                                src={logo?.[0]?.blockdata?.[0]?.image.src}
                                alt={logo?.[0]?.blockdata?.[0]?.image.alt}
                                width={
                                  logo?.[0]?.blockdata?.[0]?.image?.dimensions?.width
                                }
                                height={
                                  logo?.[0]?.blockdata?.[0]?.image?.dimensions?.height
                                }
                                text-align="left"
                              />
                            </a>
                          </Link>
                        )}
                      </Text>
                      <Text as="div" className="MyGroceryOffersLogo">
                        <Text as="div" className="logo">
                          <Link href="/">
                            <a aria-label="Logo Heading">
                              <h2>{props?.headerData?.acf_tru_text[0]?.blockdata[0]?.ptext}</h2>
                            </a>  
                          </Link>
                        </Text>
                        <Text as="div" className="LogosBrandNames">
                          <ul>
                            {!locationLogo ? (
                              <></>
                            ) : (
                              <>
                                {locationLogo[0]?.header_image?.map((data,index) => (
                                  <li key={`logo_header_desk_${index}`}>
                                    {data?.logo_url ?(<Link href={data?.logo_url}>
                                      <a target={data?.logo_link_target}>
                                    <Image
                                      src={data?.url}
                                      alt={data?.alt}
                                      width={data?.width}
                                      height={data?.height}
                                    ></Image>
                                    </a>
                                    </Link>):(
                                    <span aria-label="Scene Logo Mobile">
                                    <Image
                                      src={data?.url}
                                      alt={data?.alt}
                                      width={data?.width}
                                      height={data?.height}
                                    ></Image>
                                    </span>
                                    ) }
                                  </li>
                                ))}
                              </>
                            )}
                          </ul>
                        </Text>
                      </Text>

                      <img src="/close-icon.svg" alt="Close Menu" className="close-menu" tabIndex={0} onClick={onNavbarClose} onKeyDown={closeNavOnFocus}/>
                    </Text>

                    {intializeUser ? (
                      <>
                        {userLogin ? (
                          
                         
                          <ul className={`userLoginList showOnMobile`}>
                            <li key={`navigation_drop_1`}>
                              <div className="UserProfile">
                                <div className="UserProfileInner" tabIndex={0}>
                                <svg width="17" height="20" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                  <path fill-rule="evenodd" clip-rule="evenodd" d="M10.7609 11.7398C12.7859 11.7316 14.7432 12.4679 16.2607 13.8087C17.7781 15.1495 18.7499 17.0013 18.991 19.0118C19.0148 19.2573 19.1295 19.485 19.3127 19.6501C19.4959 19.8152 19.7344 19.9057 19.981 19.9038C20.1202 19.9057 20.2582 19.8783 20.3861 19.8233C20.5139 19.7682 20.6289 19.6869 20.7232 19.5845C20.8176 19.4822 20.8892 19.3611 20.9337 19.2292C20.9781 19.0972 20.9943 18.9574 20.981 18.8188C20.7694 16.9591 20.0486 15.1939 18.8983 13.7175C17.7479 12.2411 16.2125 11.1107 14.461 10.4508C15.1203 9.93335 15.6593 9.27888 16.0408 8.53266C16.4224 7.78644 16.6374 6.96627 16.671 6.12883C16.7011 4.55875 16.1062 3.04101 15.0173 1.90951C13.9284 0.778012 12.4345 0.125428 10.8645 0.0953262C10.087 0.0804212 9.31436 0.218793 8.59041 0.50253C7.86646 0.786267 7.20548 1.20981 6.64522 1.749C5.51372 2.83793 4.86111 4.33175 4.83101 5.90183C4.83287 6.77889 5.03364 7.64411 5.41817 8.43239C5.80269 9.22066 6.36093 9.91147 7.05098 10.4528C5.3004 11.1141 3.76583 12.2449 2.61568 13.7211C1.46552 15.1972 0.744209 16.9617 0.53096 18.8208C0.519162 18.9591 0.536309 19.0984 0.581253 19.2297C0.626198 19.361 0.698007 19.4815 0.792069 19.5836C0.88613 19.6856 1.00042 19.767 1.12764 19.8225C1.25486 19.8779 1.39217 19.9063 1.53096 19.9058C1.77848 19.9073 2.01775 19.8169 2.20247 19.6521C2.38719 19.4873 2.50423 19.2599 2.53096 19.0138C2.76994 17.0022 3.741 15.1489 5.25887 13.8074C6.77674 12.4658 8.73521 11.7299 10.7609 11.7398ZM6.84102 5.90183C6.83011 5.12548 7.05031 4.36341 7.47359 3.71251C7.89687 3.06161 8.50404 2.55127 9.21809 2.24636C9.93214 1.94145 10.7207 1.85574 11.4836 2.00013C12.2465 2.14451 12.9493 2.51247 13.5025 3.05724C14.0558 3.60201 14.4345 4.29897 14.5907 5.05954C14.7468 5.8201 14.6732 6.60992 14.3793 7.32859C14.0855 8.04726 13.5846 8.66232 12.9403 9.09559C12.296 9.52885 11.5374 9.76076 10.7609 9.76183C9.73003 9.76717 8.73904 9.36411 8.00447 8.64078C7.2699 7.91745 6.85158 6.9327 6.84102 5.90183Z" fill="currentColor"/>
                                </svg>
                                  <span className="userTitle">
                                    {Auth?.value?.firstName}
                                  </span>
                                </div>
                                <ul className="submenu ">
                                  {((userPrevilages?.value?.card && userAccount?.value?.digitalBarCode)?ServicesListCard:ServicesList).map((item, index) => {
                                    return item.id === "3" ? (
                                      <li
                                        key={`service_${index}`}
                                        onClick={
                                          item.id === "3" &&
                                          (() => GigyaLogout(handleOnLogout))
                                        }
                                      >
                                        {" "}
                                        <Link href="">{t[item.Services]}</Link>
                                      </li>
                                    ) : (
                                      <>
                                        {item.id == "1" && (
                                          <li
                                            key={`service_${index}`}
                                            onClick={() =>
                                              item.id != "2"
                                                ? handleProfileClick(
                                                  item?.PageLink
                                                )
                                                : userPrevilages?.value?.card
                                                  ? handleLoyalityClick()
                                                  : console.log("here")
                                            }
                                          >
                                            <Link href="">{t[item.Services]}</Link>
                                          </li>
                                        )}
                                        {item.id == "2" &&
                                          userPrevilages?.value?.card &&
                                          !userAccount?.value?.error &&
                                          Auth?.value?.guid &&
                                          userAccount?.value && (
                                            <li
                                              key={`service_${index}`}
                                              onClick={() =>
                                                item.id != "2"
                                                  ? handleProfileClick(
                                                    item?.PageLink
                                                  )
                                                  : userPrevilages?.value?.card
                                                    ? handleLoyalityClick()
                                                    : console.log("here")
                                              }
                                            >
                                              <Link href="">
                                                {t[item.Services]}
                                              </Link>
                                            </li>

                                          )}
                                      </>
                                    );
                                  })}
                                </ul>
                              </div>
                            </li>
                            
                          </ul>
                            
                        ):(
                        <>
                         <ul className={`userLoginList showOnMobile`}>
                          <li
                            className="menuButton btnSign"
                            key={`navigation_drop_login`}
                          >
                             <Link  href={`${process.env.NEXT_PUBLIC_ACCOUNT_LOGIN}`}>
                                    <a  aria-label="Sign In"
                              data-gtm="signin_header" id="signin_header_mobile" className="themeBtn outline" onClick={(e) => handleLogin(e)}>
                            {/* <button
                              className="themeBtn outline"
                              aria-label="Sign In"
                              data-gtm="signin_header"
                              id="signin_header"
                              onClick={(e) => handleLogin({ region: op,e })}
                            > */}
                              {menu[1].blockdata[0]?.label}
                            {/* </button> */}
                            </a>
                            </Link>
                          </li>
                          <li
                            className="menuButton"
                            key={`navigation_drop_register`}
                          >
                            <Link href={`${process?.env?.NEXT_PUBLIC_ACCOUNT_REGISTER}`}>
                            <a   id="register_header_mobile" aria-label="Register Header"
                              data-gtm="register_header" className="themeBtn" onClick={(e) => handleRegister(e)}>
                            {/* <button
                              className="themeBtn"
                              aria-label="Register Header"
                              data-gtm="register_header"
                              id="register_header"
                              onClick={(e) => handleRegister(e)}
                            > */}
                              {menu[1].blockdata[1]?.label}
                            {/* </button> */}
                            </a>
                            </Link>
                          </li>
                          </ul>
                        </>)}
                      </>
                    ) : (
                      <ul className="showOnMobile">
                        {" "}
                        <li key={`navigation_drop_loader`}>
                          <div className="loader">
                            <Image
                              alt="loader"
                              src="/icons/loader-white.svg"
                              width={20}
                              height={20}
                            />
                          </div>
                        </li>
                      </ul>
                    )}
                      {menu[0].blockdata.length > 0 && (
                        <ul className="globalList">
                          {menu[0].blockdata.map((item, index) => {
                            return (
                              <li key={`menu_li_${index}`}>
                                <Link href={item.url}>
                                  <a
                                    className={
                                      router.pathname ===
                                        (item?.url != "/" && item?.url.endsWith("/")
                                          ? item?.url.slice(0, -1)
                                          : item?.url)
                                        ? "active"
                                        : ""
                                    }
                                  >
                                    {item?.label}
                                  </a>
                                </Link>
                              </li>
                            );
                          })}
                        </ul>
                      )}
                    <ul className="loginList ">
                      {intializeUser ? (
                        <>
                          {userLogin ? (
                            <>
                              {userAccount?.value &&
                                !userAccount?.value?.error &&
                                userPrevilages?.value?.points && (
                                  <li
                                    className="hideOnMobile dropdown"
                                    key={`navigation_drop_points`}
                                  >
                                    <Text as="div" className={`PopupProgress pointsContainerFocus ${pointsWrapper ? `show` : `hide`}`} ref={pointsRef}> 
                                      <Text
                                        as="div"
                                        tabIndex={0}
                                        className={`pointContainer ${pointsActive}`}
                                        onClick={() => { setPointsWrapper(!pointsWrapper)}}
                                        onKeyPress={() => { setPointsWrapper(true)}}
                                      >
                                        <img
                                          className="logo-symbol"
                                          src="/points-dot-top-menu.svg"
                                          alt="points"
                                        />
                                        <Text
                                          as="div"
                                          colorScheme="accent"
                                          className="price"
                                        >
                                          ${userAccount?.value?.dollarValue}{" "}
                                        </Text>
                                        <Text
                                          as="div"
                                          colorScheme="accent"
                                          className="points"
                                        >
                                          {(userAccount?.value?.pointBalance).toLocaleString()}
                                          {" "}PTS
                                        </Text>
                                      </Text>
                                      <Text
                                          as="div"
                                          className="dropdownPopup showFocusDropdown"
                                        >
                                          <Text as="h4">
                                          {t.sanpNext}
                                          </Text>
                                          {userAccount?.value
                                            ?.pointsToNextThreshold && (
                                              <Text as="p" colorScheme="accent">
                                                 {t.youAre}{" "}
                                                {(userAccount?.value?.pointsToNextThreshold).toLocaleString()}
                                                {" "}{t.pts} {t.away_from} $ 
                                                {
                                                  userAccount?.value
                                                    ?.nextThreshold
                                                }{" "}
                                              </Text>
                                            )}
                                          {props?.headerData?.acf_tru_button
                                            ?.length > 0 &&
                                            props?.headerData?.acf_tru_button[0]
                                              ?.blockdata[0] && (
                                              <Link
                                                href={
                                                  props?.headerData
                                                  ?.acf_tru_button[0]
                                                  ?.blockdata[0]?.link?.url
                                                }
                                              >
                                                
                                                <a
                                                  target={
                                                    props?.headerData
                                                      ?.acf_tru_button[0]
                                                      ?.blockdata[0]?.link
                                                      ?.target
                                                  }
                                                  className="simple-link"
                                                >
                                                  {
                                                    props?.headerData
                                                      ?.acf_tru_button[0]
                                                      ?.blockdata[0]?.label
                                                  }
                                                </a>
                                              </Link>
                                            )}
                                          <CustomProgressbar
                                            className="small"
                                            points={`${userAccount?.value?.pointBalance
                                                ? userAccount?.value
                                                  ?.pointBalance
                                                : ""
                                              }`}
                                            currentPoints={
                                              userAccount?.value?.pointBalance
                                                ? userAccount?.value
                                                  ?.pointBalance
                                                : 0
                                            }
                                            minValue={`${Number.isNaN(
                                              userAccount?.value?.dollarValue
                                            )
                                                ? 0
                                                : userAccount?.value
                                                  ?.dollarValue
                                              }`}
                                            midValue={`${Number.isNaN(
                                              userAccount?.value
                                                ?.nextThreshold
                                            )
                                                ? 0
                                                : userAccount?.value
                                                  ?.nextThreshold
                                              }`}
                                            maxValue={`${Number.isNaN(
                                              userAccount?.value
                                                ?.nextThreshold
                                            )
                                                ? 0
                                                : userAccount?.value
                                                  ?.nextThreshold + 10
                                              }`}
                                            barValue={
                                              pointsAverage > 0
                                                ? pointsAverage
                                                : 10
                                            }
                                            cachedPoints={pointsCached}
                                            showAnimation={false}
                                          />
                                        </Text>
                                    </Text>
                                  </li>
                                )}
                              <li key={`navigation_drop_profile`}>
                              <NavDropdown id="user-dropdown" title={Auth?.value?.firstName}>
                              {((userPrevilages?.value?.card && userAccount?.value?.digitalBarCode)?ServicesListCard:ServicesList).map((item) => (
                                
                                      <List
                                       
                                        key={item.id}
                                        className="btn-list-item"
                                      >
                                        {item.id === "3" ? (
                                          <ListItem id="" as="span">
                                            <a
                                            role="button"
                                            href={void(0)}
                                            data-gtm={item.datagmt}
                                            id={item.buttonid}
                                            tabIndex={0}
                                              onClick={
                                                item.id === "3" &&
                                                (() =>
                                                  GigyaLogout(handleOnLogout))
                                              }
                                            >
                                              {t[item.Services]}
                                            </a>{" "}
                                          </ListItem>
                                        ) : (
                                          <>
                                            {item.id == "1" && (
                                              <ListItem id="" as="span">
                                                <a
                                                role="button"
                                                href={void(0)}
                                                data-gtm={item.datagmt}
                                                id={item.buttonid}
                                                tabIndex={0}
                                                  onClick={() =>
                                                    item.id != "2"
                                                      ? handleProfileClick(
                                                        item?.PageLink
                                                      )
                                                      : userPrevilages?.value
                                                        ?.card
                                                        ? handleLoyalityClick()
                                                        : console.log("here")
                                                  }
                                                >
                                                  {t[item.Services]}
                                                </a>
                                              </ListItem>
                                            )}
                                            {item.id == "2" &&
                                              userPrevilages?.value?.card &&
                                              !userAccount?.value?.error &&
                                              Auth?.value?.guid &&
                                              userAccount?.value && (
                                                <ListItem id="" as="span">
                                                  <a
                                                  role="button"
                                                  href={void(0)}
                                                  aria-label={item.arialabel}
                                                  data-gtm={item.datagmt}
                                                  id={item.buttonid}
                                                  tabIndex={0}
                                                    onClick={() =>
                                                      item.id != "2"
                                                        ? handleProfileClick(
                                                          item?.PageLink
                                                        )
                                                        : userPrevilages?.value
                                                          ?.card
                                                          ? handleLoyalityClick()
                                                          : console.log("here")
                                                    }
                                                  >
                                                    {t[item.Services]}
                                                  </a>
                                                </ListItem>
                                              )}
                                          </>
                                        )}
                                      </List>
                                    ))}
                              </NavDropdown>
                                {userLogin && !hideNotification &&
                                  userPrevilages?.value != undefined &&
                                  Auth?.value?.lpCardNumber &&
                                  Auth?.value?.lpLinkedStatus != true &&
                                  (Auth?.value?.enrollementStatusGigya ==
                                    "LP01" ||
                                    Auth?.value?.enrollementStatusGigya ==
                                    undefined) &&
                                  !userPrevilages?.value?.closed &&
                                  Auth?.value?.enrollementStatusGigya !=
                                  "LP00" && (
                                    <div
                                      ref={bellRef as React.RefObject<HTMLDivElement>}
                                      onClick={() => setNotification(!notification)}
                                      onKeyPress={() => setNotification(true)}
                                      className={`hideOnMobile NotifactionBell ${notification ? 'isFocus' : 'isNotFocus'}`}
                                      tabIndex={0}
                                    >
                                      <div 
                                        role="button" 
                                        aria-label="Notification" 
                                        id="user-notification"
                                        
                                      >
                                        <img
                                          src="/icons/notif.svg"
                                          alt="Notifaction Bell Icon"
                                          width="17px"
                                          height="20px"
                                        />
                                        <span>1</span>
                                      </div>
                                      
                                      <div className="NotificationTooltip" role="alert" aria-labelledby="user-notification">
                                        <h6>{t.notificationLabel}</h6>
                                        <p>
                                          {userPrevilages?.value?.ghost
                                            ? `${t.registerText}`
                                            : `${t.verifyText}`}{" "}
                                          {t.verifyNotificationText}{" "}
                                          <button
                                            onClick={handleNotificationClick}
                                            role="button"
                                          >
                                            {t.notificationButtonText}
                                          </button>  
                                        </p>
                                      </div>
                                      
                                    </div>
                                  )}
                                {/***
                                 * Add card popup notification
                                 */}

                                {userLogin && !hideNotification && !Auth?.value?.lpCardNumber && (
                                      <div
                                        ref={bellRef as React.RefObject<HTMLDivElement>}
                                        onClick={() => setNotification(!notification)}
                                        onKeyPress={() => setNotification(true)}
                                        className={`hideOnMobile NotifactionBell ${notification ? 'isFocus' : 'isNotFocus'}`}
                                       
                                      >
                                      <div 
                                        role="button" 
                                        aria-label="Notification" 
                                        id="user-notification"
                                        
                                      >
                                        <img
                                          src="/icons/notif.svg"
                                          alt="Notifaction Bell Icon"
                                          width="17px"
                                          height="20px"
                                        />
                                        <span>1</span>
                                      </div>

                                      <div className="NotificationTooltip" role="alert" aria-labelledby="user-notification">
                                        <h6>{t.notificationLabel}</h6>
                                        <p>{t.notificationAddCard}{" "}
                                          <button
                                            onClick={handleAddCardClick}
                                            role="button"
                                          >
                                           {t.notificationButtonText}
                                          </button>
                                        </p>
                                      </div>

                                      </div>
                                )}
                              </li>
                            </>
                          ) : (
                            <>
                              <li
                                className="menuButton btnSign"
                                key={`navigation_drop_login`}
                              >
                                  <Link href={`${process?.env?.NEXT_PUBLIC_ACCOUNT_LOGIN}`}>
                                    <a aria-label="Sign In"
                                  data-gtm="signin_header"
                                  id="signin_header" className="themeBtn outline"  onClick={(e) => handleLogin(e)}>
                                {/* <button
                                  className="themeBtn outline"
                                  aria-label="Sign In"
                                  data-gtm="signin_header"
                                  id="signin_header_mobile"
                                  onClick={() => handleLogin({ region: op })}
                                > */}
                                
                                  {menu[1].blockdata[0]?.label}
                                 
                                {/* </button> */}
                                </a>
                                </Link>
                              </li>
                              <li
                                className="menuButton btn-accessibility"
                                key={`navigation_drop_register`}
                              >
                                <Link href={`${process?.env?.NEXT_PUBLIC_ACCOUNT_REGISTER}`}>
                            <a  aria-label="Register Header"
                              data-gtm="register_header" id="register_header" className="themeBtn" onClick={(e) => handleRegister(e)}>
                                {/* <button
                                  className="themeBtn"
                                  aria-label="Register Header"
                                  data-gtm="register_header"
                                  id="register_header_mobile"
                                  onClick={(e) => handleRegister(e)}
                                > */}
                                  {menu[1].blockdata[1]?.label}
                                {/* </button> */}
                                </a>
                                </Link>
                              </li>
                            </>
                          )}
                        </>
                      ) : (
                        <li key={`navigation_drop_loader`}>
                          <div className="loader">
                            <Image
                              alt="loader"
                              src="/icons/loader-white.svg"
                              layout="fill"
                              objectFit="contain"
                            />
                          </div>
                        </li>
                      )}
                    </ul>
                  </Text>
                </Flex>}
               {width < 992 && <>{ showNavBar && <Flex
                  justifyContent="flex-start"
                  className="MenuSlide"
                  style={{
                    display: showNavBar ? "flex" : "flex",
                    [`@media ${BreakPoints.tablet}`]: {
                      display: "flex",
                      justifyContent: "flex-end",
                    },
                  }}
                >
                  <FocusScope contain autoFocus restoreFocus><Text className="Menus">
                    <Text className="MenuHeader">
                      <Text as="div" className="Basketlogo">
                        {logo[0].blockdata[0]?.image && (
                          <Link href="/">
                            <a className="logo">
                              <Image
                                src={logo[0].blockdata[0].image.src}
                                alt={logo[0].blockdata[0].image.alt}
                                width={
                                  logo[0].blockdata[0].image.dimensions?.width
                                }
                                height={
                                  logo[0].blockdata[0].image.dimensions?.height
                                }
                                text-align="left"
                              />
                            </a>
                          </Link>
                        )}
                      </Text>
                      <Text as="div" className="MyGroceryOffersLogo">
                        <Text as="div" className="logo">
                          <Link href="/">
                            <a aria-label="Logo Heading">
                              <h2>{props?.headerData?.acf_tru_text[0]?.blockdata[0]?.ptext}</h2>
                            </a>  
                          </Link>
                        </Text>
                        <Text as="div" className="LogosBrandNames">
                          <ul>
                            {!locationLogo ? (
                              <></>
                            ) : (
                              <>
                                {locationLogo[0]?.header_image?.map((data,index) => (
                                  <li key={`logo_header_desk_${index}`}>
                                    {data?.logo_url ?(<Link href={data?.logo_url}>
                                      <a target={data?.logo_link_target}>
                                    <Image
                                      src={data?.url}
                                      alt={data?.alt}
                                      width={data?.width}
                                      height={data?.height}
                                    ></Image>
                                    </a>
                                    </Link>):(
                                    <span aria-label="Scene Logo Mobile">
                                    <Image
                                      src={data?.url}
                                      alt={data?.alt}
                                      width={data?.width}
                                      height={data?.height}
                                    ></Image>
                                    </span>
                                    ) }
                                  </li>
                                ))}
                              </>
                            )}
                          </ul>
                        </Text>
                      </Text>

                      <img src="/close-icon.svg" alt="Close Menu" className="close-menu" tabIndex={0} onClick={onNavbarClose} onKeyDown={closeNavOnFocus}/>
                    </Text>

                    {intializeUser ? (
                      <>
                        {userLogin ? (
                          
                         
                          <ul className={`userLoginList showOnMobile`}>
                            <li key={`navigation_drop_1`}>
                              <div className="UserProfile">
                                <div className="UserProfileInner" tabIndex={0}>
                                <svg width="17" height="20" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                  <path fill-rule="evenodd" clip-rule="evenodd" d="M10.7609 11.7398C12.7859 11.7316 14.7432 12.4679 16.2607 13.8087C17.7781 15.1495 18.7499 17.0013 18.991 19.0118C19.0148 19.2573 19.1295 19.485 19.3127 19.6501C19.4959 19.8152 19.7344 19.9057 19.981 19.9038C20.1202 19.9057 20.2582 19.8783 20.3861 19.8233C20.5139 19.7682 20.6289 19.6869 20.7232 19.5845C20.8176 19.4822 20.8892 19.3611 20.9337 19.2292C20.9781 19.0972 20.9943 18.9574 20.981 18.8188C20.7694 16.9591 20.0486 15.1939 18.8983 13.7175C17.7479 12.2411 16.2125 11.1107 14.461 10.4508C15.1203 9.93335 15.6593 9.27888 16.0408 8.53266C16.4224 7.78644 16.6374 6.96627 16.671 6.12883C16.7011 4.55875 16.1062 3.04101 15.0173 1.90951C13.9284 0.778012 12.4345 0.125428 10.8645 0.0953262C10.087 0.0804212 9.31436 0.218793 8.59041 0.50253C7.86646 0.786267 7.20548 1.20981 6.64522 1.749C5.51372 2.83793 4.86111 4.33175 4.83101 5.90183C4.83287 6.77889 5.03364 7.64411 5.41817 8.43239C5.80269 9.22066 6.36093 9.91147 7.05098 10.4528C5.3004 11.1141 3.76583 12.2449 2.61568 13.7211C1.46552 15.1972 0.744209 16.9617 0.53096 18.8208C0.519162 18.9591 0.536309 19.0984 0.581253 19.2297C0.626198 19.361 0.698007 19.4815 0.792069 19.5836C0.88613 19.6856 1.00042 19.767 1.12764 19.8225C1.25486 19.8779 1.39217 19.9063 1.53096 19.9058C1.77848 19.9073 2.01775 19.8169 2.20247 19.6521C2.38719 19.4873 2.50423 19.2599 2.53096 19.0138C2.76994 17.0022 3.741 15.1489 5.25887 13.8074C6.77674 12.4658 8.73521 11.7299 10.7609 11.7398ZM6.84102 5.90183C6.83011 5.12548 7.05031 4.36341 7.47359 3.71251C7.89687 3.06161 8.50404 2.55127 9.21809 2.24636C9.93214 1.94145 10.7207 1.85574 11.4836 2.00013C12.2465 2.14451 12.9493 2.51247 13.5025 3.05724C14.0558 3.60201 14.4345 4.29897 14.5907 5.05954C14.7468 5.8201 14.6732 6.60992 14.3793 7.32859C14.0855 8.04726 13.5846 8.66232 12.9403 9.09559C12.296 9.52885 11.5374 9.76076 10.7609 9.76183C9.73003 9.76717 8.73904 9.36411 8.00447 8.64078C7.2699 7.91745 6.85158 6.9327 6.84102 5.90183Z" fill="currentColor"/>
                                </svg>
                                  <span className="userTitle">
                                    {Auth?.value?.firstName}
                                  </span>
                                </div>
                                <ul className="submenu ">
                                  {((userPrevilages?.value?.card && userAccount?.value?.digitalBarCode)?ServicesListCard:ServicesList).map((item, index) => {
                                    return item.id === "3" ? (
                                      <li
                                        key={`service_${index}`}
                                        onClick={
                                          item.id === "3" &&
                                          (() => GigyaLogout(handleOnLogout))
                                        }
                                      >
                                        {" "}
                                        <Link href="">{t[item.Services]}</Link>
                                      </li>
                                    ) : (
                                      <>
                                        {item.id == "1" && (
                                          <li
                                            key={`service_${index}`}
                                            onClick={() =>
                                              item.id != "2"
                                                ? handleProfileClick(
                                                  item?.PageLink
                                                )
                                                : userPrevilages?.value?.card
                                                  ? handleLoyalityClick()
                                                  : console.log("here")
                                            }
                                          >
                                            <Link href="">{t[item.Services]}</Link>
                                          </li>
                                        )}
                                        {item.id == "2" &&
                                          userPrevilages?.value?.card &&
                                          !userAccount?.value?.error &&
                                          Auth?.value?.guid &&
                                          userAccount?.value && (
                                            <li
                                              key={`service_${index}`}
                                              onClick={() =>
                                                item.id != "2"
                                                  ? handleProfileClick(
                                                    item?.PageLink
                                                  )
                                                  : userPrevilages?.value?.card
                                                    ? handleLoyalityClick()
                                                    : console.log("here")
                                              }
                                            >
                                              <Link href="">
                                                {t[item.Services]}
                                              </Link>
                                            </li>

                                          )}
                                      </>
                                    );
                                  })}
                                </ul>
                              </div>
                            </li>
                            
                          </ul>
                            
                        ):(
                        <>
                         <ul className={`userLoginList showOnMobile`}>
                          <li
                            className="menuButton btnSign"
                            key={`navigation_drop_login`}
                          >
                             <Link  href={`${process.env.NEXT_PUBLIC_ACCOUNT_LOGIN}`}>
                                    <a  aria-label="Sign In"
                              data-gtm="signin_header" id="signin_header_mobile" className="themeBtn outline" onClick={(e) => handleLogin(e)}>
                            {/* <button
                              className="themeBtn outline"
                              aria-label="Sign In"
                              data-gtm="signin_header"
                              id="signin_header"
                              onClick={(e) => handleLogin({ region: op,e })}
                            > */}
                              {menu[1].blockdata[0]?.label}
                            {/* </button> */}
                            </a>
                            </Link>
                          </li>
                          <li
                            className="menuButton"
                            key={`navigation_drop_register`}
                          >
                            <Link href={`${process?.env?.NEXT_PUBLIC_ACCOUNT_REGISTER}`}>
                            <a   id="register_header_mobile" aria-label="Register Header"
                              data-gtm="register_header" className="themeBtn" onClick={(e) => handleRegister(e)}>
                            {/* <button
                              className="themeBtn"
                              aria-label="Register Header"
                              data-gtm="register_header"
                              id="register_header"
                              onClick={(e) => handleRegister(e)}
                            > */}
                              {menu[1].blockdata[1]?.label}
                            {/* </button> */}
                            </a>
                            </Link>
                          </li>
                          </ul>
                        </>)}
                      </>
                    ) : (
                      <ul className="showOnMobile">
                        {" "}
                        <li key={`navigation_drop_loader`}>
                          <div className="loader">
                            <Image
                              alt="loader"
                              src="/icons/loader-white.svg"
                              layout="fill"
                              objectFit="contain"
                            />
                          </div>
                        </li>
                      </ul>
                    )}
                      {menu[0].blockdata.length > 0 && (
                        <ul className="globalList">
                          {menu[0].blockdata.map((item, index) => {
                            return (
                              <li key={`menu_li_${index}`}>
                                <Link href={item.url}>
                                  <a
                                    className={
                                      router.pathname ===
                                        (item?.url != "/" && item?.url.endsWith("/")
                                          ? item?.url.slice(0, -1)
                                          : item?.url)
                                        ? "active"
                                        : ""
                                    }
                                  >
                                    {item?.label}
                                  </a>
                                </Link>
                              </li>
                            );
                          })}
                        </ul>
                      )}
                    <ul className="loginList ">
                      {intializeUser ? (
                        <>
                          {userLogin ? (
                            <>
                              {userAccount?.value &&
                                !userAccount?.value?.error &&
                                userPrevilages?.value?.points && (
                                  <li
                                    className="hideOnMobile dropdown"
                                    key={`navigation_drop_points`}
                                  >
                                    <Text as="div" className={`PopupProgress pointsContainerFocus ${pointsWrapper ? `show` : `hide`}`} ref={pointsRef}> 
                                      <Text
                                        as="div"
                                        tabIndex={0}
                                        className={`pointContainer ${pointsActive}`}
                                        onClick={() => { setPointsWrapper(!pointsWrapper)}}
                                        onKeyPress={() => { setPointsWrapper(true)}}
                                      >
                                        <img
                                          className="logo-symbol"
                                          src="/points-dot-top-menu.svg"
                                          alt="points"
                                        />
                                        <Text
                                          as="div"
                                          colorScheme="accent"
                                          className="price"
                                        >
                                          ${userAccount?.value?.dollarValue}{" "}
                                        </Text>
                                        <Text
                                          as="div"
                                          colorScheme="accent"
                                          className="points"
                                        >
                                          {(userAccount?.value?.pointBalance).toLocaleString()}
                                          {" "}PTS
                                        </Text>
                                      </Text>
                                      <Text
                                          as="div"
                                          className="dropdownPopup showFocusDropdown"
                                        >
                                          <Text as="h4">
                                          {t.sanpNext}
                                          </Text>
                                          {userAccount?.value
                                            ?.pointsToNextThreshold && (
                                              <Text as="p" colorScheme="accent">
                                                 {t.youAre}{" "}
                                                {(userAccount?.value?.pointsToNextThreshold).toLocaleString()}
                                                {" "}{t.pts} {t.away_from} $ $
                                                {
                                                  userAccount?.value
                                                    ?.nextThreshold
                                                }{" "}
                                              </Text>
                                            )}
                                          {props?.headerData?.acf_tru_button
                                            ?.length > 0 &&
                                            props?.headerData?.acf_tru_button[0]
                                              ?.blockdata[0] && (
                                              <Link
                                                href={
                                                  props?.headerData
                                                  ?.acf_tru_button[0]
                                                  ?.blockdata[0]?.link?.url
                                                }
                                              >
                                                
                                                <a
                                                  target={
                                                    props?.headerData
                                                      ?.acf_tru_button[0]
                                                      ?.blockdata[0]?.link
                                                      ?.target
                                                  }
                                                  className="simple-link"
                                                >
                                                  {
                                                    props?.headerData
                                                      ?.acf_tru_button[0]
                                                      ?.blockdata[0]?.label
                                                  }
                                                </a>
                                              </Link>
                                            )}
                                          <CustomProgressbar
                                            className="small"
                                            points={`${userAccount?.value?.pointBalance
                                                ? userAccount?.value
                                                  ?.pointBalance
                                                : ""
                                              }`}
                                            currentPoints={
                                              userAccount?.value?.pointBalance
                                                ? userAccount?.value
                                                  ?.pointBalance
                                                : 0
                                            }
                                            minValue={`${Number.isNaN(
                                              userAccount?.value?.dollarValue
                                            )
                                                ? 0
                                                : userAccount?.value
                                                  ?.dollarValue
                                              }`}
                                            midValue={`${Number.isNaN(
                                              userAccount?.value
                                                ?.nextThreshold
                                            )
                                                ? 0
                                                : userAccount?.value
                                                  ?.nextThreshold
                                              }`}
                                            maxValue={`${Number.isNaN(
                                              userAccount?.value
                                                ?.nextThreshold
                                            )
                                                ? 0
                                                : userAccount?.value
                                                  ?.nextThreshold + 10
                                              }`}
                                            barValue={
                                              pointsAverage > 0
                                                ? pointsAverage
                                                : 10
                                            }
                                            cachedPoints={pointsCached}
                                            showAnimation={false}
                                          />
                                        </Text>
                                    </Text>
                                  </li>
                                )}
                              <li key={`navigation_drop_profile`}>
                              <NavDropdown id="user-dropdown" title={Auth?.value?.firstName}>
                              {((userPrevilages?.value?.card && userAccount?.value?.digitalBarCode)?ServicesListCard:ServicesList).map((item) => (
                                
                                      <List
                                       
                                        key={item.id}
                                        className="btn-list-item"
                                      >
                                        {item.id === "3" ? (
                                          <ListItem id="" as="span">
                                            <a
                                            role="button"
                                            href={void(0)}
                                            data-gtm={item.datagmt}
                                            id={item.buttonid}
                                            tabIndex={0}
                                              onClick={
                                                item.id === "3" &&
                                                (() =>
                                                  GigyaLogout(handleOnLogout))
                                              }
                                            >
                                              {t[item.Services]}
                                            </a>{" "}
                                          </ListItem>
                                        ) : (
                                          <>
                                            {item.id == "1" && (
                                              <ListItem id="" as="span">
                                                <a
                                                role="button"
                                                href={void(0)}
                                                data-gtm={item.datagmt}
                                                id={item.buttonid}
                                                tabIndex={0}
                                                  onClick={() =>
                                                    item.id != "2"
                                                      ? handleProfileClick(
                                                        item?.PageLink
                                                      )
                                                      : userPrevilages?.value
                                                        ?.card
                                                        ? handleLoyalityClick()
                                                        : console.log("here")
                                                  }
                                                >
                                                  {t[item.Services]}
                                                </a>
                                              </ListItem>
                                            )}
                                            {item.id == "2" &&
                                              userPrevilages?.value?.card &&
                                              !userAccount?.value?.error &&
                                              Auth?.value?.guid &&
                                              userAccount?.value && (
                                                <ListItem id="" as="span">
                                                  <a
                                                  role="button"
                                                  href={void(0)}
                                                  aria-label={item.arialabel}
                                                  data-gtm={item.datagmt}
                                                  id={item.buttonid}
                                                  tabIndex={0}
                                                    onClick={() =>
                                                      item.id != "2"
                                                        ? handleProfileClick(
                                                          item?.PageLink
                                                        )
                                                        : userPrevilages?.value
                                                          ?.card
                                                          ? handleLoyalityClick()
                                                          : console.log("here")
                                                    }
                                                  >
                                                    {t[item.Services]}
                                                  </a>
                                                </ListItem>
                                              )}
                                          </>
                                        )}
                                      </List>
                                    ))}
                              </NavDropdown>
                                {userLogin && !hideNotification &&
                                  userPrevilages?.value != undefined &&
                                  Auth?.value?.lpCardNumber &&
                                  Auth?.value?.lpLinkedStatus != true &&
                                  (Auth?.value?.enrollementStatusGigya ==
                                    "LP01" ||
                                    Auth?.value?.enrollementStatusGigya ==
                                    undefined) &&
                                  !userPrevilages?.value?.closed &&
                                  Auth?.value?.enrollementStatusGigya !=
                                  "LP00" && (
                                    <div
                                      ref={bellRef as React.RefObject<HTMLDivElement>}
                                      onClick={() => setNotification(!notification)}
                                      onKeyPress={() => setNotification(true)}
                                      className={`hideOnMobile NotifactionBell ${notification ? 'isFocus' : 'isNotFocus'}`}
                                      tabIndex={0}
                                    >
                                      <div 
                                        role="button" 
                                        aria-label="Notification" 
                                        id="user-notification"
                                        
                                      >
                                        <img
                                          src="/icons/notif.svg"
                                          alt="Notifaction Bell Icon"
                                          width="17px"
                                          height="20px"
                                        />
                                        <span>1</span>
                                      </div>
                                      
                                      <div className="NotificationTooltip" role="alert" aria-labelledby="user-notification">
                                        <h6>{t.notificationLabel}</h6>
                                        <p>
                                          {userPrevilages?.value?.ghost
                                            ? `${t.registerText}`
                                            : `${t.verifyText}`}{" "}
                                          {t.verifyNotificationText}{" "}
                                          <button
                                            onClick={handleNotificationClick}
                                            role="button"
                                          >
                                            {t.notificationButtonText}
                                          </button>  
                                        </p>
                                      </div>
                                      
                                    </div>
                                  )}
                                {/***
                                 * Add card popup notification
                                 */}

                                {userLogin && !hideNotification && !Auth?.value?.lpCardNumber && (
                                      <div
                                        ref={bellRef as React.RefObject<HTMLDivElement>}
                                        onClick={() => setNotification(!notification)}
                                        onKeyPress={() => setNotification(true)}
                                        className={`hideOnMobile NotifactionBell ${notification ? 'isFocus' : 'isNotFocus'}`}
                                       
                                      >
                                      <div 
                                        role="button" 
                                        aria-label="Notification" 
                                        id="user-notification"
                                        
                                      >
                                        <img
                                          src="/icons/notif.svg"
                                          alt="Notifaction Bell Icon"
                                          width="17px"
                                          height="20px"
                                        />
                                        <span>1</span>
                                      </div>

                                      <div className="NotificationTooltip" role="alert" aria-labelledby="user-notification">
                                        <h6>{t.notificationLabel}</h6>
                                        <p>{t.notificationAddCard}{" "}
                                          <button
                                            onClick={handleAddCardClick}
                                            role="button"
                                          >
                                           {t.notificationButtonText}
                                          </button>
                                        </p>
                                      </div>

                                      </div>
                                )}
                              </li>
                            </>
                          ) : (
                            <>
                              <li
                                className="menuButton btnSign"
                                key={`navigation_drop_login`}
                              >
                                  <Link href={`${process?.env?.NEXT_PUBLIC_ACCOUNT_LOGIN}`}>
                                    <a aria-label="Sign In"
                                  data-gtm="signin_header"
                                  id="signin_header" className="themeBtn outline"  onClick={(e) => handleLogin(e)}>
                                {/* <button
                                  className="themeBtn outline"
                                  aria-label="Sign In"
                                  data-gtm="signin_header"
                                  id="signin_header_mobile"
                                  onClick={() => handleLogin({ region: op })}
                                > */}
                                
                                  {menu[1].blockdata[0]?.label}
                                 
                                {/* </button> */}
                                </a>
                                </Link>
                              </li>
                              <li
                                className="menuButton btn-accessibility"
                                key={`navigation_drop_register`}
                              >
                                <Link href={`${process?.env?.NEXT_PUBLIC_ACCOUNT_REGISTER}`}>
                            <a  aria-label="Register Header"
                              data-gtm="register_header" id="register_header" className="themeBtn" onClick={(e) => handleRegister(e)}>
                                {/* <button
                                  className="themeBtn"
                                  aria-label="Register Header"
                                  data-gtm="register_header"
                                  id="register_header_mobile"
                                  onClick={(e) => handleRegister(e)}
                                > */}
                                  {menu[1].blockdata[1]?.label}
                                {/* </button> */}
                                </a>
                                </Link>
                              </li>
                            </>
                          )}
                        </>
                      ) : (
                        <li key={`navigation_drop_loader`}>
                          <div className="loader">
                            <Image
                              alt="loader"
                              src="/icons/loader-white.svg"
                              width={20}
                              height={20}
                            />
                          </div>
                        </li>
                      )}
                    </ul>
                  </Text></FocusScope>
                </Flex>}</>}
              </Text>
            </Row>
          </Container>
        </Text>
      </Text>


      {/**** old navigation  */}
      {secondModal && !maintainModal && (
        <Modal overlayColor="rgba(0, 0, 0, 0.8)" zIndex={99}
          closeIcon={
            <Image
              src="/icons/close.svg"
              layout="fixed"
              height={13}
              width={13}
              alt="icon close"
            />
          }
          onClick={() => setSecondModal(!secondModal)}
          className="modaltest"
          style={{
            maxWidth: "470px",
            [`@media ${BreakPoints.tabletS}`]: {
              maxWidth: "730px",
            },
            padding: "20px",
          }}
        >
          <div className="offerSection2">
            <div className="offerImgBox">
              <Image
                alt={imagePopupSecond?.image?.alt}
                src={imagePopupSecond?.image?.src}
                layout="responsive"
                width={84}
                height={84}
              />
            </div>
            <h3>
              {popup2.blockdata[0]?.title}
            </h3>
            <Text
              as="p"
              style={{
                fontSize: "16px",
                lineHeight: "28px",
                color: "#404040",
                textAlign: "center",
                fontWeight: "400",
                marginBottom: "0px",
                marginTop: "0px",
                maxWidth: "315px",
                margin: "0px auto 30px",
                [`@media ${BreakPoints.mobileS}`]: {
                  fontSize: "14px",
                  lineHeight: "20px",
                },
                [`@media ${BreakPoints.tabletS}`]: {
                  maxWidth: "100%",
                },
              }}
            >
              {popup2.blockdata[0]?.description}
            </Text>
            {popup2.blockdata[0] &&
              popup2.blockdata[0]?.actionproperties.map((data) => {
                return (
                  <div
                    className="offerLinks"
                    key={`action_links_${data.label}`}
                    style={{ textAlign: "center" }}
                  >
                    {data.text}{" "}
                    <Link href={data.link.url}>
                      <a className="themeBtn" target={data?.link?.target}>
                        {data.label}
                      </a>
                    </Link>
                  </div>
                );
              })}
          </div>
        </Modal>
      )}
      {/**** Modal to show no banner is rolled out  */}
      {(bannerRegionModal) && (
        <Modal overlayColor="rgba(0, 0, 0, 0.8)" zIndex={99}
          closeIcon={
            <Image
              src="/icons/close.svg"
              layout="fixed"
              height={13}
              width={13}
              alt="icon close"
            />
          }
          onClick={() => setBannerRegionModal(false)}
          className="modaltest"
          style={{
            maxWidth: "470px",
            [`@media ${BreakPoints.tabletS}`]: {
              maxWidth: "730px",
            },
            padding: "20px",
          }}
        >
          <div className="offerSection2">
            <div className="offerImgBox">
              <Image
                alt="Mountains"
                src={imagePopupSecond?.image?.src}
                layout="responsive"
                width={84}
                height={84}
              />
            </div>
            <Text
              as="h3"
              textAlign="center"
              style={{
                fontFamily: "Poppins-Bold",
                fontSize: "26px",
              }}
            >
            {t.noProvince}
            </Text>
            <Text
              as="p"
              style={{
                fontSize: "16px",
                lineHeight: "28px",
                color: "#404040",
                textAlign: "center",
                fontWeight: "400",
                marginBottom: "0px",
                marginTop: "0px",
                maxWidth: "315px",
                margin: "0px auto 30px",
                [`@media ${BreakPoints.mobileS}`]: {
                  fontSize: "14px",
                  lineHeight: "20px",
                },
                [`@media ${BreakPoints.tabletS}`]: {
                  maxWidth: "100%",
                },
              }}
            >
              {popup2.blockdata[0]?.description}
            </Text>
            {popup2.blockdata[0] &&
              popup2.blockdata[0]?.actionproperties.map((data) => {
                return (
                  <div
                    className="offerLinks"
                    key={`action_links_${data.label}`}
                    style={{ textAlign: "center" }}
                  >
                    {data.text}{" "}
                    <Link href={data.link.url}>
                      <a className="themeBtn" target={data?.link?.target}>
                        {data.label}
                      </a>
                    </Link>
                  </div>
                );
              })}
          </div>
        </Modal>
      )}
      {/***** bar code modal  */}

      {barCodeModal && (
        <Text as="div" className="BarcodeModalContainer">
        <Modal overlayColor="rgba(0, 0, 0, 0.8)" zIndex={99}
          closeIcon={
            <Image
              src="/icons/close.svg"
              layout="fixed"
              height={13}
              width={13}
              alt="icon close"
            />
          }
          onClick={() => setBarCodeModal(!barCodeModal)}
          className={" modaltest barcodeModal"}
          style={{          
            maxWidth: "430px",  
            [`@media ${BreakPoints.mobileS}`]: {
              maxWidth: "280px",
            },
            [`@media ${BreakPoints.tabletS}`]: {
              maxWidth: "510px",
            }           
          }}
        >
          {userAccount?.value && !userAccount?.value?.error ? (
            <Text as="div" className="barcodeModalInner">
              <div className="barcodeModalInnerFlex">
                <div className="barcodeModalInnerFlexLeft">
                  <div className="content">
                    <Text as="p" textAlign="center" colorScheme="accent">
                      {props?.headerData?.acf_tru_modal?.[2]?.blockdata?.[0]?.modalcontent?.[0]}
                    </Text>
                    <Text as="div" className="price">
                      {
                        <>
                          <sup>$</sup>
                          {userAccount?.value?.dollarValue}
                        </>
                      }
                    </Text>
                    <Text as="p" textAlign="center" colorScheme="accent">
                    {props?.headerData?.acf_tru_modal?.[2]?.blockdata?.[0]?.modalcontent?.[1]}
                    </Text>
                  </div>
                </div>
                <div className="barcodeModalInnerFlexRight">
                  <div className="headerSection">
                    <div className="header">
                      <div className="headerInner">
                        <div className="headerInnerLeft">
                          <Image
                            src="/scene-logo-white.svg"
                            width={87}
                            height={28}
                          />
                        </div>
                        {userAccount?.value?.fullName && (
                          <div className="headerInnerRight">
                            {userAccount?.value?.fullName}
                          </div>
                        )}
                      </div>
                      {userAccount?.value?.pointBalance && (
                        <div className="headerPoints">
                          {(userAccount?.value?.pointBalance).toLocaleString()}{" "}
                          <span> {props?.headerData?.acf_tru_modal?.[2]?.blockdata?.[0]?.modalcontent?.[2]}</span>
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="content">
                    <div className="contentInner">
                      <Image
                        src={`data:image/png;base64,${userAccount?.value?.digitalBarCode}`}
                        width={398}
                        height={68}
                        objectFit="cover"
                      />
                    </div>
                    <Text as="p">{userAccount?.value?.cardNumber}</Text>
                  </div>
                </div>
              </div>
              <Text as="div" className="IconTop">
                <Image
                  src="/icons/loyalty-dot-icon.svg"
                  alt="loyalty top dot icon"
                  width={103}
                  height={103}
                />
              </Text>
              <Text as="div" className="IconBottom">
                <Image
                  src="/icons/loyalty-dot-icon.svg"
                  alt="loyalty bottom dot icon"
                  width={103}
                  height={103}
                />
              </Text>
            </Text>
          ) : (
            <Loader />
          )}
        </Modal>
        </Text>
      )}
      {/*** Maintanace Modal */}
      {maintainModal && (
        <Modal overlayColor="rgba(0, 0, 0, 0.8)" zIndex={99}
          closeIcon={
            <Image
              src="/icons/close.svg"
              layout="fixed"
              height={13}
              width={13}
              alt="icon close"
            />
          }
          onClick={() => handleMaintainClick()}
          className="modaltest"
          style={{
            maxWidth: "470px",
            [`@media ${BreakPoints.tabletS}`]: {
              maxWidth: "730px",
            },
            padding: "20px",
          }}
          hideBackdrop={true}
        >
          <div className="offerSection2">
            <div className="offerImgBox">
              <Image
                alt={maintanancePopup?.image_group?.[0]?.image?.alt}
                src={maintanancePopup?.image_group?.[0]?.image?.src}
                layout="responsive"
                width={84}
                height={84}
              />
            </div>
            <h3>
              {maintanancePopup?.title}
            </h3>
            <Text
              as="p"
              style={{
                fontSize: "16px",
                lineHeight: "28px",
                color: "#404040",
                textAlign: "center",
                fontWeight: "400",
                marginBottom: "0px",
                marginTop: "0px",
                maxWidth: "315px",
                margin: "0px auto 30px",
                [`@media ${BreakPoints.mobileS}`]: {
                  fontSize: "14px",
                  lineHeight: "20px",
                },
                [`@media ${BreakPoints.tabletS}`]: {
                  maxWidth: "100%",
                },
              }}
            >
              {maintanancePopup?.description}
            </Text>
            {/* {popup2.blockdata[0] &&
              popup2.blockdata[0]?.actionproperties.map((data) => {
                return (
                  <div
                    className="offerLinks"
                    key={`action_links_${data.label}`}
                    style={{ textAlign: "center" }}
                  >
                    {data.text}{" "}
                    <Link href={data.link.url}>
                      <a className="themeBtn" target={data?.link?.target}>
                        {data.label}
                      </a>
                    </Link>
                  </div>
                );
              })} */}
          </div>
        </Modal>
      )}
{/*** Maintanance Modal Close */}

      {(props?.host?.showrolledpopup)?(<>{Auth?.value?.email && checkRolledOut((props?.host?.rolledOut).length > 0 ?props?.host?.rolledOut :GigyaObject?.thisScript?.globalConf?.ELM_REGIONS) && (
        <AccountLinking offerPageData={props?.offerData} />
      )}</>):(<>{Auth?.value?.email && (
        <AccountLinking offerPageData={props?.offerData} />
      )}</>)}
       {/***
        * To check banner optin shows or not
        */}
        {Auth?.value && <div><OptNotification
          headerData={props?.headerData}
         /></div>}
    </>
  );
});

export const Header = React.memo(HeaderData);
