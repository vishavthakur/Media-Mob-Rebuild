import React from "react";
import { getCookie, removeCookies, setCookies } from "cookies-next";
import { Container, Row, Text, Modal } from "@components";
import Select from "@components/Select";
import { AccountLinking, MaintainAlert } from "@templates";
import { USER_AUTH } from "../../redux/actions/authActions";
import { useSelector, RootStateOrAny, useDispatch } from "react-redux";
import { BANNER_LOCATION } from "@redux/actions/counterActions";
import { GigyaObject,checkRolledOut } from "@services/Gigya";
import Image from "@templates/ImageConversion";
import Link from "next/link";
import { BreakPoints } from "@util/units";
import { useRouter } from "next/router";
import { Regions, defaultStores } from "@util/banners";
import { getMemberDetail } from "@services/Mulesoft";
import { Flash } from '@templates/ErrorNotifaction';
import en from "lang/en";
import fr from "lang/fr";
interface pageData {
  headerData?: any;
  offerData?: Record<any, any>;
  host?:Record<any, any>;
}
/**
 * @function HeaderVerify
 * Header with logo only
 */



export const HeaderVerify = React.forwardRef<
  HTMLDivElement,
  React.PropsWithChildren<pageData>
>(
  (
    {
      children,
      ...props
    },
    ref,
  ) => {
    const [locationLogo, setLocationLogo] = React.useState(null);
    const [bannerListRegion, setBannerListRegion] = React.useState(null);
    const [maintainModal, setMaintainModal] = React.useState(false);
    const [bannerRegionModal, setBannerRegionModal] = React.useState(false);
    const option: { id: string; name: string }[] = (props?.headerData?.acf_tru_taxonomy[0]?.blockdata?.length > 0) ? (props?.headerData?.acf_tru_taxonomy[0]?.blockdata?.map((data) => {
      return { id: (data?.slug).replaceAll("-", ""), name: data?.name };
    })): [
      { id: "alberta", name: "Alberta" },
      { id: "britishcolumbia", name: "British Columbia" },
      { id: "manitoba", name: "Manitoba" },
      { id: "newfoundland and labrador", name: "Newfoundland and labrador" },
      { id: "newbrunswick", name: "New Brunswick" },
      { id: "novascotia", name: "Nova Scotia" },
      { id: "ontario", name: "Ontario" },
      { id: "princeedwardisland", name: "Prince edward island" },
      { id: "saskatchewan", name: "Saskatchewan" },
    ];
    const logoText = props?.headerData?.acf_tru_text?.[0]?.blockdata?.[0]?.ptext;
    const logo = props?.headerData?.acf_tru_image;
      /****
   * Handle the logo's on location change
   * @function locationChangeLogo
   * @param location type string
   */
  const locationChangeLogo = (location: string) => {
    let locationlogo = props?.headerData?.acf_tru_taxonomy[0]?.blockdata?.filter((data) => ((data?.slug).replaceAll("-", "") === location));
    setLocationLogo(locationlogo);
  }

    const Auth = useSelector((state: RootStateOrAny) => state.auth);
    const {
      0: popup2,
    } = props?.headerData?.acf_tru_modal;
    const bannerSelected  = useSelector((state: RootStateOrAny) => state.banner);
    const imagePopupSecond = popup2.blockdata[0]?.image_group[0];
    const [secondModal, setSecondModal] = React.useState(false);
    const [op, setOp] = React.useState("");
    const router = useRouter();
    const { locale } = router; 
    const t = locale === "en" ? en : fr;
    /***
   * @function dispatch
   * to use the redux 
   */
  const dispatch = useDispatch();
    React.useEffect(() => {
    /*** get value from local storage */
    let banner_provience = JSON.parse(localStorage.getItem("banner"));
    let rolled_region = (props?.host?.rolledOut.length > 0)?props?.host?.rolledOut:GigyaObject?.thisScript?.globalConf?.ELM_REGIONS;
    if (banner_provience && GigyaObject != undefined && !router?.query?.region) {
      setOp(banner_provience);
      onLocationChange(banner_provience);
      if (rolled_region?.indexOf(Regions[banner_provience]) === -1 && rolled_region != Regions[banner_provience] && banner_provience) {
        /***
         * Hardcoded liquor offers
         */
        if(props?.host?.showrolledpopup){
       
        if(router.pathname === process.env.NEXT_PUBLIC_REGISTER_VERIFYCARD_SLUG){
         router.push("/");
        }
        else{
          setSecondModal(true);
        }
        }
      } else {
        setSecondModal(false);
      }
      }
      else if(router?.query?.region && defaultStores[(router?.query?.region as string)?.toLocaleLowerCase()] != undefined){
        onLocationChange(defaultStores[(router?.query?.region as string)?.toLocaleLowerCase()]);
      }
    else {
      localStorage.setItem("banner", JSON.stringify((props?.host?.defaultRegion)?props?.host?.defaultRegion:"ontario"));
      /*** Update the banners */
      dispatch({
        type: BANNER_LOCATION,
        payload: {
          location: (props?.host?.defaultRegion)?props?.host?.defaultRegion:"ontario",
        },
      });
      }

  const timer = setTimeout(() => {
    /*** Get account response  */
    const getAccountInfoResponse = (response) => {
      if (response.status === "OK") {
        /**** Check rolledout region after login */
        if (rolled_region?.indexOf(Regions[banner_provience]) === -1 && rolled_region != Regions[banner_provience] && banner_provience) {
          /***
           * Hardcoded liquor offers
           */
          if(props?.host?.showrolledpopup){
          if(router.pathname === process.env.NEXT_PUBLIC_REGISTER_VERIFYCARD_SLUG){
           router.push("/");
          }
          }
        }
        if(getCookie('personOffersUniqueId') == undefined && response?.data?.scene?.cardNumber) {
          getMemberDetail(response?.data?.scene?.cardNumber, false);
        }
        dispatch({
          type: USER_AUTH,
          payload: {
            /**** Lp card number not coming from response so added empty here or can be changed from url */
            user: {guid:response?.UID,lpCardNumber:response?.data?.scene?.cardNumber,lpLinkedStatus: response?.data?.scene?.linkedStatus, ...response?.profile },
          },
        });
      } else {
        removeCookies(`personOffersUniqueId`, { path: '/', domain: `${process.env.NEXT_PUBLIC_COOKIE_DOMAIN}` }); 
      }
    };
    if (GigyaObject != undefined) {
      GigyaObject.accounts.getAccountInfo({ callback: getAccountInfoResponse });
    }
  }, 300);
  return () => clearTimeout(timer);
}, [router?.query?.region]);
/***
 * change location manually
 */
 const onLocationManualyChnage = (e:string) => {
  setCookies("manually_region_changed", 1, { path: '/', domain: `${process.env.NEXT_PUBLIC_COOKIE_DOMAIN}`, sameSite: true });
  onLocationChange(e);
  return true;
}
/****
   * @function onLocationChange
   * On location change set the banner value
   */
 const onLocationChange = (e) => {
  setOp(e);
  //@ts-ignore
  // const rolledOutRegion = (props?.host?.rolledOut.length > 0)?props?.host?.rolledOut:gigya?.thisScript?.globalConf?.ELM_REGIONS;
  // if (
  //   rolledOutRegion.indexOf(Regions[e]) === -1 &&
  //   rolledOutRegion != Regions[e]
  // ) {
  //   setSecondModal(true);
  // } else {
  //   setSecondModal(false);
  //   if ((props?.host?.banners[Regions[e]]).length === 0) {
  //     setBannerRegionModal(true);
  //   }
  // }
  locationChangeLogo(e);
  localStorage.setItem("banner", JSON.stringify(e));
  dispatch({
    type: BANNER_LOCATION,
    payload: {
      location: e,
    },
  });
};

React.useEffect(() => {
  if (bannerSelected?.value) {
    locationChangeLogo(bannerSelected?.value);
    setOp(bannerSelected?.value);
    setBannerListRegion(props?.host?.banners[Regions[bannerSelected?.value]]);
    //@ts-ignore
    const rolledOutRegion = (props?.host?.rolledOut.length > 0)?props?.host?.rolledOut:gigya?.thisScript?.globalConf?.ELM_REGIONS;
    if (
      rolledOutRegion.indexOf(Regions[bannerSelected?.value]) === -1 &&
      rolledOutRegion != Regions[bannerSelected?.value]
    ) {
      if(props?.host?.showrolledpopup){
        if(router.pathname === process.env.NEXT_PUBLIC_REGISTER_VERIFYCARD_SLUG){
          router.push("/");
         }
         else{
            setSecondModal(true);
         }
      }
    } else {
      setSecondModal(false);
      if ((props?.host?.banners[Regions[bannerSelected?.value]]).length === 0) {
        onLocationChange(props?.host?.defaultRegion);
      }
    }
  }
},[bannerSelected?.value]);
 /***
   * Maintainance Popup and alerts data and settings
   */
  const maintainanceBar = props?.headerData?.acf_tru_information_banner?.[0]?.blockdata?.[0];
  const maintanancePopup = props?.headerData?.acf_tru_modal?.[1]?.blockdata?.[0];
  const maintananceAlert = props?.headerData?.acf_tru_footer?.[0]?.blockdata?.[0]?.tru_enable_maintainance_alert;
  const maintananceAlertPopup = props?.headerData?.acf_tru_footer?.[0]?.blockdata?.[0]?.tru_enable_maintainance_popup;
  /****
   * Check if the maintainance popup enable
   */
  React.useEffect(() => {
  if(maintananceAlertPopup === "1"){
    if(!getCookie('hide_maintein_modal')){
     setMaintainModal(true);
     setSecondModal(false);
    }
  
 }
  },[maintananceAlert,maintananceAlertPopup])
  /***
   * @function handleMaintainClick
   * To set the cookie for session if the maintainance popup visible
   */
   const handleMaintainClick = () => {
    setCookies("hide_maintein_modal", 1, { path: '/', domain: `${process.env.NEXT_PUBLIC_COOKIE_DOMAIN}`, sameSite: true });
    setMaintainModal(false);
  }
    return (
      <>
        <Text as="header" className="Header HeaderVerify">
        <MaintainAlert headline={maintainanceBar} enableAlert={maintananceAlert}/>
          <Text as="div" className="NavigationBar">
          <Text as="div" className="ErrorNotificationOuter">
          <Flash />
          </Text>
            <Container size="fluid" style={{ width: 1730 }}>
            <Row className="NavigationBarRow">
              <Text
                className="NavigationBarLeft"
                style={{ alignItems: "center", display: "flex" }}
              >
                <Text as="div" className="Basketlogo">
                          {logo[0].blockdata[0]?.image && (
                            <Link href="/">
                              <a className="logo">
                                <Image
                                  src={logo[0].blockdata[0].image.src}
                                  alt={logo[0].blockdata[0].image.alt}
                                  width={
                                    logo[0].blockdata[0].image.dimensions?.width
                                  }
                                  height={
                                    logo[0].blockdata[0].image.dimensions?.height
                                  }
                                  text-align="left"
                                />
                              </a>
                            </Link>
                          )}
                    </Text>   
                <Text as="div" className="MyGroceryOffersLogo">
                  <Text as="div" className="logo">
                    <Link href="/">
                      <a tabIndex={0} aria-label={logoText}>
                          <h2>{logoText}</h2>
                      </a>
                    </Link>
                  </Text>
                  <Text as="div" className="LogosBrandNames">
                    <ul>
                      {!locationLogo ? (
                        <></>
                      ) : (
                        <>
                          {locationLogo[0]?.header_image?.map((data,index) => (
                              <li key={`logo_header_verify_index_${index}`}>
                              {data?.logo_url ?(<Link href={data?.logo_url}>
                                <a target={data?.logo_link_target} aria-label={data?.logo_aria_label} id={`logo_${index}`}>
                              <Image
                                src={data?.url}
                                alt={data?.alt}
                                width={data?.width}
                                height={data?.height}
                              ></Image>
                              </a>
                              </Link>):(
                              <Image
                                src={data?.url}
                                alt={data?.alt}
                                width={data?.width}
                                height={data?.height}
                              ></Image>
                              ) }
                            </li>
                          ))}
                        </>
                      )}
                    </ul>
                  </Text>
                </Text>
              </Text>
              <Text className="NavigationBarRight VerifySelect">
              <Text as="div" className="NavSelect">
                    <img
                      src="/icons/location-icon-black.svg"
                      width="17px"
                      height="20px"
                      alt="icon location"
                    />
                    <span style={{}}>
                      {" "}
                      Your region:
                    </span>
                    <Select
                      placeholder={(props?.host?.defaultRegion)?props?.host?.defaultRegion:"Ontario"}
                      options={option}
                      selected={op ? op : (props?.host?.defaultRegion)?props?.host?.defaultRegion:"ontario"}
                      className={"selectRetailer"}
                      style={{ color: "#aaaaaa", textTransform: "capitalize" }}
                      onChange={(e) => onLocationManualyChnage(e)}
                      classes={{ root:"selectroot",selectInput:"inputSelect", selectContainerWrapper:"selectContainerWrapper",selectText:"SelectBoxText", selectIcon:"SelectBoxIcon",selectOptions:"SelectDropdownContainer",selectList:"SelectDropdownUl",selectListItem:"selectListItem", selectActiveItem:"selectActiveItem" }}
                    />
                  </Text>
              </Text>
            </Row>
          </Container>
          </Text>
        </Text>
        {(props?.host?.showrolledpopup)?(<>{Auth?.value?.email && checkRolledOut((props?.host?.rolledOut).length > 0 ?props?.host?.rolledOut :GigyaObject?.thisScript?.globalConf?.ELM_REGIONS) && (
        <AccountLinking offerPageData={props?.offerData} />
      )}</>):(<>{Auth?.value?.email && (
        <AccountLinking offerPageData={props?.offerData} />
      )}</>)}
        
        {secondModal && !maintainModal && (
        <Modal overlayColor="rgba(0, 0, 0, 0.8)" zIndex={99}
          closeIcon={<Image alt="close_icon" src="/icons/close.svg" layout="fixed" height={13} width={13} />}
          onClick={() => setSecondModal(!secondModal)}
          className="modaltest"
          style={{
            maxWidth: '470px',
            [`@media ${BreakPoints.tabletS}`]: {
              maxWidth: "730px",
            },
            padding: "20px",
          }}
        >
          <div className="offerSection2">

            <div className="offerImgBox">
              <Image
                alt="Mountains"
                src={imagePopupSecond?.image?.src}
                layout="responsive"
                width={84}
                height={84}
              />
            </div>
            <Text
              as="h3"
              textAlign="center"
              style={{
                fontFamily: "Poppins-Bold",
                fontSize: "26px",
              }}
            >
              {popup2.blockdata[0]?.title}
            </Text>
            <Text
              as="p"
              style={{
                fontSize: "16px",
                lineHeight: "28px",
                color: "#404040",
                textAlign: "center",
                fontWeight: "400",
                marginBottom: "0px",
                marginTop: "0px",
                maxWidth: "315px",
                margin: "0px auto 30px",
                [`@media ${BreakPoints.mobileS}`]: {
                  fontSize: "14px",
                  lineHeight: "20px",
                },
                [`@media ${BreakPoints.tabletS}`]: {
                  maxWidth: "100%",
                },
              }}
            >
              {popup2.blockdata[0]?.description}
            </Text>
            {popup2.blockdata[0] && popup2.blockdata[0]?.actionproperties.map((data) => {
              return (
                <div
                  className="offerLinks"
                  key={`action_links_${data.label}`}
                  style={{ textAlign: "center" }}
                >
                  {data.text} <Link href={data.link.url}><a className="themeBtn" target={data?.link?.target}>{data.label}</a></Link>
                </div>
              );
            })}
          </div>
        </Modal>
      )}

        
{(bannerRegionModal) && (
        <Modal overlayColor="rgba(0, 0, 0, 0.8)" zIndex={99}
          closeIcon={<Image alt="close_icon" src="/icons/close.svg" layout="fixed" height={13} width={13} />}
          onClick={() => setBannerRegionModal(false)}
          className="modaltest"
          style={{
            maxWidth: '470px',
            [`@media ${BreakPoints.tabletS}`]: {
              maxWidth: "730px",
            },
            padding: "20px",
          }}
        >
          <div className="offerSection2">

            <div className="offerImgBox">
              <Image
                alt="Mountains"
                src={imagePopupSecond?.image?.src}
                layout="responsive"
                width={84}
                height={84}
              />
            </div>
            <Text
              as="h3"
              textAlign="center"
              style={{
                fontFamily: "Poppins-Bold",
                fontSize: "26px",
              }}
            >
          {t.noProvince}
            </Text>
            <Text
              as="p"
              style={{
                fontSize: "16px",
                lineHeight: "28px",
                color: "#404040",
                textAlign: "center",
                fontWeight: "400",
                marginBottom: "0px",
                marginTop: "0px",
                maxWidth: "315px",
                margin: "0px auto 30px",
                [`@media ${BreakPoints.mobileS}`]: {
                  fontSize: "14px",
                  lineHeight: "20px",
                },
                [`@media ${BreakPoints.tabletS}`]: {
                  maxWidth: "100%",
                },
              }}
            >
              {popup2.blockdata[0]?.description}
            </Text>
            {popup2.blockdata[0] && popup2.blockdata[0]?.actionproperties.map((data) => {
              return (
                <div
                  className="offerLinks"
                  key={`action_links_${data.label}`}
                  style={{ textAlign: "center" }}
                >
                  {data.text} <Link href={data.link.url}><a className="themeBtn" target={data?.link?.target}>{data.label}</a></Link>
                </div>
              );
            })}
          </div>
        </Modal>
      )}
         {/*** Maintanace Modal */}
         {maintainModal && (
        <Modal overlayColor="rgba(0, 0, 0, 0.8)" zIndex={99}
          closeIcon={
            <Image
              src="/icons/close.svg"
              layout="fixed"
              height={13}
              width={13}
              alt="icon close"
            />
          }
          onClick={() => handleMaintainClick()}
          className="modaltest"
          style={{
            maxWidth: "470px",
            [`@media ${BreakPoints.tabletS}`]: {
              maxWidth: "730px",
            },
            padding: "20px",
          }}
          hideBackdrop={true}
        >
          <div className="offerSection2">
            <div className="offerImgBox">
              <Image
                alt={maintanancePopup?.image_group?.[0]?.image?.alt}
                src={maintanancePopup?.image_group?.[0]?.image?.src}
                layout="responsive"
                width={84}
                height={84}
              />
            </div>
            <h3>
              {maintanancePopup?.title}
            </h3>
            <Text
              as="p"
              style={{
                fontSize: "16px",
                lineHeight: "28px",
                color: "#404040",
                textAlign: "center",
                fontWeight: "400",
                marginBottom: "0px",
                marginTop: "0px",
                maxWidth: "315px",
                margin: "0px auto 30px",
                [`@media ${BreakPoints.mobileS}`]: {
                  fontSize: "14px",
                  lineHeight: "20px",
                },
                [`@media ${BreakPoints.tabletS}`]: {
                  maxWidth: "100%",
                },
              }}
            >
              {maintanancePopup?.description}
            </Text>
            {/* {popup2.blockdata[0] &&
              popup2.blockdata[0]?.actionproperties.map((data) => {
                return (
                  <div
                    className="offerLinks"
                    key={`action_links_${data.label}`}
                    style={{ textAlign: "center" }}
                  >
                    {data.text}{" "}
                    <Link href={data.link.url}>
                      <a className="themeBtn" target={data?.link?.target}>
                        {data.label}
                      </a>
                    </Link>
                  </div>
                );
              })} */}
          </div>
        </Modal>
      )}
      </>
    );
  })