import React from "react";
import { SectionTitle, SectionBoxed } from "@templates";
import { Row, Col, Text } from "@components";
import Image from "@templates/ImageConversion";
interface offersNotFound {
     image?: string,
     title?: string,
     belowTitle?: string,
     className?: string
}
export const OfferNotFound = React.forwardRef<
     HTMLDivElement,
     React.PropsWithChildren<offersNotFound>
>(({ children, ...props }, ref) => {
     return (<SectionBoxed className={`fluid AffterLoginOffers ${props?.className}`}>
          <Row>
               <Col md={12}>
                    <Text className="Image">
                         <Image
                              src={props?.image}
                              layout="fill"
                              objectFit="contain"
                              alt="Great Offers for coming soon"
                         />
                    </Text>
                    <SectionTitle
                         className="offersTitle mb-0"
                         title={props?.title}
                         belowTitle={props?.belowTitle}
                         tabIndex={0}
                         belowTabIndex={0}
                    />
               </Col>
          </Row>
     </SectionBoxed>)
});
OfferNotFound.defaultProps = {
     image: '/After-Login-Loaded-GetMyOffers.svg',
     title: 'Great offers, coming soon',
     belowTitle: 'Check back every week to see offers created just for you'
}   
