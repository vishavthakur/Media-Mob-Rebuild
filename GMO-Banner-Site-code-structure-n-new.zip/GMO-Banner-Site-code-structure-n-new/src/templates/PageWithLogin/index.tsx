import Image from "@templates/ImageConversion";
import Link from "next/link";
import React from "react";
import { useRouter } from "next/router";
import { useSelector, RootStateOrAny, useDispatch } from "react-redux";
import {
  Tab,
  TabItem,
  TabList,
  TabPanel,
  Container,
  Row,
  Col,
  Text,
  Modal
} from "@components";
import { OffersCardNew } from "@templates/OfferCardNew";
import {
  Header,
  Footer,
  SectionTitle,
  FooterAboveCard,
  SectionBoxed,
  CustomProgressbar,
  SectionFluid,
  SlickCircleNextArrow,
  SlickCirclePrevArrow,
  FilterSelect,
  SeoMeta,
  Loader,
  OfferNotFound,
  CardNotFound,
  CustomTabs, 
  CustomTabList,
  CustomTab, 
  CustomTabPanels, 
  CustomTabPanel
} from "@templates";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { getMemberOffers,loadMemberOffers,getMassOffers } from "@services/Mulesoft";
import { SwitchOfferType } from "@services/Offers";
import { MassOffers } from "@templates/MassOffers";
import { UserTime } from "@util/UserTime";
import {addDataLayer,getBannerId,checkRegionOffers} from "@util/helpers";
import { loadOffers, loadMemberPendingOffers } from "@services/NewRelic"
import en from "lang/en";
import fr from "lang/fr";
import { getCookie } from "cookies-next";

interface Props {
  headerData: Record<any, any>;
  offerPageData: Record<any, any>;
  myOffers: Record<any, any>;
  domainFilters?: any;
  massoffers?: any;
  host?: any;
  defaultBanner?:string;
}

interface userAccess {
  points: Boolean;
  card: Boolean;
  offers: Boolean;
}

const GetMyOffers: React.FC<Props> = (props: Props) => {
  const router = useRouter();
  const { locale } = router;
  const t = locale === "en" ? en : fr;
  const Auth = useSelector((state: RootStateOrAny) => state.auth);
  const userAccount = useSelector((state: RootStateOrAny) => state.account);
  const Banner = useSelector((state: RootStateOrAny) => state.banner);
  const userPrevilages = useSelector(
    (state: RootStateOrAny) => state.userAccess
  );
  const [allOffers, setAllOffers] = React.useState(null);
  const [filterSelected, setFilterSelected] = React.useState([]);
  const [allActiveOffers, setAllActiveOffers] = React.useState([]);
  const [allFeaturedOffers, setAllFeaturedOffers] = React.useState([]);
  const [pendingOffers, setPendingOffers] = React.useState([]);
  const [featuredOffers, setFeaturedOffers] = React.useState([]);
  const [massOffers, setMassOffers] = React.useState([]);
  const [headlineMassOffers, setHeadlineMassOffers] = React.useState([]);
  const [rdeemedOffers, setRdeemedOffers] = React.useState([]);
  const [expiredOffers, setExpiredOffers] = React.useState([]);
  const [pointsCached, setPointsCached] = React.useState(null);
  const [loadedModal, setLoadedModal] = React.useState(false);
  const [filterOffers, setFilterOffers] = React.useState([]);
  const [filterBanners, setFilterBanners] = React.useState([]);
  /***
   * To set the condition IGA offers load for quebec or not 
   */

  /***
   * Loader set for page api's to load
   */
  const [pageLoader, setPageLoader] = React.useState(true);
  const headerData = props?.headerData;

  const learnMoreCard =
    props?.myOffers?.acf_tru_information_banner[0]?.blockdata[0];

  const productBanners =
    props?.myOffers?.acf_tru_products[0]?.blockdata?.product_taxonomy;
  const option: { id: string; name: string }[] = productBanners;
  const pointsBreakDownMin = userAccount?.value?.nextThreshold - 10;
  const pointsAverage = ((1000 - 0) / 1000) * 100;

/***
 * To check banner is changed or not
 */
let arrayForBanners = [];
React.useEffect(() => {
let bannersSelected = props?.headerData?.acf_tru_taxonomy[0]?.blockdata?.filter(
  (data) => (data?.slug).replaceAll("-", "") === Banner?.value
);
/****
 * Load offers accotding to the filter
 */
let all_filters = bannersSelected[0]?.header_image?.map((data)=> (getBannerId({name:(data?.logo_label).replace(/[^A-Z0-9]/ig, "").toLowerCase()})));
setFilterOffers(all_filters);
/****
 * Banner Array for the filters
 */
let banner_array = (props?.domainFilters?.filterItemsBanners)?.filter((filterData) => (all_filters?.includes(filterData?.value)));
setFilterSelected([]);
setFilterBanners(banner_array);
arrayForBanners = all_filters?.filter((a) => a);
},[Banner])

  /***
   * @function dispatch
   * to use the redux
   */
  const dispatch = useDispatch();
  
  React.useEffect(() => {
    setPointsCached(localStorage.getItem("points_cached"));
   // setMassOffers(props?.massoffers?.slidesHeroMassOffer);
    //setHeadlineMassOffers(props?.massoffers?.headlineMassoffer)
    if (
      Auth?.value?.lpCardNumber != undefined &&
      userPrevilages?.value?.offers
    ) {
      getMemberOffers(Auth?.value?.lpCardNumber, 30, "all", locale)
        .then((data) => {
          if (data?.error) {
            loadOffers(getCookie("personOffersUniqueId"), data?.error?.code, 30, "all", locale)  // initiated newRelic loadOffers event
          } else {
            setAllOffers(data);
          }
          
          loadOffers(getCookie("personOffersUniqueId"), "success", 30, "all", locale, data?.pendingOffers?.length, data?.pendingOffers?.map((obj)=>obj.id), data?.activeOffers?.length, data?.activeOffers?.map((obj)=>obj.id), data?.redeemedOffers?.length, data?.redeemedOffers?.map((obj)=>obj.id), data?.expiredOffers?.length, data?.expiredOffers?.map((obj)=>obj.id))   // initiated newRelic loadOffers event
          
          let allpendingOffers = data?.activeOffers;
          if(data?.pendingOffers?.length > 0) {
          let AllAvailable = data?.pendingOffers?.map((data)=>{ 
          let offerValid =  arrayForBanners.some((itemFilter) => (data?.bannerInd).includes(itemFilter) && checkRegionOffers(props?.domainFilters?.renderFrom,data?.regionalFlag));
          if(offerValid){
            return {"id":data?.id,"channel": "004","banner": props?.defaultBanner??"MYO"} 
          }
          });
          /***
           * Check offers are avaliable for loading
           */
          if(AllAvailable.filter((e)=> e!=null ).length > 0){
          loadMemberOffers(Auth?.value?.lpCardNumber,AllAvailable.filter((e)=> e!=null )).then((dataCard) => {
            if(dataCard?.error){
              loadMemberPendingOffers(getCookie("personOffersUniqueId"), dataCard?.error?.code, 30, "pending offers", locale);
              addDataLayer({event:"load_all_offer",event_param:"-1",param_value:Auth?.value?.lpCardNumber});
            }
            else{
              /**
               * New relic log for the offers loaded
               */
              loadMemberPendingOffers(getCookie("personOffersUniqueId"), "success", 30, "pending offers", locale, AllAvailable.filter((e)=> e!=null )?.length, AllAvailable.filter((e)=> e!=null )?.map((dataPending) => dataPending?.id)); 

              allpendingOffers = [...allpendingOffers,...data?.pendingOffers];
              let allActiveOffers = allpendingOffers?.filter((item) =>
              arrayForBanners.some((itemFilter) => ((item?.bannerInd).includes(itemFilter) && item?.featuredReward === false && checkRegionOffers(props?.domainFilters?.renderFrom,item?.regionalFlag)))
               );
              setPendingOffers(allActiveOffers);
              setAllActiveOffers(allActiveOffers);
              setLoadedModal(true);
              let allfeatureOffers = allpendingOffers?.filter((item) =>
                arrayForBanners.some((itemFilter) => ((item?.bannerInd).includes(itemFilter) && item?.featuredReward === true && checkRegionOffers(props?.domainFilters?.renderFrom,item?.regionalFlag)))
              );
             setFeaturedOffers(allfeatureOffers);
             setAllFeaturedOffers(allfeatureOffers);
             //added data in data layer
             addDataLayer({event:"load_all_offer",event_param:data?.pendingOffers?.length,param_value:Auth?.value?.lpCardNumber});
            }
            
          }).catch((error) => {

          })
        }
           }
           else{
             //push in the data layer if no offer loaded
            addDataLayer({event:"load_all_offer",event_param:"0",param_value:Auth?.value?.lpCardNumber});
           }
          /***
           * Get pending offers and remove featured offers from that
           */

          let allActiveOffers = allpendingOffers?.filter((item) =>
            arrayForBanners.some((itemFilter) => ((item?.bannerInd).includes(itemFilter) && item?.featuredReward === false && checkRegionOffers(props?.domainFilters?.renderFrom,item?.regionalFlag)))
          );
          setPendingOffers(allActiveOffers);
          setAllActiveOffers(allActiveOffers);
          /***
           * Get pending offers with featured offers
           */
          let allfeatureOffers = allpendingOffers?.filter((item) =>
            arrayForBanners.some((itemFilter) => ((item?.bannerInd).includes(itemFilter) && item?.featuredReward === true && checkRegionOffers(props?.domainFilters?.renderFrom,item?.regionalFlag)))
          );
          setFeaturedOffers(allfeatureOffers);
          setAllFeaturedOffers(allfeatureOffers);
          /***
           * Get expired offres according to banners of website
           */
          let allexpiredOffers = data?.expiredOffers?.filter((item) =>
            arrayForBanners.some(
              (itemFilter) => ((item?.bannerInd).includes(itemFilter) && checkRegionOffers(props?.domainFilters?.renderFrom,item?.regionalFlag))
            )
          );
          setExpiredOffers(allexpiredOffers);
          /***
           * Get redemed offres according to banners of website
           */
          let allredemmedOffers = data?.redeemedOffers?.filter((item) =>
            arrayForBanners.some(
              (itemFilter) => ((item?.bannerInd).includes(itemFilter) && checkRegionOffers(props?.domainFilters?.renderFrom,item?.regionalFlag))
            )
          );
          setRdeemedOffers(allredemmedOffers);
        })
        .finally(() => {
          setPageLoader(false);
        });
    
    } else if (userPrevilages?.value != undefined) {
      setPageLoader(false);
    }
  }, [userPrevilages?.value?.card, Auth?.value?.lpCardNumber,Banner?.value]);

  React.useEffect(() => {
    if(userPrevilages?.value?.offers === true){
 getMassOffers().then((data) => {
      setMassOffers(data?.data?.slidesHeroMassOffer);
      setHeadlineMassOffers(data?.data?.headlineMassoffer)
    });
  }
  },[userPrevilages?.value?.offers,Banner?.value]);
  const OfferSliderLength = featuredOffers?.length;
  let offersSlider = {
    slidesToShow: 4,
    centerPadding: "0",
    infinite: (OfferSliderLength > 4) ? true : false,
    nextArrow: <SlickCircleNextArrow />,
    prevArrow: <SlickCirclePrevArrow />,
    dots: false,
    responsive: [
      {
        breakpoint: 1200,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,
          infinite: featuredOffers?.length > 3 ? true : false,
        },
      },
      {
        breakpoint: 991,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
          infinite: featuredOffers?.length > 1 ? true : false,
        },
      },
      {
        breakpoint: 767,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          infinite: true,
          centerPadding: "25%",
          centerMode:true,
        },
      },
      {
        breakpoint: 576,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          infinite: true,
          centerPadding: "60px",
          centerMode:true,
        },
      },
      {
        breakpoint: 479,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          infinite: true,
          centerPadding: "50px",
          centerMode:true,
        },
      },
      {
        breakpoint: 413,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          infinite: true,
          centerPadding: "10px",
          centerMode:true,
        },
      },
    ],
  };
  /***
   * This is for testing
   */
  const offersTypesArray = [
    "11",
    "12",
    "13",
    "14",
    "15",
    "16",
    "17",
    "18",
    "19",
    "20",
    "21",
    "22",
    "23",
    "24",
    "25",
    "26",
    "27",
  ];

  const lists = [
    {
      listName: "Custom offers personalized to suit your shopping habits.",
    },
    {
      listName:
        "Earn with any Sobeys family brand and combine with other great deals.",
    },
    {
      listName:
        "Redeem in store or use your points for amazing rewards with our partners.",
    },
  ];

  const allMassOffers = [
    {
      imageUrl: "/gifts-card-promo.svg",
      headlineText: "Out with the Old. In with the Blue",
      descriptionText: "Save up to 15%",
      ctaLabel: "Learn More",
      ctaUrl: "#",
    },
    {
      imageUrl: "/chance-to-win.svg",
      headlineText: "Shop. Enter. Win",
      descriptionText: "Chance to win 1 of 3 FREE groceries for a year",
      ctaLabel: "Learn More",
      ctaUrl: "link",
    },
    {
      imageUrl: "/turmeric-black-pepper-dressing.svg",
      headlineText: "Turmeric & Black Pepper dressing",
      descriptionText: "Save up to 15%",
      ctaLabel: "Learn More",
      ctaUrl: "link",
    },
  ];

  let dataFilter = allOffers;
  let filterValue = filterSelected;
  let allData = dataFilter;

  const filterSelect = (e) => {
    if (e.target.checked) {
      if (!e.target.value) {
        filterValue = filterBanners?.map((data) => data?.value);
      } else {
        filterValue.push(e.target.value);
        /***
         * Checked all if all options selected
         */
        if(filterValue.length >= (filterBanners.length -1)){
          filterValue = filterBanners?.map((data) => data?.value);
        }
      }
    } else {
      if (!e.target.value) {
        filterValue = [];
      } else {
        let itemToBeRemoved = [e.target.value];
        filterValue = filterValue.filter(function (el) {
          return el != "";
        });
        filterValue = filterValue.filter(
          (item) => !itemToBeRemoved.includes(item)
        );
        
      }
    }
    setFilterSelected([...filterValue]);
    if (filterValue.length > 0) {
      let allData = allActiveOffers?.filter((item) =>
        filterValue
          .filter((a) => a)
          .some((itemFilter) => (item?.bannerInd).includes(itemFilter))
      );
      let allFeatured = allFeaturedOffers?.filter((item) =>
        filterValue
          .filter((a) => a)
          .some((itemFilter) => (item?.bannerInd).includes(itemFilter))
      );
      setPendingOffers(allData);
      setFeaturedOffers(allFeatured);
    } else {
    setPendingOffers(allActiveOffers);
      setFeaturedOffers(allFeaturedOffers);
    }
  };
  return (
    <>
      <Header headerData={headerData} offerData={props?.offerPageData} host={props?.domainFilters}/>
      <SeoMeta 
      title={props?.myOffers?.acf_tru_seometa?.[0]?.blockdata?.[0]?.browserList?.[process?.env?.NEXT_PUBLIC_GIGYA_BRAND]?.title}
      description={props?.myOffers?.acf_tru_seometa?.[0]?.blockdata?.[0]?.browserList?.[process?.env?.NEXT_PUBLIC_GIGYA_BRAND]?.browserMetaDescription}
      keywords={props?.myOffers?.acf_tru_seometa?.[0]?.blockdata?.[0]?.browserList?.[process?.env?.NEXT_PUBLIC_GIGYA_BRAND]?.browserMetaKeywords}
      />

      {Auth?.value && !pageLoader ? (
        <>
          <SectionBoxed className="profileBanner">
            <Row>
              <Col sm={7}>
                <Text as="h1"  id="start-of-content" tabIndex={0}>
                  <UserTime />
                  <Text as="span">{Auth?.value?.firstName}</Text>
                </Text>
                {userAccount?.value &&
                  !userAccount?.value.error &&
                  userPrevilages?.value?.points && (
                    <>
                      {" "}
                      <Text as="div" className="profileBannerPoints" tabIndex={0}>
                        {userAccount?.value && (
                          <Text as="p">
                            ${userAccount?.value?.dollarValue}{" "}
                            <span>
                              <img
                                className="logo-symbol"
                                src="/points-dot-top-menu.svg"
                                alt="points"
                                height="24"
                                width="24"
                              />{" "}
                              {(userAccount?.value?.pointBalance).toLocaleString()}{" "}
                              {t.pts}
                            </span>
                            {/* )} */}
                          </Text>
                        )}
                      </Text>
                    </>
                  )}
                   <Text as="p" className="hideOnMobile" tabIndex={0}>
                   {t.weekOffer}
                      </Text>
              </Col>
              {userAccount?.value &&
                !userAccount?.value.error &&
                userPrevilages?.value?.points && (
                  <Col sm={5}>
                    <div className="CustomProgessContainer">
                      <CustomProgressbar
                        points={`${userAccount?.value?.pointBalance}`}
                        currentPoints={
                          userAccount?.value?.pointBalance
                            ? userAccount?.value?.pointBalance
                            : 0
                        }
                        minValue={`${
                          Number.isNaN(userAccount?.value?.dollarValue)
                            ? 0
                            : userAccount?.value?.dollarValue
                        }`}
                        midValue={`${
                          Number.isNaN(userAccount?.value?.nextThreshold)
                            ? 0
                            : userAccount?.value?.nextThreshold
                        }`}
                        maxValue={`${
                          Number.isNaN(userAccount?.value?.nextThreshold)
                            ? 0
                            : userAccount?.value?.nextThreshold + 10
                        }`}
                        barValue={pointsAverage > 0 ? pointsAverage : 10}
                        cachedPoints={localStorage.getItem("points_cached")}
                        showAnimation={true}
                      />
                      {userAccount?.value?.pointsToNextThreshold && (
                        <Text as="p">
                         <span tabIndex={0}> {t.youAre}{" "}
                          {`${(userAccount?.value?.pointsToNextThreshold).toLocaleString()} PTS`}{" "}
                          {t.away_from} ${userAccount?.value?.nextThreshold}{" "}</span>
                          {props?.myOffers?.acf_tru_inner_header[1]
                            ?.blockdata && (
                            <Link
                              href={
                                props?.myOffers?.acf_tru_inner_header[1]
                                  ?.blockdata[0]?.action_properties[0]?.link
                                  ?.url
                              }
                            >
                              <a
                                className="simple-link"
                                tabIndex={0}
                                target={
                                  props?.myOffers?.acf_tru_inner_header[1]
                                    ?.blockdata[0]?.action_properties[0]?.link
                                    ?.target
                                }
                                aria-label={props?.myOffers?.acf_tru_inner_header[1]
                                  ?.blockdata[0]?.action_properties[0]
                                  ?.arialabel}
                              >
                               
                                {
                                  props?.myOffers?.acf_tru_inner_header[1]
                                    ?.blockdata[0]?.action_properties[0]?.label
                                }
                              </a>
                            </Link>
                          )}
                        </Text>
                      )}
                    </div>
                  </Col>
                )}
            </Row>
          </SectionBoxed>
          <SectionFluid className="tabContainer">
          {/* New Tab */}
            <CustomTabs className="horizontal offers-page" defaultValue="loaded">
              <CustomTabList>
                <div className="container">
                  <CustomTab value="loaded">
                    <Image src="/loaded-black.svg" alt="Offers Loaded Icon" width={24} height={17} />
                    {t.loaded}
                  </CustomTab>
                  <CustomTab value="redeemed">
                    <Image src="/reedemed-black.svg" alt="Offers Reedemed Icon" width={24} height={20} />
                    {t.redeemed}
                  </CustomTab>
                  <CustomTab value="expired">
                    <Image src="/expired-black.svg" alt="Offers Expired Icon" width={24} height={20} />
                    {t.expired}
                  </CustomTab>
                </div>
              </CustomTabList>
              <CustomTabPanels>
                  {userPrevilages?.value?.offers && Auth?.value?.lpCardNumber ? (
                <>
                  <CustomTabPanel key="Loaded" value="loaded" className={`${pendingOffers?.length > 0 ?'offersloadedfirst':''}`}>
                     {(allFeaturedOffers?.length > 0 && featuredOffers?.length) > 0 && (
                    <SectionBoxed className="fluid pb-18 featuredOffers">
                      <Row>
                        <Col xs={12} className="featuredOffersTitle">
                          {props?.myOffers && allFeaturedOffers?.length > 0 && (
                            <SectionTitle
                              className="offersTitle"
                              tabIndex={0}
                              title={
                                props?.myOffers?.acf_tru_products[0]?.blockdata
                                  ?.Loaded?.innerdata_0?.title
                              }
                              belowTabIndex={0}
                              belowTitle={
                                props?.myOffers?.acf_tru_products[0]?.blockdata
                                  ?.Loaded?.innerdata_0?.subtitle
                              }
                            />
                          )}
                          <Text className="selectContainer">
                            <FilterSelect
                              label="Filter Offers By Banner"
                              itemsList={filterBanners}
                              onClick={filterSelect}
                              selectedItems={filterSelected}
                            />
                          </Text>
                        </Col>
                      </Row>
                      {featuredOffers?.length > 0 ? (
                        <Slider
                          {...offersSlider}
                          className={`offersSliderList arrow-in-bottom brandCard 
                          ${(featuredOffers?.length === 1)?'hide-arrows':''}
                          `}
                        >
                          {featuredOffers?.map((products, index) => {
                            return (
                              <div key={`pending_offers${index}`}  id={products?.id}>
                                {offersTypesArray.indexOf(
                                  products?.offerType
                                ) !== -1 ? (
                                  <SwitchOfferType
                                    allProps={products}
                                    type={products?.offerType}
                                  />
                                ) : (
                                  <OffersCardNew
                                    title={products?.description}
                                    tag={`test`}
                                    tagHeadline={`testing offers`}
                                    mainImage={products?.imageName}
                                    brandImages={products?.bannerInd}
                                    termsText={`Terms & Conditions`}
                                    termsLink={`terms`}
                                    termsTarget={``}
                                    expireDate={"2023/11/01"}
                                  />
                                )}
                              </div>
                            );
                          })}
                        </Slider>
                      ) : (
                        <OfferNotFound
                            image={props?.offerPageData?.acf_tru_content_editor?.[0]?.blockdata?.[1]?.image?.src}
                            title={props?.offerPageData?.acf_tru_content_editor?.[0]?.blockdata?.[1]?.sub_title}
                            belowTitle={props?.offerPageData?.acf_tru_content_editor?.[0]?.blockdata?.[1]?.description}
                        />
                      )}
                    </SectionBoxed>
                    )}
                    <SectionBoxed className={`fluid ${(allFeaturedOffers?.length || featuredOffers?.length) === 0 ? 'featuredOffers':'offersSection'}`}>
                      <Row>
                        <Col xs={12}>
                          {props?.myOffers && (
                            <SectionTitle
                              className="offersTitle"
                              tabIndex={0}
                              title={
                                props?.myOffers?.acf_tru_products[0]?.blockdata
                                  ?.Loaded?.innerdata_1?.title
                              }
                              belowTabIndex={0}
                              belowTitle={
                                props?.myOffers?.acf_tru_products[0]?.blockdata
                                  ?.Loaded?.innerdata_1?.subtitle
                              }
                            />
                          )}
                        </Col>
                      </Row>
                      {(featuredOffers?.length ) === 0 && (
                      <Text className="selectContainer">
                            <FilterSelect
                              label="Filter Offers By Banner"
                              itemsList={filterBanners}
                              onClick={filterSelect}
                              selectedItems={filterSelected}
                            />
                          </Text>
                          )}
                      <Row className="offersList">
                        {pendingOffers?.length > 0 ? (
                          pendingOffers?.map((products, index) => {
                            return (
                              <Col
                                sm={6}
                                md={4}
                                lg={3}
                                className="offerGrid"
                                key={`pending_offers_product${index}`}
                                id={products?.id}
                              >
                                {offersTypesArray.indexOf(
                                  products?.offerType
                                ) !== -1 ? (
                                  <SwitchOfferType
                                    allProps={products}
                                    type={products?.offerType}
                                  />
                                ) : (
                                  <OffersCardNew
                                    title={products?.description}
                                    tag={`test`}
                                    tagHeadline={`testing offers`}
                                    mainImage={products?.imageName}
                                    brandImages={products?.bannerInd}
                                    termsText={`Terms & Conditions`}
                                    termsLink={`terms`}
                                    termsTarget={``}
                                    expireDate={"2023/11/01"}
                                  />
                                )}
                              </Col>
                            );
                          })
                        ) : (
                          <OfferNotFound
                            image={props?.offerPageData?.acf_tru_content_editor?.[0]?.blockdata?.[1]?.image?.src}
                            title={props?.offerPageData?.acf_tru_content_editor?.[0]?.blockdata?.[1]?.sub_title}
                            belowTitle={props?.offerPageData?.acf_tru_content_editor?.[0]?.blockdata?.[1]?.description}
                          />
                        )}
                      </Row>
                    </SectionBoxed>
                    {massOffers.length > 0 && <SectionBoxed className={`fluid  ${allFeaturedOffers?.length === 0 ? 'offersSection masofferpoint':''}`}>
                    <MassOffers massOffers={massOffers} headlineMassOffers={headlineMassOffers}/>
                    </SectionBoxed>}
                  </CustomTabPanel>
                  <CustomTabPanel key="Redeemed" value="redeemed" className={`${rdeemedOffers?.length > 0 ?'offersloaded':''}`}>
                    <Container size="lg">
                      <Row className="offersList">
                        {rdeemedOffers?.length > 0 ? (
                          rdeemedOffers?.map((products, index) => {
                            return (
                              <Col
                                sm={6}
                                md={4}
                                lg={3}
                                className="offerGrid"
                                key={`all_offers${index}`}
                                id={products?.id}
                              >
                                {offersTypesArray.indexOf(
                                  products?.offerType
                                ) !== -1 ? (
                                  <SwitchOfferType
                                    allProps={products}
                                    type={products?.offerType}
                                  />
                                ) : (
                                  <OffersCardNew
                                    title={products?.description}
                                    tag={`test`}
                                    tagHeadline={`testing offers`}
                                    mainImage={products?.imageName}
                                    brandImages={products?.bannerInd}
                                    termsText={`Terms & Conditions`}
                                    termsLink={`terms`}
                                    termsTarget={``}
                                    expireDate={"2023/11/01"}
                                  />
                                )}
                              </Col>
                            );
                          })
                        ) : (
                          <OfferNotFound
                            image={props?.offerPageData?.acf_tru_content_editor?.[0]?.blockdata?.[2]?.image?.src}
                            title={props?.offerPageData?.acf_tru_content_editor?.[0]?.blockdata?.[2]?.sub_title}
                            belowTitle={props?.offerPageData?.acf_tru_content_editor?.[0]?.blockdata?.[2]?.description}
                          />
                        )}
                      </Row>
                    </Container>
                  </CustomTabPanel>
                  <CustomTabPanel key="Expired" value="expired" className={`${expiredOffers?.length > 0 ?'offersloaded':''}`}>
                     <Container size="lg">
                      <Row className="offersList">
                        {expiredOffers?.length > 0 ? (
                          expiredOffers?.map((products, index) => {
                            return (
                              <Col
                                sm={6}
                                md={4}
                                lg={3}
                                className="offerGrid"
                                key={`expired_offers${index}`}
                                id={products?.id}
                              >
                                {offersTypesArray.indexOf(
                                  products?.offerType
                                ) !== -1 ? (
                                  <SwitchOfferType
                                    allProps={products}
                                    type={products?.offerType}
                                  />
                                ) : (
                                  <OffersCardNew
                                    title={products?.description}
                                    tag={`test`}
                                    tagHeadline={`testing offers`}
                                    mainImage={products?.imageName}
                                    brandImages={products?.bannerInd}
                                    termsText={`Terms & Conditions`}
                                    termsLink={`terms`}
                                    termsTarget={``}
                                    expireDate={"2023/11/01"}
                                  />
                                )}
                              </Col>
                            );
                          })
                        ) : (
                          <OfferNotFound
                            image={props?.offerPageData?.acf_tru_content_editor?.[0]?.blockdata?.[3]?.image?.src}
                            title={props?.offerPageData?.acf_tru_content_editor?.[0]?.blockdata?.[3]?.sub_title}
                            belowTitle={props?.offerPageData?.acf_tru_content_editor?.[0]?.blockdata?.[3]?.description}
                          />
                        )}
                      </Row>
                    </Container>
                  </CustomTabPanel>
                </>
              ) : (
                <>
                  {
                    <>
                      {Auth?.value?.lpCardNumber ? (
                        <OfferNotFound
                          image={props?.offerPageData?.acf_tru_content_editor?.[0]?.blockdata?.[1]?.image?.src}
                          title={props?.offerPageData?.acf_tru_content_editor?.[0]?.blockdata?.[1]?.sub_title}
                          belowTitle={props?.offerPageData?.acf_tru_content_editor?.[0]?.blockdata?.[1]?.description}
                        />
                      ) : (
                        <>
                        <CardNotFound
                          CardNotFoundheading={props?.offerPageData?.acf_tru_modal?.[3]?.blockdata?.[0]?.title}
                          CardNotFoundlists={props?.offerPageData?.acf_tru_modal?.[3]?.blockdata?.[0]?.modalcontent}
                          CardNotFoundbutton={props?.offerPageData?.acf_tru_modal?.[3]?.blockdata?.[0]?.actionproperties?.[0]?.label}
                          CardNotFoundLink={props?.offerPageData?.acf_tru_modal?.[3]?.blockdata?.[0]?.actionproperties?.[0]?.link.url}
                          CardNotFoundImage={props?.offerPageData?.acf_tru_modal?.[3]?.blockdata?.[0]?.image_group?.[0]?.image?.src}
                          CardNotFoundImageAlt={props?.offerPageData?.acf_tru_modal?.[3]?.blockdata?.[0]?.image_group?.[0]?.image?.alt}
                          CardNotFoundDataGtm={props?.offerPageData?.acf_tru_modal?.[3]?.blockdata?.[0]?.actionproperties?.[0]?.datagmt}
                          CardNotFoundButtonId={props?.offerPageData?.acf_tru_modal?.[3]?.blockdata?.[0]?.actionproperties?.[0]?.buttonId}
                          CardNotFoundAriaLabel={props?.offerPageData?.acf_tru_modal?.[3]?.blockdata?.[0]?.actionproperties?.[0]?.aria_label}
                        />
                        <MassOffers massOffers={massOffers} headlineMassOffers={headlineMassOffers}/>
                        </>
                      )}

                    </>
                  }
                </>
              )}
              </CustomTabPanels>
            </CustomTabs>

            {/* old tab */}
         
          </SectionFluid>
          {/* Tab Section End Here */}

          <FooterAboveCard
            className="bgNone getMyOfferFooter"
            title={learnMoreCard?.title}
            subTitle={learnMoreCard?.subtitle}
            description={learnMoreCard?.description}
            actionButtons={learnMoreCard?.action_properties}
            topRightImage={learnMoreCard?.image_content[0]?.image}
            topLeftImage={learnMoreCard?.image_content[1]?.image}
          />
        </>
      ) : (
        <>
          <Loader />
        </>
      )}

      <Footer footerData={headerData} />
      {/* Footer Above Card end */}
      {loadedModal && (
        
        <Text as="div" className="loadedModalContainer"> 
        <Modal
          closeIcon={<Image alt="close_icon" src="/icons/close.svg" layout="fixed" height={13} width={13} />}
          onClick={() => setLoadedModal(!loadedModal)}
          className={" modaltest loadedModal"}>
            <Text className="inner">
              <Image src="/loaded-cart.svg" width={118} height={111} />
              <Text as="h3">{t.automaticLoad}</Text>
              <Link href="#" >
                <a className="themeBtn" onClick={() => setLoadedModal(!loadedModal)}>Dismiss</a>
              </Link>
            </Text>
        </Modal>
        </Text>
      )}
    </>
  );
};
export default React.memo(GetMyOffers);
