import React from "react";
import Image from "@templates/ImageConversion";
import parse from "html-react-parser";
import { Text } from '@components';
import { GetBannerImage, getImageName, getNumberOfDays, getDate, expiredDaysOffers } from "@services/Offers"
interface cardProps {
    offerIconText1?: string;
    tagPtsText?: string;
    description?: string;
    imageName?: string;
    bannerInd?: string;
    tcsDescription?: string;
    termsText?: string;
    endDate?: string;
    startDate: string;
    offerActiveClass?: string;
    daysLeft?:number;
}
const OfferType27 = React.forwardRef<
    HTMLDivElement,
    React.PropsWithChildren<cardProps>
>(({ children, ...props }, ref) => {

    const [offerClick, setOfferClick] = React.useState(false);
    const offerClickHandler = () => {
        setOfferClick(true);
    }
    const offerClickHandlerHide = () => {
        setOfferClick(false);
    }
    const onOfferKeyDown = (e: { key: string }) =>{
        if(e.key === 'Enter'){
            setOfferClick(true);
        }
    }
    const onOfferKeyDownHide = (e: { key: string }) =>{
        if(e.key === 'Enter'){
            setOfferClick(false);
        }
    }
    return (

        <Text as="div" className={`offersCard ${offerClick ? "active" : ""}`}>
            <Text as="header" className="offersCardHeader">
             <Text as="p" tabIndex={0}>{parse(`${(`Custom Offer`)}`)}</Text>
            </Text>
            <Text as="div" className="offersCardThumb">
                <Text as="p" colorScheme="accent" tabIndex={0}>
                {props?.endDate && parse(expiredDaysOffers(props?.daysLeft,getDate(props?.endDate)?.dateShort,props?.endDate)) }
                </Text>
                <Text as="div" className="offersCardThumbImg">
                    {props?.imageName &&  <Image src={getImageName(props?.imageName)} layout="fill" objectFit="contain"  role="presentation" />
}
                </Text>
            </Text>
            <Text as="div" className="offersCardContent">
                <Text as="h3" colorScheme="accent" tabIndex={0}>{props?.description && parse(props?.description)}</Text>
            </Text>
            <Text as="div" className="offersCardBrand">
                <Text as="div" className="offersCardBrandInner">
                    {props?.bannerInd &&
                        (<GetBannerImage bannerInd={props?.bannerInd} />)}
                </Text>
                <button className="linkText" onKeyDown={(e) => onOfferKeyDown(e)} tabIndex={0} onClick={offerClickHandler}>{props?.termsText}</button>
            </Text>
            <Text as="div" className={`offersCardHover ${offerClick ? 'active' : ''}`}>
                <div className="offersCardHoverHeader">
                    <button tabIndex={offerClick ? 0 : -1}  onKeyDown={(e) => onOfferKeyDownHide(e)}  onClick={offerClickHandlerHide}><Image alt="arrow up" src="/fill-arrow-up.svg" height={11} width={18} /></button>
                    <h4 tabIndex={offerClick ? 0 : -1}>{props?.termsText}</h4>
                </div>
                <div className="offersCardHoverContent">
                <p tabIndex={offerClick ? 0 : -1}> {props?.tcsDescription && parse(props?.tcsDescription)}</p>
                </div>
                <div className="offersCardHoverFooter">
                    {props?.startDate && <p tabIndex={offerClick ? 0 : -1}>
                        Starts: <strong>{getDate(props?.startDate)?.dateFull}</strong>
                    </p>
                    }
                    {props?.endDate && <p tabIndex={offerClick ? 0 : -1}>
                        Expires: <strong>{getDate(props?.endDate)?.dateFull}</strong>
                    </p>}
                </div>
            </Text>
        </Text>
    )
});
export default OfferType27;