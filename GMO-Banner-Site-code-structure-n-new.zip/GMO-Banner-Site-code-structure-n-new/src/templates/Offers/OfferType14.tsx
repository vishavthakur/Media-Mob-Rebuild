import React from "react";
import Image from "@templates/ImageConversion";
import parse from "html-react-parser";
import { Text } from '@components';
import { GetBannerImage, getImageName, getNumberOfDays, getDate, GetProgressBarHtml,GetTransactionLimitHtml,SplitAmount,expiredDaysOffers } from "@services/Offers"
interface cardProps {
    offerIconText1?: string;
    tagPtsText?: string;
    description?: string;
    imageName?: string;
    bannerInd?: string;
    tcsDescription?: string;
    termsText?: string;
    endDate?: string;
    startDate: string;
    offerActiveClass?: string;
    offerLimits?: any;
    daysLeft?:number;
}
const OfferType14 = React.forwardRef<
    HTMLDivElement,
    React.PropsWithChildren<cardProps>
>(({ children, ...props }, ref) => {
    
    const [offerClick, setOfferClick] = React.useState(false);
    const offerClickHandler = () => {
        setOfferClick(true);
    }
    const offerClickHandlerHide = () => {
        setOfferClick(false);
    }
    const onOfferKeyDown = (e: { key: string }) =>{
        if(e.key === 'Enter'){
            setOfferClick(true);
        }
    }
    const onOfferKeyDownHide = (e: { key: string }) =>{
        if(e.key === 'Enter'){
            setOfferClick(false);
        }
    }
    return (

        <Text as="div" className={`offersCard ${offerClick ? "active" : ""}`}>
            <Text as="div" className="offersCardHeader">
            <span className="offerTags" tabIndex={0}>
                {props?.offerIconText1 && <Text as="span" className="tag save">Save</Text>}
                {props?.offerIconText1 && <Text as="p"> <SplitAmount amount={props?.offerIconText1}/> off</Text>}
                </span>
            </Text>
            <Text as="div" className="offersCardThumb">
                <Text as="p" colorScheme="accent"  tabIndex={0}>
                {props?.endDate && parse(expiredDaysOffers(props?.daysLeft,getDate(props?.endDate)?.dateShort,props?.endDate)) }
                </Text>
                <Text as="div" className="offersCardThumbImg">
                   {props?.imageName && <Image src={getImageName(props?.imageName)} layout="fill" objectFit="contain"  role="presentation" />} 
                </Text>
            </Text>
            <Text as="div" className="offersCardContent">
                <Text as="h3" colorScheme="accent"  tabIndex={0}>{parse(props?.description)}</Text>
            </Text>
            <Text as="div" className={`offersCardBrand ${(props?.offerLimits?.customer.limit > 1 || props?.offerLimits?.transaction?.limit > 1)?`ActiveIndicator`:``}`}>
        {(props?.offerLimits?.customer && props?.offerLimits?.customer.limit > 1) && GetProgressBarHtml({ progress: props?.offerLimits?.customer.progress, limit: props?.offerLimits?.customer.limit })}
        {(props?.offerLimits?.transaction && props?.offerLimits?.transaction?.limit > 1)  && GetTransactionLimitHtml({progress:props?.offerLimits?.transaction.progress,limit:props?.offerLimits?.transaction.limit})}
        <Text as="div" className="offersCardBrandInner">
          {props?.bannerInd && <GetBannerImage bannerInd={props?.bannerInd} />}
        </Text>
        <button className="linkText" onKeyDown={(e) => onOfferKeyDown(e)} tabIndex={0} onClick={offerClickHandler}>
          {props?.termsText}
        </button>
      </Text>
            <Text as="div" className={`offersCardHover ${offerClick ? 'active' : ''}`}>
                <div className="offersCardHoverHeader">
                    <button tabIndex={offerClick ? 0 : -1}  onKeyDown={(e) => onOfferKeyDownHide(e)}  onClick={offerClickHandlerHide}><Image alt="arrow up" src="/fill-arrow-up.svg" height={11} width={18} /></button>
                    <h4 tabIndex={offerClick ? 0 : -1}>{props?.termsText}</h4>
                </div>
                <div className="offersCardHoverContent">
                <p tabIndex={offerClick ? 0 : -1}> {props?.tcsDescription && parse(props?.tcsDescription)}</p>
                </div>
                <div className="offersCardHoverFooter">
                    {props?.startDate && <p tabIndex={offerClick ? 0 : -1}>
                        Starts: <strong>{getDate(props?.startDate)?.dateFull}</strong>
                    </p>
                    }
                    {props?.endDate && <p tabIndex={offerClick ? 0 : -1}>
                        Expires: <strong>{getDate(props?.endDate)?.dateFull}</strong>
                    </p>}
                </div>
            </Text>
        </Text>
    )
});
export default OfferType14;