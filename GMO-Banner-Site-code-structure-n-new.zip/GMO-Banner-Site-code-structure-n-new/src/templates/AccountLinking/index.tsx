
import Image from "@templates/ImageConversion";
import Link from "next/link";
import Router,{useRouter} from "next/router";
import parse from "html-react-parser";
import { ExternalLink } from "react-feather";
import React from "react";
import { getCookie } from "cookies-next";
import { addCookie } from "@util/manageCookies";
import { useSelector, RootStateOrAny, useDispatch } from "react-redux";
import { Text, Modal } from "@components";
import { SceneCard, Loader } from "@templates";
import { LINKAGE_ACCOUNT, USER_ACCESS } from "@redux/actions/authActions";
import { GigyaObject,gigyaLoggedIn } from "@services/Gigya";
import { BreakPoints } from "@util/units";
import { responseAccount } from "@util/mulesoftResponses";
import { USER_AUTH } from "../../redux/actions/authActions";
import Bus from "@util/Bus";
import {addDataLayer} from "@util/helpers";
import en from "lang/en";
import fr from "lang/fr";
import {
  accountStatus,
  linkAccount,
  getMemberDetail
} from "@services/Mulesoft";
interface Props {
  offerPageData: Record<any, any>;
}
import { promptDisplay, promptDismiss, promptRemindLater, enquireEnrolment, accountVerificationInitiated } from "@services/NewRelic"

interface userAccess {
  points: Boolean;
  card: Boolean;
  offers: Boolean;
  ghost?: Boolean;
  closed?: Boolean;
}

/**
 * @function HeaderVerify
 * Header with logo only
 */
export const AccountLinkingData = React.forwardRef<
  HTMLDivElement,
  React.PropsWithChildren<Props>
>(({ children, ...props }, ref) => {
  const Auth = useSelector((state: RootStateOrAny) => state.auth);
  const userAccount = useSelector((state: RootStateOrAny) => state.account);
  const userPrevilages = useSelector(
    (state: RootStateOrAny) => state.userAccess
  );
  const routerLocale = useRouter();
  const { locale } = routerLocale; 
  const t = locale === "en" ? en : fr;
  /***** End show contact modal  */
  const pageData = props?.offerPageData;

  const {
    0: verifyCard,
    1: addCard,
    2: registerCard,
  } = pageData?.acf_tru_modal;
  const imagePopup = verifyCard ? verifyCard?.blockdata[0]?.image_group[0] : {};
  const imagePopupAddCard = addCard
    ? addCard?.blockdata[0]?.image_group[0]
    : {};
  const [addCardModal, setAddCardModal] = React.useState(false);
  const [offersModal, setOffersModal] = React.useState(false);
  const [registerModal, setRegisterModal] = React.useState(false);
  const [registerCardError, setRegisterCardError] = React.useState(null);
  const [verifyCardActive, setVerifyCardActive] = React.useState(false);
  const [userActions, SetUserActions] = React.useState({});
  const [bannerSelected, SetBannerSelected] = React.useState("");
  const pointsBreakDownMin = userAccount?.value?.nextThreshold - 10;
  const pointsAverage =
    ((userAccount?.value?.nextThreshold -
      pointsBreakDownMin -
      (userAccount?.value?.nextThreshold - userAccount?.value?.dollarValue)) /
      10) *
    100;

  /***
   * @function dispatch
   * to use the redux
   */
  const dispatch = useDispatch();

  const handleVerifyCard = () => {
    setVerifyCardActive(true);
    Router.push(`${process.env.NEXT_PUBLIC_REGISTER_VERIFYCARD_SLUG}`);
  };
  /**** Handle account status and popups
   * @function handleAccountStatus
   * @param cardNumber
   */
  const handleAccountStatus = (
    userCardNumber: string,
    repeat?: Boolean,
    ghostSubmit?: Boolean
  ) => {
    accountStatus(userCardNumber,(Router?.query?.bypass as string)).then((data) => {
      if (data?.error) {
        enquireEnrolment(getCookie("personOffersUniqueId"), data?.error?.code);  //initiated newRelic enquireEnrolment event
        console.log("error in card number");
        globalThis.flash(
          `${t.errorInCard}`,
          "danger"
        );
      } else {
        enquireEnrolment(getCookie("personOffersUniqueId"), "success", data.enrollmentStatusCode);  //initiated newRelic enquireEnrolment event
        if (responseAccount[data.enrollmentStatusCode] === "contact") {
          if (data.enrollmentStatusCode === "LP00") {
            addUserAccess({
              points: false,
              offers: false,
              card: false,
              ghost: false,
              closed: true,
            });
            globalThis.flash(`${t.cardClosed}`, "danger");
          } else {
            /**** In case of suspended *****/

            addUserAccess({
              points: false,
              offers: true,
              card: false,
              ghost: false,
              closed: true,
            });
            if (
              Router.pathname ===
              `${process.env.NEXT_PUBLIC_REGISTER_VERIFYCARD_SLUG}`
            ) {
              Router.push("/");
            }
            globalThis.flash(`${t.cardSuspended}`, 'danger');
            Bus.emit('hideNotification', ({ type:"suspended" }));
          }
        } else if (responseAccount[data.enrollmentStatusCode] === "verify") {
          /****
           * for the linked status true
           */
          if (Auth?.value?.lpLinkedStatus === true) {
            addUserAccess({
              points: true,
              offers: true,
              card: true,
              ghost: false,
              closed: false,
            });
            if (
              Router.pathname ===
              `${process.env.NEXT_PUBLIC_REGISTER_VERIFYCARD_SLUG}`
            ) {
              Router.push("/");
            }
          } else if (Auth?.value?.lpLinkedStatus === false) {
            /****
             * for the linked status false
             */
            addUserAccess({
              points: false,
              offers: true,
              card: false,
              ghost: false,
              closed: false,
            });
            if (
              Router.pathname ===
              `${process.env.NEXT_PUBLIC_REGISTER_VERIFYCARD_SLUG}`
            ) {
              if (Auth?.value?.lpCardNumber) {
                linkAccount(Auth?.value?.lpCardNumber, Auth?.value?.guid).then(
                  (data) => {
                    if (data?.error) {
                      dispatch({
                        type: LINKAGE_ACCOUNT,
                        payload: {
                          otp: true,
                          error: data?.error?.details[0]?.message,
                        },
                      });
                      accountVerificationInitiated(getCookie("personOffersUniqueId"), data?.error?.code);   //initiated newRelic accountVerificationInitiated event
                    } else {
                      /*** Here we will handle the valid card information */
                      dispatch({
                        type: LINKAGE_ACCOUNT,
                        payload: {
                          otp: true,
                          error: "",
                        },
                      });
                      accountVerificationInitiated(getCookie("personOffersUniqueId"), "success");
                    }
                  }
                );
              }
            }
          } else {
            /****
             * for the linked status null
             */
            addUserAccess({
              points: false,
              offers: true,
              card: false,
              ghost: false,
              closed: false,
            });
            console.log(Router.pathname);
            if (
              !Auth?.value?.skipVerify &&
              getCookie("disableVerifyCard") != "1" &&
              !repeat &&
              Router.pathname !=
                `${process.env.NEXT_PUBLIC_REGISTER_VERIFYCARD_SLUG}`
            ) {
              setOffersModal(true);
              promptDisplay(getCookie("personOffersUniqueId"), "success", "verifyCardPrompt");  //initiated newRelic promptDisplay event
            } else if (
              Router.pathname ===
                `${process.env.NEXT_PUBLIC_REGISTER_VERIFYCARD_SLUG}` &&
              !repeat
            ) {
              if (Auth?.value?.lpCardNumber) {
                linkAccount(Auth?.value?.lpCardNumber, Auth?.value?.guid).then(
                  (data) => {
                    if (data?.error) {
                      dispatch({
                        type: LINKAGE_ACCOUNT,
                        payload: {
                          otp: true,
                          error: data?.error?.details[0]?.message,
                        },
                      });
                      accountVerificationInitiated(getCookie("personOffersUniqueId"), data?.error?.code);   //initiated newRelic accountVerificationInitiated event
                    } else {
                      /*** Here we will handle the valid card information */
                      dispatch({
                        type: LINKAGE_ACCOUNT,
                        payload: {
                          otp: true,
                          error: "",
                        },
                      });
                      accountVerificationInitiated(getCookie("personOffersUniqueId"), "success");   //initiated newRelic accountVerificationInitiated event
                    }
                  }
                );
              }
            } else if (repeat === true) {
              /** Dispatch to otp screen directly  */
              if (
                Auth?.value?.lpCardNumber &&
                Router.pathname ===
                  `${process.env.NEXT_PUBLIC_REGISTER_VERIFYCARD_SLUG}`
              ) {
                accountVerificationInitiated(getCookie("personOffersUniqueId"), "success");   //initiated newRelic accountVerificationInitiated event
                linkAccount(Auth?.value?.lpCardNumber, Auth?.value?.guid).then(
                  (data) => {
                    if (data?.error) {
                      dispatch({
                        type: LINKAGE_ACCOUNT,
                        payload: {
                          otp: true,
                          error: data?.error?.details[0]?.message,
                        },
                      });
                      accountVerificationInitiated(getCookie("personOffersUniqueId"), data?.error?.code);   //initiated newRelic accountVerificationInitiated event
                    } else {
                      /*** Here we will handle the valid card information */
                      dispatch({
                        type: LINKAGE_ACCOUNT,
                        payload: {
                          otp: true,
                          error: "",
                        },
                      });
                      accountVerificationInitiated(getCookie("personOffersUniqueId"), "success");   //initiated newRelic accountVerificationInitiated event
                      if (
                        Router.pathname !=
                        `${process.env.NEXT_PUBLIC_REGISTER_VERIFYCARD_SLUG}`
                      ) {
                        Router.push(
                          `${process.env.NEXT_PUBLIC_REGISTER_VERIFYCARD_SLUG}`
                        );
                      }
                    }
                  }
                );
              } else {
                accountVerificationInitiated(getCookie("personOffersUniqueId"), "success");   //initiated newRelic accountVerificationInitiated event
                linkAccount(Auth?.value?.lpCardNumber, Auth?.value?.guid).then(
                  (data) => {
                    if (data?.error) {
                      dispatch({
                        type: LINKAGE_ACCOUNT,
                        payload: {
                          otp: true,
                          error: data?.error?.details[0]?.message,
                        },
                      });
                      accountVerificationInitiated(getCookie("personOffersUniqueId"), data?.error?.code);   //initiated newRelic accountVerificationInitiated event
                    } else {
                      /*** Here we will handle the valid card information */
                      dispatch({
                        type: LINKAGE_ACCOUNT,
                        payload: {
                          otp: true,
                          error: "",
                        },
                      });
                      accountVerificationInitiated(getCookie("personOffersUniqueId"), "success");   //initiated newRelic accountVerificationInitiated event
                      if (
                        Router.pathname !=
                        `${process.env.NEXT_PUBLIC_REGISTER_VERIFYCARD_SLUG}`
                      ) {
                        Router.push(
                          `${process.env.NEXT_PUBLIC_REGISTER_VERIFYCARD_SLUG}`
                        );
                      }
                    }
                  }
                );
              }
              Router.push(
                `${process.env.NEXT_PUBLIC_REGISTER_VERIFYCARD_SLUG}`
              );
            } else {
              console.log("here in null state");
            }
          }
        } else if (responseAccount[data.enrollmentStatusCode] === "register") {
          if (
            !ghostSubmit &&
            !Auth?.value?.skipGhost &&
            Router.pathname !=
              `${process.env.NEXT_PUBLIC_REGISTER_VERIFYCARD_SLUG}`
          ) {
            if (getCookie("disableGhostCard") != "1") {
              setRegisterModal(true);
              promptDisplay(getCookie("personOffersUniqueId"), "success", "ghostCardRegisterPrompt"); //initiated newRelic promptDisplay event
            }
          } else if (
            Router.pathname ===
            `${process.env.NEXT_PUBLIC_REGISTER_VERIFYCARD_SLUG}`
          ) {
            if (getCookie("disableGhostCard") != "1") {
              setRegisterModal(true);
              promptDisplay(getCookie("personOffersUniqueId"), "success", "ghostCardRegisterPrompt"); //initiated newRelic promptDisplay event
            } else {
              Router.push("/");
            }
          }
          addUserAccess({
            points: false,
            offers: true,
            card: false,
            ghost: true,
            closed: false,
          });
        } else {
          /*** Handle other things  */
        }
      }
    });
  };

  /****
   * @function handleGhostSubmit
   *
   */

  const handleGhostSubmit = (cardData: any) => {
    console.log(cardData, "===== data account");
    accountVerificationInitiated(getCookie("personOffersUniqueId"), "success");   //initiated newRelic accountVerificationInitiated event
    linkAccount(
      cardData?.cardnumber.replace(/\s/g, ""),
      Auth?.value?.guid
    ).then((data) => {
      setRegisterCardError(null);
      if (data?.error) {
        setRegisterCardError(data?.error?.details[0]?.message);
      } else {
        /*** Here we will handle the valid card information */
        setRegisterModal(false);
        dispatch({
          type: USER_AUTH,
          payload: {
            /**** Adding the lp card number****/
            user: {
              ...Auth?.value,
              lpCardNumber: cardData?.cardnumber.replace(/\s/g, ""),
            },
          },
        });
        handleAccountStatus(
          cardData?.cardnumber.replace(/\s/g, ""),
          false,
          true
        );
      }
    });
  };
  /****
   * @function handleGhostClosed
   */

  const handleGhostClosed = () => {
    setRegisterModal(!registerModal);
    promptDismiss(getCookie("personOffersUniqueId"), "success", "ghostCardRegisterPrompt");    // initiated newRelic promptDismiss event
    const timer = setTimeout(() => {
      /*** Get account response  */
      const getAccountInfoResponse = (response) => {
        if (response.status === "OK") {
          dispatch({
            type: USER_AUTH,
            payload: {
              /**** Adding the lp card number****/
              user: {
                ...Auth?.value,
                lpCardNumber: response?.data?.scene?.cardNumber,
                skipGhost: true,
              },
            },
          });
          handleCloseModal("ghostCard", "hard");
          handleAccountStatus(response?.data?.scene?.cardNumber);
        } else {
        }
      };
      if (GigyaObject != undefined) {
        GigyaObject.accounts.getAccountInfo({
          callback: getAccountInfoResponse,
        });
      }
    }, 1500);
    return () => clearTimeout(timer);
  };
  /****
   * @function sceneCardSubmit
   * on submit the scene card poup
   */
  const sceneCardSubmit = () => {
    /**
       * Hide the notification
       */
    Bus.emit('hideflash', ({ type:"cardError" }));
    const getAccountInfoResponse = (response) => {
      if (response.status === "OK") {
    if (response?.data?.scene?.cardNumber) {
      /*** Here we will handle the valid card information */
      addDataLayer({event:"add_card",event_param:"",param_value:response?.data?.scene?.cardNumber});
      /**
       * Get the user information after add card
       */
       getMemberDetail(response?.data?.scene?.cardNumber, false);
      /***** Handle link account api ******/
      dispatch({
        type: USER_AUTH,
        payload: {
          /**** Adding the lp card number****/
          user: {
            ...Auth?.value,
            lpCardNumber: response?.data?.scene?.cardNumber,
            enrollementStatusGigya: response?.data?.scene?.enrollmentStatus,
            skipVerify: true,
          },
        },
      });
      setAddCardModal(false);
      setRegisterModal(false);
    }
  }
}
    if (GigyaObject != undefined) {
      GigyaObject.accounts.getAccountInfo({ callback: getAccountInfoResponse });
    }
  };

  /****
   * @function handleChange
   * Handle value change callBack
   */
  const handleChange = () => {
    setRegisterCardError(null);
  };
  /****
   * @function onFilterChange
   * on filter change to sort the offers
   */
  const onFilterChange = (e) => {
    SetBannerSelected(e);
  };

  /***
   *@function addUserAccess
   *@param points boolean
   *@param offers boolean
   *@param card boolean
   */
  const addUserAccess = ({
    points,
    offers,
    card,
    ghost,
    closed,
  }: userAccess) => {
    dispatch({
      type: USER_ACCESS,
      payload: {
        points: points,
        offers: offers,
        card: card,
        ghost: ghost,
        closed: closed,
      },
    });
  };

  /**** Handle add card model close
   * @function handleCloseModal
   *
   */
  const handleCloseModal = (type: string, supress: string) => {
    if (type === "addCard") {
      setAddCardModal(!addCardModal);
      if(supress=='soft') {
        promptRemindLater(getCookie("personOffersUniqueId"), "success", "addCardDisablePrompt");  //initiated newRelic promptRemindLater event
      } else {
        promptDismiss(getCookie("personOffersUniqueId"), "success", "addCardDisablePrompt");    //initiated newRelic promptDismiss event
      }
      addCookie({
        name: "disableAddCard",
        type: supress,
        value: 1,
        counterValue: getCookie("counter_disableAddCard") ?? 0,
      });
    } else if (type === "verifyCard") {
      setOffersModal(!offersModal);
      promptDismiss(getCookie("personOffersUniqueId"), "success", "verifyCardDisablePrompt");    //initiated newRelic promptDismiss event
      addCookie({
        name: "disableVerifyCard",
        type: supress,
        value: 1,
        counterValue: getCookie("counter_disableVerifyCard") ?? 0,
      });
    } else if (type === "ghostCard") {
      setRegisterModal(!registerModal);
      promptDismiss(getCookie("personOffersUniqueId"), "success", "ghostCardDisablePrompt");     //initiated newRelic promptDismiss event
      addCookie({
        name: "disableGhostCard",
        type: supress,
        value: 1,
        counterValue: getCookie("counter_disableGhostCard") ?? 0,
      });
      /***
       * Check if on verify card page then push back user to home page
       */
      if(Router.pathname === `${process.env.NEXT_PUBLIC_REGISTER_VERIFYCARD_SLUG}`){
        Router.push('/')
      }
    }
  };

  /**** Checking on the profile card is added or removed  */
  React.useEffect(() => {
    if (
      Router.pathname != `${process.env.NEXT_PUBLIC_REGISTER_VERIFYCARD_SLUG}`
    ) {
      /**
       * Hide the notification
       */
      Bus.emit('hideflash', ({ type:"cardError" }));
      const timer = setTimeout(() => {
        /*** Get account response  */
        const getAccountInfoResponse = async (response) => {
          if (response != undefined && response !="") {
            if (
              Auth?.value != undefined &&
              (Auth?.value?.lpCardNumber === undefined ||
                Auth?.value?.lpCardNumber === "")
            ) {
              if (
                (getCookie("disableAddCard") != "1" ||
                  getCookie("disableAddCard") === undefined) &&
                Router.pathname !=
                  `${process.env.NEXT_PUBLIC_REGISTER_VERIFYCARD_SLUG}`
              ) {
                Bus.emit('showNotification', ({ type:"" }));
                setAddCardModal(true);
                promptDisplay(getCookie("personOffersUniqueId"), "success", "addCardNotificationPrompt");     //initiated newRelic promptDisplay event
              } else if (
                Router.pathname ===
                `${process.env.NEXT_PUBLIC_REGISTER_VERIFYCARD_SLUG}`
              ) {
                Router.push("/");
              }
              addUserAccess({
                points: false,
                offers: false,
                card: false,
                ghost: false,
                closed: false,
              });
            } else {
              if (Auth?.value?.lpCardNumber) {
                /***
                 * Checking the status here if user added or remove the card from here
                 */
                const data = await accountStatus(Auth?.value?.lpCardNumber,(Router?.query?.bypass as string));
                if (data != undefined) {
                  if (data?.error) {
                    enquireEnrolment(getCookie("personOffersUniqueId"), data?.error?.code);  //initiated newRelic enquireEnrolment event
                    console.log("error in card number");
                    globalThis.flash(
                      `${t.errorInCard}`,
                      "danger"
                    );
                  } else {
                    enquireEnrolment(getCookie("personOffersUniqueId"), "success", data.enrollmentStatusCode);  //initiated newRelic enquireEnrolment event
                    if (
                      responseAccount[data.enrollmentStatusCode] === "contact"
                    ) {
                      if (data.enrollmentStatusCode === "LP00") {
                        addUserAccess({
                          points: false,
                          offers: false,
                          card: false,
                          ghost: false,
                          closed: true,
                        });
                        globalThis.flash(`${t.cardClosed}`, "danger");
                      } else {
                        /**** In case of suspended *****/
                        addUserAccess({
                          points: false,
                          offers: true,
                          card: false,
                          ghost: false,
                          closed: true,
                        });
                        globalThis.flash(`${t.cardSuspended}`, 'danger');
                        if (
                          Router.pathname ===
                          `${process.env.NEXT_PUBLIC_REGISTER_VERIFYCARD_SLUG}`
                        ) {
                          Router.push("/");
                        }
                      }
                    } else if (
                      responseAccount[data.enrollmentStatusCode] === "verify"
                    ) {
                      /****
                       * for the linked status true
                       */
                      if (Auth?.value?.lpLinkedStatus === true) {
                        addUserAccess({
                          points: true,
                          offers: true,
                          card: true,
                          ghost: false,
                          closed: false,
                        });
                        if (
                          Router.pathname ===
                          `${process.env.NEXT_PUBLIC_REGISTER_VERIFYCARD_SLUG}`
                        ) {
                          Router.push("/");
                        }
                      } else if (Auth?.value?.lpLinkedStatus === false) {
                        /****
                         * for the linked status false
                         */
                        addUserAccess({
                          points: false,
                          offers: true,
                          card: false,
                          ghost: false,
                          closed: false,
                        });
                        if (
                          Router.pathname ===
                          `${process.env.NEXT_PUBLIC_REGISTER_VERIFYCARD_SLUG}`
                        ) {
                        }
                        /****
                         * Show verify card
                         */
                        if (Auth?.value?.showVerify) {
                          setOffersModal(true);
                          promptDisplay(getCookie("personOffersUniqueId"), "success", "verifyCardPrompt");     //initiated newRelic promptDisplay event
                        }
                      } else {
                        /****
                         * for the linked status null
                         */
                        addUserAccess({
                          points: false,
                          offers: true,
                          card: false,
                          ghost: false,
                          closed: false,
                        });
                        if (
                          !Auth?.value?.skipVerify &&
                          getCookie("disableVerifyCard") != "1"
                        ) {
                          setOffersModal(true);
                          promptDisplay(getCookie("personOffersUniqueId"), "success", "verifyCardPrompt");     //initiated newRelic promptDisplay event
                        } else if (Auth?.value?.skipVerify) {
                          Router.push(
                            `${process.env.NEXT_PUBLIC_REGISTER_VERIFYCARD_SLUG}`
                          );
                        }
                      }
                    } else if (
                      responseAccount[data.enrollmentStatusCode] === "register"
                    ) {
                      if (getCookie("disableGhostCard") != "1") {
                        setRegisterModal(true);
                        promptDisplay(getCookie("personOffersUniqueId"), "success", "ghostCardRegisterPrompt");     //initiated newRelic promptDisplay event
                      }
                      Bus.emit('showNotification', ({ type:"" }));
                      addUserAccess({
                        points: false,
                        offers: true,
                        card: false,
                        ghost: true,
                        closed: false,
                      });
                    } else {
                      /*** Handle other things  */
                    }
                  }
                }
              }
            }
          }
        };
        if (GigyaObject != undefined) {
          getAccountInfoResponse(gigyaLoggedIn());
        }
      }, 100);
      return () => clearTimeout(timer);
    }
  }, [Auth?.value?.lpCardNumber]);

  /***** End checking card is added on profile update********/

  /****
   * To check status of the pages on refresh
   */
  React.useEffect(() => {
    if (
      Router.pathname === `${process.env.NEXT_PUBLIC_REGISTER_VERIFYCARD_SLUG}`
    ) {
      const timer = setTimeout(() => {
        /*** Get account response  */
        const getAccountInfoResponse = async (response) => {
          if (response != undefined && response!='') {
            if (
              Auth?.value != undefined &&
              (Auth?.value?.lpCardNumber === undefined ||
                Auth?.value?.lpCardNumber === "")
            ) {
              if (
                (getCookie("disableAddCard") != "1" ||
                  getCookie("disableAddCard") === undefined) &&
                Router.pathname !=
                  `${process.env.NEXT_PUBLIC_REGISTER_VERIFYCARD_SLUG}`
              ) {
                setAddCardModal(true);
                promptDisplay(getCookie("personOffersUniqueId"), "success", "addCardDisablePrompt");     //initiated newRelic promptDisplay event
              } else if (
                Router.pathname ===
                `${process.env.NEXT_PUBLIC_REGISTER_VERIFYCARD_SLUG}`
              ) {
                Router.push("/");
              }
            } else {
              if (Auth?.value?.lpCardNumber) {
                handleAccountStatus(Auth?.value?.lpCardNumber);
              }
            }
          } else {
          }
        };
        if (GigyaObject != undefined) {
          getAccountInfoResponse(gigyaLoggedIn());
        }
      }, 100);
      return () => clearTimeout(timer);
    }
  }, [Auth?.value?.lpCardNumber]);
/***
 * handle the notification clicks
 */
  React.useEffect(() => {
    Bus.addListener('notificationClick', ({type}) => {
      if(type==="addCard"){
        setAddCardModal(true);
        promptDisplay(getCookie("personOffersUniqueId"), "success", "addCardNotificationPrompt");     //initiated newRelic promptDisplay event
      }
      else if(type==="verifyCard"){
        setOffersModal(true);
        promptDisplay(getCookie("personOffersUniqueId"), "success", "verifyCardNotificationPrompt");     //initiated newRelic promptDisplay event
      }
      else if(type==="ghostCard"){
        setRegisterModal(true);
        promptDisplay(getCookie("personOffersUniqueId"), "success", "ghostCardNotificationPrompt");     //initiated newRelic promptDisplay event
      }
    });
            

}, []);
  return (
    <>
      {/**** modals  */}

      {offersModal && (
        <>
          {verifyCard.blockdata[0] && (
            <Modal
              overlayColor="rgba(0, 0, 0, 0.8)"
              zIndex={99}
              hideBackdrop={false}
              closeIcon={
                <Image
                  src="/icons/close.svg"
                  layout="fixed"
                  height={13}
                  width={13}
                  alt="close_icon"
                />
              }
              onClick={() => handleCloseModal("verifyCard", "hard")}
              className="modaltest"
              style={{
                [`@media ${BreakPoints.tabletS}`]: {
                  maxWidth: "630px",
                },
                [`@media ${BreakPoints.tablet}`]: {
                  maxWidth: "970px",
                },
                padding: "20px",
              }}
            >
              <div className="offerSection second">
                <Text
                  className="offerSection-left"
                  style={{
                    width: "63%",
                    maxWidth:"370px",
                    display: "none",
                    [`@media ${BreakPoints.tablet}`]: {
                      display: "block",
                    },
                  }}
                >
                  <div className="offerSectionImage">
                    <Image
                      src={imagePopup?.image?.src}
                      alt={imagePopup?.image?.alt}
                      objectFit="cover"
                      layout="fill"
                    ></Image>
                  </div>
                </Text>
                <div className="offerContent">
                  <Text
                    as="h3"
                    textAlign="left"
                    style={{
                      fontFamily: "Poppins-Bold",
                      fontSize: "26px",
                      margin: "0px",
                      color: "#000",
                      lineHeight: "40px",
                    }}
                  >
                    {parse(verifyCard.blockdata[0]?.title)}
                  </Text>
                  <ul>
                    {verifyCard.blockdata[0]?.modalcontent.map((mapData) => {
                      return <li> {mapData} </li>;
                    })}
                  </ul>
                  {verifyCardActive ? (
                    <div className="offerLoader">
                      <Loader />
                    </div>
                  ) : (
                    <>
                      <div className="OfferButtons">
                        {verifyCard.blockdata[1] &&
                          verifyCard.blockdata[1]?.actionproperties && (
                            <button
                              className="themeBtn outline"
                              tabIndex={0}
                              aria-label={
                                verifyCard.blockdata[1]?.actionproperties[0]
                                  .arialabel
                              }
                              id={
                                verifyCard.blockdata[1]?.actionproperties[0]
                                  .buttonId
                              }
                              data-gtm={
                                verifyCard.blockdata[1]?.actionproperties[0]
                                  .datagmt
                              }
                              onClick={() =>
                                handleCloseModal("verifyCard", "soft")
                              }
                            >
                              {
                                verifyCard.blockdata[1]?.actionproperties[0]
                                  .text
                              }
                            </button>
                          )}

                        {verifyCard.blockdata[1] &&
                          verifyCard.blockdata[1]?.actionproperties && (
                            <button
                              className="themeBtn"
                              tabIndex={0}
                              aria-label={
                                verifyCard.blockdata[1]?.actionproperties[1]
                                  .arialabel
                              }
                              id={
                                verifyCard.blockdata[1]?.actionproperties[1]
                                  .buttonId
                              }
                              data-gtm={
                                verifyCard.blockdata[1]?.actionproperties[1]
                                  .datagmt
                              }
                              onClick={() => handleVerifyCard()}
                            >
                              {
                                verifyCard.blockdata[1]?.actionproperties[1]
                                  .text
                              }
                            </button>
                          )}
                      </div>
                    </>
                  )}
                  {verifyCard.blockdata[0]?.actionproperties.map((data) => {
                    return (
                      <Text colorScheme="accent" className="offerLinks">
                        {data.text}{" "}
                        <a className="simple-link" href={data.link.url} target={data.link.target}>
                          {data.label}
                        </a>
                      </Text>
                    );
                  })}
                </div>
              </div>
            </Modal>
          )}
        </>
      )}

      {addCardModal && (
        <>
          {addCard?.blockdata[0] && (
            <Modal
              overlayColor="rgba(0, 0, 0, 0.8)"
              zIndex={99}
              hideBackdrop={false}
              closeIcon={
                <Image
                  src="/icons/close.svg"
                  layout="fixed"
                  height={13}
                  width={13}
                  alt="close_icon"
                />
              }
              idbody="add-card-modal"
              onClick={() => handleCloseModal("addCard", "hard")}
              className="modaltest sl"
              style={{
                [`@media ${BreakPoints.tabletS}`]: {
                  maxWidth: "630px",
                },
                [`@media ${BreakPoints.tablet}`]: {
                  maxWidth: "970px",
                },
                padding: "20px",
              }}
            >
              <div className="offerSection">
                <Text
                  className="offerSectionLeft"
                >
                  <div className="offerSectionImage">
                    <Image
                      src={imagePopupAddCard?.image?.src}
                      objectFit="cover"
                      layout="fill"
                      alt={imagePopupAddCard?.image?.alt}
                    ></Image>
                  </div>
                </Text>
                <div className="offerContent">
                  <Text as="h3" textAlign="left" colorScheme="primary">
                    {parse(addCard.blockdata[0]?.title)}
                  </Text>

                  <ul
                    className="add-card-list"
                  >
                    {addCard.blockdata[0]?.modalcontent.map((mapData) => {
                      return <li> {mapData} </li>;
                    })}
                  </ul>
                  <SceneCard
                    onSubmit={sceneCardSubmit}
                    handleChange={handleChange}
                    errorResponse={registerCardError}
                  ></SceneCard>
                  <span
                    id="remind-addcard"
                    onClick={() => handleCloseModal("addCard", "soft")}
                    className="clear"
                  ></span>
                  <span
                    id="add-card-aftersubmit"
                    onClick={() => sceneCardSubmit()}
                    className="clear"
                  ></span>
                </div>
              </div>
            </Modal>
          )}
        </>
      )}

      {/**** register modal ******/}
      {registerModal && (
        <Modal
          overlayColor="rgba(0, 0, 0, 0.8)"
          zIndex={99}
          hideBackdrop={false}
          closeIcon={
            <Image
              src="/icons/close.svg"
              layout="fixed"
              height={13}
              width={13}
              alt="close_icon"
            />
          }
          onClick={() => handleGhostClosed()}
          className={" modaltest"}
          style={{
            maxWidth: "430px",
            [`@media ${BreakPoints.mobileS}`]: {
              maxWidth: "100%",
              padding: "0px 20px",
            },
            [`@media ${BreakPoints.tabletS}`]: {
              maxWidth: "510px",
            },
          }}
        >
          <div className="GhostPopup">
            <Text as="div" className="GhostPopupContent">
              {registerCard?.blockdata[1]?.image_group[0]?.image && (
                <div className="GhostPopupContentImage">
                  <Image
                    src={registerCard?.blockdata[1]?.image_group[0]?.image?.src}
                    alt={registerCard?.blockdata[1]?.image_group[0]?.image?.alt}
                    layout="fill"
                  ></Image>
                </div>
              )}
              <Text as="h3">{registerCard?.blockdata[0]?.title}</Text>
              <Text as="p" className="GhostPopupContentText">
                {registerCard?.blockdata[0]?.description}
              </Text>

              <Text as="div">
                <Text as="div">
                  <Link
                    href={
                      registerCard?.blockdata[1]?.actionproperties[0]?.link?.url
                    }
                  >
                    <a
                      target={registerCard?.blockdata[1]?.actionproperties[0]?.link?.target}
                      className="themeBtn"
                      aria-label={
                        registerCard?.blockdata[1]?.actionproperties[0]
                          ?.arialabel
                      }
                      id={
                        registerCard?.blockdata[1]?.actionproperties[0]
                          ?.buttonId
                      }
                      data-gtm={
                        registerCard?.blockdata[1]?.actionproperties[0]?.datagmt
                      }
                    >
                      {registerCard?.blockdata[1]?.actionproperties[0]?.text}{" "}
                      <ExternalLink
                        style={{ marginLeft: "15px" }}
                        size="18px"
                      />
                    </a>
                  </Link>
                  <button
                    className="themeBtn outline"
                    id="close_ghost_card"
                    data-gtm="ghost_card_modal"
                    aria-label="Close Ghost Card"
                    onClick={() => handleCloseModal("ghostCard", "soft")}
                  >
                    {`Close`}
                  </button>
                </Text>

                <Text as="p" className="footerLink">
                  {registerCard?.blockdata[2]?.actionproperties[0]?.text}{" "}
                  <Link
                    href={locale==='en'?GigyaObject?.thisScript?.globalConf?.SCENE_CONTACT_SUPPORT_URL:GigyaObject?.thisScript?.globalConf?.SCENE_CONTACT_SUPPORT_URL_FR}
                  >
                    <a
                      className="simple-link"
                      target={
                        registerCard?.blockdata[2]?.actionproperties[0]?.link?.target
                      }
                    >
                      {registerCard?.blockdata[2]?.actionproperties[0]?.label}
                    </a>
                  </Link>
                </Text>
              </Text>
            </Text>
          </div>
        </Modal>
      )}      
    </>
  );
});

export const AccountLinking = React.memo(AccountLinkingData);
