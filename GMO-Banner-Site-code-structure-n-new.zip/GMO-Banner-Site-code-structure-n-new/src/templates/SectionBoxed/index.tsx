import { Text, Container } from "@components";

export const SectionBoxed = (props: any) =>{
    const { children, className } = props;
    return (
        <Text as="section" className={`${className} containerFluid`}>
            <Container size="lg">
                {children}
            </Container>
        </Text>
    )
}