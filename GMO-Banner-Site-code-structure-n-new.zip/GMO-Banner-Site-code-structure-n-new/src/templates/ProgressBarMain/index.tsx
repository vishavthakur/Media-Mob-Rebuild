import Link from 'next/link';
import { ProgressBar } from '@components';

export const ProgressBarMain = () =>{
    return(
        <ProgressBar
            value={40}
            startPoint={`$25`}
            midPoint={`$30`}
            endPoint={`$35`}
            label="2,880pts"
            backgroundColor="#9c42ff"
            width={"570px"}
        >
            <div className="progressBarContent">You’re <strong>120 PTS</strong> away from $30  <Link href="#"><a className="simple-link">View recent activity</a></Link></div>
        </ProgressBar>
    )
}