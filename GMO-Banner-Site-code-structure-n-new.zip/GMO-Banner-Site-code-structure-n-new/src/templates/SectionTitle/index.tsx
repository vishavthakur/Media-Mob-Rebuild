import { Text } from "@components";

export const SectionTitle = (props: any) => {
  const {
    title,
    aboveTitle,
    belowTitle,
    className,
    tabIndex,
    belowTabIndex,
    belowtitleColorScheme = "accent",
  } = props;
  return (
    <Text as="div" className={`${className} sectionTitle`}>
      {aboveTitle && aboveTitle != undefined && (
        <Text
          as="p"
          className="above-title"
          textAlign="center"
          colorScheme="primary"
        >
          {aboveTitle}
        </Text>
      )}
      {title && title != undefined && (
        <Text
          as="h2"
          textAlign="center"
          colorScheme="primary"
          className="section-title"
          tabIndex={tabIndex}
        >
          {title}
        </Text>
      )}

      {belowTitle && belowTitle != undefined && (
        <Text as="p" textAlign="center" colorScheme={belowtitleColorScheme} tabIndex={belowTabIndex}>
          {belowTitle}
        </Text>
      )}
    </Text>
  );
};
