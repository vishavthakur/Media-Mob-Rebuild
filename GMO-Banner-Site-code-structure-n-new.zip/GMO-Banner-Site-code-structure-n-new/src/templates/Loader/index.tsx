import styled from "@emotion/styled";
import Style from "./index.module.scss";
import Image from "@templates/ImageConversion";
interface LoaderType{
type?:"white" | "black"
}
export const Loader = ({ type }:LoaderType) => {
     return (<>
          <div className={Style.outerloadercfl}>
               <div className={Style.loaders}>
                    <Image 
                         alt="loader" src={`/icons/loader-${type}.svg`}
                         width={64}
                         height={64}
                    />
               </div>
          </div>

     </>
     );
}
Loader.defaultProps = {
     type: "white",
 };