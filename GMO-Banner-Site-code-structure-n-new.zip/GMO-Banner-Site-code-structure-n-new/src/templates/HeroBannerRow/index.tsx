import React from "react";
import Image from "@templates/ImageConversion";
import parse from "html-react-parser";
import Link from "next/link";
import { Row, Col, Text, Card } from '@components';
import { BreakPoints } from "@util/units";
import useWindowSize from '@util/hooks/useWindowSize';
interface siderProps {
    title?: string,
    subTitle?: string;
    titlearialabel?:string;
    subtitlearialabel?:string;
    content?: string;
    contentarialabel?:string;
    image?: { src: string, title: string, dimension: { height: number, width: number }, alt: string;};
    buttonText?: string;
    buttonLink?: string;
    buttonTarget?: string;
    buttonId?: string;
    buttonAriaLabel?: string;
    buttonDataGtm?: string;
    buttonIndex?:any;
    tabindex?: any;
    mobileImage?:{ src: string, title: string, dimension: { height: number, width: number }, alt: string;};
}
export const HeroBannerRow = React.forwardRef<
HTMLDivElement,
React.PropsWithChildren<siderProps>
>(({ children, ...props }, ref) => {
    const { width } = useWindowSize();
    return(
        <Row className={'HeroRow'} style={{
            margin: '0',
            [`@media ${BreakPoints.tabletS}`]: {
                alignItems: 'stretch',
                flexDirection: 'row-reverse',
                overflow: 'hidden'
            }
        }}
        >
        { width > 767 && <Col 
            xs={12}
            sm={6}
            md={7}
            lg={8}
            style={{ padding: "0px" }}
            className="HeroBannerImage Desk"
        >
                <Image layout='fill' objectFit="cover" src={props?.image?.src} alt={props?.image?.alt} />
        </Col>}
        { width < 767 && <Col 
            xs={12}
            sm={6}
            md={7}
            lg={8}
            style={{ padding: "0px" }}
            className="HeroBannerImage Mob"
        >
                <Image layout='fill' objectFit="cover" src={props?.image?.src} alt={props?.image?.alt} />
        </Col>}
        <Col 
            xs={12} 
            sm={6} 
            md={5} 
            lg={4}
            style={{ padding: "0px" }}
        >
            <Card
                variant="solid"
                colorScheme="primary"
                justifyContent="center"
                className="HeroBannerContent"
                style={{ border: 'inherit' }}
            >
                <Text className="HeroBannerContentInner">
                   {(props?.title || props?.subTitle) && <Text colorScheme="primary" as="div" className="mainHeading">
                            {parse(props?.title)}
                            {parse(props?.subTitle)}
                    </Text> } 
                   {props?.content && <Text colorScheme="primary" as="p" aria-label={props?.contentarialabel?props?.contentarialabel:''}>
                            {parse(props?.content)}
                        </Text> }
                        {props?.buttonLink &&  
                        <span className="btn-accessibility">
                            <Link href={props?.buttonLink}>
                                <a tabIndex={props?.tabindex} target={props?.buttonTarget} className={`themeBtn white ${props?.buttonId}`} aria-label={props?.buttonAriaLabel}  data-gtm={props?.buttonDataGtm}>{props?.buttonText}</a>
                            </Link>
                        </span>
                        }
                </Text>
            </Card>
        </Col>
      </Row>
    )
})