import { SectionBoxed } from "@templates";
import { Row, Col, Text,Button } from "@components";
import Image from "@templates/ImageConversion";
import { useRouter } from 'next/router';
import { useSelector, RootStateOrAny, useDispatch } from "react-redux";
import Bus from "@util/Bus";
export const CardNotFound = (props) => {
  const { CardNotFoundheading, CardNotFoundlists, CardNotFoundbutton, CardNotFoundLink, CardNotFoundImage, CardNotFoundDataGtm, CardNotFoundButtonId, CardNotFoundAriaLabel,CardNotFoundImageAlt } = props;
  const router = useRouter();
  const Auth = useSelector((state: RootStateOrAny) => state.auth);
    /***
           * @function dispatch
           * to use the redux
           */
     const dispatch = useDispatch();
  const handleClick = () => {
    Bus.emit('notificationClick', ({ type:"addCard" }));
  }
  return (
    <SectionBoxed className="fluid CardNotFoundSection py-18">
      <Text as="div" className="CardNotFound">
        <Row>
          <Col md={7} sm={7}>
            <Text as="div" className="CardNotFoundContent">
              {CardNotFoundheading &&<Text
                as="h3"
                className="CardNotFoundContentHeading"
                colorScheme="primary"
              >
                {CardNotFoundheading}
              </Text>}
              <ul className="CardNotFoundContentList">
                {
                  CardNotFoundlists?.map((list,index) =>(
                    <li key={`card_not_found${index}`}>{list[0]}</li>
                  ))
                }
              </ul>
              {CardNotFoundbutton && <Text as="div">
                <Button className="themeBtn" aria-label={CardNotFoundAriaLabel} id={CardNotFoundButtonId} data-gtm={CardNotFoundDataGtm} onClick={()=>handleClick()} ><a>{CardNotFoundbutton}</a></Button>
              </Text>}
            </Text>
          </Col>
          <Col md={5} sm={5}>
            {CardNotFoundImage &&<Text as="div" textAlign="center">
              <Image
                src={CardNotFoundImage}
                alt={CardNotFoundImageAlt}
                width="394px"
                height="300px"
              />
            </Text>}
          </Col>
        </Row>
      </Text>
    </SectionBoxed>
  );
};
