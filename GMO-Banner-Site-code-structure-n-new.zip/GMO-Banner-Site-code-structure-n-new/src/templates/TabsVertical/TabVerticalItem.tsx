import React, { useContext } from 'react'
import { TabsContext } from './TabsContext'; 

interface TabItem extends React.HTMLAttributes<HTMLButtonElement>{
    value?: number,
    tabAriaLabel?: string,
    panelAriaLabel?: string,
    title?: string
}

export const TabVerticalItem: React.FC<TabItem> = ({ children, value, tabAriaLabel, panelAriaLabel, title, style }) =>{
    //@ts-ignore
    const { open, setOpen }  = useContext(TabsContext);

    const isMount = React.useRef<boolean>(true)
    const ref = React.useRef<HTMLDivElement>();

    const onKeyDownHandle = (e: { key: string; }) =>{
        if(e.key === 'Enter'){
            setOpen(value)
            ref?.current?.focus();
            document.querySelectorAll('.Tabs__panel.open .AccordionHeader').forEach(b=>b.setAttribute('tabindex', '0'))
        }
    }

    React.useEffect(() => {
        if(!isMount.current) {
             ref?.current?.focus();
             document.querySelectorAll('.Tabs__panel .AccordionHeader').forEach(b=>b.removeAttribute('tabindex'))
             document.querySelectorAll('.Tabs__panel.open .AccordionHeader').forEach(b=>b.setAttribute('tabindex', '0'))
        }
        return () => {
            isMount.current = false;
          }
      }, [open]);

    return (
        <>
        <button
            className={`TabItem ${open === value ? 'active-tabs' : ''}`}
            onClick={() => setOpen(value)}
            onKeyDown={(e) => onKeyDownHandle(e)}
            value={value}
            aria-label={`${tabAriaLabel}, enter here to read content`}
            id={`TabItem-${value}`}
        >
            {title}
        </button>
        <div 
            ref={ref as React.RefObject<HTMLDivElement>} 
            className={`Tabs__panel ${open === value ? 'open' : ''}`}
            tabIndex={-1}
            aria-label={`${panelAriaLabel} content, tab here to read content`}
            style={style}
        >
            {children}
        </div>
        </>
    )
}