import React, { HTMLAttributes, useRef } from 'react'
import { TabsContext } from './TabsContext'; 

interface TabsPanel extends HTMLAttributes<HTMLDivElement>{
  value?: number;
}


export const TabVerticalPanelMemo: React.FC<TabsPanel> = ({ children, value, ...rest }) => {
  const isMount = React.useRef<boolean>()
  const ref = React.useRef<HTMLDivElement>();
  //@ts-ignore
  const { open, setOpen }  = React.useContext(TabsContext)

  let panel_active = -1;
  const handleKeyDown = (e: { key: string; }) =>{
    if(e.key === 'Enter'){
      ref?.current?.focus();
      panel_active = open === value ? 0 : -1;
      document.querySelectorAll('.Tabs__panel *').forEach(b=>b.removeAttribute('tabindex'))
      document.querySelectorAll('.Tabs__panel.open *').forEach(b=>b.setAttribute('tabindex', '0'))
    }
  }

  React.useEffect(() => {
    if(!isMount.current) {
      if(open === value){
        window.addEventListener('keydown', handleKeyDown, false);
      }
    }
    return () => {
      isMount.current = false;
      window.removeEventListener('keydown', handleKeyDown, false);
    }
  }, [open]);
  return (
    <div 
      ref={ref as React.RefObject<HTMLDivElement>} 
      className={`Tabs__panel ${open === value ? 'open' : ''}`}
      tabIndex={panel_active}
      {...rest}
    >
      {children}
    </div>
  )
}


export const TabVerticalPanel = React.memo(TabVerticalPanelMemo)