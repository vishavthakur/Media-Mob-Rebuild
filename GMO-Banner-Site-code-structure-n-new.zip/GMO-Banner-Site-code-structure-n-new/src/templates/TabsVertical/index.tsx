import React, { HTMLAttributes } from 'react'
import { TabsContext } from './TabsContext'; 


interface Tabs extends HTMLAttributes<HTMLDivElement>{
}
interface ProviderProps{
  open: number;
  setOpen: any
}

export const Tabs: React.FC<Tabs> = ({ children, className }) =>{
    const [open, setOpen] = React.useState(0);
    const tabsContext: ProviderProps = ({
        open,
        setOpen
    })
  return (
    <div className={`Tabs__vertical ${className}`}>
      <TabsContext.Provider value={tabsContext}>
          {children}
      </TabsContext.Provider>
    </div>
  )
}
