import React from "react";
import Image from "@templates/ImageConversion";
import parse from "html-react-parser";
import { Text } from '@components';

interface cardProps {
    tag?: string;
    tagHeadline?: string;
    title?: string;
    mainImage?: string;
    brandImages?: any;
    termsText?: string;
    termsLink?: string;
    termsTarget?: string;
    expireDate?: string;
    offerClick?: any;
    offerClickHide?:any;
    offerActiveClass?: any
}
export const OffersCard = React.forwardRef<
HTMLDivElement,
React.PropsWithChildren<cardProps>
    >(({ children, ...props }, ref) => {

        const  getNumberOfDays = (end:string) => {
            const date1 = new Date();
            const date2 = new Date((end).split("/").reverse().join("-"));
            // One day in milliseconds
            const oneDay = 1000 * 60 * 60 * 24;
        
            // Calculating the time difference between two dates
            const diffInTime = date2.getTime() - date1.getTime();
            // Calculating the no. of days between two dates
            const diffInDays = Math.round(diffInTime / oneDay);
            const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sept", "Oct", "Nov", "Dec"];
            const date = new Date(diffInTime);
            const dateShort = ('0' + date.getDate()).slice(-2) + " " + months[date.getMonth()];
            const dateFull = ('0' + date.getDate()).slice(-2) + "/" + (date.getMonth() + 1) + "/" + (date.getFullYear().toString().substr(-2));
            return dateShort;
        }

        const [offerClick, setOfferClick] = React.useState(false);
        const offerClickHandler = () =>{
            setOfferClick(true);
        }
        const offerClickHandlerHide = () =>{
            setOfferClick(false);
        }

    return(

        <Text as="div" className={`offersCard ${offerClick ? "active" : ""}`}>
            <Text as="header" className="offersCardHeader">
                {props?.tag && <Text as="span" className="tag save">{props?.tag}</Text>}
                {props?.tagHeadline && <Text as="p">{parse(props?.tagHeadline)}</Text>}
            </Text>
            <Text as="div" className="offersCardThumb">
                <Text as="p" colorScheme="accent"> {props?.expireDate
            ? (parse(`Expires <span> ${getNumberOfDays(props?.expireDate)} </span>`))
            : ``}</Text>
                <Text as="div" className="offersCardThumbImg">
                    <Image src={props?.mainImage} alt="" layout="fill" objectFit="contain" />
                </Text>
            </Text>
            <Text as="div" className="offersCardContent">
                <Text as="h3" colorScheme="accent">{parse(props?.title)}</Text>
            </Text>
            <Text as="div" className="offersCardBrand">
                <Text as="div" className="offersCardBrandInner">
                    {props?.brandImages && props?.brandImages.map((image) => {
                        return (
                        <Image src={image?.image?.url} alt={image?.image?.alt} width={image?.image?.width} height={image?.image?.height} objectFit="contain" />
                    )
                    })} 
                </Text>
                <button className="linkText" onFocus={offerClickHandler}>{props?.termsText}</button>
            </Text>
            <Text as="div" className={`offersCardHover ${offerClick ? 'active' : ''}`}>
                <div className="offersCardHoverHeader">
                    <button onFocus={offerClickHandlerHide}><Image alt="arrow up" src="/fill-arrow-up.svg" height={11} width={18} /></button>
                    <h4>Terms & Conditions</h4>
                </div>
                <div className="offersCardHoverContent">
                    <p>Valid at participating Sobeys, Foodland & participating Co-Ops locations in Atlantic Canada. Offer must be loaded before time of purchase to the AIR MILES Card swiped in the transaction. Minimum purchase requirements must be met in a single transaction. Offer expires after a single use unless otherwise stated. Product availability may vary by store. We reserve the right to limit quantities to reasonable family requirements.®™ Trademarks of AM Royalties Limited Partnership used under license by LoyaltyOne, Co. and Sobeys Capital Incorporated.</p>
                </div>
                <div className="offersCardHoverFooter">
                    <p>Starts: <strong>01/26/22</strong></p>
                    <p>Expires: <strong>02/02/22</strong></p>
                </div>
            </Text>
        </Text>
    )
})