import React from "react";
import Image from "@templates/ImageConversion";
import { Breadcrumb, Container, Row, Col, Text } from "@components";

const breadCrumbList = [{ id: "1", to: "/", label: "Home" }];
type innerBanner = {
  title?:string,
  id?:string
}
export const InnerBanner = ({ title, id }:innerBanner) => {
  return (
    <Text
      as="div"
      className="BreadCrumb"
      aria-label="breadcrumb"
      role="navigation"
    >
      <Container size="lg" className="innerbanner">
        <Row>
          <Col xs={12}>
            <Text as="div">
              {breadCrumbList && (
                <Breadcrumb
                  className="BreadcrumbItem"
                >
                  {breadCrumbList.map(({ to, label }, i, { length }) => (
                    <li>
                      <a
                        data-link="breadcrumb-link"
                        key={to}
                        href={to}
                        style={{
                          pointerEvents: "unset",
                          textDecoration: "none",
                        }}
                      >
                        {label}
                        <Text as="div" className="BreadcrumbImage">
                          <Image
                            src="/icons/breadcrumbs-arrow.svg"
                            alt="breadcrumb arrow"
                            width="5"
                            height="8"
                            layout="fixed"
                          />
                        </Text>
                      </a>
                    </li>
                  ))}
                </Breadcrumb>
              )}
              <h1 id={id}>{title}</h1>
            </Text>
          </Col>
        </Row>
      </Container>
    </Text>
  );
};
