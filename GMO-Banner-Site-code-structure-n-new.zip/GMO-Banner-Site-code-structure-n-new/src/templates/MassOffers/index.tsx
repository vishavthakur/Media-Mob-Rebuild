import React, { useEffect } from "react";
import { Text, Row, Col } from "@components";
import {
  SectionBoxed,
  SectionTitle,
  SlickCircleNextArrow,
  SlickCirclePrevArrow,
} from "@templates";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Slider from "react-slick";
import { EarnMoreWithSceneCard } from "@templates/EarnMoreWithSceneCard";
interface massProps {
  massOffers: {
    imageUrl: string;
    imageAltText?: string;
    headlineText: string;
    descriptionText: string;
    ctaUrl: string;
    ctaLabel: string;
    ctaId: string;
    ctaAriaLabel?:string;
  }[];
  headlineMassOffers:{
    title:string,
    description:string
  }[];
}
export const MassOffers = (props: massProps) => {
  const lengthSlider = props?.massOffers?.length;
  let massSlider = {
    centerMode: (lengthSlider > 2)?true:false,
    slidesToShow: 3,
    centerPadding: "0",
    infinite:(lengthSlider > 2)?true:false,
    nextArrow: <SlickCircleNextArrow />,
    prevArrow: <SlickCirclePrevArrow />,
    dots: false,
    responsive: [
      {
        breakpoint: 1200,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
          centerPadding: "10%",
          infinite:(lengthSlider > 1)?true:false,
          centerMode:(lengthSlider > 1)?true:false,
        },
      },
      {
        breakpoint: 767,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          centerPadding: "20%",
          
        },
      },
      {
        breakpoint: 576,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          centerPadding: "60px",
        },
      },
      {
        breakpoint: 479,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          centerPadding: "50px",
        },
      },
      {
        breakpoint: 413,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          centerPadding: "0px",
        },
      },
    ],
  };
  React.useEffect(() => {
    const timer = setTimeout(() => {
      document.querySelectorAll('.slick-slide').forEach(b=>b.setAttribute('aria-hidden','false'))
    }, 500);
    return () => clearTimeout(timer);
  }, []);

  return (
    <>
      <SectionBoxed className="fluid pb-18 MassOffers">
        {(props?.massOffers?.length > 0) && <Row>
          <Col md={12}>
            <SectionTitle
              className="offersTitle"
              title={`More ways to earn`}
              belowTitle={`Earn even more Scene+ points through product offers and in-store events`}
            />
          </Col>
        </Row>}
        
        <Slider {...massSlider} className={`personalizeArrow arrow-in-bottom brandCard MassOffersSlider ${(lengthSlider === 1)?'hide-arrow':''} ${(lengthSlider === 2)?'hide-tab':''}`}>
          {props?.massOffers?.length > 0 &&
            props?.massOffers?.map((massOffersCard, index) => (
              <Text as="div" key={`mass_offers${index}`} >
                <EarnMoreWithSceneCard
                  imageUrl={massOffersCard.imageUrl}
                  imageAlt={massOffersCard.imageAltText}
                  headlineText={massOffersCard.headlineText}
                  descriptionText={massOffersCard.descriptionText}
                  ctaLabel={massOffersCard.ctaLabel}
                  ctaUrl={massOffersCard.ctaUrl}
                  ctaId= {`mass_offers_button_${index+1}`}
                  ariaLabel={massOffersCard?.ctaAriaLabel}
                />
              </Text>
            ))}
        </Slider>
      </SectionBoxed>
    </>
  );
};
