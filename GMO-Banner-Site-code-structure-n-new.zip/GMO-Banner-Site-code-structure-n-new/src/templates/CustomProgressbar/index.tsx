import React from "react";
interface Progressbar {
    className?: string,
    points?: any,
    minValue?: string,
    midValue?: string,
    maxValue?: string,
    barValue?: number,
    cachedPoints?: string,
    showAnimation?: boolean;
    currentPoints?: any;
}
export const CustomProgressbar = (props: Progressbar) => {
    const { className = '', points, minValue, midValue, maxValue, barValue = 40, cachedPoints, showAnimation } = props;

    /**** Use effect for cached points  */
    const interval = React.useRef(null);
    const [progress, setProgress] = React.useState(null);
    const [progressPoints, setProgressPoints] = React.useState(0);
    const [opacity, setOpacity] = React.useState(false);
    const [hideDots, setHideDots] = React.useState(false);
    const [animationClass, setAnimationClass] = React.useState(false);
    const [progressValues, setProgressValues] = React.useState([0, 0, 0]);
    const animationSpeed = 14;
  
    React.useEffect(() => {
        const point_history = localStorage.getItem('points_history');

        /***
         * Defined parms for showing or not showing the animation
         */
        let show_animation = false;
        let progress_till = 0; //1 > upto mid 2 > full animation
        let show_points_animation = false;
        let update_points = false;
        let all_point_data = { "min": "0", "mid": "0", "max": "0", "current_points": "0", "bar_value": 0 };
        const current_points = props?.currentPoints;
        /**
         * if in local storage data is not defined
         */
        if (point_history != undefined) {
            all_point_data = JSON.parse(point_history);
            /***
             * To check progress points exceed from the previous max value
             */
            if (parseInt(current_points) >= parseInt(all_point_data?.max) * 100 && (parseInt(current_points) != parseInt(all_point_data?.current_points)) ) {
                show_animation = true;
                progress_till = 2;
                show_points_animation = false;
                update_points = true;
            }
            /**
             * To check if progress points exceed from the middle points
             */
            else if (current_points >= parseInt(all_point_data?.mid) * 100 && parseInt(all_point_data?.current_points) < parseInt(all_point_data?.mid) * 100 && (parseInt(current_points) != parseInt(all_point_data?.current_points))) {
                console.log(all_point_data?.mid, "===== mid");
                show_animation = true;
                progress_till = 1;
                show_points_animation = false;
                update_points = true;
            }
            /***
             * Check if only points increase from the previous value
             */
            else if (parseInt(current_points) > parseInt(all_point_data?.current_points)) {
                show_animation = false;
                progress_till = 0;
                show_points_animation = true;
                update_points = true;
            }
        }
        /**
         * If points are same as previous
         */
        else {
            //update points in the local storage
            show_animation = false;
            progress_till = 0;
            show_points_animation = false;
            update_points = true;
        }

        /**
         * If bar value increase and animation need to display
         */
        if (showAnimation && show_animation) {
            /**
             * Get the old values
             */
            let minValueOld = parseInt(all_point_data?.min);
            let midValueOld = parseInt(all_point_data?.mid);
            let maxValueOld = parseInt(all_point_data?.max);
            let points_array = [10, 50, 99];
            setProgressValues([minValueOld, midValueOld, maxValueOld])
            let points_label = 0;
            let hide_progress = false;
            let currentHold = 0;
            let pointsIncrease = parseInt(all_point_data?.current_points);
            setProgress(all_point_data?.bar_value);
            setProgressPoints(parseInt(all_point_data?.current_points));
            points_label = all_point_data?.bar_value;

          /****
           * Check progress bar check in the middle or full
           */
            if (progress_till !== 2) {
                //half way progress 
                interval.current = setInterval(() => {
                    if (parseInt(all_point_data?.current_points) + 10 < (midValueOld * 100)) {
                        points_label = points_label + 0.5;
                        pointsIncrease = pointsIncrease + 10;
                        if (pointsIncrease < (midValueOld * 100)) {
                            setProgress(points_label);
                            setProgressPoints(pointsIncrease);
                        }
                        else {
                            setProgress(50);
                            setProgressPoints((midValueOld * 100));

                            /***
                             * Added the logic for the next points need to chnage in function
                             */
                            clearInterval(interval.current);
                            setAnimationClass(true);
                            setHideDots(true);
                            setTimeout(() => {

                                setOpacity(true);
                                setTimeout(() => {
                                    setAnimationClass(false)
                                    setOpacity(false);
                                    setHideDots(false);
                                    if (parseInt(midValue) > maxValueOld) {
                                        setProgressValues([parseInt(minValue), parseInt(midValue), parseInt(maxValue)]);
                                    }
                                    let barValue = 0;
                                    if (progress_till === 1) {
                                        barValue = ((2000 - ((maxValueOld * 100) - current_points)) /
                                            2000) * 100;
                                    }
                                    else {
                                        barValue = ((2000 - ((parseInt(maxValue) * 100) - current_points)) /
                                            2000) * 100;
                                    }
                                    animationUpto(midValue, maxValue, points, barValue, (progress_till === 2 ? 0 : 50), (progress_till === 2 ? 30 : 0));
                                    localStorage.setItem('points_cached', midValue);
                                    if (update_points) {
                                        let points_data = {};
                                        if (parseInt(midValue) > maxValueOld) {
                                            points_data = { "min": parseInt(minValue), "mid": parseInt(midValue), "max": parseInt(maxValue), "current_points": props?.currentPoints, "bar_value": barValue };
                                        }
                                        else {
                                            points_data = { "min": minValueOld, "mid": midValueOld, "max": maxValueOld, "current_points": props?.currentPoints, "bar_value": barValue };
                                        }
                                        localStorage.setItem('points_history', JSON.stringify(points_data));
                                    }
                                }, 500);

                            }, 800);
                        }

                    }
                    else {
                        setProgress(50);
                        setProgressPoints((midValueOld * 100));
                        /***
                        * Added the logic for the next points need to chnage in function
                        */
                        clearInterval(interval.current);
                        setAnimationClass(true);
                        setHideDots(true);
                        setTimeout(() => {
      
                            setOpacity(true);
                            setTimeout(() => {
                                setAnimationClass(false)
                                setOpacity(false);
                                setHideDots(false);
                                if (parseInt(midValue) > maxValueOld) {
                                    setProgressValues([parseInt(minValue), parseInt(midValue), parseInt(maxValue)]);
                                }
                                let barValue = 0;
                                if (progress_till === 1) {
                                    barValue = ((2000 - ((maxValueOld * 100) - current_points)) /
                                        2000) * 100;
                                }
                                else {
                                    barValue = ((2000 - ((parseInt(maxValue) * 100) - current_points)) /
                                        2000) * 100;
                                }
                                animationUpto(midValue, maxValue, points, barValue, (progress_till === 2 ? 0 : 50), (progress_till === 2 ? 30 : 0));
                                localStorage.setItem('points_cached', midValue);
                                if (update_points) {
                                    let points_data = {};
                                    if (parseInt(midValue) > maxValueOld) {
                                        points_data = { "min": parseInt(minValue), "mid": parseInt(midValue), "max": parseInt(maxValue), "current_points": props?.currentPoints, "bar_value": barValue };
                                    }
                                    else {
                                        points_data = { "min": minValueOld, "mid": midValueOld, "max": maxValueOld, "current_points": props?.currentPoints, "bar_value": barValue };
                                    }
                                    localStorage.setItem('points_history', JSON.stringify(points_data));
                                }
                            }, 500);
      
                        }, 800);
                    }
                }, animationSpeed);
            }
            else if(progress_till === 2) {
                //full progress 
                interval.current = setInterval(() => {
                    if (parseInt(all_point_data?.current_points) + 10 < (maxValueOld * 100)) {
                  
                        points_label = points_label + 0.5;
                        pointsIncrease = pointsIncrease + 10;
                        if (pointsIncrease < (maxValueOld * 100)) {
                            setProgress(points_label);
                            setProgressPoints(pointsIncrease);
                        }
                        else {
                            setProgress(100);
                            setProgressPoints((maxValueOld * 100));

                            /***
                             * Added the logic for the next points need to chnage in function
                             */
                            clearInterval(interval.current);
                            setAnimationClass(true);
                            setHideDots(true);
                            setTimeout(() => {

                                setOpacity(true);
                                setTimeout(() => {
                                    setAnimationClass(false)
                                    setOpacity(false);
                                    setHideDots(false);
                                    if (parseInt(midValue) > maxValueOld) {
                                        setProgressValues([parseInt(minValue), parseInt(midValue), parseInt(maxValue)]);
                                    }
                                    let barValue = 0;
                                    if (progress_till === 1) {
                                        barValue = ((2000 - ((maxValueOld * 100) - current_points)) /
                                            2000) * 100;
                                    }
                                    else {
                                        barValue = ((2000 - ((parseInt(maxValue) * 100) - current_points)) /
                                            2000) * 100;
                                    }
                                    animationUpto(minValue, maxValue, points, barValue, (progress_till === 2 ? 0 : 50), (progress_till === 2 ? 30 : 0));
                                    localStorage.setItem('points_cached', midValue);
                                    if (update_points) {
                                        let points_data = {};
                                        if (parseInt(midValue) > maxValueOld) {
                                            points_data = { "min": parseInt(minValue), "mid": parseInt(midValue), "max": parseInt(maxValue), "current_points": props?.currentPoints, "bar_value": barValue };
                                        }
                                        else {
                                            points_data = { "min": minValueOld, "mid": midValueOld, "max": maxValueOld, "current_points": props?.currentPoints, "bar_value": barValue };
                                        }
                                        localStorage.setItem('points_history', JSON.stringify(points_data));
                                    }
                                }, 500);

                            }, 800);
                        }
                    }
                    else {
                        setProgress(100);
                        setProgressPoints((maxValueOld * 100));

                        /***
                         * Added the logic for the next points need to chnage in function
                         */
                        clearInterval(interval.current);
                        setAnimationClass(true);
                        setHideDots(true);
                        setTimeout(() => {

                            setOpacity(true);
                            setTimeout(() => {
                                setAnimationClass(false)
                                setOpacity(false);
                                setHideDots(false);
                                if (parseInt(midValue) > maxValueOld) {
                                    setProgressValues([parseInt(minValue), parseInt(midValue), parseInt(maxValue)]);
                                }
                                let barValue = 0;
                                if (progress_till === 1) {
                                    barValue = ((2000 - ((maxValueOld * 100) - current_points)) /
                                        2000) * 100;
                                }
                                else {
                                    barValue = ((2000 - ((parseInt(maxValue) * 100) - current_points)) /
                                        2000) * 100;
                                }
                                animationUpto(minValue, maxValue, points, barValue, (progress_till === 2 ? 0 : 50), (progress_till === 2 ? 30 : 0));
                                localStorage.setItem('points_cached', midValue);
                                if (update_points) {
                                    let points_data = {};
                                    if (parseInt(midValue) > maxValueOld) {
                                        points_data = { "min": parseInt(minValue), "mid": parseInt(midValue), "max": parseInt(maxValue), "current_points": props?.currentPoints, "bar_value": barValue };
                                    }
                                    else {
                                        points_data = { "min": minValueOld, "mid": midValueOld, "max": maxValueOld, "current_points": props?.currentPoints, "bar_value": barValue };
                                    }
                                    localStorage.setItem('points_history', JSON.stringify(points_data));
                                }
                            }, 500);

                        }, 800);
                    }
                }, animationSpeed);
            }

        }
        else if ((!parseInt(cachedPoints) && current_points > 1000)  && showAnimation) {
            /**
             * Incase loaded first time and points are more than 2000
             */
            /****
             * When no cached points exists  
             * */
            let minValueOld = 0;
            let midValueOld = 10;
            let maxValueOld = 20;
            let points_array = [10, 50, 99];
            setProgressValues([minValueOld, midValueOld, maxValueOld])
            let points_label = 0;
            let hide_progress = false;
            let currentHold = 0;
            let pointsIncrease = 0;
            let totalPoints = maxValueOld * 100;
            interval.current = setInterval(() => {
                points_label = points_label + 0.5;
                pointsIncrease = pointsIncrease + 10;
                if (pointsIncrease < totalPoints) {
                    setProgressPoints(pointsIncrease);
                    setProgress(points_label);
                }
                else {
                    console.log('completed');
                    clearInterval(interval.current);
                    setProgress(100);
                    setProgressPoints(totalPoints);
                    setAnimationClass(true);
                    setHideDots(true);
                    setTimeout(() => {
                        setProgress(0)
                        setOpacity(true);
                        setTimeout(() => {
                            setAnimationClass(false)
                            setOpacity(false);
                            setHideDots(false);
                            if (parseInt(midValue) > maxValueOld) {
                                setProgressValues([parseInt(minValue), parseInt(midValue), parseInt(maxValue)]);
                            }
                            let barValue = ((2000 - ((parseInt(maxValue) * 100) - current_points)) /
                            2000) * 100;
                            animationUpto(minValue, maxValue, points,barValue,0);
                            localStorage.setItem('points_cached', midValue);
                            if (update_points) {
                                let points_data = {};
                                if (parseInt(midValue) > maxValueOld) {
                                    points_data = { "min": parseInt(minValue), "mid": parseInt(midValue), "max": parseInt(maxValue), "current_points": props?.currentPoints, "bar_value": barValue };
                                }
                                else {
                                    points_data = { "min": minValueOld, "mid": midValueOld, "max": maxValueOld, "current_points": props?.currentPoints, "bar_value": barValue };
                                }
                                localStorage.setItem('points_history', JSON.stringify(points_data));
                            }
                        }, 500);

                    }, 800);
                }
                
            },animationSpeed);
         
        }
        else {
         if(showAnimation){
            /**
             * checked only points increase or decrease 
             */
            let minValueOld = parseInt(all_point_data?.min);
            let midValueOld = parseInt(all_point_data?.mid);
            let maxValueOld = parseInt(all_point_data?.max);
            let barValue = 0;
            /***
             * Incase points are increased and max old value exists
             */
            if (current_points > all_point_data?.current_points && maxValueOld) {
                setProgressValues([minValueOld, midValueOld, maxValueOld]);
                setProgressPoints(parseInt(all_point_data?.current_points));
                setProgress(all_point_data?.bar_value)
               
                const timer = setTimeout(() => {
                    setProgressPoints(parseInt(current_points));
                    barValue = ((2000 - ((maxValueOld * 100) - current_points)) /
                        2000) * 100;
                    setProgress(barValue);
                 
                    /**
                     * Adding data in local storage
                     */
                let points_data = { "min":minValueOld, "mid": midValueOld, "max": maxValueOld, "current_points": props?.currentPoints, "bar_value": barValue };
                localStorage.setItem('points_history', JSON.stringify(points_data));
                }, 7000);
            }
            else {
                /**
                 * Set the initial bar value
                 */
                barValue = ((2000 - ((parseInt(maxValue) * 100) - current_points)) /
                    2000) * 100;
                setProgressPoints(current_points);
                setProgress(barValue);
                setProgressValues([parseInt(minValue), parseInt(midValue), parseInt(maxValue)]);
                setProgressPoints(points);

            }
           /***
            * Checked here if points decrease
            */
            if (all_point_data?.current_points && (current_points < parseInt(all_point_data?.current_points))) {
                console.log("here in condition if points decrease");
                let barValue = ((2000 - ((parseInt(maxValue) * 100) - current_points)) /
                    2000) * 100;
                console.log((parseInt(maxValue) * 100) - current_points, "===== points");
                setProgressValues([parseInt(minValue), parseInt(midValue), parseInt(maxValue)]);
                let points_data = { "min": parseInt(minValue), "mid": parseInt(midValue), "max": parseInt(maxValue), "current_points": props?.currentPoints, "bar_value": barValue };
                localStorage.setItem('points_history', JSON.stringify(points_data));
                setProgress(barValue);
            }
             /***
             * All new values recieved
             */
            if (maxValueOld != 0 && (parseInt(midValue) > maxValueOld)) {
                let barValue = ((2000 - ((maxValueOld * 100) - current_points)) /
                    2000) * 100;
                console.log((parseInt(maxValue) * 100) - current_points, "===== points");
                setProgressValues([parseInt(minValue), parseInt(midValue), parseInt(maxValue)]);
                let points_data = { "min": parseInt(minValue), "mid": parseInt(midValue), "max": parseInt(maxValue), "current_points": props?.currentPoints, "bar_value": barValue };
                localStorage.setItem('points_history', JSON.stringify(points_data));
                setProgress(barValue);
            }

            /***
             * Updating with the old values
             */
            else {

                if (current_points === all_point_data?.current_points) {
                    let barValue = 0
                    if (maxValueOld != 0) {
                        barValue = ((2000 - ((maxValueOld * 100) - current_points)) /
                            2000) * 100;
                    }
                    else {
                        barValue = ((2000 - ((parseInt(maxValue) * 100) - current_points)) /
                            2000) * 100;
                    }
                    setProgressValues([minValueOld, midValueOld, maxValueOld]);
                    let points_data = { "min": minValueOld, "mid": midValueOld, "max": maxValueOld, "current_points": props?.currentPoints, "bar_value": barValue };
                    setProgressPoints(parseInt(props?.currentPoints));
                    localStorage.setItem('points_history', JSON.stringify(points_data));
                    setProgress(barValue);
                }
            }
            localStorage.setItem('points_cached', midValue);
            if (update_points) {
                let points_data = { "min": parseInt(minValue), "mid": parseInt(midValue), "max": parseInt(maxValue), "current_points": props?.currentPoints, "bar_value": barValue };
                localStorage.setItem('points_history', JSON.stringify(points_data));
            }
        }
        else{
            /*** 
             * As due to accessibility component is changed
             */
            if(!showAnimation){
                /**
                 * checked only points increase or decrease 
                 */
                let minValueOld = parseInt(all_point_data?.min);
                let midValueOld = parseInt(all_point_data?.mid);
                let maxValueOld = parseInt(all_point_data?.max);
                let barValue = 0;
                /***
                 * Incase points are increased and max old value exists
                 */
                if (current_points > all_point_data?.current_points && maxValueOld) {
                    setProgressValues([minValueOld, midValueOld, maxValueOld]);
                    setProgressPoints(parseInt(all_point_data?.current_points));
                    setProgress(all_point_data?.bar_value)
                   
                    const timer = setTimeout(() => {
                        setProgressPoints(parseInt(current_points));
                        barValue = ((2000 - ((maxValueOld * 100) - current_points)) /
                            2000) * 100;
                        setProgress(barValue);
                     
                        /**
                         * Adding data in local storage
                         */
                    }, 7000);
                }
                else {
                    /**
                     * Set the initial bar value
                     */
                    barValue = ((2000 - ((parseInt(maxValue) * 100) - current_points)) /
                        2000) * 100;
                    setProgressPoints(current_points);
                    setProgress(barValue);
                    setProgressValues([parseInt(minValue), parseInt(midValue), parseInt(maxValue)]);
                    //setProgressPoints(points);
    
                }
               /***
                * Checked here if points decrease
                */
                if (all_point_data?.current_points && (current_points < parseInt(all_point_data?.current_points))) {
                    console.log("here in condition if points decrease");
                    let barValue = ((2000 - ((parseInt(maxValue) * 100) - current_points)) /
                        2000) * 100;
                    console.log((parseInt(maxValue) * 100) - current_points, "===== points");
                    setProgressValues([parseInt(minValue), parseInt(midValue), parseInt(maxValue)]);
                    setProgress(barValue);
                }
                 /***
                 * All new values recieved
                 */
                if (maxValueOld != 0 && (parseInt(midValue) > maxValueOld)) {
                    let barValue = ((2000 - ((maxValueOld * 100) - current_points)) /
                        2000) * 100;
                    setProgressValues([parseInt(minValue), parseInt(midValue), parseInt(maxValue)]);
                    setProgress(barValue);
                }
    
                /***
                 * Updating with the old values
                 */
                else {
    
                    if (current_points === all_point_data?.current_points) {
                        let barValue = 0
                        if (maxValueOld != 0) {
                            barValue = ((2000 - ((maxValueOld * 100) - current_points)) /
                                2000) * 100;
                        }
                        else {
                            barValue = ((2000 - ((parseInt(maxValue) * 100) - current_points)) /
                                2000) * 100;
                        }
                        setProgressValues([minValueOld, midValueOld, maxValueOld]);
                     
                        setProgressPoints(parseInt(props?.currentPoints));
                        setProgress(barValue);
                    }
                }
              
            }
        }
        }


        return () => {
            clearInterval(interval.current)
            clearTimeout()
        };
    }, []);

/***
 * Handle the animation upto points
 */
    const animationUpto = (current, upto, max, width, currentWidth,defaultTimeout=30) => {
        console.log(currentWidth);
        let currentPoints = parseInt(current) * 100;
        let pointsUpto = parseInt(max);
        let current_width = currentWidth;
        setProgress(currentWidth);
        setProgressPoints(currentPoints);

        setTimeout(
            () => {
                interval.current = setInterval(() => {
                    currentPoints = currentPoints + 10;
                    current_width = current_width + 0.5;
                    if (currentPoints <= pointsUpto) {
                        setProgressPoints(currentPoints);
                    }
                    else {
                        setProgressPoints(pointsUpto);    
                    }
                    if (current_width <= width) {
                        setProgress(current_width);
                    }
                }, animationSpeed);
            }, 
            700
          );
       
        return () => {
            clearInterval(interval.current)
        };
    }
    const minActive = progress >= 7 ? 'active' : '';
    const midActive = progress >= 50 ? 'active' : '';
    const maxActive = progress >= 99 ? 'active' : '';
    const rowPinPosition = progress > 94 ? 94 : progress;
    const opacityClass = opacity ? 'opacity-0' : '';
    const hidedots = hideDots ? 'opacity-0' : '';

    const ProgressBarInner = ({width,points,hidedots}) => {
        return (<>
        <div className="ProgressbarRow">
                    <span className="ProgressbarRowFill" style={{ width: `${width}%` }}></span>
                </div>
                <span className="ProgessbarRowPin" style={{ left: `${width}%` }}></span>
                <span className={`ProgressbarPoints ${hidedots}`} style={{ left: `${width}%` }}>
                    {points && points.toLocaleString()} PTS</span>
        </>)
    }
    return (
        <div className={`Progressbar ${className} ${animationClass ? 'playAnimation' : ''} ${opacityClass}`}>
            <div className="ProgressbarInner">
                <ProgressBarInner width={progress} points={progressPoints} hidedots={hidedots}/>
                <span className={`ProgressbarDot min ${minActive} ${hidedots}`}><span>${progressValues[0]}</span></span>
                <span className={`ProgressbarDot mid ${midActive} ${hidedots}`}><span>${progressValues[1]}</span></span>
                <span className={`ProgressbarDot max ${maxActive}`}><span>${progressValues[2]}</span></span>

                <i className="bubble bubble-1"></i>
                <i className="bubble bubble-2"></i>
                <i className="bubble bubble-3"></i>
                <i className="bubble bubble-4"></i>
                <i className="bubble bubble-5"></i>
                <i className="bubble bubble-6"></i>
                <i className="bubble bubble-7"></i>
                <i className="bubble bubble-8"></i>
                <i className="bubble bubble-9"></i>
                <i className="bubble bubble-10"></i>
                <i className="bubble bubble-11"></i>
                <i className="bubble bubble-12"></i>
                <i className="bubble bubble-13"></i>
                <i className="bubble bubble-14"></i>
            </div>
        </div>
    )
}