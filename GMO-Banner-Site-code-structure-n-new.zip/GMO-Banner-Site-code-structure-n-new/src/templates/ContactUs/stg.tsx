import React from "react";
import ReCAPTCHA from "react-google-recaptcha";
import { useForm, Controller } from "react-hook-form";
import { useRouter } from "next/router";
import parse from "html-react-parser";
import { css } from "@emotion/css";
import Select from "@components/Select";
import { Input, TextArea, Row, Col, Container, Text } from "@components";
import styles from "@styles/contactus.module.scss";
import en from "lang/en";
import fr from "lang/fr";
interface pageData {
  pageData?: any;
}
const StgForm = React.forwardRef<
  HTMLDivElement,
  React.PropsWithChildren<pageData>
>(({ pageData, children, ...props }, ref) => {
  const router = useRouter();
  const { locale } = router;
  const t = locale === "en" ? en : fr;
  const recaptchaRef = React.createRef();
  const [recaptchaValid, SetReacaptchaValid] = React.useState(false);
  const [recaptchaValue, SetRecaptchaValue] = React.useState(null);
  const [secondStep, setSecondStep] = React.useState([false, true]);
  const [subTypeList, setSubTypeList] = React.useState([]);
  const [contactText, setContactText] = React.useState(false);
  const [emailHidden, SetEmailHidden] = React.useState(null);
  const [showSubType, setShowSubType] = React.useState(false);
  const [submissionError, setSubmissionError] = React.useState(false);
  /***
   * 
   * fields for the contact form dropdown selection
   */
  const valueMap = {
    // "In-Store-Purchase": ["Returns", "Purchase History", "Track Savings", "Redeem Points", "Missing Points", "Points Adjustments"],
    // "Online-Purchase": ["Order Status", "Returns", "Purchase History", "Track Savings", "Redeem Points", "Missing Points", "Points Adjustments", "Vouchers"],
    // "Available-Offers": ["Loyalty Partner Offers", "My Offers", "Personalized Offers"],
    // "Loyalty-Account": ["Registration", "Update/ Manage Account", "De-link Loyalty Account", "Lock/ Unlock Account", "Delete Account", "Manage Household Profile", "Change Personal/ Contact Info", "Update Communication Preference", "Communication Opt In", "Communication Opt Out", "Manage Collector Profiles", "Linking Cards", "Close Accounts", "Scotia Scene Card*"],
    // "Loyalty-Points": ["Balance", "Points Redemption", "Transfer Points", "Buy Points", "Add Goodwill Points", "Points Escalation"],
    // "Loyalty-Card": ["Lost card", "Lock/ Unlock Card", "Report Fraud/ other issues", "Merging Card", "Load MyOffers to Loyalty Card"],
    // "General-Inquiries": ["Foodland", "Provide feedback for points", "Loyalty Partner", "Scene Unresponsive"],
    "Scene": ["In-Store Purchase", "Online Purchase", "Scene Partner Offers (Non Empire)", "Personalized Offers", "Registration", "Scene Account updates", "Linking Cards", "De-linking Card", "Loyalty Points", "Loyalty Card", "Program Feedback", "App Inquiries", "Reason Not Listed"],
  };
  /***
   * To show the contact text instead of the form
   */
  const showContactText = ["In-Store Purchase", "Online Purchase", "Scene Partner Offers (Non Empire)", "Personalized Offers", "Registration", "Scene Account updates", "Linking Cards", "Loyalty Points", "Program Feedback", "App Inquiries", "Loyalty Card"];
  let dataFields = {
    emailSale: "00N1U00000VsCWB",
    phoneSale: "00N1D00000NVLlj",
    firstNameSale: "00N1U00000VsCWE",
    lastNameSale: "00N1U00000VsCWL",
    bannerSale: "00N1U00000VsCW7",
    storeIdSale: "00N1D00000BqR8T",
    provinceSale: "00N1U00000VsApl",
    languageSale: "00N1U00000VsCWK",
    storeId: "00N1D00000BqR8T",
    issueType: "00N1U00000UlXji",
    subType: "00N1U00000UlXjp"
  };
  const {
    emailSale,
    phoneSale,
    firstNameSale,
    lastNameSale,
    bannerSale,
    provinceSale,
    languageSale,
    storeId,
    issueType,
    subType
  } = dataFields;

  const {
    register,
    handleSubmit,
    control,
    setValue,
    setError,
    formState: { errors, isValid },
  } = useForm();
  const [Success, SetSuccess] = React.useState(false);

  const onSubmit = async (data) => {
    const urlExists = await fetch('api/sobeys?url='+(document.getElementById("form1") as HTMLFormElement).action, {
      method: "GET"
    });
    try{
      const jsonData = await urlExists.json();
      if(jsonData?.success){
       (document.getElementById("form1") as HTMLFormElement)?.submit();
      }
      else{
        setSubmissionError(true);
        console.log('something went wrong');
      }
    }
    catch(Exception){
      setSubmissionError(true);
     console.log(Exception.message);
    }
    return true;
  };

  /*** Google recaptcha on change  */
  const RecaptchaChange = () => {
    SetReacaptchaValid(true);
  };
  /*** Google recaptcha on expired  */
  const RecaptchaExpired = () => {
    SetReacaptchaValid(false);
  };
  /****
   * @function inputChange
   * to set the value in email hidden field
   */
  const inputChange = (e) => {
    SetEmailHidden(e.target.value);
  }
  React.useEffect(() => {

    const timestamp = () => {
      var response = document.getElementById("g-recaptcha-response");
      //@ts-ignore
      if ((response === null || response?.value.trim() === "") && document.getElementsByName("captcha_settings")[0]?.value != undefined) {
        //@ts-ignore
        var elems = JSON?.parse(document.getElementsByName("captcha_settings")[0]?.value);
        elems["ts"] = JSON?.stringify(new Date().getTime());
        SetRecaptchaValue(JSON?.stringify(elems));
        //  //@ts-ignore
      }
    }
    setInterval(timestamp, 500);
    if (router.query && router.query.success) {
      SetSuccess(true);
      router.replace('/contact-us', undefined, { shallow: true });
    }
    return () => {};
  }, [router.query]);
  const handleNumberChange = (e) => {
    const re = /^[0-9\b]+$/;
    if (e.target.value === '' || re.test(e.target.value)) {
      setValue("phone", e.target.value);
    }
    else {
      setValue("phone", '');
    }
  }
  const handleInputChange = (e, name) => {
    if (name === "issueType") {
      if (e) {
        setValue(issueType, e);
        setError(issueType, { message: "" });
        setSecondStep([true, true]);
        if (e === "Scene") {
          setShowSubType(true);
          setSecondStep([true, false]);
        } else {
          setContactText(false);
          setShowSubType(false);
        }
        setSubTypeList(valueMap[(e).replaceAll(" ", "-")]);
        setValue(subType, '');
      }
      else {
        setValue(issueType, '');
        setError(issueType, { message: "Issue Type is required" });
        setShowSubType(false);
        setSecondStep([false, true]);
        setSubTypeList([]);
      }
    }
    else {
      if (e) {
        setValue(subType, e);
        setError(subType, { message: "" });
        setSecondStep([secondStep["0"], true]);
        setContactText(showContactText.includes(e) ? true : false)
      }
      else {
        setValue(subType, '');
        setError(subType, { message: "Sub type is required" })
        setSecondStep([secondStep["0"], false]);
        setContactText(false);
      }
    }
  }
  const formatInput = (event) => {
    const attribute = event.target.getAttribute('name');
    setValue(attribute, event.target.value.trimStart())
  }
  const optionDropdown: { id: string; name: string }[] = [
    { id: "Scene", name: "Scene" },
    { id: "Online Orders", name: "Online Orders" },
    { id: "Food Safety", name: "Food Safety" },
    { id: "Customer Experience", name: "Customer Experience" },
    { id: "National Brands", name: "National Brands" },
    { id: "Consumer Marketing", name: "Consumer Marketing" },
    { id: "Product Inquiries", name: "Product Inquiries" },
    { id: "Human Resources", name: "Human Resources" },
    { id: "Store Level", name: "Store Level" },
    { id: "Corporate", name: "Corporate" },
  ];
  const optionScene: { id: string; name: string }[] = [
    { id: "In-Store Purchase", name: "In-Store Purchase" },
    { id: "Online Purchase", name: "Online Purchase" },
    { id: "Scene Partner Offers (Non Empire)", name: "Scene Partner Offers (Non Empire)" },
    { id: "Personalized Offers", name: "Personalized Offers" },
    { id: "Registration", name: "Registration" },
    { id: "Scene Account updates", name: "Scene Account updates" },
    { id: "Linking Cards", name: "Linking Cards" },
    { id: "De-linking Card", name: "De-linking Card" },
    { id: "Loyalty Points", name: "Loyalty Points" },
    { id: "Loyalty Card", name: "Loyalty Card" },
    { id: "Program Feedback", name: "Program Feedback" },
    { id: "App Inquiries", name: "App Inquiries" },
    { id: "Reason Not Listed", name: "Reason Not Listed" }
  ];

  const optionRegion: { id: string; name: string }[] = [
    { id: "AB", name: "Alberta" },
    { id: "BC", name: "British Columbia" },
    { id: "MB", name: "Manitoba" },
    { id: "NB", name: "New Brunswick" },
    { id: "NL", name: "Newfoundland and Labrador" },
    { id: "NS", name: "Nova Scotia" },
    { id: "NT", name: "Northwest Territories" },
    { id: "NU", name: "Nunavut" },
    { id: "ON", name: "Ontario" },
    { id: "PE", name: "Prince Edward Island" },
    { id: "QC", name: "Quebec" },
    { id: "SK", name: "Saskatchewan" },
    { id: "YT", name: "Yukon" },
  ];

  const optionBanner: { id: string; name: string }[] = [
    { id: "Voila", name: "Voila" },
    { id: "Sobeys", name: "Sobeys" },
    { id: "Safeway", name: "Safeway" },
    { id: "Thrifty Foods", name: "Thrifty Foods" },
    { id: "Foodland", name: "Foodland" },
    { id: "IGA West", name: "IGA West" },
    { id: "IGA", name: "IGA" },
    { id: "FreshCo", name: "FreshCo" },
    { id: "Lawtons", name: "Lawtons" },
    { id: "Rachelle Berry", name: "Rachelle Berry" },
    { id: "Tradition", name: "Tradition" },
    { id: "Needs (Fast Fuel)", name: "Needs (Fast Fuel)" },
    { id: "Sobeys Liquor", name: "Sobeys Liquor" },
    { id: "Safeway Liquor", name: "Safeway Liquor" },
    { id: "Thrifty Foods Liquor", name: "Thrifty Foods Liquor" }
  ];
  /**
   * Handle on change banner sale
   */
const handleBannerChange = (val) => {
    if(val){
  setValue(bannerSale,val);
  setValue("bannerSale",val);
  setError("bannerSale",{message:''})
    }
  }
const handleProvienceChange = (val) => {
    if(val){
  setValue(provinceSale,val);
  setValue("provinceSale",val);
  setError("provinceSale",{message:''})
    }
  }
  return (
    <>
    {!submissionError ? (  <div className={styles.ContactUs + " py-18 contact-us"} aria-label="inner-form" role="form">
        <Container size="lg">
          <>
            <div className="DefaultForm">
              <Row alignItems="flex-start">
                <Col xs={12} md={8}>
                  
                  {Success ? (<div className="thankyouMessage">
                    <h3>{pageData?.acf_tru_information_banner?.[0]?.blockdata?.[0]?.subtitle && parse(pageData?.acf_tru_information_banner?.[0]?.blockdata?.[0]?.subtitle)} </h3>
                  </div>) : (
                    <>
                    {pageData?.acf_tru_inner_header[0] &&
                    <div className={styles.TopHeaderText}>
                      <p>
                        {
                          pageData?.acf_tru_inner_header[0]?.blockdata[0]
                            ?.description
                        }
                      </p>
                    </div>
                  }
                  <form
                    method="POST"
                    id="form1"
                    action="https://sobeys--preprod.my.salesforce.com/servlet/servlet.WebToCase?encoding=UTF-8"
                    onSubmit={handleSubmit(onSubmit)}
                  >
                    <Row>
                      <Col xs={12} sm={6} md={6} lg={6}>
                        <div className="ContactSelect" id="start-of-content">
                          <Controller
                            name={issueType}
                            control={control}
                            rules={{
                              required: t["Issue Type is required."],
                            }}
                            render={({ field }) => (
                              <Select
                                id="00N1U00000UlXji"
                                tabIndex={0}
                                placeholder="Select Issue Type"
                                options={optionDropdown}
                                {...field}
                                className={"selectRetailer"}
                                style={{ width: 80, color: "#aaaaaa" }}
                                onChange={(e) => handleInputChange(e, "issueType")}
                                classes={{
                                  root: "selectroot",
                                  selectInput: "inputSelect",
                                  selectContainerWrapper: "selectContainerWrapper",
                                  selectText: "SelectBoxText",
                                  selectIcon: "SelectBoxIcon",
                                  selectOptions: "SelectDropdownContainer",
                                  selectList: "SelectDropdownUl",
                                  selectListItem: "selectListItem",
                                  selectActiveItem: "selectActiveItem",
                                }}

                              />

                            )}
                          />
                          {errors[issueType] && (
                            <span className="SelectErrorMessage">
                              {errors[issueType].message}
                            </span>
                          )}
                        </div>
                      </Col>
                      {showSubType && <Col xs={12} sm={6} md={6} lg={6}>
                        <div className="ContactSelect">
                          <Controller
                            name={subType}
                            control={control}
                            // rules={{
                            //   required: t["Sub Type is required."],
                            // }}
                            render={({ field }) => (
                              <Select
                              id="00N1U00000UlXjp"
                                tabIndex={0}
                                placeholder="Select Subtype"
                                options={optionScene}
                                {...field}
                                className={"selectRetailer"}
                                style={{ width: 80, color: "#aaaaaa" }}
                                onChange={(e) => handleInputChange(e, "SubType")}
                                classes={{
                                  root: "selectroot",
                                  selectInput: "inputSelect",
                                  selectContainerWrapper: "selectContainerWrapper",
                                  selectText: "SelectBoxText",
                                  selectIcon: "SelectBoxIcon",
                                  selectOptions: "SelectDropdownContainer",
                                  selectList: "SelectDropdownUl",
                                  selectListItem: "selectListItem",
                                  selectActiveItem: "selectActiveItem",
                                }}

                              />
                            )}
                          />
                          {errors[subType] && (
                            <span className="SelectErrorMessage">
                              {errors[subType].message}
                            </span>
                          )}
                        </div>
                      </Col>}

                    </Row>
                    <>

                      {(secondStep[0] && secondStep[1] && !contactText) && (<>
                        <Row>
                          <Col xs={12} sm={6} md={6} lg={6}>
                            <label htmlFor="00N1U00000VsCWE" aria-hidden="true" className="hiden-label">First Name</label>
                            <Controller
                              name={firstNameSale}
                              control={control}
                              rules={{
                                required: t["First name is required."],
                                pattern: {
                                  value: /^[A-Za-z\s]+$/i,
                                  message: t["Please enter valid first name"]
                                }
                              }}
                              render={({ field }) => (
                                <Input
                                  type="text"
                                  id="00N1U00000VsCWE"
                                  isRequired={false}
                                  className="form-control"
                                  placeholder="First Name*"
                                  maxLength={18}
                                  //onKeyUp={formatInput}
                                  aria-required="true"
                                  errorMessage={
                                    errors[firstNameSale] &&
                                    errors[firstNameSale].message
                                  }
                                  {...field}
                                />
                              )}
                            />
                            {/* <span id="firstName" className="sr-only">First Name</span> */}
                          </Col>
                          <Col xs={12} sm={6} md={6} lg={6}>
                            <label htmlFor="00N1U00000VsCWL" aria-hidden="true" className="hiden-label">Last Name</label>
                            <Controller
                              name={lastNameSale}
                              control={control}
                              rules={{
                                required: t["Last name is required."],
                                pattern: {
                                  value: /^[A-Za-z\s]+$/i,
                                  message: t["Please enter valid last name"]
                                }
                              }}
                              render={({ field }) => (
                                <Input
                                  type="text"
                                  id="00N1U00000VsCWL"
                                  maxLength={18}
                                  isRequired={false}
                                  className="form-control"
                                  aria-required="true"
                                  placeholder="Last Name*"
                                  //onKeyUp={formatInput}
                                  errorMessage={
                                    errors[lastNameSale] &&
                                    errors[lastNameSale].message
                                  }
                                  {...field}
                                />
                              )}
                            />
                          </Col>
                        </Row>
                        <Row>
                          <Col xs={12} sm={6} md={6} lg={6}>
                            <label htmlFor="email" aria-hidden="true" className="hiden-label">Email</label>
                            <Controller
                              name={emailSale}
                              control={control}
                              rules={{
                                required: t["Email is required."],
                                pattern: {
                                  value:
                                    /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                                  message: t["Please enter a valid email address."],
                                },
                              }}
                              render={({ field }) => (
                                <Input
                                  type="text"

                                  isRequired={false}
                                  id="email"
                                  className="form-control"
                                  aria-required="true"
                                  placeholder="Email*"
                                  onKeyUp={inputChange}
                                  errorMessage={
                                    errors[emailSale] && errors[emailSale].message
                                  }
                                  {...field}
                                />
                              )}
                            />
                          </Col>
                          <Col xs={12} sm={6} md={6} lg={6}>
                            <label htmlFor="phone" aria-hidden="true" className="hiden-label">Phone</label>
                            <Controller
                              name="phone"
                              control={control}
                              rules={{
                                required: t["Phone number is required."],
                                pattern: {
                                  value: /^[0-9\b]+$/,
                                  message: t["Please enter the valid phone number"],
                                },
                                maxLength: {
                                  value: 10,
                                  message: t["Max 10 numbers are allowed."],
                                },

                              }}
                              render={({ field }) => (
                                <Input
                                  type="text"
                                  id="phone"
                                  className="form-control"
                                  isRequired={false}
                                  onKeyUp={handleNumberChange}
                                  aria-required="true"
                                  placeholder="Phone*"
                                  errorMessage={
                                    errors["phone"] && errors["phone"].message
                                  }
                                  {...field}
                                />
                              )}
                            />
                          </Col>
                        </Row>

                        <Row>
                          <Col xs={12} sm={6} md={6} lg={6}>
                            <div className="ContactSelect">
                              <label htmlFor="00N1U00000VsApl" aria-hidden="true" className="hiden-label">Province</label>
                              <Controller
                                name={"provinceSale"}
                                control={control}
                                rules={{
                                  required: t["Province is required."],
                                }}
                                render={({ field}) => (
                                  <Select
                                    id="00N1U00000VsApl"
                                    tabIndex={0}
                                    placeholder="Select Province"
                                    options={optionRegion}
                                    className={`selectRetailer ${(errors["provinceSale"]?.message)?'error-tru':''}`}
                                    style={{ width: 80, color: "#aaaaaa" }}
                                    {...field}
                                    onChange={(e) => handleProvienceChange(e)}
                                    classes={{
                                      root: "selectroot",
                                      selectInput: "inputSelect",
                                      selectContainerWrapper: "selectContainerWrapper",
                                      selectText: "SelectBoxText",
                                      selectIcon: "SelectBoxIcon",
                                      selectOptions: "SelectDropdownContainer",
                                      selectList: "SelectDropdownUl",
                                      selectListItem: "selectListItem",
                                      selectActiveItem: "selectActiveItem",
                                    }}

                                  />
                                )}
                              />
                              {errors["provinceSale"]?.message && (
                                <span className="SelectErrorMessage">
                                  {errors["provinceSale"].message}
                                </span>
                              )}
                            </div>
                          </Col>
                          <Col xs={12} sm={6} md={6} lg={6}>
                            <div className="ContactSelect">
                              <label htmlFor="00N1U00000VsCW7" aria-hidden="true" className="hiden-label">Banner</label>
                              <Controller
                                name={"bannerSale"}
                                control={control}
                                rules={{
                                  required: t["Banner is required."],
                                }}
                                render={({ field }) => (
                                  <Select
                                  id="00N1U00000VsCW7"
                                  tabIndex={0}
                                  placeholder="Select Banner"
                                  options={optionBanner}
                                  {...field}
                                  onChange={(e) => handleBannerChange(e)}
                                  className={`selectRetailer ${(errors["bannerSale"]?.message)?'error-tru':''}`}
                                  style={{ width: 80, color: "#aaaaaa" }}
                                  classes={{
                                    root: "selectroot",
                                    selectInput: "inputSelect",
                                    selectContainerWrapper: "selectContainerWrapper",
                                    selectText: "SelectBoxText",
                                    selectIcon: "SelectBoxIcon",
                                    selectOptions: "SelectDropdownContainer",
                                    selectList: "SelectDropdownUl",
                                    selectListItem: "selectListItem",
                                    selectActiveItem: "selectActiveItem",
                                  }}

                                />
                                )}
                              />
                              {errors["bannerSale"]?.message && (
                                <span className="SelectErrorMessage">
                                  {errors["bannerSale"].message}
                                </span>
                              )}
                            </div>
                          </Col>

                        </Row>

                        <Row>

                          {/* <Col xs={12} sm={6} md={6} lg={6}>
                            <div className="ContactSelect">
                            <label htmlFor="00N1U00000VsCWK" aria-hidden="true" className="hiden-label">Select Language</label>
                              <Controller
                                name={languageSale}
                                control={control}
                                rules={{
                                  required: t["Language is required."],
                                }}
                                render={({ field }) => (
                                  <select
                                    id="00N1U00000VsCWK"
                                    style={{}}
                                    title="Banner"
                                    aria-required="true"
                                    className={css`
                                  border: 1px solid
                                    ${errors[languageSale]
                                        ? "#dc3545!important"
                                        : "#f1f1f1"};
                                `}
                                    {...field}
                                  >
                                    <option value="">Select Language*</option>
                                    <option value="English">English</option>
                                    <option value="French">French</option>
                                  </select>
                                )}
                              />
                              {errors[languageSale] && (
                                <span className="SelectErrorMessage">
                                  {errors[languageSale].message}
                                </span>
                              )}
                            </div>
                          </Col> */}
                          <Col xs={12} sm={6} md={6} lg={6}>
                            <label htmlFor="subject" aria-hidden="true" className="hiden-label">Subject</label>
                            <Controller
                              name="subject"
                              control={control}
                              rules={{
                                required: t["Subject is required."],
                              }}
                              render={({ field }) => (
                                <Input
                                  type="text"
                                  id="subject"
                                  placeholder="Subject*"
                                  className="form-control"
                                  aria-required="true"
                                  onKeyUp={formatInput}
                                  errorMessage={
                                    errors["subject"] && errors["subject"].message
                                  }
                                  {...field}
                                />
                              )}
                            />
                          </Col>
                        </Row>
                        <Row>
                          <Col xs={12}>
                            <label htmlFor="subject" aria-hidden="true" className="hiden-label">Description</label>
                            <Controller
                              name="description"
                              control={control}
                              rules={{
                                required: t["Description is required."],
                              }}
                              render={({ field }) => (
                                <TextArea
                                  minRows={10}
                                  resize="none"
                                  aria-label="Description"
                                  aria-required="true"
                                  className="form-control"
                                  placeholder="Description*"
                                  errorMessage={
                                    errors.description &&
                                    errors.description.message
                                  }
                                  {...field}
                                />
                              )}
                            />
                          </Col>
                        </Row>
                        <div className={`captcha-outer`}>
                          <ReCAPTCHA
                            ref={recaptchaRef}
                            sitekey={`${process.env.NEXT_PUBLIC_GOOGLE_RECAPTCHA_SITEKEY}`}
                            onChange={RecaptchaChange}
                            onExpired={RecaptchaExpired}
                            onErrored={RecaptchaExpired}
                            aria-label="captcha"
                          />
                        </div>
                        <input
                          type="submit"
                          value="Submit"
                          disabled={!recaptchaValid}
                          className="themeBtn"
                          aria-label="Contact Us"
                          id="contact_us"
                          data-gmt="contact_us"
                          tabIndex={0}
                        />
                      </>)}
                      {(secondStep[0] && secondStep[1] && contactText) && (<p className="QueryContact">{pageData?.acf_tru_information_banner?.[0]?.blockdata?.[0]?.description && parse(pageData?.acf_tru_information_banner?.[0]?.blockdata?.[0]?.description)}</p>)}
                    </>
                    <input
                      type="hidden"
                      defaultValue="00D1U0000012jGb"
                      {...register("orgid")}
                    />
                    {/* <input
                      type="hidden"
                      defaultValue="LP"
                      id="00N1U00000UlXji"
                      {...register("00N1U00000UlXji")}
                    /> */}
                    <input
                      type="hidden"
                      defaultValue={`${process.env.NEXT_PUBLIC_CONTACT_REDIRECTURL}`}
                      {...register("retURL")}
                    />
                    <input
                      type="hidden"
                      id="00N1U00000VsCWK"
                      defaultValue={(router?.locale == "en") ? 'English' : 'French'}
                      {...register(languageSale)}
                    />
                    <input
                      type="hidden"
                      id="00N1U00000VsCWK"
                      {...register(subType)}
                    />
                    <input
                      type="hidden"
                      id="00N1U00000UlXji"
                      {...register(issueType)}
                    />
                    <input
                      type="hidden"
                      id="00N1U00000VsApl"
                      {...register(provinceSale)}
                    />
                    <input
                      type="hidden"
                      id="00N1U00000VsCW7"
                      {...register(bannerSale)}
                    />
                    <input
                      type="hidden"
                      defaultValue={0}
                      {...register("debug")}
                    />
                    <input
                      type="hidden"
                      defaultValue={``}
                      {...register("debugEmail")}
                    />
                    <input
                      type="hidden"
                      id="recordType"
                      defaultValue={"0121U000000jvAV"}
                      {...register("recordType")}
                    />
                    <input
                      type="hidden"
                      id="external"
                      defaultValue={"1"}
                      {...register("external")}
                    />
                    <input
                      type="hidden"
                      defaultValue={(recaptchaValue) ? recaptchaValue : `{"keyname":"MapleContactUsForm","fallback":"true","orgId":"00D1U0000012jGb","ts":""}`}
                      {...register("captcha_settings")}
                    />

                  </form>
                  </>
                  )}
                </Col>
                <Col xs={12} md={4}>
                  <div className={styles.sidebar}>
                    {pageData?.acf_tru_content_editor[0] && pageData?.acf_tru_content_editor[0]?.blockdata.map(
                      (data, index) => {
                        return (
                          <div className={styles.SidebarContent} key={`contact_sidebar${index}`}>
                            {data.title && <Text as="h2">{data.title}</Text>}
                            {data.description && (
                              <Text as="div">{parse(data.description)}</Text>
                            )}
                          </div>
                        );
                      }
                    )}
                  </div>
                </Col>
              </Row>
            </div>
          </>

        </Container>
      </div>):(
      <div className={styles.ContactError + " py-18 contact-us"} aria-label="inner-form" role="form">
      <Container size="lg">
        <>
      <p>{pageData?.acf_tru_text?.[0]?.blockdata?.[0]?.ptext && parse(pageData?.acf_tru_text?.[0]?.blockdata?.[0]?.ptext)}</p>
      </>
      </Container>
      </div>
      )}
    
    </>
  );
});
export const StgContact = React.memo(StgForm);