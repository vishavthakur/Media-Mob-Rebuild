import { Text, Container } from "@components";

export const SectionFluid = (props: any) =>{
    const { children, className, id, ...rest } = props;
    return (
        <Text as="section" className={`${className} containerFluid`} id={id} {...rest}> 
            <Container>
                {children}
            </Container>
        </Text>
    )
}