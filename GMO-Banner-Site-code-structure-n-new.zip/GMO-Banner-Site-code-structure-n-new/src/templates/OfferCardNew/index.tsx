import React from "react";
import Image from "@templates/ImageConversion";
import parse from "html-react-parser";
import { Text } from '@components';

interface cardProps {
    tag?: string;
    tagHeadline?: string;
    title?: string;
    mainImage?: string;
    brandImages?: any;
    termsText?: string;
    termsLink?: string;
    termsTarget?: string;
    expireDate?: string;
    offerClick?: any;
    offerClickHide?:any;
    offerActiveClass?: any
}
interface bannerImages {
    bannerInd: string;
    regionalFlag?: string;
}
export const OffersCardNew = React.forwardRef<
HTMLDivElement,
React.PropsWithChildren<cardProps>
    >(({ children, ...props }, ref) => {

        const  getNumberOfDays = (end:string) => {
            const date1 = new Date();
            const date2 = new Date((end).split("/").reverse().join("-"));
            // One day in milliseconds
            const oneDay = 1000 * 60 * 60 * 24;
        
            // Calculating the time difference between two dates
            const diffInTime = date2.getTime() - date1.getTime();
        
            // Calculating the no. of days between two dates
            const diffInDays = Math.round(diffInTime / oneDay);
        
            return diffInDays;
        }

        const [offerClick, setOfferClick] = React.useState(false);
        const offerClickHandler = () =>{
            setOfferClick(true);
        }
        const offerClickHandlerHide = () =>{
            setOfferClick(false);
        }
        /****
         * @function getImageName to get the image from url
         * @param urlImage type string
         */
        const getImageName = (urlImage: string) => {
            if(urlImage.indexOf('amd-cdn.azureedge.net') != -1){
                return urlImage;
            } else if(urlImage.indexOf('mysensepgmo.wpengine.com') != -1){
                return urlImage;
            }
            else
            {
                return `https://getmyoffers.ca/offers/images/${urlImage}`; 
            }
        }
        /***
         * @function GetBannerImage get logo of the banners
         * @param bannerInd type string
         * @param regionalFlag type string
         */
        const GetBannerImage = ({ bannerInd, regionalFlag }:bannerImages) => {
            //    bannerInd="AB";
            //    regionalFlag = "Atlantic";
            let output = "";
            let output1 = "";
            let j=0;
            for (let i = 0; i <= bannerInd.length - 1; i++) {
                let code = bannerInd.substr(i, 1);
                let store_name = "";
                let store_alt = "";
                let store_name1 = "";
        
                switch (code) {
                    case "A":
                        store_name = "sobeys";
                        store_alt = "Sobeys-Logo";
                        break;
                    case "B":
                        if (regionalFlag == "Atlantic"){
                            store_name1 = "foodland_coop";
                            j++;
                        }
                        store_name= "foodland";
                        store_alt = "foodland-Logo";
                        break;
                    case "C":
                        store_name = "safeway";
                        store_alt = "Safeway-Logo";
                        break;
                    case "D":
                        store_name = "iga";
                        store_alt = "iga-Logo";
                        break;
                    case "E":
                        store_name = "thrifty_foods";
                        store_alt = "thriftyfood-Logo";
                        break;
                    case "F":
                        store_name = "sobeys_liquor";
                        store_alt = "sobeysliquor-Logo";
                        break;
                    case "G":
                        store_name = "safeway_liquor";
                        store_alt = "Safewayliquor-Logo";
                        break;
                    case "H":
                        store_name = "freshco";
                        store_alt = "freshco-Logo";
                        break;
                    case "I":
                        store_name = "lawtons";
                        store_alt = "lawtons-Logo";
                        break;
                    default:
                        break;
                }
                
                if (store_name.length > 0) {
                    output += `<span tabindex="0" class='banner_item ${store_name} group_${bannerInd.length}'><img alt='${store_alt}' src='${`https://dev.getmyoffers.ca/wp-content/plugins/sobeys-gmo-integration/assets/images/offer_store_logo/${store_name}_${bannerInd.length}.png`}'></span>`;
                    output1 += `<span tabindex="0" class='banner_item ${store_name} group_${(bannerInd.length+1)}'><img alt='${store_alt}' src='${`https://dev.getmyoffers.ca/wp-content/plugins/sobeys-gmo-integration/assets/images/offer_store_logo/${store_name}_${(bannerInd.length+1)}.png`}'></span>`;
                }
        
                if (store_name1.length > 0) {
                    output += `<span tabindex="0" class='banner_item ${store_name1} group_${bannerInd.length}'><img alt='${store_alt}' src='${`https://dev.getmyoffers.ca/wp-content/plugins/sobeys-gmo-integration/assets/images/offer_store_logo/${store_name1}_${bannerInd.length}.png`}'></span>`;
                    output1 += `<span tabindex="0" class='banner_item ${store_name1} group_${(bannerInd.length+1)}'><img alt='${store_alt}' src='${`https://dev.getmyoffers.ca/wp-content/plugins/sobeys-gmo-integration/assets/images/offer_store_logo/${store_name1}_${(bannerInd.length+1)}.png`}'></span>`;
                }
        
            };
            if(j>0)
                return <>{parse(output1)}</>;
            else
                return <>{parse(output)}</>;
        }
    return(

        <Text as="div" className={`offersCard ${offerClick ? "active" : ""}`}>
            <Text as="header" className="offersCardHeader">
                {props?.tag && <Text as="span" className="tag">{props?.tag}</Text>}
                {props?.tagHeadline && <Text as="p">{parse(props?.tagHeadline)}</Text>}
            </Text>
            <Text as="div" className="offersCardThumb">
                <Text as="p" colorScheme="accent">{(props?.expireDate && getNumberOfDays(props?.expireDate) > 0 ? (parse(`Expires in <span>${getNumberOfDays(props?.expireDate)} day${(getNumberOfDays(props?.expireDate) > 1)?`s`:``}</span>`)): ``)}</Text>
                <Text as="div" className="offersCardThumbImg">
                    <Image src={getImageName(props?.mainImage)} alt="" layout="fill" objectFit="contain" />
                </Text>
            </Text>
            <Text as="div" className="offersCardContent">
                <Text as="h3" colorScheme="accent">{parse(props?.title)}</Text>
            </Text>
            <Text as="div" className="offersCardBrand">
                <Text as="div" className="offersCardBrandInner">
                   {props?.brandImages && <GetBannerImage bannerInd={props?.brandImages} />}
                </Text>
                <button className="linkText" onFocus={offerClickHandler}>{parse(props?.termsText)}</button>
            </Text>
            <Text as="div" className={`offersCardHover ${offerClick ? 'active' : ''}`}>
                <div className="offersCardHoverHeader">
                    <button onFocus={offerClickHandlerHide}><Image alt="arrow up" src="/fill-arrow-up.svg" height={11} width={18} /></button>
                    <h4>Terms & Conditions</h4>
                </div>
                <div className="offersCardHoverContent">
                    <p>Valid at participating Sobeys, Foodland & participating Co-Ops locations in Atlantic Canada. Offer must be loaded before time of purchase to the AIR MILES Card swiped in the transaction. Minimum purchase requirements must be met in a single transaction. Offer expires after a single use unless otherwise stated. Product availability may vary by store. We reserve the right to limit quantities to reasonable family requirements.®™ Trademarks of AM Royalties Limited Partnership used under license by LoyaltyOne, Co. and Sobeys Capital Incorporated.</p>
                </div>
                <div className="offersCardHoverFooter">
                    <p>Starts: <strong>01/26/22</strong></p>
                    <p>Expires: <strong>02/02/22</strong></p>
                </div>
            </Text>
        </Text>
    )
})