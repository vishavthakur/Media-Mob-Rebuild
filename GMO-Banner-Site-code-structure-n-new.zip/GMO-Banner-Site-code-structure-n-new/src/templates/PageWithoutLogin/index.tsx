import React from "react";
import {
  Header,
  Footer,
  SeoMeta,
  Loader,
  Banner,
  DownloadYourGroceryApps,
  GrocerySavings,
  SignInGroceryAccount,
  SkipTarget,
} from "@templates";
import { GigyaObject,gigyaLoggedIn } from "@services/Gigya";
import { useSelector, RootStateOrAny } from "react-redux";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

interface Props {
  headerData: Record<any, any>;
  pageData: Record<any, any>;
  newPageData: Record<any, any>;
  offerPageData: Record<any, any>;
  host?:Record<any, any>;
}
const HomeWithoutLogin: React.FC<Props> = (props: Props) => {
  const [intializeUser, setIntializeUser] = React.useState(false);
  const Auth = useSelector((state: RootStateOrAny) => state.auth);
  const AllBanners = useSelector((state: RootStateOrAny) => state.banner);
  const headerData = props?.headerData;
  const homeData = props?.pageData;
  const NewhomeData = props?.newPageData;
  const truSliderList = props.newPageData?.acf_tru_slider?.[0]?.blockdata;
  const truSignInList = props.newPageData?.acf_tru_cards?.[0]?.blockdata[0];
  const truSignInLoggedIn = props.newPageData?.acf_tru_cards?.[0]?.blockdata[1];
  const truInformationBannerOne =
    props.newPageData?.acf_tru_information_banner?.[0]?.blockdata;
  const truInformationBannertwo =
    props.newPageData?.acf_tru_information_banner?.[1]?.blockdata;
    const [locationLogo, setLocationLogo] = React.useState(null);

  const [userLogin, setuserLogin] = React.useState(null);

  React.useEffect(() => {
    const getAccountInfoResponse = (response) => {
      if (response != undefined && response !="") {
        setuserLogin("loggedin");
        setIntializeUser(true);
      } else {
        setIntializeUser(true);
      }
    };
    //@ts-ignore

    if (GigyaObject != undefined) {
      getAccountInfoResponse(gigyaLoggedIn());
       }
       return () => {
       
    };
  }, []);
/**
 * To change the logo according to location
 */
React.useEffect(()=>{
 if(AllBanners?.value){
  let locationlogo =
  props?.headerData?.acf_tru_taxonomy[0]?.blockdata?.filter(
    (data) => (data?.slug).replaceAll("-", "") === AllBanners?.value
  );
setLocationLogo(locationlogo); }
},[AllBanners?.value]);
  return (
    <>
      {intializeUser ? (
        <>
          <Header headerData={headerData} offerData={props?.offerPageData} host={props?.host}/>
          {/*[ Header end here ]*/}
          <SeoMeta 
      title={props?.newPageData?.acf_tru_seometa?.[0]?.blockdata?.[0]?.browserList?.[process?.env?.NEXT_PUBLIC_GIGYA_BRAND]?.title}
      description={props?.newPageData?.acf_tru_seometa?.[0]?.blockdata?.[0]?.browserList?.[process?.env?.NEXT_PUBLIC_GIGYA_BRAND]?.browserMetaDescription}
      keywords={props?.newPageData?.acf_tru_seometa?.[0]?.blockdata?.[0]?.browserList?.[process?.env?.NEXT_PUBLIC_GIGYA_BRAND]?.browserMetaKeywords}
      />
          {/*[ Seo Meta end here ]*/}
          <Banner truSliderList={truSliderList} />
          <SkipTarget />
          {/*[ Banner end here ]*/}
          {!Auth?.value?.guid ?(truSignInList && <SignInGroceryAccount
            truSignInList={truSignInList} logos={locationLogo} loginIn={true}
          />) : (truSignInLoggedIn && <SignInGroceryAccount
            truSignInList={truSignInLoggedIn}
            loginIn={false}
          />)
          
        }
          
          {/*[ Sign In And Register End ]*/}
          {truInformationBannerOne &&  <GrocerySavings truInformationBannerOne={truInformationBannerOne} />}
         
          {/* [ grocery Savings Just for you End] */}
          {truInformationBannertwo &&  <DownloadYourGroceryApps
            truInformationBannertwo={truInformationBannertwo}
          />}
         
          {/* [Download your grocery apps] */}
          <Footer footerData={headerData} />
        </>
      ) : (
        <div className="">
          {" "}
          <Loader></Loader>{" "}
        </div>
      )}
      {/* Footer end here */}
    </>
  );
};
export default HomeWithoutLogin;
