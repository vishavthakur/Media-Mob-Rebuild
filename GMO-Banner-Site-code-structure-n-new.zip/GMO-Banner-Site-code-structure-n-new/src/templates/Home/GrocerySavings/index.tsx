import Link from "next/link";
import Image from "@templates/ImageConversion";
import { Row, Col, Text, Flex, Card, FlexItem } from "@components";
import { SectionBoxed, SectionTitle } from "@templates";
import styles from "./GrocerySavings.module.scss";
import parse from "html-react-parser";

export const GrocerySavings = (props) => {
  const { truInformationBannerOne } = props;

  return (
    <>
      <SectionBoxed id="grocerysavings" className={styles.GrocerySavings + " fluid"}>
        <Row className={styles.cardRow}>
          <Col lg={6} md={5} sm={6}>
            <Text as="div" className={styles.GrocerySavingsContent}>
              {truInformationBannerOne[0]?.title && (
                <Text as="h2" colorScheme="primary">
                  {parse(truInformationBannerOne[0]?.title)}
                </Text>
              )}
              {truInformationBannerOne[0]?.description && (
                <Text as="p">
                  {" "}
                  {parse(truInformationBannerOne[0]?.description)}
                </Text>
              )}
            </Text>
          </Col>
          <Col lg={6} md={7} sm={6}>
            <Text as="div" textAlign="right" className={styles.Image} id="groceryimageright">
              <Image
                src={truInformationBannerOne[0]?.image_content[0]?.image?.src}
                alt={truInformationBannerOne[0]?.image_content[0]?.image?.alt}
                layout="fill"
                objectFit="contain"
              />
            </Text>
          </Col>
        </Row>
        <Text as="div" className={styles.SceneIconOne}>
          <Image
            src="/scene-icon.svg"
            alt="/Doted Element"
           layout="fill"
          />
        </Text>
        <Text as="div" className={styles.SceneIconTwo}>
          <Image
            src="/scene-icon.svg"
            alt="/Doted Element"
            layout="fill"
          />
        </Text>
        <Text as="div" className={styles.SceneIconThree}>
          <Image
            src="/scene-icon.svg"
            alt="/Doted Element"
           layout="fill"
          />
        </Text>
      </SectionBoxed>
    </>
  );
};
