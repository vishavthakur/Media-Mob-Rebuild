import Link from "next/link";
import Image from "@templates/ImageConversion";
import { Row, Col, Text, Flex, Card, FlexItem } from "@components";
import { SectionBoxed, SectionTitle } from "@templates";
import styles from "./DownloadYourGroceryApps.module.scss";
import parse from "html-react-parser";

export const DownloadYourGroceryApps = (props) => {
  const { truInformationBannertwo } = props;
  return (
    <>
      <SectionBoxed>
        <Text as="div" className={styles.DownloadYourGroceryApps}>
          <Row className={styles.DownloadYourGroceryAppsInner}>
            <Col lg={6} md={6} sm={6}>
              <Text
                as="div"
                className={styles.DownloadYourGroceryAppsInnerLeft}
              >
                {truInformationBannertwo[0]?.title && (
                  <Text as="h2" colorScheme="primary">
                    {parse(truInformationBannertwo[0]?.title)}
                  </Text>
                )}
                {truInformationBannertwo[0]?.description && (
                  <Text as="p" colorScheme="primary">
                    {truInformationBannertwo[0]?.description}
                  </Text>
                )}
                <Flex justifyContent="flex-start" className={styles.appsIcons}>
                  {truInformationBannertwo[0]?.action_properties &&
                    truInformationBannertwo[0]?.action_properties.map(
                      (items, index) => (
                        <Text
                          as="div"
                          className={styles.playStoreButton}
                          key={`aap_buttons${index}`}
                        >
                          <Link href={items?.url?.url ? items?.url?.url : "#!"}>
                            <a
                              className="appicon"
                              aria-label={items?.arialabel}
                              id={items?.buttonId}
                              data-gtm={items?.datagmt}
                              target={items?.url?.target}
                            >
                              {items?.buttonImage && (
                                <Image
                                  src={items?.buttonImage?.src}
                                  alt={items?.buttonImage?.alt}
                                  layout="fill"
                                  objectFit="contain"
                                />
                              )}
                            </a>
                          </Link>
                        </Text>
                      )
                    )}
                </Flex>
              </Text>
            </Col>
            <Col lg={6} md={6} sm={6}>
              <Text className={styles.bgWrap}>
                {truInformationBannertwo[0]?.image_content[2]?.image &&  <Image
                  src={truInformationBannertwo[0]?.image_content[2]?.image?.src}
                  alt={truInformationBannertwo[0]?.image_content[2]?.image?.alt}
                  layout="fill"
                />}
              </Text>
            </Col>
          </Row>
        </Text>
      </SectionBoxed>
    </>
  );
};
