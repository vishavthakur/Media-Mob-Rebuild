import React from "react";
import Link from "next/link";
import { useRouter } from "next/router";
import { useSelector, RootStateOrAny } from "react-redux";
import Image from "@templates/ImageConversion";
import { Text, Flex } from "@components";
import { SectionBoxed } from "@templates";
import parse from "html-react-parser";
import {
  GigyaLogin,
  GigyaRegister,
} from "@services/Gigya";
import styles from "./SignInGroceryAccount.module.scss";

export const SignInGroceryAccount = (props) => {
  const bannerSelected = useSelector((state: RootStateOrAny) => state.banner);
  const [op, setOp] = React.useState("");
  const { truSignInList } = props;
  const router = useRouter();
  const { locale } = router;
  React.useEffect(() => {
    if (bannerSelected?.value) {
      setOp(bannerSelected?.value);
    }
  }, [bannerSelected])
  let logoCount = 0;
  if (props?.logos) {
    let dataCount = props?.logos[0]?.header_image?.filter(
      (dataFilter) => dataFilter.logo_label
    );
    logoCount = dataCount?.length;
  }
  /***
 * @function handleLogin
 * @param region
 * TO handle the login if hash exists in the url
 */

  const handleLogin = async (e) => {
    e.preventDefault();
    const queryParams = new URLSearchParams(location.search);
    let gl = '';
    if (e?.target?.href.indexOf('_gl=') !== -1) {
      const glLink = e?.target?.href?.substring(e?.target?.href?.indexOf('_gl=') + 1);
      if (glLink) {
        gl = glLink.replace("gl=", "");
      }
    }
    if (queryParams.has("hash")) {
      queryParams.delete("hash");
      await router.replace(router.pathname);
      GigyaLogin({ value: op, langauge: locale, gl: gl });
    } else {
      GigyaLogin({ value: op, langauge: locale, gl: gl });
    }
    // return false;
  };

  /***
   * @function handleRegister
   * @param region
   * TO handle the login if hash exists in the url
   */

  const handleRegister = async (e) => {
    e.preventDefault();
    const queryParams = new URLSearchParams(location.search);
    let gl = '';
    if (e?.target?.href.indexOf('_gl=') !== -1) {
      const glLink = e?.target?.href?.substring(e?.target?.href?.indexOf('_gl=') + 1);
      if (glLink) {
        gl = glLink.replace("gl=", "");
      }
    }
    if (queryParams.has("hash")) {
      queryParams.delete("hash");
      await router.replace(router.pathname);
      GigyaRegister({ value: op, langauge: locale, gl: gl });
    } else {
      GigyaRegister({ value: op, langauge: locale, gl: gl });
    }
  };
  //console.log("here"+props);
  return (
    <>
      <SectionBoxed className={styles.rewardsSection}>
        <div className={styles.rewardsCard}>
          <div className={styles.rewardsCardLeft}>
            {truSignInList?.cardimages && (
              <Image
                src={truSignInList?.cardimages[0]?.desktopimage.src}
                alt={truSignInList?.cardimages[0]?.desktopimage.alt}
                layout="fill"
                objectFit="cover"
              />
            )}
          </div>
          <div className={styles.rewardsCardRight}>
            {truSignInList?.cardtitle && (
              <Text as="h1">{parse(truSignInList?.cardtitle)}</Text>
            )}
            {truSignInList?.cardsubtitle && (
              <Text as="p" className={styles.SignInText} aria-label={truSignInList?.cardsubtitle_aria_label ? truSignInList?.cardsubtitle_aria_label : ''}>
                {parse(truSignInList?.cardsubtitle)}
              </Text>
            )}
            <Flex
              justifyContent="flex-start"
              className={styles.rewardsCardRightSection}
            >
              {truSignInList?.card_actionproperty[0]?.label && (
                <Text
                  as="div"
                  className={`${styles.rewardsCardRightSectionButton} btn-accessibility`}
                >
                  <Link
                    href={
                      truSignInList?.card_actionproperty[0]?.link?.url
                        ? truSignInList?.card_actionproperty[0]?.link?.url
                        : "#"
                    }
                  >
                    {truSignInList?.card_actionproperty[0]?.label && (
                      <a
                        aria-label={
                          truSignInList?.card_actionproperty[0]?.arialabel
                        }
                        id={truSignInList?.card_actionproperty[0]?.buttonId}
                        data-gtm={
                          truSignInList?.card_actionproperty[0]?.datagmt
                        }
                        onClick={(e) => (props?.loginIn) ? handleLogin(e) : (``)}
                        className="themeBtn"
                      >
                        {parse(truSignInList?.card_actionproperty[0]?.label)}
                      </a>
                    )}
                  </Link>
                </Text>
              )}
              {truSignInList?.card_actionproperty[1]?.label && (
                <Text as="div" className={styles.rewardsCardRightSectionButton}>
                  <Link
                    href={
                      truSignInList?.card_actionproperty[1]?.link?.url
                        ? truSignInList?.card_actionproperty[1]?.link?.url
                        : "#"
                    }
                  >
                    {truSignInList?.card_actionproperty[1]?.label && (
                      <a
                        aria-label={
                          truSignInList?.card_actionproperty[1]?.arialabel
                        }
                        id={truSignInList?.card_actionproperty[1]?.buttonId}
                        data-gtm={
                          truSignInList?.card_actionproperty[1]?.datagmt
                        }
                        onClick={(e) => (props?.loginIn) ? handleRegister(e) : (``)}
                        className="themeBtn outline"
                      >
                        {parse(truSignInList?.card_actionproperty[1]?.label)}
                      </a>
                    )}
                  </Link>
                </Text>
              )}
            </Flex>
            {props?.logos && props?.logos?.length > 0 && (
              <div className={styles.AfterLoginText + " regionlogohome"}>
                {/* {props?.logos[0]?.header_image?.length > 0 ?( <span></span>):(``)} */}
                {props?.logos[0]?.header_image?.map((data, index) => {
                 
                  return (
                    <React.Fragment key={`after_login_${index}`}>
                      {data?.logo_label ? (
                        <>
                        <Link href={data?.logo_url}>
                          <a
                            target={data?.logo_link_target}
                            aria-label={data?.logo_aria_label}
                          >
                            {data?.logo_label}
                           
                          </a>
                        
                        </Link>
                          {index != logoCount - 1 ? "," : ""}{" "}
                          </>
                          
                      ) : (
                        ``
                      )}
                    </React.Fragment>
                  );
                })}
              </div>
            )}
            {!props?.logos && truSignInList?.card_discription && (
              <Text as="p" className={styles.storesText}>
                {parse(truSignInList?.card_discription)}
              </Text>
            )}
          </div>
        </div>
      </SectionBoxed>
    </>
  );
};
