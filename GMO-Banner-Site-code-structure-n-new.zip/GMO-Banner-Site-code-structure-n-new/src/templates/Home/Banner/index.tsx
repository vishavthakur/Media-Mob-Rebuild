import React from 'react';
import { SectionFluid, HeroBannerRow, HeroNextArrow, HeroPrevArrow } from "@templates";

import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

export const Banner = (props) =>{
    const { truSliderList } = props;

    // Banner Slider play pause function
    const heroSliderRef = React.createRef();
    const [playSlider, setPlaySlider] = React.useState(true);
    const [activeSlide, setActiveSlide] = React.useState(0)

    const heroPlay = () => {
      setPlaySlider(!playSlider);
      console.log(playSlider);
    };

    React.useEffect(() => {
      const timer = setTimeout(() => {
      //@ts-ignore
        playSlider ? (heroSliderRef.current?.slickPlay()) : heroSliderRef.current?.slickPause();
        // document.querySelectorAll('.slick-slide').forEach(b=>b.removeAttribute('aria-hidden'))
        document.querySelectorAll('.slick-slide.slick-cloned .themeBtn').forEach(b => b.setAttribute('tabindex', '-1'));
        document.querySelectorAll('.slick-slide.slick-cloned h1').forEach(b => b.setAttribute('tabindex', '-1'));
        document.querySelectorAll('.slick-slide.slick-cloned p').forEach(b => b.setAttribute('tabindex', '-1'));

      }, 500);
      return () => clearTimeout(timer);
    }, [playSlider, activeSlide]);

    // Banner Slider configuration
    let heroSlider = {
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplaySpeed: 6000,
        autoplay: true,
        useTransform: false,
        nextArrow: <HeroNextArrow />,
        prevArrow: <HeroPrevArrow />,
        pauseOnFocus: true,
        pauseOnHover: true,
        beforeChange: (current, next) => setActiveSlide(next),
        appendDots: dots => (
        <div className="heroDots">
            <ul style={{ margin: "0px" }}> <li className="sliderPlayButtons"><button className={playSlider ? 'pauseBtn' : 'playBtn'} onClick={() => heroPlay()}>Play / Pause Btn</button></li>{dots} </ul>
        </div>
        ),
         
    };
    return(
        <SectionFluid className="HeroBanner" id="hero-slider">
          <Slider pause-on-focus="true" ref={heroSliderRef} {...heroSlider}>
            {truSliderList.length > 0 && truSliderList.map((sliderItems, index: React.Key) => {
              return (<div key={index}> <HeroBannerRow tabindex={activeSlide !== index ? -1: 0} title={sliderItems?.title} titlearialabel={sliderItems?.titlearialabel} subTitle={sliderItems?.subtitle} subtitlearialabel={sliderItems?.subtitlearialabel} contentarialabel= {sliderItems?.content_aria_label}content={sliderItems?.content} image={sliderItems?.desktopimage} 
                mobileImage={sliderItems?.mobileimage} buttonText={sliderItems?.label} buttonLink={sliderItems?.link?.url} buttonTarget={sliderItems?.link?.target} buttonId={sliderItems?.buttonId} buttonIndex={(Math.random())} buttonAriaLabel={sliderItems?.arialabel} buttonDataGtm={sliderItems?.datagmt}/> </div>);
            })}
          </Slider>
        </SectionFluid>

    )
}