import React from "react";
import {
    Global,
    css,
    ThemeProvider as EmotionThemeProver,
    Theme as EmotionThemeType,
} from "@emotion/react";
import { useLocalStorage } from "@util/hooks/useLocalStorage";
export interface Theme extends EmotionThemeType {
    [key: string]: any;
}
import createCache from "@emotion/cache";
import { spacing, fontSizes } from "@util/units";
import { CacheProvider } from "@emotion/react";
const cache = createCache({
    key: "css",
    prepend: true,
});

const transparent = "transparent";
const white = "#fff";
const black = "#111";
const test = "#202124";
const error = "#dc3545";

/** Default Theme **/
export const defaultTheme: Theme = {
    mode: "light",
    palette: {
        common: {
            black,
            white,
            transparent,
            test,
            error,
        },

        mode: {
            light: {
                buttonGlobalTheme: {
                    padding: "10px",
                    backgroundImage:
                        "linear-gradient(120deg, #006241 50%, white 50%)",
                    color: white,
                    backgroundSize: "500px",
                    backgroundRepeat: "no-repeat",
                    backgroundPosition: "0%",
                    WebkitTransition: "background 400ms ease-in-out",
                    transition: "background 400ms ease-in-out",
                    "&:hover": { backgroundPosition: "100%", color: "#006241" },
                },
                // buttonGlobalTheme:{
                //     gradient {
                //         position: relative,
                //         backgroundImage: "linear-gradient(to right, hsl(211, 100%, 50%), hsl(179, 100%, 30%))",
                //         zIndex: 1,
                //       }

                //       gradient::before {
                //         position: absolute;
                //         content: "";
                //         top: 0;
                //         right: 0;
                //         bottom: 0;
                //         left: 0;
                //         backgroundImage: "linear-gradient(
                //           to bottom,
                //           hsl(344, 100%, 50%),
                //           hsl(31, 100%, 40%)
                //         ),
                //         zIndex: -1,
                //         transition: "opacity 0.5s linear",
                //         opacity: 0,
                //       }

                //       gradient:hover::before {
                //         opacity: 1;
                //       }
                // }
                primary: {
                    main: "#5599dd",
                    light: "#a8c8ec67",
                    dark: "#1565c0",
                    contrastText: white,
                    hover: "#d3d0d0",
                },

                secondary: {
                    main: "#28a745",
                    light: "#28a74533",
                    contrastText: white,
                    border: "#ccc",
                    bgColor: "#ddd",
                },
                accent: {
                    main: "#800080",
                    light: "#80008033",
                    contrastText: white,
                    border: "#10dddd",
                    bgColor: "#10dddd",
                },
                default: {
                    main: "#fff",
                },
                error: {
                    main: "#dc3545",
                    dark: "#690711c8",
                    light: "#dc354533",
                    contrastText: white,
                },
                grey: {
                    100: "#EAEAEA",
                    200: "#C9C5C5",
                    300: "#888",
                    400: "#666",
                },
                paper: {
                    background: "#f1f1f1",
                    border: "1px solid #f1f1f1;",
                    shadow: "box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px",
                    hoverColor: "rgba(0, 0, 0, 0.04)",
                    textColor: "#222",
                },

                textColor: {
                    main: black,
                },
                divider: "rgba(0, 0, 0, 0.12)",
                shadows: "rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px",
                background: {
                    card: "#A51C30",
                    cardLight: white,
                    cardDark: black,
                },
                // The colors used to style the text.
                text: {
                    // The most important text.
                    primary: "rgba(0, 0, 0, 0.87)",
                    // Secondary text.
                    secondary: "rgba(0, 0, 0, 0.6)",
                    accent: "rgba(128, 0, 128, 1)",
                    // Disabled text have even lower visual prominence.
                    disabled: "rgba(0, 0, 0, 0.38)",
                },
                action: {
                    active: " rgba(0, 0, 0, 0.54)",
                    activatedOpacity: 0.12,
                    hover: " rgba(0, 0, 0, 0.08)",
                    hoverOpacity: 0.2,

                    inActive: "#5e5c5c",
                    selected: "#c4adad",
                    selectedOpacity: 0.08,
                    disabled: "rgba(0, 0, 0, 0.26)",
                    disabledBackground: "rgba(0, 0, 0, 0.12)",
                    disabledOpacity: 0.38,
                    focus: "rgba(0, 0, 0, 0.12)",
                    focusOpacity: 0.12,
                    stripedColor: "#ddd",
                },
            },
            dark: {
                primary: {
                    main: "#5599dd",
                    light: "#a8c8ec67",
                    dark: "#1565c0",
                    contrastText: "#ccc",
                    hover: "#2a2929",
                },
                // primary: {
                //     main: "#F4B233",
                //     light: "#f4b033b3",
                //     contrastText: white,
                //     border: "#F4B233",
                //     bgColor: "#F4B233",
                // },

                secondary: {
                    main: "#28a745",
                    light: "#28a74533",
                    contrastText: white,
                    border: "#000",
                    bgColor: "#282828",
                },
                accent: {
                    main: "#800080",
                    light: "#80008033",
                    contrastText: white,
                    border: "#800080",
                    bgColor: "#10dddd",
                },
                paper: {
                    background: "#121212",
                    border: "1px solid #121212;",
                    shadow: "box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px",
                    hoverColor: "rgba(0, 0, 0, 0.04)",
                    textColor: "#fff",
                },

                default: {
                    main: "#141414",
                },
                error: {
                    main: "#dc3545",
                    dark: "#690711c8",
                    light: "#dc354533",
                    contrastText: white,
                },
                grey: {
                    100: "#EAEAEA",
                    200: "#C9C5C5",
                    300: "#888",
                    400: "#666",
                    500: "#555",
                },
                divider: "rgba(0, 0, 0, 0.12)",
                shadows: "rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px",
                textColor: {
                    main: "#ffffffb3",
                },
                text: {
                    // The most important text.
                    primary: "rgba(255, 255, 255, 0.87)",
                    // Secondary text.
                    secondary: "rgba(255, 255, 255, 0.7)",
                    accent: "#ae52ae",
                    // Disabled text have even lower visual prominence.
                    disabled: "rgba(255, 255, 255, 0.5)",
                },
                action: {
                    active: " rgba(0, 0, 0, 0.54)",
                    hoverTest: "#A51C30",
                    hoverOpacity: 0.2,
                    hover: "rgba(88, 86, 86, 0.5)",
                    selected: "rgba(88, 86, 86, 1)",
                    selectedOpacity: 0.08,
                    disabled: "rgba(0, 0, 0, 0.26)",
                    disabledBackground: "rgba(0, 0, 0, 0.12)",
                    disabledOpacity: 0.38,
                    focus: "rgba(0, 0, 0, 0.12)",
                    focusOpacity: 0.12,
                    activatedOpacity: 0.12,
                    cursor: "not-allowed",
                    stripedColor: "#ddd",
                },
            },
        },
    },

    shadows: {
        0: "none",
        1: "0px 5px 10px rgba(0, 0, 0, 0.12)",
        2: "0px 8px 30px rgba(0, 0, 0, 0.24)",
        3: "rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px",
    },

    typography: {
        fontFamily:
            "Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Ubuntu, 'Helvetica Neue', sans-serif",
    },

    shape: {
        borderRadius: spacing["xxsmall"],
    },
};

/** Sobeys Theme **/
export const sobeysTheme: Theme = {
    mode: "light",
    palette: {
        common: {
            black,
            white,
            transparent,
            test,
            error,
        },

        mode: {
            light: {
                primary: {
                    main: "#006241",
                    light: "#00624166",
                    dark: "#06432f",
                    contrastText: "white",
                    hover: "#d5d5d5",
                },

                secondary: {
                    main: "#48a648",
                    light: "#48a64833",
                    contrastText: white,
                    border: "#48a648",
                    bgColor: "#ddd",
                },
                accent: {
                    main: "#800080",
                    light: "#80008033",
                    contrastText: white,
                    border: "#800080",
                    bgColor: "#10dddd",
                },
                default: {
                    main: "#fff",
                },
                error: {
                    main: "#dc3545",
                    dark: "#690711c8",
                    light: "#dc354533",
                    contrastText: white,
                },
                grey: {
                    100: "#EAEAEA",
                    200: "#C9C5C5",
                    300: "#888",
                    400: "#666",
                },
                // paper: {
                //     background: "#f1f1f1",

                //     border: "1px solid #f1f1f1;",

                //     shadow: "box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px",

                //     hoverColor: "rgba(0, 0, 0, 0.04)",

                //     textColor: "#222",
                // },
                paper: {
                    background: "#f1f1f1",
                    border: "1px solid #f1f1f1;",
                    shadow: "box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px",
                    hoverColor: "rgba(0, 0, 0, 0.04)",
                    textColor: "#222",
                },

                textColor: {
                    main: "#404040",
                },
                divider: "rgba(0, 0, 0, 0.12)",
                shadows: "rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px",
                background: {
                    card: "#A51C30",
                    cardLight: white,
                    cardDark: black,
                },
                // The colors used to style the text.
                text: {
                    // The most important text.
                    primary: "#404040",
                    // Secondary text.
                    secondary: "rgba(0, 0, 0, 0.6)",
                    accent: "rgba(128, 0, 128, 1)",
                    // Disabled text have even lower visual prominence.
                    disabled: "rgba(0, 0, 0, 0.38)",
                },
                action: {
                    active: " rgba(0, 0, 0, 0.54)",
                    activatedOpacity: 0.12,
                    hover: " rgba(0, 0, 0, 0.08)",
                    hoverOpacity: 0.2,
                    inActive: "#5e5c5c",
                    selected: "#c4adad",
                    selectedOpacity: 0.08,
                    disabled: "rgba(0, 0, 0, 0.26)",
                    disabledBackground: "rgba(0, 0, 0, 0.12)",
                    disabledOpacity: 0.38,
                    focus: "rgba(0, 0, 0, 0.12)",
                    focusOpacity: 0.12,
                    stripedColor: "#ddd",
                },
            },
            dark: {
                primary: {
                    main: "#006241",
                    light: "#00624166",
                    dark: "#06432f",
                    contrastText: "white",
                    hover: "#393737",
                },
                // primary: {
                //     main: "#F4B233",
                //     light: "#f4b033b3",
                //     contrastText: white,
                //     border: "#F4B233",
                //     bgColor: "#F4B233",
                // },

                secondary: {
                    main: "#48a648",
                    light: "#48a64833",
                    contrastText: white,
                    border: "#48a648",
                    bgColor: "#ddd",
                },
                accent: {
                    main: "#800080",
                    light: "#80008033",
                    contrastText: white,
                    border: "#800080",
                    bgColor: "#10dddd",
                },

                // paper: {
                //     background: "#121212",

                //     border: "1px solid #121212;",

                //     shadow: "box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px",

                //     hoverColor: "rgba(0, 0, 0, 0.04)",

                //     textColor: "#fff",
                // },
                paper: {
                    background: "#121212",
                    border: "1px solid #121212;",
                    shadow: "box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px",
                    hoverColor: "rgba(0, 0, 0, 0.04)",
                    textColor: "#fff",
                },

                default: {
                    main: "#141414",
                },
                error: {
                    main: "#dc3545",
                    dark: "#690711c8",
                    light: "#dc354533",
                    contrastText: white,
                },
                grey: {
                    100: "#EAEAEA",
                    200: "#C9C5C5",
                    300: "#888",
                    400: "#666",
                    500: "#555",
                },
                divider: "rgba(0, 0, 0, 0.12)",
                shadows: "rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px",
                textColor: {
                    main: "#ffffffb3",
                },
                text: {
                    // The most important text.
                    primary: "rgba(255, 255, 255, 0.87)",
                    // Secondary text.
                    secondary: "rgba(255, 255, 255, 0.7)",
                    accent: "#ae52ae",
                    // Disabled text have even lower visual prominence.
                    disabled: "rgba(255, 255, 255, 0.5)",
                },
                action: {
                    active: " rgba(0, 0, 0, 0.54)",
                    hoverTest: "#A51C30",
                    hoverOpacity: 0.2,
                    inActive: "#7e7e7e",
                    hover: "rgba(88, 86, 86, 0.5)",
                    selected: "rgba(88, 86, 86, 1)",
                    selectedOpacity: 0.08,
                    disabled: "rgba(0, 0, 0, 0.26)",
                    disabledBackground: "rgba(0, 0, 0, 0.12)",
                    disabledOpacity: 0.38,
                    focus: "rgba(0, 0, 0, 0.12)",
                    focusOpacity: 0.12,
                    activatedOpacity: 0.12,
                    cursor: "not-allowed",
                    stripedColor: "#ddd",
                },
            },
        },
    },

    shadows: {
        0: "none",
        1: "0px 5px 10px rgba(0, 0, 0, 0.12)",
        2: "0px 8px 30px rgba(0, 0, 0, 0.24)",
        3: "rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px",
    },

    typography: {
        fontFamily:
            "Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Ubuntu, 'Helvetica Neue', sans-serif",
    },

    shape: {
        borderRadius: spacing["xxsmall"],
    },
};

/** Thebeerstore Theme **/
export const thebeestoreTheme: Theme = {
    mode: "light",
    palette: {
        common: {
            black,
            white,
            transparent,
            test,
            error,
        },

        mode: {
            light: {
                primary: {
                    main: "#f4b233",
                    light: "#f4b23366",
                    dark: "#e89800",
                    contrastText: "black",
                    hover: "#f6f6f6",
                },

                secondary: {
                    main: "#28a745",
                    light: "#28a74533",
                    contrastText: white,
                    border: "#ccc",
                    bgColor: "#ddd",
                },
                accent: {
                    main: "#800080",
                    light: "#80008033",
                    contrastText: white,
                    border: "#10dddd",
                    bgColor: "#10dddd",
                },
                default: {
                    main: "#fff",
                },
                error: {
                    main: "#dc3545",
                    dark: "#690711c8",
                    light: "#dc354533",
                    contrastText: white,
                },
                grey: {
                    100: "#EAEAEA",
                    200: "#C9C5C5",
                    300: "#888",
                    400: "#666",
                },
                paper: {
                    background: "#f1f1f1",
                    border: "1px solid #f1f1f1;",
                    shadow: "box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px",
                    hoverColor: "rgba(0, 0, 0, 0.04)",
                    textColor: "#222",
                },

                textColor: {
                    main: black,
                },
                divider: "rgba(0, 0, 0, 0.12)",
                shadows: "rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px",
                background: {
                    card: "#A51C30",
                    cardLight: white,
                    cardDark: black,
                },
                // The colors used to style the text.
                text: {
                    // The most important text.
                    primary: "rgba(0, 0, 0, 0.87)",
                    // Secondary text.
                    secondary: "rgba(0, 0, 0, 0.6)",
                    accent: "rgba(128, 0, 128, 1)",
                    // Disabled text have even lower visual prominence.
                    disabled: "rgba(0, 0, 0, 0.38)",
                },
                action: {
                    active: " rgba(0, 0, 0, 0.54)",
                    activatedOpacity: 0.12,
                    hover: " rgba(0, 0, 0, 0.08)",
                    hoverOpacity: 0.2,
                    selected: "#c4adad",
                    selectedOpacity: 0.08,
                    disabled: "rgba(0, 0, 0, 0.26)",
                    disabledBackground: "rgba(0, 0, 0, 0.12)",
                    disabledOpacity: 0.38,
                    focus: "rgba(0, 0, 0, 0.12)",
                    focusOpacity: 0.12,
                    stripedColor: "#ddd",
                },
            },
            dark: {
                primary: {
                    main: "#f4b233",
                    light: "#f4b23366",
                    dark: "#e89800",
                    contrastText: "black",
                    hover: "#444444",
                },
                // primary: {
                //     main: "#F4B233",
                //     light: "#f4b033b3",
                //     contrastText: white,
                //     border: "#F4B233",
                //     bgColor: "#F4B233",
                // },

                secondary: {
                    main: "#28a745",
                    light: "#28a74533",
                    contrastText: white,
                    border: "#ccc",
                    bgColor: "#ddd",
                },
                accent: {
                    main: "#800080",
                    light: "#80008033",
                    contrastText: white,
                    border: "#800080",
                    bgColor: "#10dddd",
                },
                paper: {
                    background: "#121212",
                    border: "1px solid #121212;",
                    shadow: "box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px",
                    hoverColor: "rgba(0, 0, 0, 0.04)",
                    textColor: "#fff",
                },

                default: {
                    main: "#141414",
                },
                error: {
                    main: "#dc3545",
                    light: "#dc354533",
                    contrastText: white,
                },
                grey: {
                    100: "#EAEAEA",
                    200: "#C9C5C5",
                    300: "#888",
                    400: "#666",
                    500: "#555",
                },
                divider: "rgba(0, 0, 0, 0.12)",
                shadows: "rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px",
                textColor: {
                    main: white,
                },
                text: {
                    // The most important text.
                    primary: "rgba(255, 255, 255, 0.87)",
                    // Secondary text.
                    secondary: "rgba(255, 255, 255, 0.7)",
                    accent: "#ae52ae",
                    // Disabled text have even lower visual prominence.
                    disabled: "rgba(255, 255, 255, 0.5)",
                },
                action: {
                    active: " rgba(0, 0, 0, 0.54)",
                    hoverTest: "#A51C30",
                    hoverOpacity: 0.2,
                    hover: "rgba(88, 86, 86, 0.5)",
                    selected: "rgba(88, 86, 86, 1)",
                    selectedOpacity: 0.08,
                    disabled: "rgba(0, 0, 0, 0.26)",
                    disabledBackground: "rgba(0, 0, 0, 0.12)",
                    disabledOpacity: 0.38,
                    focus: "rgba(0, 0, 0, 0.12)",
                    focusOpacity: 0.12,
                    activatedOpacity: 0.12,
                    cursor: "not-allowed",
                    stripedColor: "#ddd",
                },
            },
        },
    },

    shadows: {
        0: "none",
        1: "0px 5px 10px rgba(0, 0, 0, 0.12)",
        2: "0px 8px 30px rgba(0, 0, 0, 0.24)",
        3: "rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px",
    },

    typography: {
        fontFamily:
            "Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Ubuntu, 'Helvetica Neue', sans-serif",
    },

    shape: {
        borderRadius: spacing["xxsmall"],
    },
};

type ThemeMode = "light" | "dark";
interface ThemeContextType {
    themeMode: ThemeMode;
    setThemeMode: (mode: ThemeMode) => void;
    toggleThemeMode: () => void;
}
const ThemeContext = React.createContext<ThemeContextType>({
    themeMode: "light",
    // eslint-disable-next-line @typescript-eslint/no-empty-function
    setThemeMode: (_mode: "light" | "dark") => {},
    toggleThemeMode: () => {},
});
const ThemeProvider: React.FC<{ theme?: Theme }> = ({ children, theme }) => {
    /**
     * For Deafult Theme Please Use This themeName => defaultTheme
     * For Sobeys Theme Please Use This themeName => sobeysTheme
     * For Thebeestore Theme Please Use This themeName => thebeestoreTheme
     **/
    const selectedTheme = theme || sobeysTheme;
    const [themeMode, setThemeMode] = useLocalStorage<"light" | "dark">(
        "themeMode",
        selectedTheme.mode,
    );
    const selectedPalette = {
        ...selectedTheme.palette.mode[themeMode],
        common: selectedTheme.palette.common,
    };
    const selectedLightTheme = {
        ...selectedTheme,
        palette: selectedPalette,
        mode: "light",
    };
    const selectedDarkTheme = {
        ...selectedTheme,
        palette: selectedPalette,
        mode: "dark",
    };

    const toggleThemeMode = React.useCallback(() => {
        setThemeMode(themeMode === "light" ? "dark" : "light");
    }, [themeMode]);
    return (
        <ThemeContext.Provider
            value={{ themeMode, setThemeMode, toggleThemeMode }}
        >
            {" "}
            {/* <CacheProvider value={cache}> */}
            <EmotionThemeProver
                theme={
                    themeMode === "light"
                        ? selectedLightTheme
                        : selectedDarkTheme
                }
            >
                <Global
                    styles={css`
                        body {
                            background-color: ${themeMode === "light"
                                ? selectedTheme.palette.common.white
                                : selectedTheme.palette.common.test};
                            .testing {
                                background-color: red;
                                padding: 20px;
                            }
                        }
                    `}
                />
                {children}
            </EmotionThemeProver>
            {/* </CacheProvider> */}
        </ThemeContext.Provider>
    );
};
export const useThemeMode = (): ThemeContextType =>
    React.useContext(ThemeContext);

export default ThemeProvider;
