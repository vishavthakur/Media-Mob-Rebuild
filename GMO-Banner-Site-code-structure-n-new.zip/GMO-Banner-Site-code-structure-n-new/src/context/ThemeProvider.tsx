import React from "react";
import {
    Global,
    css,
    ThemeProvider as EmotionThemeProver,
    Theme as EmotionThemeType,
} from "@emotion/react";

import { useLocalStorage } from "@util/hooks/useLocalStorage";
export interface Theme extends EmotionThemeType {
    [key: string]: any;
}
import createCache from "@emotion/cache";
import { spacing, fontSizes } from "@util/units";
import { CacheProvider } from "@emotion/react";
const cache = createCache({
    key: "css",
    prepend: true,
});

const transparent = "transparent";
const white = "#fff";
const black = "#121212";

/** Default Theme **/
export const defaultTheme: Theme = {
    mode: "light",
    palette: {
        common: {
            black,
            white,
            transparent,
        },

        mode: {
            light: {
                primary: {
                    main: "#000000",
                    hover: "#000000",
                    contrastText: white,
                },
                secondary: {
                    main: "#9c42ff",
                    hover: "#9c42ff",
                    contrastText: white,
                },
                accent: {
                    main: "#404040",
                    hover: "#404040",
                    contrastText: white,
                },
                error: {
                    main: "#dc3545",
                    hover: "#752a31",
                    contrastText: white,
                },

                paper: {
                    background: "#f1f1f1",
                    border: "1px solid #dddddd",
                    shadow: "box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px",
                    hover: "rgba(0, 0, 0, 0.04)",
                    text: "#404040",
                },

                typography: {
                    primary: "rgba(0, 0, 0, 0.87)", //heading color
                    secondary: "rgba(0, 0, 0, 0.6)", // subheading color
                    disabled: "rgba(0, 0, 0, 0.38)", // disable color
                    success: "#2e7d32",
                    warning: "#ffc107",
                    danger: "#dc3f45",
                    info: "#0dcaf0",
                },
                action: {
                    active: " rgba(0, 0, 0, 0.54)",
                    activatedOpacity: 0.12,
                    hover: " rgba(0, 0, 0, 0.04)",
                    hoverOpacity: 0.2,
                    inActive: "#5e5c5c",
                    selected: "rgba(0, 0, 0, 0.08)",
                    selectedOpacity: 0.08,
                    disabled: "rgba(0, 0, 0, 0.26)",
                    disabledBackground: "rgba(0, 0, 0, 0.12)",
                    disabledOpacity: 0.38,
                    focus: "rgba(0, 0, 0, 0.12)",
                    focusOpacity: 0.12,
                    cursor: "not-allowed",
                },
            },
            dark: {
                primary: {
                    main: "#1d78f3",
                    hover: "#175ec3",
                    contrastText: white,
                },

                secondary: {
                    main: "#28a745",
                    hover: "#155324",
                    contrastText: white,
                },
                accent: {
                    main: "#800080",
                    hover: "#3f193f",
                    contrastText: white,
                },
                paper: {
                    background: "#212121",
                    border: "1px solid #212121",
                    shadow: "box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px",
                    hover: "rgba(0, 0, 0, 0.04)",
                    text: "#fff",
                },
                error: {
                    main: "#dc3545",
                    hover: "#752a31",
                    contrastText: white,
                },
                typography: {
                    primary: "#fff", //heading color
                    secondary: "rgba(255, 255, 255, 0.7)", //subheading color
                    disabled: "rgba(255, 255, 255, 0.5)", //disable color
                    success: "#2e7d32",
                    warning: "#ffc107",
                    danger: "#dc3f45",
                    info: "#0dcaf0",
                },
                action: {
                    inActive: "#5e5c5c",
                    active: " #fff",
                    hoverOpacity: 0.2,
                    hover: "rgba(255, 255, 255, 0.08)",
                    selected: "rgba(255, 255, 255, 0.16)",
                    selectedOpacity: 0.08,
                    disabled: "rgba(255, 255, 255, 0.5)",
                    disabledBackground: "rgba(0, 0, 0, 0.12)",
                    disabledOpacity: 0.38,
                    focus: "rgba(255, 255, 255, 0.16)",
                    focusOpacity: 0.12,
                    activatedOpacity: 0.12,
                    cursor: "not-allowed",
                },
            },
        },
    },
    shadows: {
        0: "none",
        1: "0px 5px 10px rgba(0, 0, 0, 0.12)",
        2: "0px 8px 30px rgba(0, 0, 0, 0.24)",
        3: "rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px",
    },

    // typography: {
    //     fontFamily:
    //         "Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Ubuntu, 'Helvetica Neue', sans-serif",
    // },

    shape: {
        borderRadius: spacing["xxsmall"],
    },
};

type ThemeMode = "light" | "dark";
interface ThemeContextType {
    themeMode: ThemeMode;
    setThemeMode: (mode: ThemeMode) => void;
    toggleThemeMode: () => void;
}
const ThemeContext = React.createContext<ThemeContextType>({
    themeMode: "light",
    // eslint-disable-next-line @typescript-eslint/no-empty-function
    setThemeMode: (_mode: "light" | "dark") => {},
    toggleThemeMode: () => {},
});
const ThemeProvider: React.FC<{ theme?: Theme }> = ({ children, theme }) => {
    /**
     * For Deafult Theme Please Use This themeName => defaultTheme
     * For Sobeys Theme Please Use This themeName => sobeysTheme
     * For Thebeestore Theme Please Use This themeName => thebeestoreTheme
     **/
    const selectedTheme = theme || defaultTheme;
    const [themeMode, setThemeMode] = useLocalStorage<"light" | "dark">(
        "themeMode",
        selectedTheme.mode,
    );
    const selectedPalette = {
        ...selectedTheme.palette.mode[themeMode],
        common: selectedTheme.palette.common,
    };
    const selectedLightTheme = {
        ...selectedTheme,
        palette: selectedPalette,
        mode: "light",
    };
    const selectedDarkTheme = {
        ...selectedTheme,
        palette: selectedPalette,
        mode: "dark",
    };

    const toggleThemeMode = React.useCallback(() => {
        setThemeMode(themeMode === "light" ? "dark" : "light");
    }, [themeMode]);
    return (
        <ThemeContext.Provider
            value={{ themeMode, setThemeMode, toggleThemeMode }}
        >
            {" "}
            {/* <CacheProvider value={cache}> */}
            <EmotionThemeProver
                theme={
                    themeMode === "light"
                        ? selectedLightTheme
                        : selectedDarkTheme
                }
            >
                <Global
                    styles={css`
                        body {
                            background-color: ${themeMode === "light"
                                ? selectedTheme.palette.common.white
                                : selectedTheme.palette.common.black};
                            .testing {
                                background-color: red;
                                padding: 20px;
                            }
                        }
                    `}
                />
                {children}
            </EmotionThemeProver>
            {/* </CacheProvider> */}
        </ThemeContext.Provider>
    );
};
export const useThemeMode = (): ThemeContextType =>
    React.useContext(ThemeContext);

export default ThemeProvider;
