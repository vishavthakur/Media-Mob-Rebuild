const withPlugins = require("next-compose-plugins");
const withImages = require("next-images");
const path = require("path");

const withBundleAnalyzer = require("@next/bundle-analyzer")({
    enabled: process.env.ANALYZE === "true",
});

const nextConfig = {
    future: {
        webpack5: true,
    },
    async rewrites() {
        return [
            {
                source: '/uploads/:slug*',
                destination: `${process.env.NEXT_PUBLIC_WORDPRESS_SITE_URL}/wp-content/uploads/:slug*`
            },
            {
                source: '/api/svgurl/:slug*',
                destination: `${process.env.NEXT_PUBLIC_WORDPRESS_SITE_URL}/wp-content/:slug*`

            }
        ]
    },
    images: {
        domains: process.env.NEXT_PUBLIC_ALL_IMAGES?.split(","),
        deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
        imageSizes: [16, 32, 48, 64, 96, 128, 256, 384, 750, 850],
    },
    devIndicators: {
        autoPrerender: true,
    },
    type: "module",
    sassOptions: {
        includePaths: [path.join(__dirname, "styles")],
    },
    i18n: {
        locales: process.env.NEXT_PUBLIC_LANGUAGES?.split(","),
        defaultLocale: process.env.NEXT_PUBLIC_DEFAULT_LANGUAGE,
        localeDetection: false
    },
    webpack(config) {
        config.module.rules.push({
            test: /\.svg$/,
            use: ["@svgr/webpack"],
        });
        return config;
    },
    reactStrictMode: true,
};
module.exports = withPlugins([[withImages], [withBundleAnalyzer]], nextConfig);

