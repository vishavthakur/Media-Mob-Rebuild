declare module "*.svg" {
     const content: any;
     export default content;
 }
 
 declare module "*.jpeg";
 
 declare module "*.webp";
 
 declare module "*.png";
 
 // declare module "lodash";
 
 declare module "react-slick";
 declare module "react-barcode";
 // declare module "@emotion/styled";
 